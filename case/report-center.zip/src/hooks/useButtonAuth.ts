import { useAuthStore } from '@/stores/modules/auth';

/**
 * @description 设置按钮的权限
 */
type Options = {
  read?: string;
  write?: string;
  deletes?: string;
  exports?: string;
  initFn?: (...args: any[]) => void;
};

export const useButtonAuth = ({ read = '', write = '', deletes = '', exports = '', initFn }: Options) => {
  const authStore: ReturnType<typeof useAuthStore> = useAuthStore();

  const isDisabledRead: Ref<boolean> = ref(false);
  const isDisabledWrite: Ref<boolean> = ref(false);
  const isDisabledDel: Ref<boolean> = ref(false);
  const isDisabledExport: Ref<boolean> = ref(false);

  isDisabledRead.value = !authStore.permissionListGet.includes(read);
  isDisabledWrite.value = !authStore.permissionListGet.includes(write);
  isDisabledDel.value = !authStore.permissionListGet.includes(deletes);
  isDisabledExport.value = !authStore.permissionListGet.includes(exports);

  onMounted(() => {
    !isDisabledRead.value && initFn && initFn();
  });

  return {
    isDisabledRead,
    isDisabledDel,
    isDisabledExport,
    isDisabledWrite
  };
};
