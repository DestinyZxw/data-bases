import { ResultData, ReqParams } from '@/api/interface';
import { useDownload } from '@/hooks/useDownload';
import { ElMessageBox } from 'element-plus';

export type PortType<T = any> = (params: ReqParams) => Promise<ResultData<T[]>>;
export type ExportPortType = (params: ReqParams) => Promise<BlobPart>;

export type PaginationType = {
  page: number;
  pageSize: number;
  pageSizes: number[];
  itemCount: number;
  onChange: (page: number) => void;
  onPageSizeChange: (pageSize: number) => void;
};

export type UseTableType<T = any> = {
  tableData: Ref<T[]>;
  tableLoading: Ref<boolean>;
  updateTableStatus: Ref<boolean>;
  pagination: PaginationType;
  getTableData: () => Promise<void>;
  handleSearch: () => void;
  handleReset: () => void;
  handleExport: () => void;
};

export type UseTableParamType<T, U> = {
  port: PortType<T>;
  searchForm: Ref<U> | ComputedRef<U>;
  exportPort?: ExportPortType;
  exportExcelName?: string;
  needPagination?: boolean;
};

export const useTable = <T = any, U = any>({
  port,
  searchForm,
  exportPort,
  exportExcelName,
  needPagination = true
}: UseTableParamType<T, U>): UseTableType<T> => {
  const tableData: Ref<T[]> = ref([]);
  const tableLoading = ref<boolean>(false);
  const updateTableStatus: Ref<boolean> = ref(false); // 切换tab时是否更新
  const pagination: PaginationType = reactive({
    page: 1,
    pageSize: 15,
    pageSizes: [15, 20, 30, 40, 50],
    itemCount: 0,
    onChange: (page: number) => {
      pagination.page = page;
      getTableData();
    },
    onPageSizeChange: (pageSize: number) => {
      pagination.page = 1;
      pagination.pageSize = pageSize;
      getTableData();
    }
  });

  // 获取 table数据
  async function getTableData() {
    tableLoading.value = true;
    try {
      let params = {
        ...searchForm.value,
        ...(needPagination ? { currentPage: pagination.page, pageIndex: pagination.page, pageSize: pagination.pageSize } : {})
      };

      let res = await port(params);
      if (res.success === '0') {
        tableData.value = res.val;
        needPagination && (pagination.itemCount = res?.pageInfo?.count ?? 0);
      }
    } catch (e) {
      console.log('e : ', e);
    } finally {
      tableLoading.value = false;
    }
  }

  // 搜索
  function handleSearch() {
    pagination.page = 1;
    updateTableStatus.value = false;
    getTableData();
  }

  // 重置
  function handleReset() {
    pagination.page = 1;
    pagination.pageSize = 15;
    updateTableStatus.value = false;
    getTableData();
  }

  // 导出table数据
  function handleExport() {
    if (!exportPort || !exportExcelName) return;
    try {
      let params = {
        ...searchForm.value,
        currentPage: pagination.page,
        pageIndex: pagination.page,
        pageSize: pagination.pageSize
      };

      ElMessageBox.confirm('确认导出用户数据?', '温馨提示')
        .then(() =>
          useDownload({
            port: exportPort,
            fileName: exportExcelName,
            params
          })
        )
        .catch(() => {});
    } catch (e) {
      console.log('e : ', e);
    }
  }

  return {
    tableData,
    tableLoading,
    pagination,
    updateTableStatus,
    getTableData,
    handleSearch,
    handleReset,
    handleExport
  };
};
