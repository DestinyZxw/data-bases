//  护理分析 模块
import { Menu } from '@/typings/global';

// const IFrame = () => import('@/components/rub-iframe/index.vue');

const routes: Menu.MenuOptions = {
  path: '/customerInventory',
  name: 'customerInventory',
  redirect: '/customerInventory/consultant',
  meta: {
    permissionCode: 'FOLDER_BRAND_DEPT_REPORT',
    icon: 'Grid',
    title: '品牌部报表',
    sort: 9,
    isHide: false,
    isFull: false,
    isAffix: false,
    isKeepAlive: true
  },
  children: [
    {
      path: '/customerInventory/consultant',
      name: 'customerInventoryConsultant',
      component: '/customerInventory/consultant/index',
      meta: {
        permissionCode: 'MENU_EMPLOYEE_MEMBER_TOOL',
        icon: 'Histogram',
        title: '顾问季度盘点表',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/customerInventory/nonagency',
      name: 'customerInventoryNonagency',
      component: '/customerInventory/nonagency/index',
      meta: {
        permissionCode: 'MENU_SHOP_MEMBER_TOOL',
        icon: 'Histogram',
        title: '门店无人管理有效客户盘点表',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    }
    /*,
    {
      path: '/customerInventory/newCustomerTransformation',
      name: 'customerInventoryTransformation',
      component: IFrame,
      meta: {
        permissionCode: 'MENU_SHOP_MEMBER_TOOL',
        icon: 'Histogram',
        title: '新客推广转化',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true,
        frameSrc:
          'https://bi.aliyuncs.com/token3rd/dashboard/view/pc.htm?pageId=fda170f3-5fe4-4510-963e-dc97a7665817&accessToken=20a4a6746082c3ca42ba9d97054a57e6&dd_orientation=auto'
      }
    },
    {
      path: '/customerInventory/salesDashboard',
      name: 'customerInventorySalesDashboard',
      component: IFrame,
      meta: {
        permissionCode: 'MENU_SHOP_MEMBER_TOOL',
        icon: 'Histogram',
        title: '产品销售看板',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true,
        frameSrc:
          'https://bi.aliyuncs.com/token3rd/dashboard/view/pc.htm?pageId=4950a2aa-e1a8-4ff4-a55b-97dd6414cf57&accessToken=1cd92d1c0e39c0a1bdf8d1e03859e99b&dd_orientation=auto'
      }
    },
    {
      path: '/customerInventory/activitiesDashboard',
      name: 'customerInventoryActivitiesDashboard',
      component: IFrame,
      meta: {
        permissionCode: 'MENU_SHOP_MEMBER_TOOL',
        icon: 'Histogram',
        title: '活动数据看板',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true,
        frameSrc:
          'https://bi.aliyuncs.com/token3rd/dashboard/view/pc.htm?pageId=5b8f3866-a886-4456-bd2b-b85bd47c9660&accessToken=81fc0edf2f5191e12f72a89f5a9c46b0&dd_orientation=auto'
      }
    },
    {
      path: '/customerInventory/monitoring',
      name: 'customerInventoryMonitoring',
      component: IFrame,
      meta: {
        permissionCode: 'MENU_SHOP_MEMBER_TOOL',
        icon: 'Histogram',
        title: '业绩指标监控',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true,
        frameSrc:
          'https://bi.aliyuncs.com/token3rd/dashboard/view/pc.htm?pageId=e705e9d9-336c-4f23-b057-d882a55db119&accessToken=3afe342fa3b6b325da3c287bb72f1b86&dd_orientation=auto'
      }
    }*/
  ]
};

export default routes;
