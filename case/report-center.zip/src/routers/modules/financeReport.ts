//  护理分析 模块
import { Menu } from '@/typings/global';

// const IFrame = () => import('@/components/rub-iframe/index.vue');

const routes: Menu.MenuOptions = {
  path: '/financeReport',
  name: 'financeReport',
  redirect: '/customerInventory/consultant',
  meta: {
    permissionCode: 'FOLDER_FINANCE_REPORT',
    icon: 'Grid',
    title: '财务部报表',
    sort: 10,
    isHide: false,
    isFull: false,
    isAffix: false,
    isKeepAlive: true
  },
  children: [
    {
      path: '/financeReport/shengMeiIncome',
      name: 'financeReportShengMeiIncome',
      component: '/financeReport/shengMeiIncome/index',
      meta: {
        permissionCode: 'MENU_ZY_SHOP_PAYMENT_SUMMARY',
        icon: 'Histogram',
        title: '生美收款分类汇总表',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/financeReport/shengMeiProxyKeMei',
      name: 'financeReportShengMeiProxyKeMei',
      component: '/financeReport/shengMeiProxyKeMei/index',
      meta: {
        permissionCode: 'MENU_ZY_PAYMENT_SUMMARY',
        icon: 'Histogram',
        title: '生美代收医美收款方式表',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/financeReport/keMeiIncome',
      name: 'financeReportKeMeiIncome',
      component: '/financeReport/keMeiIncome/index',
      meta: {
        permissionCode: 'MENU_KM_SHOP_PAYMENT_SUMMARY',
        icon: 'Histogram',
        title: '医美收款分类汇总表',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/financeReport/keMeiProxyShengMei',
      name: 'financeReportKeMeiProxyShengMei',
      component: '/financeReport/keMeiProxyShengMei/index',
      meta: {
        permissionCode: 'MENU_KM_PAYMENT_SUMMARY',
        icon: 'Histogram',
        title: '医美代收生美收款方式表',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    }
  ]
};

export default routes;
