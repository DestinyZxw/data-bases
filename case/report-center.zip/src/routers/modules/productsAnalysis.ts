//  产品分析 模块
import { Menu } from '@/typings/global';

const routes: Menu.MenuOptions = {
  path: '/productAnalysis',
  name: 'productAnalysis',
  redirect: '/productAnalysis/productSkuAnalysis',
  meta: {
    permissionCode: 'FOLDER_PRODUCT_ANALYSE',
    icon: 'Grid',
    title: '产品分析',
    sort: 7,
    isLink: '',
    isHide: false,
    isFull: false,
    isAffix: false,
    isKeepAlive: true
  },
  children: [
    {
      path: '/productAnalysis/productSkuAnalysis',
      name: 'productSkuAnalysis',
      component: '/productAnalysis/productSkuAnalysis/index',
      meta: {
        permissionCode: 'MENU_PRODUCT_SKU_DISTRIBUTE',
        icon: 'Histogram',
        title: '产品SKU分布',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/productAnalysis/priceRangeAnalysis',
      name: 'productPriceRangeAnalysis',
      component: '/productAnalysis/priceRangeAnalysis/index',
      meta: {
        permissionCode: 'MENU_PRODUCT_PRICE',
        icon: 'Histogram',
        title: '产品价格带',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/productAnalysis/salesCategoryStructureAnalysis',
      name: 'productSalesCategoryStructureAnalysis',
      component: '/productAnalysis/salesCategoryStructureAnalysis/index',
      meta: {
        permissionCode: 'MENU_PRODUCT_TYPE_STRUCT',
        icon: 'Histogram',
        title: '产品销售大类结构',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/productAnalysis/marketDecisionAnalysis',
      name: 'productMarketDecisionAnalysis',
      component: '/productAnalysis/marketDecisionAnalysis/index',
      meta: {
        permissionCode: 'MENU_PRODUCT_SALE_DECISION',
        icon: 'Histogram',
        title: '产品上下市决策',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/productAnalysis/productSalesRankingAnalysis',
      name: 'productSalesRankingAnalysis',
      component: '/productAnalysis/productSalesRankingAnalysis/index',
      meta: {
        permissionCode: 'MENU_PRODUCT_RANKING_LIST',
        icon: 'Histogram',
        title: '产品销售排行榜',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    } /*,
    {
      path: '/productAnalysis/productsMarketingChannelsAnalysis',
      name: 'productsMarketingChannelsAnalysis',
      component: '/productAnalysis/productsMarketingChannelsAnalysis/index',
      meta: {
        permissionCode: 'MENU_MEMBER_CONSUMER_HABITS',
        icon: 'Histogram',
        title: '产品消费渠道',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    }*/
  ]
};

export default routes;
