//  护理分析 模块
import { Menu } from '@/typings/global';

// const IFrame = () => import('@/components/rub-iframe/index.vue');

const routes: Menu.MenuOptions = {
  path: '/BiReport',
  name: 'BiReport',
  redirect: '/customerInventory/consultant',
  meta: {
    permissionCode: 'FOLDER_BI_REPORT',
    icon: 'Grid',
    title: 'BI报表',
    sort: 11,
    isHide: false,
    isFull: false,
    isAffix: false,
    isKeepAlive: true
  },
  children: [
    {
      path: '/BiReport/brandDepartment',
      name: 'BiReportBrandDepartment',
      component: '/BiReport/brandDepartment/index',
      meta: {
        permissionCode: 'MENU_BRAND_BI_REPORT',
        icon: 'Histogram',
        title: '品牌部',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/BiReport/brandDepartmentShop',
      name: 'BiReportBrandDepartmentShop',
      component: '/BiReport/brandDepartment-shop/index',
      meta: {
        permissionCode: 'MENU_BRAND_SHOP_BI_REPORT',
        icon: 'Histogram',
        title: '品牌部-门店',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/BiReport/extensionDepartment',
      name: 'BiReportExtensionDepartment',
      component: '/BiReport/extensionDepartment/index',
      meta: {
        permissionCode: 'MENU_PROMOTION_BI_REPORT',
        icon: 'Histogram',
        title: '推广部',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/BiReport/CrmDepartment',
      name: 'BiReportCrmDepartment',
      component: '/BiReport/CrmDepartment/index',
      meta: {
        permissionCode: 'MENU_CRM_BI_REPORT',
        icon: 'Histogram',
        title: 'CRM部',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    }
  ]
};

export default routes;
