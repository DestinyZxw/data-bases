// 业绩管理 模块
import { Menu } from '@/typings/global';

const routes: Menu.MenuOptions = {
  path: '/performance',
  name: 'performance',
  redirect: '/performance/sheet',
  meta: {
    permissionCode: 'FOLDER_OPERATING_PERFORMANCE',
    icon: 'Grid',
    title: '经营业绩',
    sort: 4,
    isLink: '',
    isHide: false,
    isFull: false,
    isAffix: false,
    isKeepAlive: true
  },
  children: [
    {
      path: '/performance/sheet',
      name: 'performanceSheet',
      component: '/performance/sheet/index',
      meta: {
        permissionCode: 'MENU_PERFORMANCE_MANAGEMENT',
        icon: 'Histogram',
        title: '业绩管理',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/performance/cash',
      name: 'performanceCash',
      component: '/performance/cash/index',
      meta: {
        permissionCode: 'MENU_CASH_COMPOSITION',
        icon: 'Histogram',
        title: '现金构成',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/performance/billing',
      name: 'performanceBilling',
      component: '/performance/billing/index',
      meta: {
        permissionCode: 'MENU_BILLING_PERFORMANCE',
        icon: 'Histogram',
        title: '开单业绩',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/performance/product',
      name: 'performanceProduct',
      component: '/performance/product/index',
      meta: {
        permissionCode: 'MENU_PRODUCT_PERFORMANCE',
        icon: 'Histogram',
        title: '产品业绩',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/performance/counselorMedicalBeautyCashTable',
      name: 'counselorMedicalBeautyCash',
      component: '/performance/counselorMedicalBeautyCashTable/index',
      meta: {
        permissionCode: 'COUNSELOR_MEDICAL_BEAUTY_CASH',
        icon: 'Histogram',
        title: '顾问医美现金业绩',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/performance/counselorMedicalBeautyExecuteTable',
      name: 'counselorMedicalBeautyExecute',
      component: '/performance/counselorMedicalBeautyExecuteTable/index',
      meta: {
        permissionCode: 'COUNSELOR_MEDICAL_BEAUTY_EXECUTE',
        icon: 'Histogram',
        title: '顾问医美执行业绩',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    }
  ]
};

export default routes;
