// 美容师专属 模块
import { Menu } from '@/typings/global';

const routes: Menu.MenuOptions = {
  path: '/beautician',
  name: 'beautician',
  redirect: '/beautician/regularGuestTable',
  meta: {
    permissionCode: 'FOLDER_BEAUTICIANS_EXCLUSIVE',
    icon: 'Avatar',
    title: '美容师专属',
    sort: 2,
    isLink: '',
    isHide: false,
    isFull: false,
    isAffix: false,
    isKeepAlive: true
  },
  children: [
    {
      path: '/beautician/regularGuestTable',
      name: 'regularGuestTable',
      component: '/beautician/regularGuestTable/index',
      meta: {
        permissionCode: 'MENU_FAMILIAR_CUSTOMER_DETAIL',
        icon: 'Notebook',
        title: '熟客明细表',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/beautician/regularGuestPerformanceTable',
      name: 'regularGuestPerformanceTable',
      component: '/beautician/regularGuestPerformanceTable/index',
      meta: {
        permissionCode: 'MENU_FAMILIAR_CUSTOMER_ACHIEVEMENT',
        icon: 'Notebook',
        title: '熟客业绩明细表',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/beautician/exclusiveManageTable',
      name: 'exclusiveManageTable',
      component: '/beautician/exclusiveManageTable/index',
      meta: {
        permissionCode: 'MENU_EXCLUSIVE_MANAGEMENT',
        icon: 'Notebook',
        title: '专属管理人数统计表',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/beautician/exclusivePerformanceTable',
      name: 'exclusivePerformanceTable',
      component: '/beautician/exclusivePerformanceTable/index',
      meta: {
        permissionCode: 'MENU_EXCLUSIVE_ACHIEVEMENT',
        icon: 'Notebook',
        title: '专属业绩明细表',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/beautician/juniorBeauticianTable',
      name: 'juniorBeauticianTable',
      component: '/beautician/juniorBeauticianTable/index',
      meta: {
        permissionCode: 'MENU_JUNIOR_BEAUTICIAN_TRAINEES',
        icon: 'Notebook',
        title: '初级美容师学员',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/beautician/beauticianMedicalBeautyCashPerformanceTable',
      name: 'beauticianMedicalBeautyCashPerformance',
      component: '/beautician/beauticianMedicalBeautyCashPerformanceTable/index',
      meta: {
        permissionCode: 'BEAUTICIAN_MEDICAL_BEAUTY_CASH_PERFORMANCE',
        icon: 'Notebook',
        title: '美容师医美现金业绩明细',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    }
  ]
};

export default routes;
