// 护理项目 模块 <el-icon><TrendCharts /></el-icon>
import { Menu } from '@/typings/global';

const routes: Menu.MenuOptions = {
  path: '/nurseProject',
  name: 'nurse',
  redirect: '/nurseProject/nurseTable',
  meta: {
    permissionCode: 'FOLDER_NURSING_PROJECT',
    icon: 'Grid',
    title: '护理项目',
    sort: 3,
    isLink: '',
    isHide: false,
    isFull: false,
    isAffix: false,
    isKeepAlive: true
  },
  children: [
    {
      path: '/nurseProject/nurseTable',
      name: 'nurseTable',
      component: '/nurseProject/nurseTable/index',
      meta: {
        permissionCode: 'MENU_NURSING_LIFE_CYCLE',
        icon: 'Histogram',
        title: '生命周期分析表',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      },
      children: [
        {
          path: '/nurseProject/nurseDetail/:tabTitle?/:nursingServiceCode?/:startDate?/:endDate?',
          name: 'nurseDetail',
          component: '/nurseProject/nurseDetail/index',
          meta: {
            permissionCode: 'MENU_NURSING_LIFE_CYCLE',
            icon: 'TrendCharts',
            title: '护理详情',
            activeMenu: '/nurseProject/nurseTable',
            isLink: '',
            isHide: true,
            isFull: false,
            isAffix: false,
            isKeepAlive: true
          }
        }
      ]
    },
    {
      path: '/nurseProject/profitAnalysisTable',
      name: 'profitAnalysisTable',
      component: '/nurseProject/profitAnalysisTable/index',
      meta: {
        permissionCode: 'MENU_PROFIT_ANALYSIS',
        icon: 'Histogram',
        title: '利润分析表',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    }
  ]
};

export default routes;
