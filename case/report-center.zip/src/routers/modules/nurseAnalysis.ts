//  护理分析 模块
import { Menu } from '@/typings/global';

const routes: Menu.MenuOptions = {
  path: '/nurseAnalysis',
  name: 'nurseAnalysis',
  redirect: '/nurseAnalysis/nurseMarketTimeAnalysis',
  meta: {
    permissionCode: 'FOLDER_TREATMENT_ANALYSE',
    icon: 'Grid',
    title: '护理分析',
    sort: 8,
    isLink: '',
    isHide: false,
    isFull: false,
    isAffix: false,
    isKeepAlive: true
  },
  children: [
    {
      path: '/nurseAnalysis/nurseMarketTimeAnalysis',
      name: 'nurseMarketTimeAnalysis',
      component: '/nurseAnalysis/nurseMarketTimeAnalysis/index',
      meta: {
        permissionCode: 'MENU_TREATMENT_SALE_DATE',
        icon: 'Histogram',
        title: '护理上市时间',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/nurseAnalysis/nurseSkuAnalysis',
      name: 'nurseSkuAnalysis',
      component: '/nurseAnalysis/nurseSkuAnalysis/index',
      meta: {
        permissionCode: 'MENU_TREATMENT_SKU_DISTRIBUTE',
        icon: 'Histogram',
        title: '护理SKU分布',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/nurseAnalysis/priceRangeAnalysis',
      name: 'nursePriceRangeAnalysis',
      component: '/nurseAnalysis/priceRangeAnalysis/index',
      meta: {
        permissionCode: 'MENU_TREATMENT_PRICE',
        icon: 'Histogram',
        title: '护理价格带',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/nurseAnalysis/salesCategoryStructureAnalysis',
      name: 'nurseSalesCategoryStructureAnalysis',
      component: '/nurseAnalysis/salesCategoryStructureAnalysis/index',
      meta: {
        permissionCode: 'MENU_TREATMENT_TYPE_STRUCT',
        icon: 'Histogram',
        title: '护理销售大类结构',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/nurseAnalysis/nurseSalesAnalysis',
      name: 'nurseSalesAnalysis',
      component: '/nurseAnalysis/nurseSalesAnalysis/index',
      meta: {
        permissionCode: 'MENU_TREATMENT_SALE_DETAIL',
        icon: 'Histogram',
        title: '护理销售明细表',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/nurseAnalysis/marketDecisionAnalysis',
      name: 'nurseMarketDecisionAnalysis',
      component: '/nurseAnalysis/marketDecisionAnalysis/index',
      meta: {
        permissionCode: 'MENU_TREATMENT_SALE_DECISION',
        icon: 'Histogram',
        title: '护理上下市决策',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    }
  ]
};

export default routes;
