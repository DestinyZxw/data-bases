// 美容师专属 模块
import { Menu } from '@/typings/global';
// const IFrame = () => import('@/components/rub-iframe/index.vue');

const routes: Menu.MenuOptions = {
  path: '/setting',
  name: 'setting',
  redirect: '/setting/user',
  meta: {
    permissionCode: 'FOLDER_SYSTEM_SETTINGS',
    icon: 'Setting',
    title: '设置',
    sort: 99,
    isLink: '',
    isHide: false,
    isFull: false,
    isAffix: false,
    isKeepAlive: true
  },
  children: [
    {
      path: '/setting/user',
      name: 'userManagement',
      component: '/setting/user/index',
      meta: {
        permissionCode: 'MENU_USER_MANAGEMENT',
        icon: 'Menu',
        title: '用户管理',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/setting/role',
      name: 'roleManagement',
      component: '/setting/role/index',
      meta: {
        permissionCode: 'MENU_ROLE_MANAGEMENT',
        icon: 'Menu',
        title: '角色管理',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/setting/BiReportManagement',
      name: 'BiReportManagement',
      component: '/setting/BiReport/index',
      meta: {
        permissionCode: 'MENU_BI_REPORT_CONFIG',
        icon: 'Menu',
        title: 'BI报表管理',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/setting/accessRecord',
      name: 'userAccessRecord',
      component: '/setting/accessRecord/index',
      meta: {
        permissionCode: 'MENU_USER_ACCESS_RECORD',
        icon: 'Menu',
        title: '访问记录',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    } /*,
    {
      path: '/setting/BiBoardDetail/:url/:name',
      name: 'BiBoardDetail',
      component: IFrame,
      meta: {
        permissionCode: 'MENU_SHOP_MEMBER_TOOL',
        icon: 'Histogram',
        title: '',
        isHide: true,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    }*/
  ]
};

export default routes;
