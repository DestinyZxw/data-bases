//  门店管理 模块
import { Menu } from '@/typings/global';

const routes: Menu.MenuOptions = {
  path: '/shop',
  name: 'shop',
  redirect: '/shop/customer',
  meta: {
    permissionCode: 'FOLDER_SHOP_PERFORMANCE',
    icon: 'Grid',
    title: '门店管理',
    sort: 5,
    isLink: '',
    isHide: false,
    isFull: false,
    isAffix: false,
    isKeepAlive: true
  },
  children: [
    {
      path: '/shop/customer',
      name: 'shopCustomer',
      component: '/shop/customer/index',
      meta: {
        permissionCode: 'MENU_MEMBER_SUMMARY',
        icon: 'Histogram',
        title: '顾客分析',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/shop/efficiency',
      name: 'shopEfficiency',
      component: '/shop/efficiency/index',
      meta: {
        permissionCode: 'MENU_EFFICIENCY_ANALYSE',
        icon: 'Histogram',
        title: '效能分析',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/shop/product',
      name: 'shopProduct',
      component: '/shop/product/index',
      meta: {
        permissionCode: 'MENU_PRODUCT_SALE',
        icon: 'Histogram',
        title: '产品销售',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/shop/nurse',
      name: 'shopNurse',
      component: '/shop/nurse/index',
      meta: {
        permissionCode: 'MENU_NURSING_SALE',
        icon: 'Histogram',
        title: '护理销售',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/shop/shengMei',
      name: 'shopShengMei',
      component: '/shop/shengMei/index',
      meta: {
        permissionCode: 'MENU_ZY_SALES_DETAIL',
        icon: 'Histogram',
        title: '生美销售双美卡明细表',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/shop/keMei',
      name: 'shopKeMei',
      component: '/shop/keMei/index',
      meta: {
        permissionCode: 'MENU_KM_SALES_DETAIL',
        icon: 'Histogram',
        title: '医美销售双美卡明细表',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/shop/experience',
      name: 'shopExperience',
      component: '/shop/experience/index',
      meta: {
        permissionCode: 'MENU_TRIAL_MEMBER_MANAGE',
        icon: 'Histogram',
        title: '员工体验顾客管理',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/shop/newMember',
      name: 'shopNewMember',
      component: '/shop/newMember/index',
      meta: {
        permissionCode: 'MENU_NEW_MEMBER_MANAGE',
        icon: 'Histogram',
        title: '员工新会员管理',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/shop/oldMember',
      name: 'shopOldMember',
      component: '/shop/oldMember/index',
      meta: {
        permissionCode: 'MENU_OLD_MEMBER_MANAGE',
        icon: 'Histogram',
        title: '员工老会员管理',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/shop/exclusiveMember',
      name: 'shopExclusiveMember',
      component: '/shop/exclusiveMember/index',
      meta: {
        permissionCode: 'MENU_EXCLUSIVE_CONSULTANT_MEMBER_MANAGE',
        icon: 'Histogram',
        title: '顾问专属会员管理',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/shop/starEmployee',
      name: 'shopStarEmployee',
      component: '/shop/starEmployee/index',
      meta: {
        permissionCode: 'MENU_EMPLOYEE_STAR',
        // permissionCode: '',
        icon: 'Histogram',
        title: '明星员工榜',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/shop/consultant',
      name: 'shopConsultant',
      component: '/shop/consultant/index',
      meta: {
        permissionCode: 'MENU_CONSULTANT_EFFICIENCY_MANAGE',
        icon: 'Histogram',
        title: '顾问个人效能',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/shop/beautician',
      name: 'shopBeautician',
      component: '/shop/beautician/index',
      meta: {
        permissionCode: 'MENU_BEAUTICIAN_EFFICIENCY_MANAGE',
        icon: 'Histogram',
        title: '美容师个人效能',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    /*{
      path: '/shop/kpi',
      name: 'shopKpi',
      component: '/shop/kpi/index',
      meta: {
        icon: 'Histogram',
        title: 'KPI汇总表',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },*/
    {
      path: '/shop/salesSheet',
      name: 'shopSalesSheet',
      component: '/shop/salesSheet/index',
      meta: {
        permissionCode: 'MENU_SALES_DETAIL',
        icon: 'Histogram',
        title: '销售明细表',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    }
  ]
};

export default routes;
