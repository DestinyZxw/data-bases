//  会员分析 模块
import { Menu } from '@/typings/global';

const routes: Menu.MenuOptions = {
  path: '/memberAnalysis',
  name: 'memberAnalysis',
  redirect: '/memberAnalysis/memberActualityAnalysis',
  meta: {
    permissionCode: 'FOLDER_MEMBER_ANALYSE',
    icon: 'Grid',
    title: '会员分析',
    sort: 6,
    isLink: '',
    isHide: false,
    isFull: false,
    isAffix: false,
    isKeepAlive: true
  },
  children: [
    {
      path: '/memberAnalysis/memberActualityAnalysis',
      name: 'memberActualityAnalysis',
      component: '/memberAnalysis/memberActualityAnalysis/index',
      meta: {
        permissionCode: 'MENU_MEMBER_STATUS_ANALYSE',
        icon: 'Histogram',
        title: '会员现状分析',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/memberAnalysis/RFMAnalysis',
      name: 'RFMAnalysis',
      component: '/memberAnalysis/RFMAnalysis/index',
      meta: {
        permissionCode: 'MENU_MEMBER_RFM_ANALYSE',
        icon: 'Histogram',
        title: 'RFM分析',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/memberAnalysis/experienceCustomerAnalysis',
      name: 'experienceCustomerAnalysis',
      component: '/memberAnalysis/experienceCustomerAnalysis/index',
      meta: {
        permissionCode: 'MENU_EXPERIENCE_MEMBER_ANALYSE',
        icon: 'Histogram',
        title: '体验顾客分析',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/memberAnalysis/newMemberAnalysis',
      name: 'newMemberAnalysis',
      component: '/memberAnalysis/newMemberAnalysis/index',
      meta: {
        permissionCode: 'MENU_NEW_MEMBER_ANALYSE',
        icon: 'Histogram',
        title: '新会员分析',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/memberAnalysis/oldMemberAnalysis',
      name: 'oldMemberAnalysis',
      component: '/memberAnalysis/oldMemberAnalysis/index',
      meta: {
        permissionCode: 'MENU_OLD_MEMBER_ANALYSE',
        icon: 'Histogram',
        title: '老会员分析',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/memberAnalysis/memberHabitAnalysis',
      name: 'memberHabitAnalysis',
      component: '/memberAnalysis/memberHabitAnalysis/index',
      meta: {
        permissionCode: 'MENU_MEMBER_CONSUMER_HABITS',
        icon: 'Histogram',
        title: '会员消费习惯',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/memberAnalysis/memberPreferenceAnalysis',
      name: 'memberPreferenceAnalysis',
      component: '/memberAnalysis/memberPreferenceAnalysis/index',
      meta: {
        permissionCode: 'MENU_MEMBER_CONSUMER_PERFERENCES_MONITOR',
        icon: 'Histogram',
        title: '会员消费偏好监控',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/memberAnalysis/bigCustomerAnalysis',
      name: 'bigCustomerAnalysis',
      component: '/memberAnalysis/bigCustomerAnalysis/index',
      meta: {
        permissionCode: 'MENU_VIP_ANALYSE',
        icon: 'Histogram',
        title: '大客户分析',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/memberAnalysis/lostMemberAnalysis',
      name: 'lostMemberAnalysis',
      component: '/memberAnalysis/lostMemberAnalysis/index',
      meta: {
        permissionCode: 'MENU_MEMBER_LOST_ANALYSE',
        icon: 'Histogram',
        title: '流失会员分析',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    },
    {
      path: '/memberAnalysis/memberWarningAnalysis',
      name: 'memberWarningAnalysis',
      component: '/memberAnalysis/memberWarningAnalysis/index',
      meta: {
        permissionCode: 'MENU_MEMBER_ALERTS_ANALYSE',
        icon: 'Histogram',
        title: '会员预警分析',
        isLink: '',
        isHide: false,
        isFull: false,
        isAffix: false,
        isKeepAlive: true
      }
    }
  ]
};

export default routes;
