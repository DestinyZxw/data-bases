import { Menu } from '@/typings/global';

const routes: Menu.MenuOptions = {
  path: '/home/index',
  name: 'home',
  component: '/home/index',
  meta: {
    permissionCode: '',
    icon: 'HomeFilled', // 菜单和面包屑对应的图标
    title: '首页', // 路由标题 (用作 document.title || 菜单的名称)
    activeMenu: '', // 是否在菜单中隐藏, 需要高亮的 path (通常用作详情页高亮父级菜单)
    sort: 1, // 菜单排序
    isLink: '', // 路由外链时填写的访问地址
    isHide: false, // 是否在菜单中隐藏 (通常列表详情页需要隐藏)
    isFull: false, // 菜单是否全屏 (示例：数据大屏页面)
    isAffix: true, // 菜单是否固定在标签页中 (首页通常是固定项)
    isKeepAlive: true // 当前路由是否缓存
  }
};

export default routes;
