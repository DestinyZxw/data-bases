import { Menu } from '@/typings/global';

export type LayoutType = 'vertical' | 'classic' | 'transverse' | 'columns';

export type AssemblySizeType = 'large' | 'default' | 'small';

export type LanguageType = 'zh' | 'en' | null;

export type DeviceType = 'desktop' | 'mobile';

export type TabBarType = 'card' | 'smart' | 'smooth';

/* GlobalState */
export interface GlobalState {
  version: string;
  layout: LayoutType;
  assemblySize: AssemblySizeType;
  language: LanguageType;
  device: DeviceType;
  tabsBarStyle: TabBarType;
  maximize: boolean;
  primary: string;
  isDark: boolean;
  isGrey: boolean;
  isWeak: boolean;
  asidePopup: boolean;
  asideInverted: boolean;
  isCollapse: boolean;
  accordion: boolean;
  breadcrumb: boolean;
  breadcrumbIcon: boolean;
  tabs: boolean;
  tabsIcon: boolean;
  footer: boolean;
}

/* UserState */
export interface UserState {
  token: string;
  code: string;
  userInfo: {
    appCode: string;
    appName: string;
    userNo: string;
    userName: string;
    userNameEn: string | null;
    nickName: string | null;
    email: string | null;
    avatar: string | null;
  };
}

/* tabsMenuProps */
export interface TabsMenuProps {
  icon: string;
  title: string;
  path: string;
  name: string;
  close: boolean;
  isKeepAlive: boolean;
}

/* TabsState */
export interface TabsState {
  tabsMenuList: TabsMenuProps[];
}

/* AuthState */
export interface AuthState {
  routeName: string;
  permissionList: string[]; // 菜单 和 按钮的权限列表
  authMenuList: Menu.MenuOptions[];
}

/* KeepAliveState */
export interface KeepAliveState {
  keepAliveName: string[];
}
