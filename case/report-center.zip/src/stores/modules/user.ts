import { defineStore } from 'pinia';
import { UserState } from '@/stores/interface';
import piniaPersistConfig from '@/config/piniaPersist';
import { loginPort, getUserInfoPort } from '@/api/modules/login';
import { ElNotification } from 'element-plus';

export const useUserStore = defineStore({
  id: 'report-user',
  state: (): UserState => ({
    // token: '11bf5139-59ba-487e-9c02-377cd332740f',
    token: '',
    code: '',
    userInfo: {
      appCode: '',
      appName: '',
      userNo: '',
      userName: '',
      userNameEn: null,
      nickName: null,
      email: null,
      avatar: ''
    }
  }),
  getters: {},
  actions: {
    setToken(token: string) {
      this.token = token;
    },
    setUserInfo(userInfo: UserState['userInfo']) {
      this.userInfo = userInfo;
    },
    // 授权
    async userLogin() {
      const [, query] = window.location.href.split('?');
      const code = query && query.includes('=') ? query.split('=')[1] : '5c6173c752864c0887e87763d208b61d';
      if (this.code === code) return;
      this.code = code;
      try {
        const { val: token, success } = await loginPort({ code });
        if (success === '0') {
          this.token = token;
          await this.getUserInfo();
        } else {
          ElNotification({
            title: '验证失败',
            message: 'code验证码验证失败！',
            type: 'warning',
            duration: 3000
          });
        }
      } catch (e) {
        console.log('e : ', e);
      }
    },
    async getUserInfo() {
      try {
        const { val: userInfo, success } = await getUserInfoPort();
        if (success === '0') {
          this.userInfo = userInfo;
        }
      } catch {}
    }
  },
  persist: piniaPersistConfig('report-user')
});
