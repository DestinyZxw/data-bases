import { defineStore } from 'pinia';
import { AuthState } from '@/stores/interface';
import { getUserAuthListPort, PermissionsItemType } from '@/api/modules/setting';
import { getFlatMenuList, getShowMenuList, getAllBreadcrumbList, filterPermissionsKey } from '@/utils';
import { Menu } from '@/typings/global';

// 获取模块的路由
// const modules: Record<string, any> = import.meta.globEager('@/routers/modules/**/*.ts');
const modules: Record<string, any> = import.meta.glob('@/routers/modules/**/*.ts', { eager: true });
const routeList: Menu.MenuOptions[] = [];
Object.keys(modules).forEach(key => {
  const route = modules[key].default || {};
  routeList.push(route);
});

function sortRoute(a: Menu.MenuOptions, b: Menu.MenuOptions) {
  return (a.meta?.sort || 0) - (b.meta?.sort || 0);
}

routeList.sort(sortRoute);

export const useAuthStore = defineStore({
  id: 'report-auth',
  state: (): AuthState => ({
    // 权限列表
    permissionList: [],
    // 菜单权限列表
    authMenuList: [],
    // 当前页面的 router name，用来做按钮权限筛选
    routeName: ''
  }),
  getters: {
    // 菜单、按钮权限列表
    permissionListGet: (state: AuthState) => state.permissionList,
    // 菜单权限列表 ==> 这里的菜单没有经过任何处理
    authMenuListGet: (state: AuthState) => state.authMenuList,
    // 菜单权限列表 ==> 左侧菜单栏渲染，需要剔除 isHide == true
    showMenuListGet: (state: AuthState) => getShowMenuList(state.authMenuList, state.permissionList),
    // 菜单权限列表 ==> 扁平化之后的一维数组菜单，主要用来添加动态路由
    flatMenuListGet: (state: AuthState) => getFlatMenuList(state.authMenuList, state.permissionList),
    // 递归处理后的所有面包屑导航列表
    breadcrumbListGet: (state: AuthState) => getAllBreadcrumbList(state.authMenuList)
  },
  actions: {
    // Get AuthButtonList
    async getPermissionList() {
      try {
        const res = await getUserAuthListPort();
        if (res.success === '0') {
          if (res.val.childPermission?.length) {
            this.permissionList = filterPermissionsKey<PermissionsItemType, 'childPermission', 'permissionCode'>({
              target: res.val,
              children: 'childPermission',
              key: 'permissionCode',
              isIncludeTrack: true
            });
          } else {
            this.permissionList = [];
          }
        }
      } catch (e) {
        console.log('e : ', e);
      }
    },
    // Get origin Menu List
    async getOriginMenuList() {
      this.authMenuList = routeList;
    },
    // Set RouteName
    setRouteName(name: string) {
      this.routeName = name;
    }
  }
});
