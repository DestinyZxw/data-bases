import { defineStore } from 'pinia';
import { GlobalState } from '@/stores/interface';
import { DEFAULT_PRIMARY } from '@/config';
import piniaPersistConfig from '@/config/piniaPersist';
import { ObjToKeyValArray } from '@/typings/global';

export const useGlobalStore = defineStore({
  id: 'report-global',
  // 修改默认值之后，需清除 localStorage 数据
  state: (): GlobalState => ({
    version: '1.0.0',
    // 布局模式 (纵向：vertical | 经典：classic | 横向：transverse | 分栏：columns)
    layout: 'columns',
    // element 组件大小
    assemblySize: 'default',
    // 当前系统语言
    language: null,
    // 当前页面是否全屏
    maximize: false,
    // 当前设备类型
    device: 'desktop',
    // 主题颜色
    primary: DEFAULT_PRIMARY,
    // 深色模式
    isDark: false,
    // 灰色模式
    isGrey: false,
    // 色弱模式
    isWeak: false,
    // 侧边栏反转 (目前仅支持 'vertical' 模式)
    asideInverted: false,
    // 侧边栏是否弹出
    asidePopup: false,
    // 折叠菜单
    isCollapse: false,
    // 菜单手风琴
    accordion: false,
    // 面包屑导航
    breadcrumb: true,
    // 面包屑导航图标
    breadcrumbIcon: true,
    tabsBarStyle: 'card',
    // 标签页
    tabs: true,
    // 标签页图标
    tabsIcon: true,
    // 页脚
    footer: false
  }),
  getters: {},
  actions: {
    // Set GlobalState
    setGlobalState(...args: ObjToKeyValArray<GlobalState>) {
      this.$patch({ [args[0]]: args[1] });
    }
  },
  persist: piniaPersistConfig('report-global')
});
