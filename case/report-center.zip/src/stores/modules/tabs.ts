import router from '@/routers';
import { HOME_URL } from '@/config';
import { defineStore } from 'pinia';
import { TabsState, TabsMenuProps } from '@/stores/interface';
import { useAuthStore } from '@/stores/modules/auth';
import piniaPersistConfig from '@/config/piniaPersist';

export const useTabsStore = defineStore({
  id: 'report-tabs',
  state: (): TabsState => ({
    tabsMenuList: []
  }),
  actions: {
    // Add Tabs
    async addTabs(tabItem: TabsMenuProps) {
      tabItem.path.includes(HOME_URL) && (tabItem.path = HOME_URL);
      if (this.tabsMenuList.every(item => item.path !== tabItem.path)) {
        this.tabsMenuList.push(tabItem);
      }
    },
    // Remove Tabs
    async removeTabs(tabPath: string, isCurrent: boolean = true) {
      const tabsMenuList = this.tabsMenuList;
      if (isCurrent) {
        tabsMenuList.forEach((item, index) => {
          if (item.path !== tabPath) return;
          const nextTab = tabsMenuList[index + 1] || tabsMenuList[index - 1];
          if (!nextTab) return;
          router.push(nextTab.path);
        });
      }
      this.tabsMenuList = tabsMenuList.filter(item => item.path !== tabPath);
    },
    // Close MultipleTab
    async closeMultipleTab(tabsMenuValue?: string) {
      this.tabsMenuList = this.tabsMenuList.filter(item => {
        return item.path === tabsMenuValue || !item.close;
      });
    },
    // Set Tabs
    async setTabs(tabsMenuList: TabsMenuProps[]) {
      this.tabsMenuList = tabsMenuList;
    },
    // Set Tabs Title
    async setTabsTitle(title: string) {
      const nowFullPath = location.hash.substring(1);
      this.tabsMenuList.forEach(item => {
        if (item.path == nowFullPath) item.title = title;
      });
    },
    // 重置tabs
    resetTabs() {
      const authStore = useAuthStore();
      const { flatMenuListGet } = storeToRefs(authStore);
      const tmp: TabsMenuProps[] = [];
      for (let item of this.tabsMenuList) {
        let flag = flatMenuListGet.value.find(it => it.path === item.path);
        flag && tmp.push(item);
      }
      this.tabsMenuList = tmp;
    }
  },
  persist: piniaPersistConfig('report-tab')
});
