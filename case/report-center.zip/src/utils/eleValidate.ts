// Element 常用表单校验规则

/**
 *  @rule 手机号
 */
export function checkPhoneNumber(rule: any, value: any, callback: any) {
  const regexp = /^(((13[0-9]{1})|(15[0-9]{1})|(16[0-9]{1})|(17[3-8]{1})|(18[0-9]{1})|(19[0-9]{1})|(14[5-7]{1}))+\d{8})$/;
  if (value === '') callback('请输入手机号码');
  if (!regexp.test(value)) {
    callback(new Error('请输入正确的手机号码'));
  } else {
    return callback();
  }
}

/**
 *  @rule url链接
 */
export function checkUrlAddress(rule: any, value: any, callback: any) {
  // 一个较详细的正则表达式来匹配URL
  // 包括http/https/ftp协议，域名或IP地址，可选端口，以及路径查询字符串等部分
  const urlRegex =
    /^(?:(?:https?|ftp):\/\/)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{2,})))(?::\d{2,5})?(?:[/?#]\S*)?$/i;
  if (value === '') callback('请输入地址链接');
  if (!urlRegex.test(value)) {
    callback(new Error('请输入格式正确的地址链接'));
  } else {
    return callback();
  }
}
