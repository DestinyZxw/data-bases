<script setup lang="ts" name="RubCount">
import * as TWEEN from '@tweenjs/tween.js';

type Props = {
  from?: number;
  to?: number;
  duration?: number;
};

const props = withDefaults(defineProps<Props>(), {
  // 起始值
  from: 0,
  // 结束值
  to: 1000,
  // 动画执行时间，单位毫秒
  duration: 2000
});

const count = ref(0);

watchEffect(() => {
  let frameHandler: number;
  function animate(time = 0) {
    frameHandler = requestAnimationFrame(animate);
    TWEEN.update(time); // time表示多长时间执行一次
  }
  // 创建数字动画对象
  const tween: InstanceType<typeof TWEEN.Tween> = new TWEEN.Tween({ count: props.from })
    .to({ count: props.to }, props.duration)
    .easing(TWEEN.Easing.Linear.None)
    .onUpdate(data => {
      count.value = Math.round(data.count);
    })
    .onComplete(() => {
      cancelAnimationFrame(frameHandler);
      tween.stop();
    })
    .start();

  // 开始补间动画
  animate();
});
</script>

<template>
  <div id="count">{{ count }}</div>
</template>
