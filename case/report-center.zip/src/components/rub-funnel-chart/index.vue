<template>
  <!-- echarts 容器 -->
  <div ref="containerRef" style="width: 100%; height: 800px" />
</template>

<!-- 客单价同比增长率 echarts-->
<script lang="ts" setup name="priceRateChart">
import { useEcharts } from '@/hooks/useEcharts';
import type { EChartsOption } from 'echarts';
import { Chart } from '@/typings/global';

interface Props {
  title?: string;
  colors?: string[];
  seriesData?: Chart.FunnelItemType[];
  markLines?: {
    value: number;
    itemValue: string;
    rate: string;
    show: boolean;
  }[];
}
// 设置默认值
const props = withDefaults(defineProps<Props>(), {
  title: '',
  colors: () => ['#5470C6', '#c075cc'],
  seriesData: () => [],
  markLines: () => []
});

const containerRef = ref<HTMLDivElement | null>(null);
const chart = useEcharts(containerRef as Ref<HTMLDivElement>);

const rightArrow =
  'image://data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEkAAABNBAMAAAAYzFT5AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAElBMVEUAAACZmZmZmZmqqqqZmZkAAAClqsN/AAAAA3RSTlMAf4C/aSLHAAAAAWJLR0QAiAUdSAAAAAlwSFlzAAALEgAACxIB0t1+/AAAAFdJREFUSMftzbENgCAYROEDHMCCASwYwMQFKNh/JkOhHfnPxuq9+sud9FSuZac+qnUFhUKhUKi3raNQqJ/U7qgU7k1VHZWGo+qI62qWyvHjrFkqW0pHTG6J1zAklFuGvAAAACV0RVh0ZGF0ZTpjcmVhdGUAMjAyMC0wMi0wM1QxODo0OTo1NyswODowMJLTpqcAAAAldEVYdGRhdGU6bW9kaWZ5ADIwMjAtMDItMDNUMTg6NDk6NTcrMDg6MDDjjh4bAAAAAElFTkSuQmCC';
// const colors = ['#1cd389', '#668eff', '#ffc751', '#ff6e73', '#8683e6', '#9692ff'];
const url =
  'image://data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAARCAMAAACLgl7OAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAAaVBMVEUAAADBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcHBwcEAAAD45xibAAAAInRSTlMAmT6WJYwSfBMGZAFHmEgtkBeCCW0KAlI1k5QeiA10A1tc7ah1owAAAAFiS0dEAIgFHUgAAAAJcEhZcwAACxIAAAsSAdLdfvwAAAB7SURBVCjPtZDZDoAgDAQXvA+8bwX1/3/SGKIBEd+cx07TdgtIiAF0/mygDvnAoYDr2b3nnjP8wOaDUG6J4ncfR9cdScpMzbJECZEXT1/kesyy0n1VPv6AulF908Kg6+9DWN/hjWGUfhpgYV5Ov8ywwgUhguODddtXvXIAjuUEs/70/t4AAAAldEVYdGRhdGU6Y3JlYXRlADIwMTktMTItMTZUMTU6MzM6MDkrMDg6MDCzL2BEAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDE5LTEyLTE2VDE1OjMzOjA5KzA4OjAwwnLY+AAAAABJRU5ErkJggg==';

const markLineSetting = {
  show: true,
  backgroundColor: '#e4f5da',
  borderRadius: 4,
  color: '#333',
  verticalAlign: 'middle',
  offset: [40, 0, 0, 0],
  fontSize: 14,
  padding: [15, 10, 10, 10],
  formatter: function (d: any) {
    if (d.value) {
      return (
        '买卡转化率\n {aa|' +
        d.data.itemValue +
        '}\n{bb|同比 : ' +
        d.data.rate +
        '}{' +
        (parseFloat(d.data.rate) > 0 ? 'cc' : 'dd') +
        '|' +
        (parseFloat(d.data.rate) > 0 ? '↑' : '↓') +
        '}'
      );
    }
  },
  rich: {
    aa: { color: '#8a8a8a', lineHeight: 20, padding: [15, 0, 10, 0] },
    bb: { color: '#8a8a8a', lineHeight: 20, padding: [10, 0, 10, 0] },
    cc: { color: '#00B050', lineHeight: 20, padding: [10, 0, 10, 0] },
    dd: { color: '#FF0000', lineHeight: 20, padding: [10, 0, 10, 0] }
  }
};

watch(
  props,
  () => {
    render();
  },
  { immediate: true }
);

function render() {
  const options = {
    grid: {
      top: 0,
      left: '2%',
      right: 20,
      height: 336,
      bottom: '10'
    },
    color: props.colors,
    xAxis: [
      { show: false, inverse: true, position: 'top' },
      { position: 'bottom', show: false, min: 100, max: 200 }
    ],
    yAxis: [
      {
        position: 'left',
        show: false,
        boundaryGap: false,
        inverse: true,
        type: 'category',
        min: '转化率1',
        data: ['转化率1', '转化率2', '转化率3']
      }
    ],
    series: [
      {
        top: 0,
        name: '漏斗图',
        type: 'funnel',
        gap: 20,
        left: '10%',
        height: 300,
        width: '80%',
        min: 0,
        max: 100,
        minSize: 0,
        label: {
          show: true,
          position: 'inside',
          fontSize: '14',
          formatter: function (d: any) {
            return (
              d.name +
              '{aa|}\n{bb|' +
              d.data.subName +
              ' : ' +
              d.data.number +
              '}\n{bb|同比 : ' +
              d.data.rate +
              d.data.unit +
              '}{' +
              (d.data.rate > 0 ? 'cc' : 'dd') +
              '|' +
              (d.data.rate > 0 ? '↑' : '↓') +
              '}'
            );
          },
          rich: {
            aa: { padding: [8, 0, 6, 0] },
            bb: { color: '#333', padding: [8, 0, 6, 0] },
            cc: { color: '#00B050', lineHeight: 20, padding: [10, 0, 10, 2] },
            dd: { color: '#FF0000', lineHeight: 20, padding: [10, 0, 10, 2] }
          }
        },
        data: props.seriesData
      },
      {
        type: 'pictorialBar',
        name: '小箭头',
        symbolSize: ['20', '20'],
        symbolOffset: [0, -16],
        symbolPosition: 'center',
        symbol: url,
        animation: true,
        z: 10,
        data: [{ value: 50, show: false }, 100]
      },
      {
        name: '右侧箭头',
        type: 'pictorialBar',
        symbolPosition: 'center',
        symbolSize: ['73', '154'],
        symbol: rightArrow,
        symbolClip: true,
        xAxisIndex: '1',
        z: 1,
        data: props.markLines.map(item => ({ ...item, label: markLineSetting }))
      }
    ]
  } as EChartsOption;
  chart.setOptions(options);
}
</script>
