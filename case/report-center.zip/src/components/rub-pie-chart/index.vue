<template>
  <div ref="pieRef" style="width: 100%; height: 400px" />
</template>

<script lang="ts" setup name="RubPieChart">
import { useEcharts } from '@/hooks/useEcharts';
import type { EChartsOption } from 'echarts';
type Props = {
  position?: string;
  name?: string;
  data?: Array<{ name: string; value: number }>;
  colors?: string[];
};
const props = withDefaults(defineProps<Props>(), {
  position: 'inner',
  name: '',
  data: () => [],
  colors: () => []
});

const pieRef = ref<HTMLDivElement | null>(null);
const pieECharts = useEcharts(pieRef as Ref<HTMLDivElement>);

const options = computed(() => {
  return {
    color: props.colors,
    ...(props.name
      ? {
          title: {
            text: props.name,
            left: 'center',
            top: props.position === 'outside' ? '0' : '10%'
          }
        }
      : {}),
    tooltip: {
      trigger: 'item',
      formatter: '{b} {d}%'
    },
    legend: {
      top: '10%',
      left: 'center',
      show: false
    },
    series: [
      {
        type: 'pie',
        radius: '50%',
        width: '120%',
        height: '120%',
        left: 'center',
        top: 'center',
        data: props.data,
        label: {
          position: props.position,
          fontSize: 14,
          formatter: '{b}\n {d|{d}}%',
          rich: {
            d: {
              lineHeight: 24,
              align: 'center'
            }
          }
        },
        labelLine: {
          show: props.position !== 'inner'
        },
        emphasis: {
          itemStyle: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.5)'
          }
        }
      }
    ]
  } as EChartsOption;
});

watch(
  () => props.data,
  () => {
    pieECharts.setOptions(options.value);
  },
  { immediate: true }
);
</script>
