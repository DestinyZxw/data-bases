<script lang="ts" setup name="RubSelectKit">
import { useButtonAuth } from '@/hooks/useButtonAuth';

type BaseType = number | string | null | undefined;
type OptionItem = { name: string; value: BaseType };

const props = defineProps<{
  type: BaseType;
  options: OptionItem[];
  authCode?: string; // 按钮授权码
}>();

const emit = defineEmits(['update:type']);
const currentType = ref<BaseType>();

watch(
  () => props.type,
  n => {
    currentType.value = n;
  },
  { immediate: true }
);

// 按钮权限
const { isDisabledRead } = useButtonAuth({
  read: props.authCode
});

function handleChange(item: OptionItem) {
  if (isDisabledRead.value) return;
  currentType.value = item.value;
  emit('update:type', item.value);
}
</script>

<template>
  <div class="container">
    <template v-for="(item, index) in options" :key="index">
      <div class="item" :class="[item.value === currentType ? 'active' : '']" @click="handleChange(item)">
        <div class="animate" />
        <div class="name">{{ item.name }}</div>
      </div>
    </template>
  </div>
</template>

<style scoped lang="scss">
@import './index.scss';
</style>
