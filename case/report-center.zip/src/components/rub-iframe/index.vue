<template>
  <div class="iframe-container">
    <iframe class="iframe" :src="path" />
  </div>
</template>

<script lang="ts" setup name="RubIFrame">
const route = useRoute();
const path = ref<string>('');

// const { frameSrc = '' } = route.meta;
// frameSrc && (path.value = frameSrc as string);
path.value = route.params.url as string;
</script>

<style lang="scss" scoped>
.iframe-container {
  width: 100%;
  height: 100%;
  .iframe {
    box-sizing: border-box;
    width: 100%;
    height: 100%;
    overflow: hidden;
    border: 0;
  }
}
</style>
