<template>
  <!-- echarts 容器 -->
  <div ref="chartRef" style="width: 100%; height: 600px" />
</template>

<!-- 客单价同比增长率 echarts-->
<script lang="ts" setup name="priceRateChart">
import { useEcharts } from '@/hooks/useEcharts';
import type { EChartsOption } from 'echarts';
import { Chart } from '@/typings/global';

interface Props {
  title?: string;
  colors?: string[];
  data?: Array<Chart.TreeMapItem>;
}

// 设置默认值
const props = withDefaults(defineProps<Props>(), {
  title: '',
  // colors: () => ['#F4B183', '#E2F0D9', '#A9D18E', '#C00000', '#00B050', '#70AD47', '#FF0000', '#FF7C80'],
  colors: () => [],
  data: () => []
});

const chartRef = ref<HTMLDivElement | null>(null);
const chart = useEcharts(chartRef as Ref<HTMLDivElement>);

watch(
  props,
  () => {
    render();
  },
  { immediate: false }
);

function render() {
  let data = props.data.map((item, index) => ({
    itemStyle: { color: props.colors[index] },
    ...item
  }));
  let options = {
    ...(props.title
      ? {
          title: {
            text: props.title,
            left: 'center'
          }
        }
      : {}),
    tooltip: {
      show: true,
      alwaysShowContent: false,
      showDelay: 0,
      formatter(params: any) {
        let { data, color } = params;
        return `
        <div style="min-width: 140px; background-color: #fff; border-radius: 8px; padding:5px; box-sizing: border-box; height: 56px">
          <div class="mb5 fz12 flex items-center" style="color: #333;">
            <div style="background-color: ${color};width: 2px; height: 14px;"></div>
            <span class="ml5">${data.name || '全部'}</span>
          </div>
          <div class="fz16 font-bold mb5" style="color: #333;">${data.value}</div>
        </div>
        `;
      }
    },
    series: [
      {
        type: 'treemap',
        left: 0,
        right: 0,
        top: props.title ? 50 : 0,
        bottom: 0,
        roam: false,
        nodeClick: undefined,
        breadcrumb: {
          show: false
        },
        visibleMin: 1,
        label: {
          show: true,
          fontSize: 14,
          color: '#000',
          formatter: '{b} , {c}',
          position: 'insideBottomLeft'
        },
        itemStyle: {
          borderColor: '#fff'
        },
        levels: [
          {
            itemStyle: { borderWidth: 0, gapWidth: 4 }
            // color: props.colors
          }
        ],
        data
      }
    ]
  } as EChartsOption;
  chart.setOptions(options);
}
</script>
