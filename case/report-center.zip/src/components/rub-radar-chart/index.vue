<template>
  <div ref="radarRef" style="height: 400px"></div>
</template>

<script lang="ts" setup name="RadarChart">
import { useEcharts } from '@/hooks/useEcharts';
import type { EChartsOption } from 'echarts';
import { Chart } from '@/typings/global';

type Props = {
  indicator: Chart.IndicatorItemType[];
  series: Chart.RadarChartType['series'];
};
const props = defineProps<Props>();

const radarRef = ref<HTMLDivElement | null>(null);
const radarECharts = useEcharts(radarRef as Ref<HTMLDivElement>);

const options = computed(() => {
  return {
    color: ['#5B9BD5'],
    title: {},
    legend: {},
    radar: {
      indicator: props.indicator
    },
    series: props.series
  } as EChartsOption;
});

watch(
  options,
  () => {
    radarECharts.setOptions(options.value);
  },
  { immediate: false }
);
</script>
