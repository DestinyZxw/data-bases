<template>
  <!-- echarts 容器 -->
  <div ref="containerRef" :style="{ width: '100%', height: chartHeight }" />
</template>

<!-- 客单价同比增长率 echarts-->
<script lang="ts" setup name="RubVerticalBarChart">
import { useEcharts } from '@/hooks/useEcharts';
import type { EChartsOption } from 'echarts';
import { Chart } from '@/typings/global';

interface Props {
  title?: string;
  name?: string;
  colors?: string[];
  axis?: string[];
  grid?: Chart.Grid;
  seriesData?: number[];
  dataZoom?: Chart.DataZoom[];
  labelShow?: boolean;
  inverse?: boolean;
  labelUnit?: string;
  barMaxWidth?: number;
  isSettingBarWidth?: boolean;
}

// 设置默认值
const props = withDefaults(defineProps<Props>(), {
  title: '',
  name: '',
  colors: () => ['#5470C6', '#c075cc'],
  axis: () => [],
  grid: () => ({}),
  seriesData: () => [],
  dataZoom: () => [],
  labelShow: false,
  inverse: false,
  labelUnit: '',
  barMaxWidth: 48,
  isSettingBarWidth: true
});

const containerRef = ref<HTMLDivElement | null>(null);
const chart = useEcharts(containerRef as Ref<HTMLDivElement>);

const chartHeight = computed(() => {
  let length = props?.axis?.length || 15;
  let currentHeight = length * 40;
  return `${currentHeight}px`;
});

watch(
  () => props.seriesData,
  () => {
    renderEChartsGraph();
  },
  { immediate: false }
);

function renderEChartsGraph() {
  const total = props.seriesData.reduce((prev, curr) => prev + curr);
  const avg = props.seriesData.length ? total / props.seriesData.length : 0;
  const data = props.seriesData.map(value => ({
    value,
    label: {
      show: props.labelShow,
      formatter: `{c}${props.labelUnit}`,
      position: value > avg / 3 ? 'inside' : 'right'
    }
  }));
  const title = props.title
    ? {
        title: {
          text: props.title,
          left: 'center',
          textStyle: {
            fontSize: '18px'
          }
        }
      }
    : { legend: {} };
  const options = {
    color: props.colors,
    ...title,
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      }
    },
    ...(props.dataZoom.length ? { dataZoom: props.dataZoom } : {}), // 下方的导轨
    grid: {
      top: props.title ? '8%' : '3%',
      left: '3%',
      right: '4%',
      bottom: '3%',
      containLabel: true,
      ...props.grid
    },
    xAxis: {
      type: 'value',
      boundaryGap: [0, 0.05],
      axisLabel: {
        formatter: `{value}${props.labelUnit}`
      }
    },
    yAxis: {
      type: 'category',
      inverse: props.inverse,
      data: props.axis
    },
    series: [
      {
        ...(props.name && !props.title ? { name: props.name } : {}),
        type: 'bar',
        ...(props.isSettingBarWidth ? { barMaxWidth: props.barMaxWidth } : {}),
        data
      }
    ]
  } as EChartsOption;

  chart.setOptions(options);
}
</script>
