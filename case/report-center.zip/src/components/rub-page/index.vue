<template>
  <div class="page-container">
    <div class="header">
      <slot name="header"></slot>
    </div>

    <el-scrollbar class="content" ref="scrollbarRef">
      <div class="content-inner">
        <slot></slot>
      </div>
    </el-scrollbar>
  </div>
</template>

<script setup lang="ts" name="RubPage">
import type { ScrollbarInstance } from 'element-plus';

type ScrollToType = (value: number) => void;

const scrollbarRef = ref<ScrollbarInstance | null>(null);

const scrollTo: ScrollToType = value => {
  scrollbarRef.value?.setScrollTop(value);
};

defineExpose({
  scrollTo
});
</script>

<style scoped lang="scss">
.page-container {
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  height: 100%;
  .header,
  .content-inner {
    box-sizing: border-box;
    width: 100%;
    padding-right: 12px;
    padding-left: 12px;
  }
  .content {
    flex: 1;
    width: 100%;
  }
}
.mobile {
  .page-container {
    display: block;
    height: auto;
    .header,
    .content-inner {
      padding-right: 10px;
      padding-left: 10px;
    }
    .content {
      flex: revert;
      width: 100%;
    }
  }
}
</style>
