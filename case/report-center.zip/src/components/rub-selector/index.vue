<script setup lang="ts" name="RubSelector">
import { useGlobalStore } from '@/stores/modules/global';
import { useButtonAuth } from '@/hooks/useButtonAuth';

export type SingleOrArray<T> = T | T[];
export type ModelType = number | string;
export type ModelValueType = SingleOrArray<ModelType>;
export type SelectorOptionItemType = { name: string; value: ModelType; disabled?: boolean };

export type Props = {
  modelValue: ModelValueType;
  options?: SelectorOptionItemType[];
  authCode?: string; // 按钮授权码
};

const props = withDefaults(defineProps<Props>(), {
  options: () => [],
  authCode: ''
});

const emit = defineEmits<{
  'update:modelValue': [value: ModelValueType]; // 具名元组语法
}>();

const globalStore = useGlobalStore();
const { assemblySize } = storeToRefs(globalStore); // 组件尺寸

const collection = ref<ModelType[]>([]); // 选择数组
const multiple = computed(() => Array.isArray(props.modelValue)); // 是否多选

// 按钮权限
const { isDisabledRead } = useButtonAuth({
  read: props.authCode
});

watchEffect(() => {
  if (Array.isArray(props.modelValue)) {
    collection.value = props.modelValue.slice();
  }
});

const handleClick = ({ value, disabled = false }: SelectorOptionItemType) => {
  if (disabled || isDisabledRead.value) return;
  if (multiple.value) {
    const index = collection.value.findIndex(item => item === value);
    // 如果value值已存在就删除，否则添加
    index >= 0 ? collection.value.splice(index, 1) : collection.value.push(value);
  }
  const data: ModelValueType = multiple.value ? collection.value : value;
  emit('update:modelValue', data);
};

const isActiveStatus = (item: SelectorOptionItemType) => {
  let flag: boolean;
  if (Array.isArray(props.modelValue)) {
    flag = props.modelValue.includes(item.value);
  } else {
    flag = props.modelValue === item.value;
  }
  return flag;
};
</script>

<template>
  <div class="tag-container flex items-center flex-wrap">
    <div
      v-for="(item, index) in options"
      :class="[
        `el-tag pointer el-tag--${assemblySize}`,
        isActiveStatus(item) ? 'el-tag--dark' : '',
        { 'is-disabled': item?.disabled || isDisabledRead }
      ]"
      :key="index"
      @click="handleClick(item)"
    >
      {{ item.name }}
    </div>
  </div>
</template>

<style lang="scss" scoped>
@import './index.scss';
</style>
