<template>
  <div class="container">
    <div class="content" :class="[show ? 'visible' : 'noVisible']">
      <slot />
    </div>
    <div :class="['empty-status', show ? 'noVisible' : 'visible']">
      <div v-if="title" class="title">{{ title }}</div>
      <RubSvgIcon name="emptydata" :icon-style="{ width: '200px', height: '200px' }" />
      <span>{{ tips }}</span>
    </div>
  </div>
</template>

<script lang="ts" setup name="BarLineChart">
type Props = {
  show?: boolean;
  title?: string;
  tips?: string;
};

withDefaults(defineProps<Props>(), {
  show: true,
  title: '',
  tips: '暂无数据'
});
</script>
<style scoped lang="scss">
.container {
  position: relative;
  width: 100%;
  height: auto;
}

/* 空状态 */
.empty-status {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 100%;
  font-size: 14px;
  color: var(--el-text-color-secondary);
  background-color: var(--el-fill-color-light);
  border-radius: 6px;
  .title {
    position: absolute;
    top: 20px;
    left: 50%;
    height: 30px;
    font-size: 18px;
    font-weight: bold;
    line-height: 30px;
    color: var(--el-text-color-primary);
    transform: translateX(-50%);
  }
  span {
    margin-top: -30px;
  }
}
</style>
