import { CascaderNodePathValue, ModelValueType } from 'element-plus';

export interface SearchFormType {
  shopList: CascaderNodePathValue | CascaderNodePathValue[];
  months: ModelValueType;
  month: ModelValueType;
  memberType: number;
  positionType: number;
  productType: string;
  nurseType: string;
  tableType: string;
  shopName: string;
}

export type SearchParamsType = {
  shopIdList: number[];
  startMonth: string;
  endMonth: string;
} & Omit<SearchFormType, 'shopList' | 'months'>;
