<!-- 文件描述：创建时间：2023/6/15 10:17 创建人：kai.zhang -->
<template>
  <el-form ref="searchFormRef" :model="searchForm" :rules="searchRules" label-width="80">
    <el-row :gutter="15">
      <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
        <el-form-item label="所属门店">
          <el-cascader
            class="wp-100"
            v-model="searchForm.shopList"
            :props="shopProps"
            :options="shopOptions"
            :clearable="isShopClearable"
            collapse-tags
            collapse-tags-tooltip
            filterable
          />
        </el-form-item>
      </el-col>
      <el-col v-if="isMember" :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
        <el-form-item label="用户类型">
          <el-select v-model="searchForm.memberType" class="wp-100" clearable>
            <el-option label="体验顾客" :value="0" />
            <el-option label="会员" :value="1" />
          </el-select>
        </el-form-item>
      </el-col>
      <el-col v-if="isPositionType" :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
        <el-form-item label="员工类型">
          <el-select v-model="searchForm.positionType" class="wp-100" clearable>
            <el-option label="顾问" :value="1" />
            <el-option label="美容师" :value="2" />
          </el-select>
        </el-form-item>
      </el-col>
      <el-col v-if="isMonths" :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
        <el-form-item label="所属时间" prop="months">
          <el-date-picker
            class="wp-100"
            v-model="searchForm.months"
            type="monthrange"
            format="YYYY-MM"
            value-format="YYYY-MM"
            placeholder="请选择日期"
            start-placeholder="起始月份"
            end-placeholder="结束月份"
            :disabled-date="disabledMonth"
          />
        </el-form-item>
      </el-col>
      <el-col v-else :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
        <el-form-item label="期间" prop="month">
          <el-date-picker
            class="wp-100"
            v-model="searchForm.month"
            type="month"
            format="YYYY-MM"
            value-format="YYYY-MM"
            placeholder="请选择月份"
            :clearable="false"
            :disabled-date="disabledMonth"
          />
        </el-form-item>
      </el-col>
      <el-col v-if="isProductType" :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
        <el-form-item label="护理类型">
          <el-select v-model="searchForm.nurseType" class="wp-100" clearable>
            <el-option label="护理" value="护理" />
            <el-option label="产品" value="产品" />
          </el-select>
        </el-form-item>
      </el-col>
      <el-col v-if="isProductType" :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
        <el-form-item label="产品类型">
          <el-select v-model="searchForm.productType" class="wp-100" clearable>
            <el-option label="新品" value="新品" />
            <el-option label="老品" value="老品" />
          </el-select>
        </el-form-item>
      </el-col>
      <el-col v-if="isNurseType" :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
        <el-form-item label="表单类型">
          <el-select v-model="searchForm.tableType" class="wp-100" clearable>
            <el-option label="二联单" value="二联单" />
            <el-option label="其他" value="其他" />
          </el-select>
        </el-form-item>
      </el-col>
      <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
        <el-form-item>
          <el-space>
            <el-button type="primary" @click="handleSearch" :disabled="isDisabledRead">搜索</el-button>
            <el-button type="success" @click="handleReset" :disabled="isDisabledRead">重置</el-button>
          </el-space>
        </el-form-item>
      </el-col>
    </el-row>
  </el-form>
</template>

<script lang="ts" setup name="RubSearchForm">
import type { FormRules, FormInstance, CascaderProps, CascaderNodePathValue } from 'element-plus';
import { shopRegionPort, basicShopItem } from '@/api/modules/base';
import dayjs from 'dayjs';
import { SearchFormType, SearchParamsType } from './interfaces';
import { useButtonAuth } from '@/hooks/useButtonAuth';

type Props = {
  readAuthCode: string; // 按钮授权码
  isShopMultiple?: boolean; // 店铺是否多选
  isShopClearable?: boolean; // 店铺是否关闭取消
  isMember?: boolean; // 是否是用户类型
  isPositionType?: boolean; // 是否是员工类型
  isProductType?: boolean; // 是否是产品类型
  isNurseType?: boolean; // 是否是护理类型
  isTableType?: boolean; // 是否是表格类型
  isMonths?: boolean; // 是否是月份区间类型
  isCrossYear?: boolean; // 是否跨年
};

const props = withDefaults(defineProps<Props>(), {
  readAuthCode: '',
  isShopMultiple: true,
  isShopClearable: true,
  isMember: false,
  isPositionType: false,
  isProductType: false,
  isNurseType: false,
  isTableType: false,
  isMonths: true,
  isCrossYear: false
});

onMounted(() => {
  getShopRegionData();
});

// 按钮权限
const { isDisabledRead } = useButtonAuth({
  read: props.readAuthCode,
  initFn: () => {
    emit('search', toValue(searchData));
  }
});

const emit = defineEmits(['init', 'search', 'reset', 'getForm']);
const searchFormRef = ref<FormInstance | null>();

const currentMonth = dayjs().format('YYYY-MM'); // 当前月份~
const January = dayjs().format('YYYY') + '-01'; // 当年首月

// 初始化工厂函数
const initFactory = (): SearchFormType => ({
  // shopList: props.isShopMultiple ? [['红宝区', 19]] : ['红宝区', 19], // 默认门店数据是  红宝区 / 苏州久光
  shopList: [],
  months: [January, currentMonth],
  month: currentMonth,
  // month: '2023-07',
  memberType: 0,
  positionType: 1,
  productType: '',
  nurseType: '',
  tableType: '',
  shopName: '苏州久光'
});

// 搜索表单数据
const searchForm = ref<SearchFormType>(initFactory());
const disabledMonth = (time: Date) => {
  const current = Date.now();
  const selected = new Date(time).getTime();
  return selected > current;
};

// 搜索表单规则
const searchRules = reactive<FormRules>({
  months: [
    {
      required: true,
      trigger: 'change',
      validator: (rule, value, callback) => {
        if (!value) {
          callback(new Error('请选择日期'));
        } else {
          let [startDate, endDate] = value;
          if (!props.isCrossYear && startDate.slice(0, 4) !== endDate.slice(0, 4)) {
            callback('不允许跨年选择月份');
          }
          callback();
        }
      }
    }
  ]
});

// 搜索上传的数据
const searchData = computed<SearchParamsType>(() => {
  let {
    shopList,
    memberType,
    positionType,
    months = [],
    month,
    productType,
    nurseType,
    tableType,
    shopName
  } = toValue(searchForm);
  let shopIdList: number[] = [];
  let [startMonth = '', endMonth = ''] = months as string[];

  if (!props.isMonths) {
    // startMonth = dayjs(month as string)
    //   .subtract(11, 'month')
    //   .format('YYYY-MM');
    startMonth = month as string;
    endMonth = month as string;
  }

  if (props.isShopMultiple) {
    // 店铺多选
    if ((shopList as CascaderNodePathValue[]).length > 0) {
      for (let [, id] of shopList as CascaderNodePathValue[]) {
        id && shopIdList.push(id as number);
      }
    }
  } else {
    // 店铺单选
    let [, id] = shopList as CascaderNodePathValue;
    id && shopIdList.push(id as number);
    for (let item of shopOptions.value) {
      let currentItem = item.shopRegionList.find(it => it.shopId === id);
      currentItem && (shopName = currentItem.shopName);
    }
  }

  return { shopIdList, startMonth, endMonth, month, memberType, positionType, productType, nurseType, tableType, shopName };
});

type ShopOptionType = {
  shopId: number | string;
  shopName: string;
  shopRegionList: basicShopItem[];
};

// 门店 options
const shopOptions = ref<ShopOptionType[]>([]);
const getShopRegionData = async () => {
  try {
    let { val: data, success } = await shopRegionPort();
    if (success === '0') {
      shopOptions.value = data.map(item => {
        let tmp: ShopOptionType = {
          shopId: item.region,
          shopName: item.region,
          shopRegionList: item.shopRegionList
        };
        return tmp;
      });

      // 店铺初始值
      // let arr: CascaderNodePathValue = [shopOptions.value[0].shopId, shopOptions.value[0].shopRegionList[0].shopId];
      // searchForm.value.shopList = props.isShopMultiple ? [arr] : arr;
      // searchForm.value.shopName = shopOptions.value[0].shopRegionList[0].shopName;
    }
  } catch (e) {
    console.log('e : ', e);
  }
};

// 门店 props
const shopProps: CascaderProps = {
  label: 'shopName',
  value: 'shopId',
  children: 'shopRegionList',
  multiple: props.isShopMultiple,
  expandTrigger: 'hover'
};

const handleSearch = () => {
  searchFormRef.value?.validate((valid, fields) => {
    if (valid) {
      emit('search', toValue(searchData));
    } else {
      console.log('error submit!', fields);
    }
  });
};

const handleReset = () => {
  searchForm.value = initFactory();
  searchFormRef.value?.resetFields();
  emit('reset', toValue(searchData));
};
</script>
