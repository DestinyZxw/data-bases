<template>
  <RubPage>
    <template #header>
      <div class="card pb0">
        <RubSearchForm
          read-auth-code="MENU_NEW_MEMBER_MANAGE_READ"
          isPositionType
          @init="handleSearch"
          @search="handleSearch"
          @reset="handleReset"
        />
      </div>
    </template>

    <el-card shadow="hover" class="mt14">
      <template #header>
        <div class="flex items-center h-30">
          <div class="font-bold">员工新会员管理</div>
        </div>
      </template>
      <view class="flex justify-end mb16">
        <el-button type="primary" plain size="small" @click="exportTableData">
          导出<el-icon class="el-icon--right"><Download /></el-icon>
        </el-button>
      </view>
      <el-table :data="tableData" class="wp-100" border height="660">
        <el-table-column prop="shopName" label="门店" align="center" min-width="120" />
        <el-table-column prop="employeeName" label="姓名" align="center" min-width="120" />
        <el-table-column prop="repetitionBuyCount" label="复购人数" align="center" min-width="120">
          <template #default="{ row }"> {{ handleFilterTableRow(row, 'repetitionBuyCount') }} </template>
        </el-table-column>
        <el-table-column prop="repetitionBuyRatio" label="复购率" align="center" min-width="120">
          <template #default="{ row }"> {{ handleFilterTableRow(row, 'repetitionBuyRatio') }} </template>
        </el-table-column>
        <el-table-column label="人均护理业绩产出" align="center">
          <el-table-column prop="nursingAmount" label="=180天" align="center" min-width="120">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'nursingAmount') }} </template>
          </el-table-column>
          <el-table-column prop="yearNursingAmount" label="=360天" align="center" min-width="120">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'yearNursingAmount') }} </template>
          </el-table-column>
        </el-table-column>
        <el-table-column label="人均产品业绩产出" align="center">
          <el-table-column prop="productAmount" label="=180天" align="center" min-width="120">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'productAmount') }} </template>
          </el-table-column>
          <el-table-column prop="yearProductAmount" label="=360天" align="center" min-width="120">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'yearProductAmount') }} </template>
          </el-table-column>
        </el-table-column>
      </el-table>
    </el-card>

    <el-card shadow="hover" class="mt14 pr">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold">复购率</div>
        </div>
      </template>
      <RubEmptyTip :show="chartStatus">
        <RubBaseChart v-bind="chartData" class="pt10" />
      </RubEmptyTip>
    </el-card>
  </RubPage>
</template>

<!-- 员工体验顾客 管理表 -->
<script setup lang="ts" name="shopNewMember">
import {
  NewMemberManagerTableItemType,
  getNewMemberManagerTablePort,
  exportNewMemberManagerTablePort,
  exportShopNewMemberManagerRepetitionBuyRatioChartDataPort
} from '@/api/modules/shop';
import { SearchParamsType } from '@/components/rub-search-form/interfaces';
import { Chart } from '@/typings/global';
import { useGlobalStore } from '@/stores/modules/global';
import { handleFilterTableRow } from '@/utils';
import { ElMessageBox } from 'element-plus';
import { useDownload } from '@/hooks/useDownload';

const globalStore = useGlobalStore();
const isMobile = computed(() => globalStore.device === 'mobile');

const searchParams = ref<SearchParamsType>({} as SearchParamsType);
const handleSearch = (data: SearchParamsType) => {
  searchParams.value = data;
  getTableData(data);
  // getBillingChartData(data);
};

const handleReset = (data: SearchParamsType) => {
  tableData.value = [];
  handleSearch(data);
};

const tableData = ref<NewMemberManagerTableItemType[]>([]);

// 客单价同比增长率 当前数据
const chartStatus = ref<boolean>(false);
const chartData = ref<Chart.BaseChartType>({});

const getTableData = async (args: SearchParamsType) => {
  try {
    let { shopIdList, startMonth, endMonth, positionType } = toValue(args);
    let params = { shopIdList, startMonth, endMonth, positionType };
    let { val: data, success } = await getNewMemberManagerTablePort(params);
    if (success === '0') {
      tableData.value = data;

      chartStatus.value = !!data.length;
      if (!data.length) return;

      let axis: string[] = [];
      let buyRatios: number[] = []; // 复购率

      for (let item of data) {
        if (item.shopName === '小计' && !item.employeeName) continue;
        axis.push(item.employeeName);
        buyRatios.push(+Number(item.repetitionBuyRatio).toFixed(2) || 0);
      }

      let oneScreenValue = isMobile.value ? 5 : 25, // 横向 一屏数据展示的基准值
        dataZoom = [
          {
            type: isMobile.value ? 'inside' : 'slider',
            start: 0,
            end: Math.floor((oneScreenValue * 100) / (axis.length || oneScreenValue)),
            zoomLock: !isMobile.value,
            zoomOnMouseWheel: false,
            brushSelect: false,
            padding: [10, 20, 10, 20]
          }
        ];

      chartData.value = {
        xAxisBoundaryGap: true,
        yAxisUnit: '%',
        axis,
        series: [{ type: 'bar', name: '复购率(%)', data: buyRatios, label: { show: true, formatter: '{c}%' }, barMaxWidth: 48 }],
        // 导轨
        ...(axis.length > oneScreenValue ? { dataZoom } : {}),

        // 工具箱
        toolbox: {
          exportVisible: true,
          // 此处写导出逻辑
          exportPort: () => {
            ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
              useDownload({
                port: exportShopNewMemberManagerRepetitionBuyRatioChartDataPort,
                fileName: '复购率',
                params
              })
            );
          }
        }
      };
    }
  } catch (e) {
    console.log('e : ', e);
  }
};

// 导出员工新会员管理表
const exportTableData = () => {
  let { shopIdList, startMonth, endMonth, positionType } = toValue(searchParams);
  let params = { shopIdList, startMonth, endMonth, positionType };
  ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
    useDownload({
      port: exportNewMemberManagerTablePort,
      fileName: '员工新会员管理表',
      params
    })
  );
};
</script>
