/*双美卡生美销售表*/
import { CascaderNodePathValue, ModelValueType } from 'element-plus';

// 生美销售双美卡明细表搜索表单类型
export interface ShengMeiSearchFormType {
  memberCode: string;
  shopList: CascaderNodePathValue[];
  range: ModelValueType | null;
}
export interface ShengMeiSearchParamsType {
  memberCode: string;
  shopIdList: number[];
  startDate: string;
  endDate: string;
}

// 科美销售双美卡明细表搜索表单类型.
export interface KeMeiSearchFormType {
  memberCode: string;
  shopIdList: string[];
  range: ModelValueType | null;
}
export type KeMeiSearchParamsType = Omit<KeMeiSearchFormType, 'range'> & {
  startDate: string;
  endDate: string;
};
