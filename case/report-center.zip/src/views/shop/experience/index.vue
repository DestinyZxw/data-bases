<template>
  <RubPage>
    <template #header>
      <div class="card pb0">
        <RubSearchForm
          read-auth-code="MENU_TRIAL_MEMBER_MANAGE_READ"
          isPositionType
          @init="handleSearch"
          @search="handleSearch"
          @reset="handleReset"
        />
      </div>
    </template>

    <el-card shadow="hover" class="mt14">
      <template #header>
        <div class="flex items-center h-30 justify-between">
          <div class="font-bold">体验顾客表</div>
          <el-button type="primary" plain size="small" @click="exportTableData">
            导出<el-icon class="el-icon--right"><Download /></el-icon>
          </el-button>
        </div>
      </template>
      <!--      <view class="flex justify-end mb16">

      </view>-->
      <el-table :data="tableData" class="wp-100" border height="660">
        <el-table-column prop="shopName" label="门店" align="center" min-width="120" />
        <el-table-column prop="employeeName" label="员工姓名" align="center" min-width="120" />
        <el-table-column label="体验顾客人次" align="center">
          <el-table-column prop="experienceCount" label="实际" align="center" min-width="120">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'experienceCount') }} </template>
          </el-table-column>
          <el-table-column prop="experienceCountPer" label="同比(%)" align="center" min-width="120">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'experienceCountPer') }} </template>
          </el-table-column>
        </el-table-column>
        <el-table-column label="体验顾客买卡人次" align="center">
          <el-table-column prop="buyCount" label="实际" align="center" min-width="120">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'buyCount') }} </template>
          </el-table-column>
          <el-table-column prop="buyCountPer" label="同比(%)" align="center" min-width="120">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'buyCountPer') }} </template>
          </el-table-column>
        </el-table-column>
        <el-table-column label="买卡转化率" align="center">
          <template #header>
            买卡转化率
            <el-tooltip class="box-item" effect="dark" placement="top">
              <template #content>
                <div style="max-width: 360px">{{ getQuestionMapItem(219) }}</div>
              </template>
              <el-icon class="pointer" size="20" color="#333">
                <Warning />
              </el-icon>
            </el-tooltip>
          </template>
          <el-table-column prop="experienceBuyRatio" label="实际" align="center" min-width="120">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'experienceBuyRatio') }} </template>
          </el-table-column>
          <el-table-column prop="experienceBuyRatioPer" label="同比(%)" align="center" min-width="120">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'experienceBuyRatioPer') }} </template>
          </el-table-column>
        </el-table-column>
        <el-table-column align="center">
          <template #header>
            买卡客单
            <el-tooltip class="box-item" effect="dark" placement="top">
              <template #content>
                <div style="max-width: 360px">{{ getQuestionMapItem(105) }}</div>
              </template>
              <el-icon class="pointer" size="20" color="#333">
                <Warning />
              </el-icon>
            </el-tooltip>
          </template>
          <el-table-column prop="amount" label="实际" align="center" min-width="120">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'amount') }} </template>
          </el-table-column>
          <el-table-column prop="amountPer" label="同比(%)" align="center" min-width="120">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'amountPer') }} </template>
          </el-table-column>
        </el-table-column>
      </el-table>
    </el-card>

    <el-card shadow="hover" class="mt14 pr">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold">买卡转化率</div>
        </div>
      </template>
      <RubEmptyTip :show="chartStatus">
        <RubBaseChart v-bind="chartData" class="pt10" />
      </RubEmptyTip>
    </el-card>
  </RubPage>
</template>

<!-- 员工体验顾客 管理表 -->
<script setup lang="ts" name="shopExperience">
import {
  MemberExperienceTableItemType,
  getMemberExperienceTablePort,
  exportMemberExperienceTablePort,
  exportShopMemberExperienceAndBuyCardExperienceBuyRatioChartDataPort
} from '@/api/modules/shop';
import { SearchParamsType } from '@/components/rub-search-form/interfaces';
import { Chart } from '@/typings/global';
import { useGlobalStore } from '@/stores/modules/global';
import { handleFilterTableRow, getQuestionMapItem } from '@/utils';
import { ElMessageBox } from 'element-plus';
import { useDownload } from '@/hooks/useDownload';

const globalStore = useGlobalStore();
const isMobile = computed(() => globalStore.device === 'mobile');

const searchParams = ref<SearchParamsType>({} as SearchParamsType);
const handleSearch = (data: SearchParamsType) => {
  searchParams.value = data;
  getTableData(data);
};

const handleReset = (data: SearchParamsType) => {
  tableData.value = [];
  handleSearch(data);
};

const tableData = ref<MemberExperienceTableItemType[]>([]);

// 客单价同比增长率 当前数据
const chartStatus = ref<boolean>(false);
const chartData = ref<Chart.BaseChartType>({});

const getTableData = async (args: SearchParamsType) => {
  try {
    let { shopIdList, startMonth, endMonth, positionType } = toValue(args);
    let params = { shopIdList, startMonth, endMonth, positionType };
    let { val: data, success } = await getMemberExperienceTablePort(params);
    if (success === '0') {
      tableData.value = data;

      chartStatus.value = !!data.length;
      if (!data.length) return;

      let axis: string[] = [],
        buyRatios: number[] = [], // 买卡转化率
        perBuyRatios: number[] = []; // 买卡转化率(同比)

      for (let item of data) {
        if (item.shopName === '小计' && !item.employeeName) continue;
        axis.push(item.employeeName);
        buyRatios.push(+Number(item.experienceBuyRatio).toFixed(2) || 0);
        perBuyRatios.push(+Number(item.experienceBuyRatioPer).toFixed(2) || 0);
      }

      let oneScreenValue = isMobile.value ? 5 : 25, // 横向 一屏数据展示的基准值
        dataZoom = [
          {
            type: isMobile.value ? 'inside' : 'slider',
            start: 0,
            end: Math.floor((oneScreenValue * 100) / (axis.length || oneScreenValue)),
            zoomLock: !isMobile.value,
            zoomOnMouseWheel: false,
            brushSelect: false,
            padding: [10, 20, 10, 20]
          }
        ];

      chartData.value = {
        xAxisBoundaryGap: true,
        yAxisUnit: '%',
        axis,
        series: [
          {
            type: 'bar',
            name: '买卡转化率(%)',
            data: buyRatios,
            label: { show: true, formatter: '{c}%', position: 'insideBottom' },
            barMaxWidth: 48
          },
          { type: 'line', name: '同比(%)', data: perBuyRatios, smooth: true, label: { show: true, formatter: '{c}%' } }
        ],
        // 导轨
        ...(axis.length > oneScreenValue ? { dataZoom } : {}),

        // 工具箱
        toolbox: {
          exportVisible: true,
          // 此处写导出逻辑
          exportPort: () => {
            ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
              useDownload({
                port: exportShopMemberExperienceAndBuyCardExperienceBuyRatioChartDataPort,
                fileName: '买卡转换率',
                params
              })
            );
          }
        }
      };
    }
  } catch (e) {
    console.log('e : ', e);
  }
};

// 导出销售类别结构
const exportTableData = () => {
  let { shopIdList, startMonth, endMonth, positionType } = toValue(searchParams);
  let params = { shopIdList, startMonth, endMonth, positionType };
  ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
    useDownload({
      port: exportMemberExperienceTablePort,
      fileName: '员工体验顾客管理-体验顾客表',
      params
    })
  );
};
</script>
