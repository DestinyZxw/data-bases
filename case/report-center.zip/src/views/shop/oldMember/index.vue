<template>
  <div class="table-box">
    <div class="card table-search pb0">
      <RubSearchForm
        read-auth-code="MENU_OLD_MEMBER_MANAGE_READ"
        isPositionType
        @init="handleSearch"
        @search="handleSearch"
        @reset="handleReset"
      />
    </div>

    <el-card
      shadow="hover"
      :body-style="{
        padding: '15px',
        flex: 1,
        height: 'calc(100% - 80px)',
        display: 'flex',
        flexDirection: 'column',
        boxSizing: 'border-box'
      }"
      class="table-main"
    >
      <template #header>
        <div class="flex items-center h-30">
          <div class="font-bold">员工老会员管理</div>
        </div>
      </template>
      <view class="flex justify-end mb16">
        <el-button type="primary" plain size="small" @click="exportTableData">
          导出<el-icon class="el-icon--right"><Download /></el-icon>
        </el-button>
      </view>
      <el-table :data="tableData" class="wp-100" border>
        <el-table-column prop="shopName" label="门店" align="center" min-width="120" />
        <el-table-column prop="employeeName" label="姓名" align="center" min-width="120" />
        <el-table-column label="老会员人次" align="center">
          <template #header>
            老会员人次
            <el-tooltip class="box-item" effect="dark" placement="top">
              <template #content>
                <div style="max-width: 360px">{{ getQuestionMapItem(208) }}</div>
              </template>
              <el-icon class="pointer" size="20" color="#333">
                <Warning />
              </el-icon>
            </el-tooltip>
          </template>
          <el-table-column prop="perPerson" label="实际" align="center" min-width="120">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'perPerson') }} </template>
          </el-table-column>
          <el-table-column prop="achieveRatio" label="达成(%)" align="center" min-width="120">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'achieveRatio') }} </template>
          </el-table-column>
          <el-table-column prop="perPersonIncreasePer" label="同比(%)" align="center" min-width="120">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'perPersonIncreasePer') }} </template>
          </el-table-column>
        </el-table-column>
        <el-table-column label="人次客单" align="center">
          <template #header>
            人次客单
            <el-tooltip class="box-item" effect="dark" placement="top">
              <template #content>
                <div style="max-width: 360px">{{ getQuestionMapItem(209) }}</div>
              </template>
              <el-icon class="pointer" size="20" color="#333">
                <Warning />
              </el-icon>
            </el-tooltip>
          </template>
          <el-table-column prop="perPersonAmount" label="实际" align="center" min-width="120">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'perPersonAmount') }} </template>
          </el-table-column>
          <el-table-column prop="perPersonAmountIncreasePer" label="同比(%)" align="center" min-width="120">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'perPersonAmountIncreasePer') }} </template>
          </el-table-column>
        </el-table-column>
        <el-table-column label="老会员人数" align="center">
          <template #header>
            老会员人数
            <el-tooltip class="box-item" effect="dark" placement="top">
              <template #content>
                <div style="max-width: 360px">{{ getQuestionMapItem(210) }}</div>
              </template>
              <el-icon class="pointer" size="20" color="#333">
                <Warning />
              </el-icon>
            </el-tooltip>
          </template>
          <el-table-column prop="personCount" label="实际" align="center" min-width="120">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'personCount') }} </template>
          </el-table-column>
          <el-table-column prop="prePersonCountIncreasePer" label="同比(%)" align="center" min-width="120">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'prePersonCountIncreasePer') }} </template>
          </el-table-column>
        </el-table-column>
        <el-table-column label="人数客单" align="center">
          <template #header>
            人数客单
            <el-tooltip class="box-item" effect="dark" placement="top">
              <template #content>
                <div style="max-width: 360px">{{ getQuestionMapItem(63) }}</div>
              </template>
              <el-icon class="pointer" size="20" color="#333">
                <Warning />
              </el-icon>
            </el-tooltip>
          </template>
          <el-table-column prop="personCountAmount" label="实际" align="center" min-width="120">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'personCountAmount') }} </template>
          </el-table-column>
          <el-table-column prop="personCountAmountIncreasePer" label="同比(%)" align="center" min-width="120">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'personCountAmountIncreasePer') }} </template>
          </el-table-column>
        </el-table-column>
        <el-table-column label="到店频次" align="center">
          <template #header>
            到店频次
            <el-tooltip class="box-item" effect="dark" placement="top">
              <template #content>
                <div style="max-width: 360px">{{ getQuestionMapItem(212) }}</div>
              </template>
              <el-icon class="pointer" size="20" color="#333">
                <Warning />
              </el-icon>
            </el-tooltip>
          </template>
          <el-table-column prop="visitFreq" label="本期" align="center" min-width="120">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'visitFreq') }} </template>
          </el-table-column>
          <el-table-column prop="preVisitFreq" label="同期" align="center" min-width="120">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'preVisitFreq') }} </template>
          </el-table-column>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<!-- 员工体验顾客 管理表 -->
<script setup lang="ts" name="shopOldMember">
import { OldMemberManagerTableItemType, getOldMemberManagerTablePort, exportOldMemberManagerTablePort } from '@/api/modules/shop';
import { SearchParamsType } from '@/components/rub-search-form/interfaces';
import { handleFilterTableRow, getQuestionMapItem } from '@/utils';
import { ElMessageBox } from 'element-plus';
import { useDownload } from '@/hooks/useDownload';

const searchParams = ref<SearchParamsType>({} as SearchParamsType);
const handleSearch = (data: SearchParamsType) => {
  searchParams.value = data;
  getTableData(data);
};

const handleReset = (data: SearchParamsType) => {
  tableData.value = [];
  handleSearch(data);
};

const tableData = ref<OldMemberManagerTableItemType[]>([]);
const getTableData = async (args: SearchParamsType) => {
  try {
    let { shopIdList, startMonth, endMonth, positionType } = toValue(args);
    let params = { shopIdList, startMonth, endMonth, positionType };
    let { val: data, success } = await getOldMemberManagerTablePort(params);
    if (success === '0') {
      tableData.value = data;
    }
  } catch (e) {
    console.log('e : ', e);
  }
};

// 导出员工老会员会员管理表
const exportTableData = () => {
  let { shopIdList, startMonth, endMonth, positionType } = toValue(searchParams);
  let params = { shopIdList, startMonth, endMonth, positionType };
  ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
    useDownload({
      port: exportOldMemberManagerTablePort,
      fileName: '员工老会员管理表',
      params
    })
  );
};
</script>
