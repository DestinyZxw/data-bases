<template>
  <RubPage>
    <template #header>
      <div class="card pb0">
        <RubSearchForm
          read-auth-code="MENU_EFFICIENCY_ANALYSE_READ"
          @init="handleSearch"
          @search="handleSearch"
          @reset="handleReset"
        />
      </div>
    </template>

    <el-card shadow="hover" class="mt14">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold">员工效能分析</div>
          <div class="fz14" style="color: var(--el-text-color-secondary)">单位: 元</div>
        </div>
      </template>
      <el-table :data="tableData" class="wp-100">
        <el-table-column prop="type" label="项目" align="center" min-width="120">
          <template #default="{ row }">
            <div
              :class="[['顾问', '美容师'].includes(row.type) ? 'font-bold tl underline pointer' : 'tc']"
              @click="handleNavToOtherPage(row.type)"
            >
              <template
                v-if="['人均顾问劳效', '人均服务人次', '人均服务人数', '人均美容师劳效', '人均工时', '翻床率'].includes(row.type)"
              >
                <div>
                  {{ handleFilterTableRow(row, 'type') }}
                  <el-tooltip class="box-item" effect="dark" placement="top">
                    <template #content>
                      <div style="max-width: 360px">{{ getQuestionNameByType(row.type) }}</div>
                    </template>
                    <el-icon class="pointer" size="20" color="#333">
                      <Warning />
                    </el-icon>
                  </el-tooltip>
                </div>
              </template>
              <template v-else>
                <div>
                  {{ handleFilterTableRow(row, 'type') }}
                </div>
              </template>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="userCount" label="员工人数" align="center" width="140">
          <template #default="{ row }">{{ handleFilterTableRow(row, 'userCount') }}</template>
        </el-table-column>
        <!--    当期    -->
        <el-table-column label="当期" align="center">
          <el-table-column prop="currentPeriodValue" label="本月实际" align="center" min-width="120">
            <template #default="{ row }">{{ handleFilterTableRow(row, 'currentPeriodValue') }}</template>
          </el-table-column>
          <el-table-column prop="prePeriodValue" label="上年实际" align="center" min-width="120">
            <template #default="{ row }">{{ handleFilterTableRow(row, 'prePeriodValue') }}</template>
          </el-table-column>
          <el-table-column prop="increasePer" label="同比增长率" align="center" min-width="120">
            <template #default="{ row }">{{ handleFilterTableRow(row, 'increasePer') }}</template>
          </el-table-column>
        </el-table-column>
        <!--    年度    -->
        <el-table-column label="年度累计" align="center">
          <el-table-column prop="currentYearValue" label="本年累计" align="center" min-width="120">
            <template #default="{ row }">{{ handleFilterTableRow(row, 'currentYearValue') }}</template>
          </el-table-column>
          <el-table-column prop="preYearValue" label="上年累计" align="center" min-width="120">
            <template #default="{ row }">{{ handleFilterTableRow(row, 'preYearValue') }}</template>
          </el-table-column>
          <el-table-column prop="yearIncreasePer" label="同比增长率" align="center" min-width="120">
            <template #default="{ row }">{{ handleFilterTableRow(row, 'yearIncreasePer') }}</template>
          </el-table-column>
        </el-table-column>
      </el-table>
    </el-card>

    <el-card shadow="hover" class="mt14">
      <template #header>
        <div class="font-bold h-30 lht30">顾客满意度总览</div>
      </template>
      <el-scrollbar>
        <div ref="barChartRef" class="chart" style="height: 600px" />
      </el-scrollbar>
    </el-card>

    <el-row :gutter="14">
      <el-col :xs="24" :sm="24" :md="12" :lg="12" class="mt14">
        <el-card shadow="hover">
          <template #header>
            <div class="font-bold h-30 lht30">专业线</div>
          </template>
          <RubRadarChart key="1" v-bind="majorLine" />
        </el-card>
      </el-col>
      <el-col :xs="24" :sm="24" :md="12" :lg="12" class="mt14">
        <el-card shadow="hover">
          <template #header>
            <div class="font-bold h-30 lht30">电话回访</div>
          </template>
          <RubRadarChart key="2" v-bind="telephoneCallback" />
        </el-card>
      </el-col>
    </el-row>

    <!--  顾客时段消费  -->
    <el-card shadow="hover" class="mt14">
      <template #header>
        <div class="font-bold h-30 lht30">顾客时段消费</div>
      </template>
      <div class="selector mb16">
        <RubSelector v-model="dateValue" :options="dateList" key="date" auth-code="MENU_EFFICIENCY_ANALYSE_READ" />
      </div>
      <div class="selector mb20">
        <RubSelector v-model="weekValue" :options="weekList" key="week" auth-code="MENU_EFFICIENCY_ANALYSE_READ" />
      </div>
      <RubEmptyTip :show="linesChartStatus">
        <el-scrollbar>
          <RubBaseChart class="chart" v-bind="linesChartData" />
        </el-scrollbar>
      </RubEmptyTip>
    </el-card>
  </RubPage>
</template>

<!-- 效能分析 管理表 -->
<script setup lang="ts" name="shopEfficiency">
import {
  getShopEfficiencyAnalyseTablePort,
  getShopMemberStatisticsTimePeriodPort,
  EfficiencyAnalyseTableItemType
} from '@/api/modules/shop';
import { SearchParamsType } from '@/components/rub-search-form/interfaces';
import { useEcharts } from '@/hooks/useEcharts';
import { EChartsOption } from 'echarts';
import type { ModelValueType, SelectorOptionItemType } from '@/components/rub-selector/index.vue';
import { Chart } from '@/typings/global';
import { handleFilterTableRow, getQuestionMapItem } from '@/utils';

const getQuestionNameByType = (data: string) => {
  let id = 0;
  // ['人均顾问劳效', '人均服务人次', '人均服务人数', '人均美容师劳效', '人均工时', '翻床率']
  switch (data) {
    case '人均顾问劳效':
      id = 192;
      break;
    case '人均服务人次':
      id = 194;
      break;
    case '人均服务人数':
      id = 195;
      break;
    case '人均美容师劳效':
      id = 201;
      break;
    case '人均工时':
      id = 203;
      break;
    case '翻床率':
      id = 53;
      break;
    default:
      break;
  }
  let tip: string = getQuestionMapItem(id);
  return tip;
};

const router = useRouter();

// 缓存搜索表单的上传至接口的数据
let searchParams: SearchParamsType = {} as SearchParamsType;

const handleSearch = (data: SearchParamsType) => {
  searchParams = data;
  getTableData(data);
  renderBarEChartsGraph();
  getSheetLineData(data);
};

const handleReset = (data: SearchParamsType) => {
  tableData.value = [];
  handleSearch(data);
  renderBarEChartsGraph();
  getSheetLineData(data);
};

const tableData = ref<EfficiencyAnalyseTableItemType[]>([]);
const getTableData = async (args: SearchParamsType) => {
  try {
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = { shopIdList, startMonth, endMonth };
    let { val: data, success } = await getShopEfficiencyAnalyseTablePort(params);
    if (success === '0') {
      tableData.value = data;
    }
  } catch (e) {
    console.log('e : ', e);
  }
};

// 顾客满意度总览的echarts图
const barChartRef = ref<HTMLDivElement | null>(null);
const barECharts = useEcharts(barChartRef as Ref<HTMLDivElement>);
const renderBarEChartsGraph = () => {
  let options = {
    color: ['#5B9BD5'],
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      }
    },
    grid: { left: '3%', right: '3%', bottom: '3%', top: '5%', containLabel: true },
    xAxis: {
      type: 'category',
      data: ['专业线', '技术线', '行政线', '电话回访', '微信问卷']
    },
    yAxis: {
      type: 'value',
      splitLine: {
        lineStyle: { color: 'transparent', type: 'dashed' },
        show: false
      },
      axisLine: {
        show: false // 隐藏Y轴的标线
      }
    },
    series: [
      {
        data: [
          /*120, 200, 150, 80, 70*/
        ],
        type: 'bar',
        markLine: {
          data: [{ type: 'average', name: '平均值', lineStyle: { color: '#83bff6' } }],
          symbol: '' // 不显示标记圆点或者箭头
        },
        barWidth: 48, // 柱子宽度，默认自适应
        label: { show: true, position: 'top' }
      }
    ]
  } as EChartsOption;

  barECharts.setOptions(options);
};

// 专业线
const majorLine = ref<Chart.RadarChartType>({ indicator: [], series: [] });
// 电话回访
const telephoneCallback = ref<Chart.RadarChartType>({ indicator: [], series: [] });
onMounted(() => {
  useTimeoutFn(() => {
    majorLine.value = {
      indicator: [
        { name: '暗访星级', max: 6500 },
        { name: '暗访考核项', max: 16000 },
        { name: '大众点评', max: 30000 },
        { name: '服务评价电访', max: 38000 },
        { name: '服务评价问卷', max: 52000 }
      ],
      series: [
        {
          type: 'radar',
          data: [
            {
              value: [
                /*3000, 14000, 21000, 36000, 31200*/
              ]
            }
          ]
        }
      ]
    };

    telephoneCallback.value = {
      indicator: [
        { name: '前台服务', max: 5000 },
        { name: '顾问服务', max: 30000 },
        { name: '美容师服务', max: 25000 },
        { name: '门店环境服务', max: 38000 }
      ],
      series: [
        {
          type: 'radar',
          data: [
            {
              value: [
                /*5000, 14000, 6800, 26000*/
              ]
            }
          ]
        }
      ]
    };
  }, 1500);
});

/** --------------顾客消费相关代码  --------------*/
// 日期选择数据
const weekNum = new Date().getDay();
const dateValue = ref<ModelValueType>(weekNum >= 1 && weekNum <= 5 ? 'G' : 'S');
const dateList: SelectorOptionItemType[] = [
  { name: '工作日', value: 'G' },
  { name: '双休日', value: 'S' },
  { name: '节假日', value: 'J' }
];

// 一周选择数据
const weekValue = ref<ModelValueType>(weekNum || 7);
const weekList: SelectorOptionItemType[] = [
  { name: '周一', value: 1 },
  { name: '周二', value: 2 },
  { name: '周三', value: 3 },
  { name: '周四', value: 4 },
  { name: '周五', value: 5 },
  { name: '周六', value: 6 },
  { name: '周日', value: 7 }
];

// 对日期和周的值 进行监听
watch([weekValue, dateValue], () => {
  getSheetLineData(searchParams);
});

// lines 线图数据
const linesChartStatus = ref<boolean>(false);
const linesChartData = ref<Chart.BaseChartType>({});
const getSheetLineData = async (args: SearchParamsType) => {
  try {
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = {
      shopIdList,
      startMonth,
      endMonth,
      festivalList: [dateValue.value],
      weekday: weekValue.value
    };
    let { val: data, success } = await getShopMemberStatisticsTimePeriodPort(params);
    if (success === '0') {
      linesChartStatus.value = !!data.length;
      if (!data.length) return;
      let axis: string[] = [];
      let series: number[] = [];
      for (let item of data) {
        axis.push(`${Number(item.timePeriod)}时`);
        series.push(item.count);
      }
      linesChartData.value = {
        title: '消费人数监控',
        grid: { bottom: 0 },
        axis,
        series: [
          {
            type: 'line',
            data: series,
            smooth: true,
            areaStyle: {},
            emphasis: {
              focus: 'series'
            },
            label: {
              show: true
            },
            showSymbol: true
          }
        ],
        colors: ['#5B9BD5']
      };
    }
  } catch (e) {
    console.log('e : ', e);
  }
};

// 导航到其他页面
const handleNavToOtherPage = (type: string) => {
  const maps = new Map([
    ['顾问', 'shopConsultant'],
    ['美容师', 'shopBeautician']
  ]);
  const routerName: string | undefined = maps.get(type);
  routerName && router.push({ name: routerName });
};
</script>
