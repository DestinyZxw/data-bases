<template>
  <div class="table-box">
    <div class="card table-search pb0">
      <RubSearchForm read-auth-code="MENU_MEMBER_SUMMARY_READ" @init="handleSearch" @search="handleSearch" @reset="handleReset" />
    </div>

    <el-card
      shadow="hover"
      :body-style="{
        padding: '15px',
        flex: 1,
        height: 'calc(100% - 80px)',
        display: 'flex',
        flexDirection: 'column',
        boxSizing: 'border-box'
      }"
      class="table-main"
    >
      <template #header>
        <div class="flex items-center h-30">
          <div class="font-bold">顾客分析</div>
        </div>
      </template>
      <el-table v-loading="tableLoading" :data="tableData" class="wp-100">
        <el-table-column prop="type" label="项目" align="center" min-width="160">
          <template #default="{ row }">
            <div
              :class="[['体验顾客', '新会员', '老会员'].includes(row.type) ? 'font-bold tl underline pointer' : 'pl10 tc']"
              @click="handleNavToOtherPage(row.type)"
            >
              {{ (row as CustomerReportTableItemType).type }}
            </div>
          </template>
        </el-table-column>
        <!--    当期    -->
        <el-table-column label="当期" align="center">
          <el-table-column prop="amount" label="本月实际" align="center" min-width="120">
            <template #default="{ row }"> {{ handleFilterTableCell(row, 'amount') }} </template>
          </el-table-column>
          <el-table-column prop="target" label="本月目标" align="center" min-width="120">
            <template #default="{ row }"> {{ handleFilterTableCell(row, 'target') }} </template>
          </el-table-column>
          <el-table-column prop="spAmount" label="上年实际" align="center" min-width="120">
            <template #default="{ row }"> {{ handleFilterTableCell(row, 'spAmount') }} </template>
          </el-table-column>
          <el-table-column prop="completionRate" label="月达成率" align="center" min-width="100">
            <template #default="{ row }"> {{ handleFilterTableCell(row, 'completionRate') }} </template>
          </el-table-column>
          <el-table-column prop="increasePer" label="同比增长率" align="center" min-width="100">
            <template #default="{ row }"> {{ handleFilterTableCell(row, 'increasePer') }} </template>
          </el-table-column>
        </el-table-column>
        <!--    年度    -->
        <el-table-column label="年度累计" align="center">
          <el-table-column prop="yearAmount" label="本年累计" align="center" min-width="120">
            <template #default="{ row }"> {{ handleFilterTableCell(row, 'yearAmount') }} </template>
          </el-table-column>
          <el-table-column prop="yearTarget" label="本年目标" align="center" min-width="120">
            <template #default="{ row }"> {{ handleFilterTableCell(row, 'yearTarget') }} </template>
          </el-table-column>
          <el-table-column prop="spYearAmount" label="上年累计" align="center" min-width="120">
            <template #default="{ row }"> {{ handleFilterTableCell(row, 'spYearAmount') }} </template>
          </el-table-column>
          <el-table-column prop="yearCompletionRate" label="年达成率" align="center" min-width="100">
            <template #default="{ row }"> {{ handleFilterTableCell(row, 'yearCompletionRate') }} </template>
          </el-table-column>
          <el-table-column label="同比增长率" align="center" min-width="100">
            <template #default="{ row }"> {{ handleFilterTableCell(row, 'yearIncreasePer') }} </template>
          </el-table-column>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<!-- 顾客分析 管理表 -->
<script setup lang="ts" name="shopCustomer">
import { getShopCustomerReportTablePort, CustomerReportTableItemType } from '@/api/modules/shop';
import { SearchParamsType } from '@/components/rub-search-form/interfaces';

const router = useRouter();

const handleSearch = (data: SearchParamsType) => {
  getTableData(data);
};

const handleReset = (data: SearchParamsType) => {
  tableData.value = [];
  handleSearch(data);
};

const tableData = ref<CustomerReportTableItemType[]>([]);
const tableLoading = ref(false);

const getTableData = async (args: SearchParamsType) => {
  try {
    tableLoading.value = true;
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = { shopIdList, startMonth, endMonth };
    let { val: data, success } = await getShopCustomerReportTablePort(params);
    if (success === '0') {
      const tmp: CustomerReportTableItemType[] = [];
      for (let it of data) {
        if (it.type === '体验顾客人数') {
          tmp.push({ type: '体验顾客' } as CustomerReportTableItemType);
          tmp.push(it);
        } else if (it.type === '复购人数') {
          tmp.push({ type: '新会员' } as CustomerReportTableItemType);
          tmp.push(it);
        } else if (it.type === '人均护理产出=180天') {
          tmp.push({ type: '人均护理业绩产出' } as CustomerReportTableItemType);
          tmp.push({ ...it, type: '=180天' });
        } else if (it.type === '人均护理产出=360天') {
          tmp.push({ ...it, type: '=360天' });
        } else if (it.type === '人均产品产出=180天') {
          tmp.push({ type: '人均产品业绩产出' } as CustomerReportTableItemType);
          tmp.push({ ...it, type: '=180天' });
        } else if (it.type === '人均产品产出=360天') {
          tmp.push({ ...it, type: '=360天' });
        } else if (it.type === '老会员人次') {
          tmp.push({ type: '老会员' } as CustomerReportTableItemType);
          tmp.push(it);
        } else {
          tmp.push(it);
        }
      }
      tableData.value = tmp;
    }
  } catch (e) {
    console.log('e : ', e);
  } finally {
    tableLoading.value = false;
  }
};

// 对 table 单元格的数据进行解析
const handleFilterTableCell = (row: CustomerReportTableItemType, key: keyof CustomerReportTableItemType) => {
  const maps = ['体验顾客', '新会员', '老会员', '人均护理业绩产出', '人均产品业绩产出'];
  const maps2 = ['体验客人次占比', '新会员人次占比', '老会员人次占比', '买卡成功率', '复购率', '翻床率'];
  const value = row[key];
  if (maps.includes(row.type)) {
    return null;
  } else if (maps2.includes(row.type) || key.endsWith('Rate') || key.endsWith('Per')) {
    return value || value === 0 ? `${value}%` : '/';
  }
  return value || value === 0 ? value : '/';
};

// 导航到其他页面
const handleNavToOtherPage = (type: string) => {
  const maps = new Map([
    ['体验顾客', 'shopExperience'],
    ['新会员', 'shopNewMember'],
    ['老会员', 'shopOldMember']
  ]);
  const routerName: string | undefined = maps.get(type);
  routerName && router.push({ name: routerName });
};
</script>
