<template>
  <RubPage>
    <template #header>
      <div class="card pb0">
        <RubSearchForm
          read-auth-code="MENU_EXCLUSIVE_CONSULTANT_MEMBER_MANAGE_READ"
          @init="handleSearch"
          @search="handleSearch"
          @reset="handleReset"
        />
      </div>
    </template>

    <el-card shadow="hover" class="mt14">
      <template #header>
        <div class="flex items-center h-30">
          <div class="font-bold">顾问专属会员管理</div>
        </div>
      </template>
      <view class="flex justify-end mb16">
        <el-button type="primary" plain size="small" @click="exportTableData">
          导出<el-icon class="el-icon--right"><Download /></el-icon>
        </el-button>
      </view>
      <el-table :data="tableData" class="wp-100" border height="660">
        <el-table-column prop="shopName" label="门店" align="center" min-width="120" />
        <el-table-column prop="employeeName" label="顾问姓名" align="center" min-width="120" />
        <el-table-column prop="personCount" label="专属管理人数" align="center" min-width="120">
          <template #header>
            专属管理人数
            <el-tooltip class="box-item" effect="dark" placement="top">
              <template #content>
                <div style="max-width: 360px">{{ getQuestionMapItem(234) }}</div>
              </template>
              <el-icon class="pointer" size="20" color="#333">
                <Warning />
              </el-icon>
            </el-tooltip>
          </template>
          <template #default="{ row }"> {{ handleFilterTableRow(row, 'personCount') }} </template>
        </el-table-column>
        <el-table-column prop="visitPersonCount" label="专属进店人数" align="center" min-width="120">
          <template #header>
            专属进店人数
            <el-tooltip class="box-item" effect="dark" placement="top">
              <template #content>
                <div style="max-width: 360px">{{ getQuestionMapItem(235) }}</div>
              </template>
              <el-icon class="pointer" size="20" color="#333">
                <Warning />
              </el-icon>
            </el-tooltip>
          </template>
          <template #default="{ row }"> {{ handleFilterTableRow(row, 'visitPersonCount') }} </template>
        </el-table-column>
        <el-table-column prop="visitRatio" label="专属进店率" align="center" min-width="120">
          <template #header>
            专属进店率
            <el-tooltip class="box-item" effect="dark" placement="top">
              <template #content>
                <div style="max-width: 360px">{{ getQuestionMapItem(236) }}</div>
              </template>
              <el-icon class="pointer" size="20" color="#333">
                <Warning />
              </el-icon>
            </el-tooltip>
          </template>
          <template #default="{ row }"> {{ handleFilterTableRow(row, 'visitRatio') }} </template>
        </el-table-column>
        <el-table-column prop="personCountAmount" label="专属人数客单" align="center" min-width="120">
          <template #header>
            专属人数客单
            <el-tooltip class="box-item" effect="dark" placement="top">
              <template #content>
                <div style="max-width: 360px">{{ getQuestionMapItem(238) }}</div>
              </template>
              <el-icon class="pointer" size="20" color="#333">
                <Warning />
              </el-icon>
            </el-tooltip>
          </template>
          <template #default="{ row }"> {{ handleFilterTableRow(row, 'personCountAmount') }} </template>
        </el-table-column>
        <el-table-column prop="visitPerPerson" label="专属人次" align="center" min-width="120">
          <template #header>
            专属人次
            <el-tooltip class="box-item" effect="dark" placement="top">
              <template #content>
                <div style="max-width: 360px">{{ getQuestionMapItem(239) }}</div>
              </template>
              <el-icon class="pointer" size="20" color="#333">
                <Warning />
              </el-icon>
            </el-tooltip>
          </template>
          <template #default="{ row }"> {{ handleFilterTableRow(row, 'visitPerPerson') }} </template>
        </el-table-column>
        <el-table-column prop="perPersonAmount" label="专属人次客单" align="center" min-width="120">
          <template #header>
            专属人次客单
            <el-tooltip class="box-item" effect="dark" placement="top">
              <template #content>
                <div style="max-width: 360px">{{ getQuestionMapItem(240) }}</div>
              </template>
              <el-icon class="pointer" size="20" color="#333">
                <Warning />
              </el-icon>
            </el-tooltip>
          </template>
          <template #default="{ row }"> {{ handleFilterTableRow(row, 'perPersonAmount') }} </template>
        </el-table-column>
        <el-table-column prop="visitFreq" label="专属频次" align="center" min-width="120">
          <template #header>
            专属频次
            <el-tooltip class="box-item" effect="dark" placement="top">
              <template #content>
                <div style="max-width: 360px">{{ getQuestionMapItem(241) }}</div>
              </template>
              <el-icon class="pointer" size="20" color="#333">
                <Warning />
              </el-icon>
            </el-tooltip>
          </template>
          <template #default="{ row }"> {{ handleFilterTableRow(row, 'visitFreq') }} </template>
        </el-table-column>
        <el-table-column prop="personChurnRatio" label="老会员流失率" align="center" min-width="120">
          <template #header>
            老会员流失率
            <el-tooltip class="box-item" effect="dark" placement="top">
              <template #content>
                <div style="max-width: 360px">{{ getQuestionMapItem(213) }}</div>
              </template>
              <el-icon class="pointer" size="20" color="#333">
                <Warning />
              </el-icon>
            </el-tooltip>
          </template>
          <template #default="{ row }"> {{ handleFilterTableRow(row, 'personChurnRatio') }} </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-row :gutter="10">
      <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12">
        <el-card shadow="hover" class="mt14 pr">
          <template #header>
            <div class="flex items-center justify-between h-30">
              <div class="font-bold">护理人数及客单</div>
            </div>
          </template>
          <RubEmptyTip :show="consultantExclusiveMemberStatus">
            <RubDoubleYAxisChart v-bind="nurseBarLineChartData" style="height: 480px" />
          </RubEmptyTip>
        </el-card>
      </el-col>
      <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12">
        <el-card shadow="hover" class="mt14 pr">
          <template #header>
            <div class="flex items-center justify-between h-30">
              <div class="font-bold">护理购买人数占比</div>
            </div>
          </template>
          <RubEmptyTip :show="consultantExclusiveMemberStatus">
            <RubVerticalBarChart v-bind="nurseVerticalBarChartData" style="height: 480px" />
          </RubEmptyTip>
        </el-card>
      </el-col>
      <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12">
        <el-card shadow="hover" class="mt14 pr">
          <template #header>
            <div class="flex items-center justify-between h-30">
              <div class="font-bold">产品人数及客单</div>
            </div>
          </template>
          <RubEmptyTip :show="consultantExclusiveMemberStatus">
            <RubDoubleYAxisChart v-bind="productBarLineChartData" style="height: 480px" />
          </RubEmptyTip>
        </el-card>
      </el-col>
      <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12">
        <el-card shadow="hover" class="mt14 pr">
          <template #header>
            <div class="flex items-center justify-between h-30">
              <div class="font-bold">产品购买人数占比</div>
            </div>
          </template>
          <RubEmptyTip :show="consultantExclusiveMemberStatus">
            <RubVerticalBarChart v-bind="productVerticalBarChartData" style="height: 480px" />
          </RubEmptyTip>
        </el-card>
      </el-col>
    </el-row>

    <el-card shadow="hover" class="mt14 pr">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold">老会员流失率</div>
        </div>
      </template>
      <el-scrollbar>
        <RubBaseChart v-bind="oldMemberChartData" class="pt10" />
      </el-scrollbar>
    </el-card>
  </RubPage>
</template>

<!-- 员工专属会员 管理表 -->
<script setup lang="ts" name="shopExclusiveMember">
import {
  ConsultantExclusiveMemberTableItemType,
  getConsultantExclusiveMemberTablePort,
  exportConsultantExclusiveMemberTablePort,
  getConsultantExclusiveMemberChartDataPort,
  exportConsultantExclusiveNursingMemberPersonCountAndAmountChartDataPort,
  exportConsultantExclusiveProductMemberPersonCountAndAmountChartDataPort,
  exportConsultantExclusiveMemberManagePersonChurnRatioChartDataPort
} from '@/api/modules/shop';
import { SearchParamsType } from '@/components/rub-search-form/interfaces';
import { Chart } from '@/typings/global';
import { useGlobalStore } from '@/stores/modules/global';
import { handleFilterTableRow, getQuestionMapItem } from '@/utils';
import { ElMessageBox } from 'element-plus';
import { useDownload } from '@/hooks/useDownload';

const globalStore = useGlobalStore();
const isMobile = computed(() => globalStore.device === 'mobile');

const searchParams = ref<SearchParamsType>({} as SearchParamsType);
const handleSearch = (data: SearchParamsType) => {
  searchParams.value = data;
  getTableData(data);
  getConsultantExclusiveMemberChartData(data);
};

const handleReset = (data: SearchParamsType) => {
  tableData.value = [];
  handleSearch(data);
};

const tableData = ref<ConsultantExclusiveMemberTableItemType[]>([]);
// 老会员流失率 当前数据
const oldMemberChartStatus = ref<boolean>(false);
const oldMemberChartData = ref<Chart.BaseChartType>({});

const getTableData = async (args: SearchParamsType) => {
  try {
    let { shopIdList, startMonth, endMonth } = toValue(args),
      params = { shopIdList, startMonth, endMonth },
      { val: data, success } = await getConsultantExclusiveMemberTablePort(params);
    if (success === '0') {
      tableData.value = data;

      oldMemberChartStatus.value = !!data.length;
      if (!data.length) return;

      let axis: string[] = [],
        personChurnRatios: number[] = [], // 老会员流失率
        perPersonChurnRatios: number[] = []; // 老会员流失率(同比)

      for (let item of data) {
        if (item.shopName === '小计' && !item.employeeName) continue;
        axis.push(item.employeeName);
        personChurnRatios.push(+Number(item.personChurnRatio).toFixed(2) || 0);
        perPersonChurnRatios.push(+Number(item.personChurnRatioIncreasePer).toFixed(2) || 0);
      }
      let oneScreenValue = isMobile.value ? 5 : 25, // 横向 一屏数据展示的基准值
        dataZoom = [
          {
            type: isMobile.value ? 'inside' : 'slider',
            start: 0,
            end: Math.floor((oneScreenValue * 100) / (axis.length || oneScreenValue)),
            zoomLock: !isMobile.value,
            zoomOnMouseWheel: false,
            brushSelect: false,
            padding: [10, 20, 10, 20]
          }
        ];

      oldMemberChartData.value = {
        colors: ['#5B9BD5', '#ED7D31'],
        xAxisBoundaryGap: true,
        yAxisUnit: '%',
        axis,
        series: [
          {
            type: 'bar',
            name: '老会员流失率(%)',
            data: personChurnRatios,
            label: { show: true, formatter: '{c}%', position: 'top' },
            barMaxWidth: 48
          },
          { type: 'line', name: '同比(%)', data: perPersonChurnRatios, smooth: true, label: { show: true, formatter: '{c}%' } }
        ],
        // 导轨
        ...(axis.length > oneScreenValue ? { dataZoom } : {}),
        // 工具箱
        toolbox: {
          exportVisible: true,
          // 此处写导出逻辑
          exportPort: () => {
            ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
              useDownload({
                port: exportConsultantExclusiveMemberManagePersonChurnRatioChartDataPort,
                fileName: '老会员流失率',
                params
              })
            );
          }
        }
      };
    }
  } catch (e) {
    console.log('e : ', e);
  }
};

// 导出顾问专属会员管理表
const exportTableData = () => {
  let { shopIdList, startMonth, endMonth } = toValue(searchParams),
    params = { shopIdList, startMonth, endMonth };
  ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
    useDownload({
      port: exportConsultantExclusiveMemberTablePort,
      fileName: '顾问专属会员管理表',
      params
    })
  );
};

// 护理人数及客单charts图表数据
const nurseBarLineChartData = ref<Chart.DoubleYAxisChartType>({});
// 护理购买人数占比charts图表数据
const nurseVerticalBarChartData = ref<Chart.VerticalBarChartType>({});

// 产品人数及客单charts图表数据
const productBarLineChartData = ref<Chart.DoubleYAxisChartType>({});
// 产品购买人数占比charts图表数据
const productVerticalBarChartData = ref<Chart.VerticalBarChartType>({});

// 获取四个小图表的数据
const consultantExclusiveMemberStatus = ref(false);
const getConsultantExclusiveMemberChartData = async (args: SearchParamsType) => {
  try {
    let { shopIdList, startMonth, endMonth } = toValue(args),
      params = { shopIdList, startMonth, endMonth },
      { val: data, success } = await getConsultantExclusiveMemberChartDataPort(params);
    if (success === '0') {
      consultantExclusiveMemberStatus.value = !!data.length;
      if (!data.length) return;

      let axis: string[] = [],
        nursingPersonCounts: number[] = [],
        nursingPersonCountAmounts: number[] = [],
        productBuyPersonCounts: number[] = [],
        productBuyPersonCountAmounts: number[] = [],
        nursingPersonCountRatios: number[] = [],
        productBuyPersonCountRatios: number[] = [];

      for (let item of data) {
        axis.push(item.employeeName);
        nursingPersonCounts.push(item.nursingPersonCount);
        nursingPersonCountAmounts.push(item.nursingPersonCountAmount);
        productBuyPersonCounts.push(item.productBuyPersonCount);
        productBuyPersonCountAmounts.push(item.productBuyPersonCountAmount);
        nursingPersonCountRatios.push(item.nursingPersonCountRatio);
        productBuyPersonCountRatios.push(item.productBuyPersonCountRatio);
      }

      let horizontalOneScreenValue = isMobile.value ? 5 : 12, // 横向 一屏数据展示的基准值
        verticalOneScreenValue = 12, // 纵向 一屏数据展示的基准值
        // 横向导轨
        horizontalDataZoom = [
          {
            type: isMobile.value ? 'inside' : 'slider',
            start: 0,
            end: Math.floor((horizontalOneScreenValue * 100) / (axis.length || horizontalOneScreenValue)),
            zoomLock: !isMobile.value,
            zoomOnMouseWheel: false,
            brushSelect: false,
            padding: [10, 20, 10, 20]
          }
        ],
        // 纵向导轨
        verticalDataZoom = [
          {
            type: isMobile.value ? 'inside' : 'slider',
            orient: 'vertical',
            start: 100,
            end: 100 - Math.floor((verticalOneScreenValue * 100) / (axis.length || verticalOneScreenValue)),
            zoomLock: !isMobile.value,
            zoomOnMouseWheel: false,
            brushSelect: false,
            padding: [10, 20, 10, 20]
          }
        ];

      // 护理人数及客单
      nurseBarLineChartData.value = {
        xAxisLabelRotate: 0,
        yAxisNameVisible: false,
        yAxisRightUnit: '',
        grid: { top: '10%', right: '8%' },
        axis,
        series: [
          {
            name: '护理购买人数',
            type: 'bar',
            data: nursingPersonCounts,
            label: { show: true, position: 'top' },
            barMaxWidth: 48
          },
          {
            name: '护理人数客单',
            type: 'line',
            data: nursingPersonCountAmounts,
            yAxisIndex: 1,
            smooth: true,
            label: { show: true }
          }
        ],
        colors: ['#ED7D31', '#4472C4'],
        ...(axis.length > horizontalOneScreenValue ? { dataZoom: horizontalDataZoom } : {}),
        // 工具箱
        toolbox: {
          exportVisible: true,
          // 此处写导出逻辑
          exportPort: () => {
            ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
              useDownload({
                port: exportConsultantExclusiveNursingMemberPersonCountAndAmountChartDataPort,
                fileName: '护理人数及客单',
                params
              })
            );
          }
        }
      };

      // 产品人数及客单
      productBarLineChartData.value = {
        xAxisLabelRotate: 0,
        yAxisNameVisible: false,
        yAxisRightUnit: '',
        grid: { top: '10%', right: '8%' },
        axis,
        series: [
          {
            name: '产品购买人数',
            type: 'bar',
            data: productBuyPersonCounts,
            label: { show: true, position: 'top' },
            barMaxWidth: 48
          },
          {
            name: '产品人数客单',
            type: 'line',
            data: productBuyPersonCountAmounts,
            yAxisIndex: 1,
            smooth: true,
            label: { show: true }
          }
        ],
        colors: ['#4472C4', '#ED7D31'],
        ...(axis.length > horizontalOneScreenValue ? { dataZoom: horizontalDataZoom } : {}),
        // 工具箱
        toolbox: {
          exportVisible: true,
          // 此处写导出逻辑
          exportPort: () => {
            ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
              useDownload({
                port: exportConsultantExclusiveProductMemberPersonCountAndAmountChartDataPort,
                fileName: '产品人数及客单',
                params
              })
            );
          }
        }
      };

      // 护理人数及客单占比
      nurseVerticalBarChartData.value = {
        colors: ['#ED7D31'],
        axis,
        seriesData: nursingPersonCountRatios,
        labelShow: true,
        labelUnit: '%',
        ...(axis.length > verticalOneScreenValue ? { dataZoom: verticalDataZoom } : {})
      };

      // 产品人数及客单占比
      productVerticalBarChartData.value = {
        colors: ['#4472C4'],
        axis,
        seriesData: productBuyPersonCountRatios,
        labelShow: true,
        labelUnit: '%',
        ...(axis.length > verticalOneScreenValue ? { dataZoom: verticalDataZoom } : {})
      };
    }
  } catch (e) {
    console.log('e : ', e);
  }
};
</script>
