<template>
  <RubPage>
    <template #header>
      <div class="card pb0">
        <RubSearchForm read-auth-code="MENU_NURSING_SALE_READ" @init="handleSearch" @search="handleSearch" @reset="handleReset" />
      </div>
    </template>
    <el-row :gutter="14">
      <el-col :xs="24" :sm="24" :md="14" :lg="16" class="mt14">
        <el-card shadow="hover">
          <template #header>
            <div class="flex items-center justify-between h-30">
              <div class="font-bold">销售类别结构</div>
              <div class="fz14" style="color: var(--el-text-color-secondary)">单位: 万元</div>
            </div>
          </template>
          <view class="flex justify-end mb16">
            <el-button type="primary" plain size="small" @click="exportTableData">
              导出<el-icon class="el-icon--right"><Download /></el-icon>
            </el-button>
          </view>
          <el-table :data="tableData" class="wp-100" border style="height: 500px">
            <el-table-column prop="nursingServicePositionName" label="分类" align="center" width="140" />
            <el-table-column prop="subtotalSalesCount" label="销售数量" align="center">
              <template #default="{ row }">{{ handleFilterTableRow(row, 'subtotalSalesCount') }}</template>
            </el-table-column>
            <el-table-column prop="salesCountRatio" label="数量结构(%)" align="center">
              <template #default="{ row }">{{ handleFilterTableRow(row, 'salesCountRatio') }}</template>
            </el-table-column>
            <el-table-column prop="subtotalSalesAmount" label="销售金额" align="center">
              <template #default="{ row }">{{ handleFilterTableRow(row, 'subtotalSalesAmount') }}</template>
            </el-table-column>
            <el-table-column prop="salesAmountRatio" label="销售结构(%)" align="center">
              <template #default="{ row }">{{ handleFilterTableRow(row, 'salesAmountRatio') }}</template>
            </el-table-column>
            <el-table-column prop="grossMargin" label="毛利率" align="center">
              <template #default="{ row }">{{ handleFilterTableRow(row, 'grossMargin') }}</template>
            </el-table-column>
            <el-table-column prop="grossMarginSigma" label="∑毛利率" align="center">
              <template #default="{ row }">{{ handleFilterTableRow(row, 'grossMarginSigma') }}</template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>
      <el-col :xs="24" :sm="24" :md="10" :lg="8" class="mt14">
        <el-card shadow="hover">
          <template #header>
            <div class="font-bold h-30 lht30">销售结构(%)</div>
          </template>
          <RubEmptyTip :show="pieChartsStatus">
            <RubPieChart v-bind="pieChartsData" style="height: 540px" />
          </RubEmptyTip>
        </el-card>
      </el-col>
    </el-row>

    <el-card shadow="hover" class="mt14" :body-style="{ 'padding-bottom': '6px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold">护理分析</div>
        </div>
      </template>
      <div class="selector mb14">
        <RubSelector v-model="selectorValue" :options="selectorOptions" auth-code="MENU_NURSING_SALE_READ" />
      </div>
      <el-card class="mb20">
        <RubEmptyTip :show="nursingServiceAnalyseStatus">
          <el-scrollbar>
            <RubDoubleYAxisChart class="chart" v-bind="nurseParetoChartData" />
          </el-scrollbar>
        </RubEmptyTip>
      </el-card>
      <el-row :gutter="14">
        <el-col :xs="24" :sm="24" :md="14" :lg="16">
          <div style="color: var(--el-color-white); background-color: #5b9bd5" class="lht30 fz16 mb14 pl10">
            从销量和毛利额来看
          </div>
          <el-card class="mb14">
            <RubEmptyTip :show="nursingServiceAnalyseStatus">
              <el-scrollbar>
                <FourQuadrantChart v-bind="faceGrossProfitMarginData" key="first" />
              </el-scrollbar>
            </RubEmptyTip>
          </el-card>
          <el-card class="mb14">
            <RubEmptyTip :show="nursingServiceAnalyseStatus">
              <el-scrollbar>
                <FourQuadrantChart v-bind="faceGrossProfitRateData" key="second" />
              </el-scrollbar>
            </RubEmptyTip>
          </el-card>
        </el-col>
        <el-col :xs="24" :sm="24" :md="10" :lg="8">
          <div style="color: var(--el-color-white); background-color: #1f4e78" class="lht30 fz16 mb14 pl10">小时毛利排名</div>
          <el-card v-loading="nurseHourlyGrossProfitLoading" class="mb14" :body-style="{ padding: '20px 10px' }">
            <RubEmptyTip :show="verticalBarChartsStatus">
              <el-scrollbar>
                <RubVerticalBarChart
                  v-bind="verticalBarChartsData"
                  :style="{ width: device === 'mobile' ? '500px' : '100%', height: '1416px' }"
                />
              </el-scrollbar>
            </RubEmptyTip>
          </el-card>
        </el-col>
      </el-row>
    </el-card>
  </RubPage>
</template>

<!-- 护理销售管理表 -->
<script setup lang="ts" name="shopNurse">
import {
  getNursingSaleAnalyseTablePort,
  NursingSaleAnalyseTableItemType,
  getNursingServiceAnalysePort,
  exportNursingSaleAnalysePort,
  getNursingServiceHourlyGrossProfitPort,
  exportNursingServiceAnalyseHighFrequencyParetoChartDataPort,
  exportNursingServiceAnalyseHighFrequencyItemMatrix1ChartDataPort,
  exportNursingServiceAnalyseHighFrequencyItemMatrix2ChartDataPort
} from '@/api/modules/shop';
import { SearchParamsType } from '@/components/rub-search-form/interfaces';
import { Chart } from '@/typings/global';
import { useGlobalStore } from '@/stores/modules/global';
import FourQuadrantChart from '../components/four-quadrant-chart.vue';
import { handleFilterTableRow } from '@/utils';
import type { ModelValueType, SelectorOptionItemType } from '@/components/rub-selector/index.vue';
import { ElMessageBox } from 'element-plus';
import { useDownload } from '@/hooks/useDownload';

const globalStore = useGlobalStore();
const { device } = storeToRefs(globalStore);

const searchParams = ref<SearchParamsType>({} as SearchParamsType);
const handleSearch = (data: SearchParamsType) => {
  searchParams.value = data;
  getTableData(data);
  getNursingServiceAnalyseData();
  getNursingServiceHourlyGrossProfitData();
};

const handleReset = (data: SearchParamsType) => {
  searchParams.value = data;
  selectorValue.value = 'A';
  getTableData(data);
};

// table表格数据
const tableData = ref<NursingSaleAnalyseTableItemType[]>([]);

// pie 饼图数据
const pieChartsStatus = ref<boolean>(false);
const pieChartsData = ref<Chart.PieChartType>({} as Chart.PieChartType);

const getTableData = async (args: SearchParamsType) => {
  try {
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = { shopIdList, startMonth, endMonth };
    let { val: data, success } = await getNursingSaleAnalyseTablePort(params);
    if (success === '0') {
      // 表格数据
      tableData.value = data;
      pieChartsStatus.value = !!data.length;
      if (!data.length) return;
      let pieData = data.reduce(
        (acc, item) => (
          item.nursingServicePositionName !== '总计' &&
            acc.push({
              name: item.nursingServicePositionName,
              value: item.salesAmountRatio
            }),
          acc
        ),
        [] as { name: string; value: number }[]
      );
      // 饼图分布图 数据
      pieChartsData.value = {
        position: 'outside',
        data: pieData,
        colors: ['#A38FBC', '#FBC191', '#B1B1B1', '#FFD660', '#84B2DF', '#78B153']
      };
    }
  } catch (e) {
    console.log('e : ', e);
  }
};

// 导出销售类别结构
const exportTableData = () => {
  let { shopIdList, startMonth, endMonth } = toValue(searchParams);
  let params = { shopIdList, startMonth, endMonth };
  ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
    useDownload({
      port: exportNursingSaleAnalysePort,
      fileName: '护理销售-销售类别结构',
      params
    })
  );
};

const selectorValue = ref<ModelValueType>('A');
const selectorOptions: SelectorOptionItemType[] = [
  { name: '面部独立', value: 'A' },
  { name: '面部叠加', value: 'D' },
  { name: '附加', value: 'F' }
];

const chartTitle = computed(() => {
  let item = selectorOptions.find(it => it.value === selectorValue.value);
  return item?.name ?? '面部独立';
});

watch(selectorValue, () => {
  getNursingServiceAnalyseData();
  getNursingServiceHourlyGrossProfitData();
});

type ChartType = Chart.FourQuadrantChartType;
// 面部 -- 独立高频帕累托 当前数据
const nurseParetoChartData = ref<Chart.DoubleYAxisChartType>({});
//  面部 -- 独立高频项矩阵 --> 毛利额
const faceGrossProfitMarginData = ref<ChartType>({} as ChartType);
//  面部 -- 独立高频项矩阵 --> 毛利率
const faceGrossProfitRateData = ref<ChartType>({} as ChartType);
const nursingServiceAnalyseLoading = ref(false);
const nursingServiceAnalyseStatus = ref(false);
// 获取面部 - 独立图标及矩阵数据
const getNursingServiceAnalyseData = async () => {
  if (nursingServiceAnalyseLoading.value) return;
  nursingServiceAnalyseLoading.value = true;
  try {
    let { shopIdList, startMonth, endMonth } = toValue(searchParams);
    let params = { shopIdList, startMonth, endMonth, workHourPropertyList: [selectorValue.value] };
    let { val: data, success } = await getNursingServiceAnalysePort(params);
    if (success === '0') {
      nursingServiceAnalyseStatus.value = !!data.length;
      if (!data.length) return;

      let axis = [];
      let amountArray = []; // 客单价增长 集合
      let rateArray = []; // 客单价增长率 集合
      let originalGrossProfitMarginData: Chart.FourQuadrantChartItem[] = []; // 面部 - 毛利额
      let originalGrossProfitRateData: Chart.FourQuadrantChartItem[] = []; // 面部 - 毛利率

      for (let item of data) {
        axis.push(item.nursingServiceName);
        amountArray.push(+item.subtotalSalesAmount.toFixed(2));
        rateArray.push(+item.cumulative.toFixed(2));

        originalGrossProfitMarginData.push({
          name: item.nursingServiceName,
          data: [item.subtotalSalesCount || 0, item.subtotalGrossAmount || 0]
        });

        originalGrossProfitRateData.push({
          name: item.nursingServiceName,
          data: [item.subtotalSalesCount || 0, item.grossMargin || 0]
        });
      }

      // 当期各店客单价
      nurseParetoChartData.value = {
        title: `${chartTitle.value}--高频帕累托`,
        yAxisRightUnit: '%',
        colors: ['#40699c', '#ff0000'],
        axis,
        series: [
          { name: '销售额(万元)', type: 'bar', data: amountArray, barMaxWidth: 48 },
          { name: '销售权重(%)', type: 'line', data: rateArray, yAxisIndex: 1, smooth: true }
        ],
        // 工具箱
        toolbox: {
          exportVisible: true,
          // 此处写导出逻辑
          exportPort: () => {
            ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
              useDownload({
                port: exportNursingServiceAnalyseHighFrequencyParetoChartDataPort,
                fileName: '面部独立-高频帕累托',
                params
              })
            );
          }
        }
      };

      // 面部 - 毛利额
      faceGrossProfitMarginData.value = {
        title: `${chartTitle.value}--高频项矩阵`,
        originalData: originalGrossProfitMarginData,
        // 工具箱
        toolbox: {
          exportVisible: true,
          // 此处写导出逻辑
          exportPort: () => {
            ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
              useDownload({
                port: exportNursingServiceAnalyseHighFrequencyItemMatrix1ChartDataPort,
                fileName: '面部独立-高频项矩阵(毛利额销量)',
                params
              })
            );
          }
        }
      };

      // 面部 - 毛利率
      faceGrossProfitRateData.value = {
        title: `${chartTitle.value}--高频项矩阵`,
        yAxisTipsName: '毛利率',
        yAxisUnit: '%',
        originalData: originalGrossProfitRateData,
        // 工具箱
        toolbox: {
          exportVisible: true,
          // 此处写导出逻辑
          exportPort: () => {
            ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
              useDownload({
                port: exportNursingServiceAnalyseHighFrequencyItemMatrix2ChartDataPort,
                fileName: '面部独立-高频项矩阵(毛利率销量)',
                params
              })
            );
          }
        }
      };
    }
  } catch {
  } finally {
    nursingServiceAnalyseLoading.value = false;
  }
};

// 获取小时毛利数据
const verticalBarChartsStatus = ref<boolean>(false);
const verticalBarChartsData = ref<Chart.VerticalBarChartType>({} as Chart.VerticalBarChartType);
const nurseHourlyGrossProfitLoading = ref(false);
const getNursingServiceHourlyGrossProfitData = async () => {
  if (nurseHourlyGrossProfitLoading.value) return;
  nurseHourlyGrossProfitLoading.value = true;

  try {
    let { shopIdList, startMonth, endMonth } = toValue(searchParams);
    let params = { shopIdList, startMonth, endMonth, workHourPropertyList: [selectorValue.value] };
    let { val: data, success } = await getNursingServiceHourlyGrossProfitPort(params);
    if (success === '0') {
      verticalBarChartsStatus.value = !!data.length;
      if (!data.length) return;

      let axis: string[] = [],
        seriesData: number[] = [];
      for (let item of data) {
        axis.push(item.nursingServiceName);
        seriesData.push(item.hourlyGrossProfit || 0);
      }
      verticalBarChartsData.value = {
        title: `${chartTitle.value}--高频小时毛利排名`,
        axis,
        seriesData,
        inverse: true,
        grid: { top: '4%' }
      };
    }
  } catch {
  } finally {
    nurseHourlyGrossProfitLoading.value = false;
  }
};
</script>
