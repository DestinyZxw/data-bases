<template>
  <RubPage>
    <template #header>
      <div class="card pb0">
        <RubSearchForm
          read-auth-code="MENU_EMPLOYEE_STAR_READ"
          :is-shop-clearable="false"
          @init="handleSearch"
          @search="handleSearch"
          @reset="handleReset"
        />
      </div>
    </template>

    <!--  一、目标达成排名  -->
    <el-card shadow="hover" class="mt14 pr" :body-style="{ padding: '14px 14px 8px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz20">一、目标达成排名</div>
        </div>
      </template>
      <div class="selector pt14 pb14 mb14">
        <RubSelector v-model="selectorValue" :options="selectorOptions" auth-code="MENU_EMPLOYEE_STAR_READ" />
      </div>
      <el-row :gutter="10">
        <el-col :xs="24" :sm="24" :md="24" :lg="12" :xl="12" class="mb10">
          <el-card v-loading="goalRankChartLoading">
            <RubEmptyTip :show="topTenChartStatus">
              <RubVerticalBarChart v-bind="topTenChartData" style="height: 560px" />
            </RubEmptyTip>
          </el-card>
        </el-col>
        <el-col :xs="24" :sm="24" :md="24" :lg="12" :xl="12" class="mb10">
          <el-card v-loading="goalRankChartLoading">
            <RubEmptyTip :show="endTenChartStatus">
              <RubVerticalBarChart v-bind="endTenChartData" style="height: 560px" />
            </RubEmptyTip>
          </el-card>
        </el-col>
      </el-row>
    </el-card>

    <!--  二、门店创新高  -->
    <el-card shadow="hover" class="mt14 pr" :body-style="{ padding: '14px 14px 8px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz20">二、门店创新高</div>
          <div class="fz14" style="color: var(--el-text-color-secondary)">单位: 万元</div>
        </div>
      </template>
      <el-table v-loading="tableLoading" :data="tableData" class="wp-100" border style="height: 580px">
        <el-table-column prop="shopName" label="门店名称" align="center" width="140" />
        <el-table-column prop="employeeName" label="门店负责人" align="center" />
        <el-table-column label="上年月度新高" align="center">
          <el-table-column prop="prevCashMaxValue" label="现金" align="center">
            <template #default="{ row }">{{ handleFilterTableRow(row, 'prevCashMaxValue') }}</template>
          </el-table-column>
          <el-table-column prop="prevNursingMaxValue" label="开单" align="center">
            <template #default="{ row }">{{ handleFilterTableRow(row, 'prevNursingMaxValue') }}</template>
          </el-table-column>
          <el-table-column prop="prevProductMaxValue" label="产品" align="center">
            <template #default="{ row }">{{ handleFilterTableRow(row, 'prevProductMaxValue') }}</template>
          </el-table-column>
        </el-table-column>
        <el-table-column label="本年月度新高" align="center">
          <el-table-column prop="currentCashMaxValue" label="现金" align="center">
            <template #default="{ row }">
              <el-link
                v-bind="(row.currentCashMaxValue ?? 0) > (row.prevCashMaxValue ?? 0) ? { type: 'success' } : {}"
                :underline="false"
              >
                {{ handleFilterTableRow(row, 'currentCashMaxValue') }}
              </el-link>
            </template>
          </el-table-column>
          <el-table-column prop="currentNursingMaxValue" label="开单" align="center">
            <template #default="{ row }">
              <el-link
                v-bind="(row.currentNursingMaxValue ?? 0) > (row.prevNursingMaxValue ?? 0) ? { type: 'success' } : {}"
                :underline="false"
              >
                {{ handleFilterTableRow(row, 'currentNursingMaxValue') }}
              </el-link>
            </template>
          </el-table-column>
          <el-table-column prop="currentProductMaxValue" label="产品" align="center">
            <template #default="{ row }">
              <el-link
                v-bind="(row.currentProductMaxValue ?? 0) > (row.prevProductMaxValue ?? 0) ? { type: 'success' } : {}"
                :underline="false"
              >
                {{ handleFilterTableRow(row, 'currentProductMaxValue') }}
              </el-link>
            </template>
          </el-table-column>
        </el-table-column>
      </el-table>
    </el-card>

    <!--  三、销售冠军  -->
    <el-card shadow="hover" class="mt14 pr" :body-style="{ padding: '14px 14px 8px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz20">三、销售冠军</div>
        </div>
      </template>
      <RubEmptyTip :show="salesChampionStatus" style="min-height: 268px">
        <el-row :gutter="20">
          <template v-for="(item, index) in salesChampionList" :key="index">
            <el-col :xs="24" :sm="24" :md="8" :lg="8" :xl="8" class="mb10">
              <div class="flex champion justify-center">
                <img
                  :src="`https://rubis-report-center.oss-cn-shanghai.aliyuncs.com/images/${
                    ['cash', 'billing', 'product'][index]
                  }.png`"
                  alt=""
                />
                <div class="flex flex-col justify-between pl20">
                  <div class="inline-flex flex-col items-center">
                    <span class="name">{{ item.shop.name }}</span>
                    <div class="performance inline-flex items-center pt10">
                      收入：<span style="color: #b0754b">{{ item.shop.amount }}万</span>
                    </div>
                  </div>
                  <div class="inline-flex flex-col items-center">
                    <span class="name">{{ item.employee.name }}</span>
                    <div class="performance inline-flex items-center pt10">
                      收入：<span style="color: #b0754b">{{ item.employee.amount }}万</span>
                    </div>
                  </div>
                </div>
              </div>
            </el-col>
          </template>
        </el-row>
      </RubEmptyTip>
    </el-card>

    <!--  四、最佳进步   -->
    <el-card shadow="hover" class="mt14 pr" :body-style="{ padding: '14px 14px 8px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz20">四、最佳进步</div>
        </div>
      </template>
      <RubEmptyTip :show="bestProgressStatus" style="min-height: 520px">
        <el-row>
          <template v-for="(item, index) in bestProgressList" :key="index">
            <el-col :xs="24" :sm="24" :md="24" :lg="24" :xl="12" class="mb10">
              <div class="best">
                <el-row>
                  <el-col :span="8">
                    <div class="best-item_1 flex flex-col items-center">
                      <span class="name">{{ item.second.name ?? '--' }}</span>
                      <div class="performance inline-flex items-center pt10">
                        同比：<span style="color: #b0754b">{{
                          item.second.increasePer || item.second.increasePer === 0 ? item.second.increasePer + '%' : '--'
                        }}</span>
                      </div>
                    </div>
                  </el-col>
                  <el-col :span="8">
                    <div class="best-item_2 flex flex-col items-center">
                      <span class="name">{{ item.first.name ?? '--' }}</span>
                      <div class="performance inline-flex items-center pt10">
                        同比：<span style="color: #b0754b">{{
                          item.first.increasePer || item.first.increasePer === 0 ? item.first.increasePer + '%' : '--'
                        }}</span>
                      </div>
                    </div>
                  </el-col>
                  <el-col :span="8">
                    <div class="best-item_3 flex flex-col items-center">
                      <span class="name">{{ item.third.name ?? '--' }}</span>
                      <div class="performance inline-flex items-center pt10">
                        同比：<span style="color: #b0754b">{{
                          item.third.increasePer || item.third.increasePer === 0 ? item.third.increasePer + '%' : '--'
                        }}</span>
                      </div>
                    </div>
                  </el-col>
                </el-row>
              </div>
            </el-col>
          </template>
        </el-row>
      </RubEmptyTip>
    </el-card>
  </RubPage>
</template>

<script setup lang="ts" name="shopStarEmployee">
import {
  getStarEmployeeForReachTheGoalRankPort,
  ReachTheGoalRankItemType,
  getStarEmployeeForNewHighTablePort,
  StarEmployeeForNewHighItemType,
  getStarEmployeeForSalesChampionPort,
  StarEmployeeForSalesChampionItemType,
  getStarEmployeeForBestProgressPort,
  StarEmployeeForBestProgressItemType
} from '@/api/modules/shop';
import { SearchParamsType } from '@/components/rub-search-form/interfaces';
import type { ModelValueType, SelectorOptionItemType } from '@/components/rub-selector/index.vue';
import { handleFilterTableRow } from '@/utils';
import { Chart } from '@/typings/global';
import { useGlobalStore } from '@/stores/modules/global';

const globalStore = useGlobalStore();
const isMobile = computed(() => globalStore.device === 'mobile');

let cacheSearchData: SearchParamsType = {} as SearchParamsType;
const handleSearch = (data: SearchParamsType) => {
  cacheSearchData = data;
  getReachTheGoalRankChartData(data);
  getTableData(data);
  getStarEmployeeForSalesChampion(data);
  getStarEmployeeForBestProgress(data);
};

const handleReset = (data: SearchParamsType) => {
  handleSearch(data);
};

const selectorValue = ref<ModelValueType>(1);
const selectorOptions: SelectorOptionItemType[] = [
  { name: '现金', value: 1 },
  { name: '产品', value: 2 },
  { name: '开单', value: 3 },
  { name: '买卡成功率', value: 4 },
  { name: '复购率', value: 5 }
];
watch(selectorValue, () => {
  getReachTheGoalRankChartData(cacheSearchData);
});

// 护理购买人数占比charts图表数据
const topTenChartStatus = ref(false);
const topTenChartData = ref<Chart.VerticalBarChartType>({});
// 产品购买人数占比charts图表数据
const endTenChartStatus = ref(false);
const endTenChartData = ref<Chart.VerticalBarChartType>({});

type GenerateChartOptionsType = {
  title: string;
  data: ReachTheGoalRankItemType[];
  colors: string[];
};
const generateChartOptions = ({ title, data, colors }: GenerateChartOptionsType) => {
  let axis: string[] = [],
    seriesData: number[] = [];
  for (let item of data) {
    axis.push(item.employeeName);
    seriesData.push(item.itemValue);
  }
  const verticalOneScreenValue = 12, // 纵向 一屏数据展示的基准值
    // 纵向导轨
    verticalDataZoom = [
      {
        type: isMobile.value ? 'inside' : 'slider',
        orient: 'vertical',
        start: 100,
        end: 100 - Math.floor((verticalOneScreenValue * 100) / (axis.length || verticalOneScreenValue)),
        zoomLock: !isMobile.value,
        zoomOnMouseWheel: false,
        brushSelect: false,
        padding: [10, 20, 10, 20]
      }
    ];
  return {
    title,
    colors,
    axis,
    seriesData,
    labelShow: true,
    inverse: true,
    labelUnit: '%',
    ...(axis.length > verticalOneScreenValue ? { dataZoom: verticalDataZoom } : {})
  };
};
const goalRankChartLoading = ref(false);
const getReachTheGoalRankChartData = async (args: SearchParamsType) => {
  try {
    goalRankChartLoading.value = true;
    let { shopIdList, startMonth, endMonth } = toValue(args),
      params = { shopIdList, startMonth, endMonth, reachTheGoalType: selectorValue.value },
      { val: data, success } = await getStarEmployeeForReachTheGoalRankPort(params);
    if (success === '0') {
      let { topTen = [], endTen = [] } = data ?? {};
      let item = selectorOptions.find(it => it.value === selectorValue.value);

      topTenChartStatus.value = !!topTen.length;
      if (topTen.length) {
        topTenChartData.value = generateChartOptions({
          title: `${item?.name}TOP10`,
          colors: ['#70AD47'],
          data: topTen
        });
      }

      endTenChartStatus.value = !!endTen.length;
      if (endTen.length) {
        endTenChartData.value = generateChartOptions({
          title: `${item?.name}END10`,
          colors: ['#FF0000'],
          data: endTen
        });
      }
    }
  } catch {
  } finally {
    goalRankChartLoading.value = false;
  }
};

// 门店创新高
const tableLoading = ref(false);
const tableData = ref<StarEmployeeForNewHighItemType[]>([]);
const getTableData = async (args: SearchParamsType) => {
  try {
    tableLoading.value = true;
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = { shopIdList, startMonth, endMonth };
    let { val: data, success } = await getStarEmployeeForNewHighTablePort(params);
    if (success === '0') {
      // 表格数据
      tableData.value = data;
    }
  } catch {
  } finally {
    tableLoading.value = false;
  }
};

// 销售冠军
type ChampionItemType = Record<'shop' | 'employee', StarEmployeeForSalesChampionItemType>;
const salesChampionStatus = ref<boolean>(false);
const salesChampionList = ref<Array<ChampionItemType>>([]);
const getStarEmployeeForSalesChampion = async (args: SearchParamsType) => {
  try {
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = { shopIdList, startMonth, endMonth };
    let { val: data, success } = await getStarEmployeeForSalesChampionPort(params);
    if (success === '0') {
      salesChampionStatus.value = !!(data ?? []).length;
      if (!salesChampionStatus.value) return;

      let maps: Map<string, ChampionItemType> = new Map();
      for (let item of data) {
        let tmp: ChampionItemType = maps.get(item.topic) ?? ({} as ChampionItemType);
        if (item.type === '1') {
          tmp.shop = item;
        } else if (item.type === '2') {
          tmp.employee = item;
        }
        maps.set(item.topic, tmp);
      }
      salesChampionList.value = [...maps.values()];
    }
  } catch {}
};

// 最佳进步
type ProgressItemType = Record<'first' | 'second' | 'third', StarEmployeeForBestProgressItemType>;
const bestProgressStatus = ref<boolean>(false);
const bestProgressList = ref<ProgressItemType[]>([]);
const getStarEmployeeForBestProgress = async (args: SearchParamsType) => {
  try {
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = { shopIdList, startMonth, endMonth };
    let { val: data, success } = await getStarEmployeeForBestProgressPort(params);
    if (success === '0') {
      bestProgressStatus.value = !!(data ?? []).length;
      if (!bestProgressStatus.value) return;

      let maps: Map<string, ProgressItemType> = new Map();
      for (let item of data) {
        let tmp: ProgressItemType = maps.get(item.type) ?? ({} as ProgressItemType);
        if (item.rank === 1) {
          tmp.first = item;
        } else if (item.rank === 2) {
          tmp.second = item;
        } else {
          tmp.third = item;
        }
        maps.set(item.type, tmp);
      }
      bestProgressList.value = [...maps.values()];
    }
  } catch {}
};
</script>
<style scoped lang="scss">
@import 'index';
</style>
