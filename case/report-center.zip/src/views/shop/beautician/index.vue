<template>
  <div class="table-box">
    <div class="card table-search pb0">
      <RubSearchForm
        read-auth-code="MENU_BEAUTICIAN_EFFICIENCY_MANAGE_READ"
        @init="handleSearch"
        @search="handleSearch"
        @reset="handleReset"
      />
    </div>

    <el-card
      shadow="hover"
      :body-style="{
        padding: '15px',
        flex: 1,
        height: 'calc(100% - 80px)',
        display: 'flex',
        flexDirection: 'column',
        boxSizing: 'border-box'
      }"
      class="table-main"
    >
      <template #header>
        <div class="flex items-center justify-between">
          <div class="font-bold">美容师个人效能表</div>
          <div class="fz14" style="color: var(--el-text-color-secondary)">单位: 元</div>
        </div>
      </template>
      <view class="flex justify-end mb16">
        <el-button type="primary" plain size="small" @click="exportTableData">
          导出<el-icon class="el-icon--right"><Download /></el-icon>
        </el-button>
      </view>
      <el-table v-loading="tableLoading" :data="tableData" class="wp-100" border>
        <el-table-column prop="shopName" label="门店" align="center" width="140" />
        <el-table-column prop="employeeName" label="美容师姓名" align="center" />

        <el-table-column label="美容师劳效" align="center">
          <el-table-column prop="currentPeriodBeauticianPerformance" label="实际" align="center">
            <template #default="{ row }">{{ handleFilterTableRow(row, 'currentPeriodBeauticianPerformance') }}</template>
          </el-table-column>
          <el-table-column prop="beauticianPerformanceIncreasePer" label="同比(%)" align="center">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'beauticianPerformanceIncreasePer') }} </template>
          </el-table-column>
        </el-table-column>

        <el-table-column label="工时" align="center">
          <el-table-column prop="target" label="实际" align="center">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'currentPeriodBeauticianWorkHour') }} </template>
          </el-table-column>
          <el-table-column prop="beauticianWorkHourIncreasePer" label="同比(%)" align="center">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'beauticianWorkHourIncreasePer') }} </template>
          </el-table-column>
        </el-table-column>

        <el-table-column label="工时客单" align="center">
          <el-table-column prop="currentPeriodBeauticianWorkHourPerPerson" label="实际" align="center">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'currentPeriodBeauticianWorkHourPerPerson') }} </template>
          </el-table-column>
          <el-table-column prop="beauticianWorkHourPerPersonIncreasePer" label="同比(%)" align="center">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'beauticianWorkHourPerPersonIncreasePer') }} </template>
          </el-table-column>
        </el-table-column>

        <el-table-column label="翻床率" align="center">
          <el-table-column prop="currentPeriodBeauticianPerBedRate" label="实际" align="center">
            <template #default="{ row }">
              {{
                (row as BeauticianEfficiencyTableItemType).currentPeriodBeauticianPerBedRate ||
                (row as BeauticianEfficiencyTableItemType).currentPeriodBeauticianPerBedRate === 0
                  ? (row as BeauticianEfficiencyTableItemType).currentPeriodBeauticianPerBedRate
                  : '/'
              }}
            </template>
          </el-table-column>
          <el-table-column prop="beauticianPerBedRateIncreasePer" label="同比(%)" align="center">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'beauticianPerBedRateIncreasePer') }} </template>
          </el-table-column>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<!-- 美容师个人效能 管理表 -->
<script setup lang="ts" name="shopBeautician">
import {
  getBeauticianEfficiencyTablePort,
  exportBeauticianEfficiencyTablePort,
  BeauticianEfficiencyTableItemType
} from '@/api/modules/shop';
import { SearchParamsType } from '@/components/rub-search-form/interfaces';
import { handleFilterTableRow } from '@/utils';
import { ElMessageBox } from 'element-plus';
import { useDownload } from '@/hooks/useDownload';

const searchParams = ref<SearchParamsType>({} as SearchParamsType);
const handleSearch = (data: SearchParamsType) => {
  searchParams.value = data;
  getTableData(data);
};

const handleReset = (data: SearchParamsType) => {
  tableData.value = [];
  handleSearch(data);
};

const tableData = ref<BeauticianEfficiencyTableItemType[]>([]);
const tableLoading = ref<Boolean>(false);

const getTableData = async (args: SearchParamsType) => {
  try {
    tableLoading.value = true;
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = { shopIdList, startMonth, endMonth };
    let { val: data, success } = await getBeauticianEfficiencyTablePort(params);
    if (success === '0') {
      tableData.value = data;
    }
  } catch (e) {
    console.log('e : ', e);
  } finally {
    tableLoading.value = false;
  }
};

// 导出美容师个人效能表
const exportTableData = () => {
  let { shopIdList, startMonth, endMonth } = toValue(searchParams),
    params = { shopIdList, startMonth, endMonth };
  ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
    useDownload({
      port: exportBeauticianEfficiencyTablePort,
      fileName: '美容师个人效能表',
      params
    })
  );
};
</script>
