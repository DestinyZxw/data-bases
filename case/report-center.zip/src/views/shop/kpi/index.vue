<template>
  <RubPage>
    <template #header>
      <div class="card pb0">
        <RubSearchForm
          read-auth-code="MENU_PERFORMANCE_MANAGEMENT_READ"
          @init="handleSearch"
          @search="handleSearch"
          @reset="handleReset"
        />
      </div>
    </template>

    <el-card shadow="hover" class="mt14">
      <template #header>
        <div class="flex items-center h-30">
          <div class="font-bold">门店顾问KPI达成结果</div>
        </div>
      </template>
      <el-table :data="tableData" class="wp-100" border>
        <el-table-column prop="amount" label="顾问姓名" align="center" min-width="120">
          <template #default="{ row }">
            <div class="tr">{{ (row as businessSummaryItemType).amount }}</div>
          </template>
        </el-table-column>

        <el-table-column label="开单" align="center">
          <el-table-column prop="target" label="10" align="center" min-width="120">
            <template #default="{ row }">
              <div class="tr">{{ (row as businessSummaryItemType).target || '/' }}</div>
            </template>
          </el-table-column>
        </el-table-column>

        <el-table-column label="产品" align="center">
          <el-table-column prop="target" label="10" align="center" min-width="120">
            <template #default="{ row }">
              <div class="tr">{{ (row as businessSummaryItemType).target || '/' }}</div>
            </template>
          </el-table-column>
        </el-table-column>

        <el-table-column label="现金" align="center">
          <el-table-column prop="target" label="10" align="center" min-width="120">
            <template #default="{ row }">
              <div class="tr">{{ (row as businessSummaryItemType).target || '/' }}</div>
            </template>
          </el-table-column>
        </el-table-column>

        <el-table-column label="客流目标达成率" align="center">
          <el-table-column prop="target" label="15" align="center" min-width="120">
            <template #default="{ row }">
              <div class="tr">{{ (row as businessSummaryItemType).target || '/' }}</div>
            </template>
          </el-table-column>
        </el-table-column>

        <el-table-column label="卓越服务达成率" align="center">
          <el-table-column prop="target" label="15" align="center" min-width="120">
            <template #default="{ row }">
              <div class="tr">{{ (row as businessSummaryItemType).target || '/' }}</div>
            </template>
          </el-table-column>
        </el-table-column>

        <el-table-column label="专属会员管理人数得分" align="center">
          <el-table-column prop="target" label="5" align="center" min-width="120">
            <template #default="{ row }">
              <div class="tr">{{ (row as businessSummaryItemType).target || '/' }}</div>
            </template>
          </el-table-column>
        </el-table-column>

        <el-table-column label="专属会员到店率" align="center">
          <el-table-column prop="target" label="10" align="center" min-width="120">
            <template #default="{ row }">
              <div class="tr">{{ (row as businessSummaryItemType).target || '/' }}</div>
            </template>
          </el-table-column>
        </el-table-column>

        <el-table-column label="新会员开发" align="center">
          <el-table-column prop="target" label="25" align="center" min-width="120">
            <template #default="{ row }">
              <div class="tr">{{ (row as businessSummaryItemType).target || '/' }}</div>
            </template>
          </el-table-column>
        </el-table-column>

        <el-table-column label="综合得分" align="center">
          <el-table-column prop="target" label="100" align="center" min-width="120">
            <template #default="{ row }">
              <div class="tr">{{ (row as businessSummaryItemType).target || '/' }}</div>
            </template>
          </el-table-column>
        </el-table-column>

        <el-table-column prop="target" label="综合排名" align="center" min-width="120">
          <template #default="{ row }">
            <div class="tr">{{ (row as businessSummaryItemType).target || '/' }}</div>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-card shadow="hover" class="mt14 pr">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold">门店美容师主管KPI达成结果</div>
        </div>
      </template>
      <el-table :data="tableData" class="wp-100" border>
        <el-table-column prop="amount" label="美容师姓名" align="center" min-width="120">
          <template #default="{ row }">
            <div class="tr">{{ (row as businessSummaryItemType).amount }}</div>
          </template>
        </el-table-column>
        <el-table-column prop="amount" label="等级" align="center" min-width="120">
          <template #default="{ row }">
            <div class="tr">{{ (row as businessSummaryItemType).amount }}</div>
          </template>
        </el-table-column>
        <el-table-column prop="amount" label="新会员达成率" align="center" min-width="120">
          <template #default="{ row }">
            <div class="tr">{{ (row as businessSummaryItemType).amount }}</div>
          </template>
        </el-table-column>
        <el-table-column prop="amount" label="门店客流达成率" align="center" min-width="120">
          <template #default="{ row }">
            <div class="tr">{{ (row as businessSummaryItemType).amount }}</div>
          </template>
        </el-table-column>
        <el-table-column prop="amount" label="客流日基础目标达成率" align="center" min-width="120">
          <template #default="{ row }">
            <div class="tr">{{ (row as businessSummaryItemType).amount }}</div>
          </template>
        </el-table-column>
        <el-table-column prop="amount" label="员工保有率" align="center" min-width="120">
          <template #default="{ row }">
            <div class="tr">{{ (row as businessSummaryItemType).amount }}</div>
          </template>
        </el-table-column>
        <el-table-column prop="amount" label="服务成本达成率" align="center" min-width="120">
          <template #default="{ row }">
            <div class="tr">{{ (row as businessSummaryItemType).amount }}</div>
          </template>
        </el-table-column>
        <el-table-column prop="amount" label="技术考核" align="center" min-width="120">
          <template #default="{ row }">
            <div class="tr">{{ (row as businessSummaryItemType).amount }}</div>
          </template>
        </el-table-column>
        <el-table-column prop="amount" label="综合得分" align="center" min-width="120">
          <template #default="{ row }">
            <div class="tr">{{ (row as businessSummaryItemType).amount }}</div>
          </template>
        </el-table-column>
        <el-table-column prop="amount" label="综合排名" align="center" min-width="120">
          <template #default="{ row }">
            <div class="tr">{{ (row as businessSummaryItemType).amount }}</div>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </RubPage>
</template>

<!-- KPI汇总 管理表 -->
<script setup lang="ts" name="shopKpi">
import { getSheetTableAndPiePort, businessSummaryItemType } from '@/api/modules/performance';
import { SearchParamsType } from '@/components/rub-search-form/interfaces';

const handleSearch = (data: SearchParamsType) => {
  getSheetTableAndPieData(data);
};

const handleReset = (data: SearchParamsType) => {
  tableData.value = [];
  handleSearch(data);
};

const tableData = ref<businessSummaryItemType[]>([]);
const getSheetTableAndPieData = async (args: SearchParamsType) => {
  try {
    let { shopIdList, startMonth, endMonth } = unref(args);
    let params = { shopIdList, startMonth, endMonth };
    let { val: data, success } = await getSheetTableAndPiePort(params);
    if (success === '0') {
      tableData.value = data.businessSummaryVOList;
    }
  } catch (e) {
    console.log('e : ', e);
  }
};
</script>
