<template>
  <RubPage>
    <template #header>
      <div class="card pb0">
        <RubSearchForm read-auth-code="MENU_PRODUCT_SALE_READ" @init="handleSearch" @search="handleSearch" @reset="handleReset" />
      </div>
    </template>

    <el-card shadow="hover" class="mt14">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold mr10">有效产品销售大类分布</div>
          <div class="fz14 ml-auto" style="color: var(--el-text-color-secondary)">单位: 元</div>
        </div>
      </template>
      <RubEmptyTip :show="productCategoriesTableStatus" style="min-height: 420px">
        <view class="flex justify-end mb16">
          <el-button type="primary" plain size="small" @click="exportProductCategories">
            导出<el-icon class="el-icon--right"><Download /></el-icon>
          </el-button>
        </view>
        <el-table :data="productCategoriesTableData" class="wp-100" border>
          <el-table-column
            v-for="(value, key, index) in productCategoriesTableData[0] ?? {}"
            align="center"
            min-width="120"
            :prop="key as string"
            :label="(ProductCategoriesMaps[key as ProductCategoriesKeyType] as string) || (key as string)"
            :key="index"
          >
            <template #default="{ row }">{{ filterProductCategoriesValue(key as string, row) }}</template>
          </el-table-column>
        </el-table>
      </RubEmptyTip>
    </el-card>

    <el-row :gutter="14">
      <el-col :xs="24" :sm="24" :md="14" :lg="16" class="mt14">
        <el-card shadow="hover">
          <template #header>
            <div class="flex items-center h-30">
              <div class="font-bold">产品的SKU数分布</div>
            </div>
          </template>
          <RubEmptyTip :show="productSkuTableStatus" style="min-height: 400px">
            <el-table :data="productSkuTableData" show-summary class="wp-100" border style="height: 400px">
              <el-table-column
                v-for="(value, key, index) in productSkuTableData[0] ?? {}"
                align="center"
                min-width="120"
                :prop="key as string"
                :label="(ProductSkuMaps[key as ProductSkuKeyType] as string) || (key as string)"
                :key="index"
              >
                <template #default="{ row }">
                  {{ Number(row[key]) || Number(row[key]) === 0 ? Number(row[key]) : row[key] ?? '/' }}
                </template>
              </el-table-column>
            </el-table>
          </RubEmptyTip>
        </el-card>
      </el-col>
      <el-col :xs="24" :sm="24" :md="10" :lg="8" class="mt14">
        <el-card shadow="hover">
          <template #header>
            <div class="font-bold h-30 lht30">产品客院装销售占比</div>
          </template>
          <RubEmptyTip :show="pieChartsStatus">
            <RubPieChart v-bind="pieChartsData" />
          </RubEmptyTip>
        </el-card>
      </el-col>
    </el-row>

    <el-card shadow="hover" class="mt14">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold">产品分析</div>
        </div>
      </template>
      <div class="selector mb14">
        <RubSelector v-model="selectorValue" :options="selectorOptions" auth-code="MENU_PRODUCT_SALE_READ" />
      </div>
      <el-card class="mb14">
        <RubEmptyTip :show="productAnalyseStatus" style="height: auto">
          <el-scrollbar>
            <RubDoubleYAxisChart v-bind="productParetoChartData" class="chart pt10" style="height: 900px" />
          </el-scrollbar>
        </RubEmptyTip>
      </el-card>
      <el-card>
        <RubEmptyTip :show="productAnalyseStatus" style="height: auto">
          <el-scrollbar>
            <FourQuadrantChart v-bind="productFourQuadrantData" />
          </el-scrollbar>
        </RubEmptyTip>
      </el-card>
    </el-card>
  </RubPage>
</template>

<!-- 产品销售管理表 -->
<script setup lang="ts" name="shopProduct">
import {
  getProductCategoriesSalesTablePort,
  exportProductCategoriesSalesDistributionPort,
  ProductCategoriesSalesTableItemType,
  getProductSkuTablePort,
  getProductSalesRatioPort,
  getProductPackTypeAnalysePort,
  exportProductPackTypeAnalysePassengerParetoChartDataPort,
  exportProductPackTypeAnalyseCustomerProductMatrixChartDataPort
} from '@/api/modules/shop';
import { SearchParamsType } from '@/components/rub-search-form/interfaces';
import { Chart } from '@/typings/global';
import FourQuadrantChart from '../components/four-quadrant-chart.vue';
import type { ModelValueType, SelectorOptionItemType } from '@/components/rub-selector/index.vue';
import { ElMessageBox } from 'element-plus';
import { useDownload } from '@/hooks/useDownload';

// 缓存的数据
const searchParams = ref<SearchParamsType>({} as SearchParamsType);
const handleSearch = (data: SearchParamsType) => {
  searchParams.value = data;
  getProductCategoriesTableData(data);
  getProductSkuTableData(data);
  getProductSalesRatioData(data);
  getProductPackTypeAnalyseData();
};

const handleReset = (data: SearchParamsType) => {
  searchParams.value = data;
  selectorValue.value = '客装';
  getProductCategoriesTableData(data);
  getProductSkuTableData(data);
  getProductSalesRatioData(data);
};

/**
 * 有效产品销售大类分布相关代码
 */
const productCategoriesTableStatus = ref(false);
const productCategoriesTableData = ref<ProductCategoriesSalesTableItemType[]>([]);
type ProductCategoriesKeyType = 'productTypeName' | 'productTypeRatio' | 'subTotalAmount';
const ProductCategoriesMaps: Record<ProductCategoriesKeyType, string> = {
  productTypeName: '产品名称',
  productTypeRatio: '品类结构(%)',
  subTotalAmount: '总计'
};
const getProductCategoriesTableData = async (args: SearchParamsType) => {
  try {
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = { shopIdList, startMonth, endMonth };
    let { val: data, success } = await getProductCategoriesSalesTablePort(params);
    if (success === '0') {
      productCategoriesTableStatus.value = !!data.length;
      productCategoriesTableData.value = data;
    }
  } catch (e) {
    console.log('e : ', e);
  }
};

// 对产品大类的值进行过滤
const filterProductCategoriesValue = (key: string, row: ProductCategoriesSalesTableItemType) => {
  const value = Number(row[key]);
  return value ? (key.includes('Ratio') ? value.toFixed(2) + '%' : value.toFixed(2)) : row[key] || '/';
};

// 有效产品销售大类分布导出
const exportProductCategories = () => {
  let { shopIdList, startMonth, endMonth } = toValue(searchParams);
  let params = { shopIdList, startMonth, endMonth };
  ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
    useDownload({
      port: exportProductCategoriesSalesDistributionPort,
      fileName: '产品销售-有效产品销售大类分布',
      params
    })
  );
};

/**
 * 产品SKU数分布相关代码
 */
const productSkuTableStatus = ref(false);
const productSkuTableData = ref<ProductCategoriesSalesTableItemType[]>([]);
type ProductSkuKeyType = 'productTypeName' | 'subTotalCount';
const ProductSkuMaps: Record<ProductSkuKeyType, string> = {
  productTypeName: '产品名称',
  subTotalCount: '总计'
};
const getProductSkuTableData = async (args: SearchParamsType) => {
  try {
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = { shopIdList, startMonth, endMonth };
    let { val: data, success } = await getProductSkuTablePort(params);
    if (success === '0') {
      productSkuTableStatus.value = !!data.length;
      productSkuTableData.value = data;
    }
  } catch (e) {
    console.log('e : ', e);
  }
};

/**
 * 产品客院装销售占比相关代码
 */
// pie饼图数据
const pieChartsStatus = ref<boolean>(false);
const pieChartsData = ref<Chart.PieChartType>({} as Chart.PieChartType);
const getProductSalesRatioData = async (args: SearchParamsType) => {
  try {
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = { shopIdList, startMonth, endMonth };
    const { val: data, success } = await getProductSalesRatioPort(params);
    if (success === '0') {
      pieChartsStatus.value = !!data.length;
      if (!data.length) return;
      const tmp: { name: string; value: number }[] = [];
      for (let item of data) {
        item.productPackTypeName !== '试用装' &&
          tmp.push({
            name: item.productPackTypeName,
            value: (item.subTotalAmount * 100) / item.totalAmount
          });
      }
      pieChartsData.value = {
        position: 'outside',
        data: tmp,
        colors: ['#A38FBC', '#FBC191', '#8DCADB']
      };
    }
  } catch (e) {
    console.log('e : ', e);
  }
};

const selectorValue = ref<ModelValueType>('客装');
const selectorOptions: SelectorOptionItemType[] = [
  { name: '客装', value: '客装' },
  { name: '院装', value: '院装' },
  { name: '客院两用', value: '客院两用' }
];

// 对品类筛选进行监听
watch(selectorValue, () => {
  getProductPackTypeAnalyseData();
});

/**
 * 产品波士顿矩阵及帕累托图  相关代码
 */
// 客装帕累托图
const productParetoChartData = ref<Chart.DoubleYAxisChartType>({});

// 客装产品矩阵图
const productFourQuadrantData = ref<Chart.FourQuadrantChartType>({});
const productAnalyseLoading = ref<boolean>(false);
const productAnalyseStatus = ref<boolean>(false);
const getProductPackTypeAnalyseData = async () => {
  if (productAnalyseLoading.value) return;
  productAnalyseLoading.value = true;
  try {
    let { shopIdList, startMonth, endMonth } = toValue(searchParams);
    let params = { shopIdList, startMonth, endMonth, productPackTypeNameList: [selectorValue.value] };
    let { val: data, success } = await getProductPackTypeAnalysePort(params);
    if (success === '0') {
      productAnalyseStatus.value = !!data.length;
      if (!data.length) return;

      let axis = [];
      let amountArray = []; // 销售额 集合
      let rateArray = []; // 销售权重 集合
      let originalData: Chart.FourQuadrantChartItem[] = [];

      for (let item of data) {
        axis.push(item.productName);
        amountArray.push(+item.subTotalAmount.toFixed(2));
        rateArray.push(+item.cumulative.toFixed(2));
        originalData.push({
          name: item.productName,
          code: item.productCode,
          data: [item.subSalesCount || 0, item.subGrossTotalAmount || 0]
        });
      }

      // 客装帕累托图 数据
      productParetoChartData.value = {
        // title: '客装帕累托图',
        title: `${selectorValue.value}帕累托图`,
        xAxisLabelRotate: 75,
        yAxisRightUnit: '%',
        colors: ['#40699c', '#ff0000'],
        axis,
        grid: { top: '14%', bottom: '30%' },
        series: [
          { name: '销售额(万元)', type: 'bar', data: amountArray },
          { name: '销售权重(%)', type: 'line', data: rateArray, yAxisIndex: 1, smooth: true }
        ],
        // 工具箱
        toolbox: {
          exportVisible: true,
          // 此处写导出逻辑
          exportPort: () => {
            ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
              useDownload({
                port: exportProductPackTypeAnalysePassengerParetoChartDataPort,
                fileName: '客装帕累托图',
                params
              })
            );
          }
        }
      };

      // 客装产品矩阵 数据
      productFourQuadrantData.value = {
        title: `${selectorValue.value}产品矩阵`,
        originalData,
        // 工具箱
        toolbox: {
          exportVisible: true,
          // 此处写导出逻辑
          exportPort: () => {
            ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
              useDownload({
                port: exportProductPackTypeAnalyseCustomerProductMatrixChartDataPort,
                fileName: `${selectorValue.value}产品矩阵`,
                params
              })
            );
          }
        }
      };
    }
  } catch (e) {
    console.log('e : ', e);
  } finally {
    productAnalyseLoading.value = false;
  }
};
</script>
