<template>
  <div class="table-box">
    <div class="card table-search pb0">
      <RubSearchForm
        read-auth-code="MENU_CONSULTANT_EFFICIENCY_MANAGE_READ"
        @init="handleSearch"
        @search="handleSearch"
        @reset="handleReset"
      />
    </div>

    <el-card
      shadow="hover"
      :body-style="{
        padding: '15px',
        flex: 1,
        height: 'calc(100% - 80px)',
        display: 'flex',
        flexDirection: 'column',
        boxSizing: 'border-box'
      }"
      class="table-main"
    >
      <template #header>
        <div class="flex items-center">
          <div class="font-bold">顾问个人效能表</div>
        </div>
      </template>
      <view class="flex justify-end mb16">
        <el-button type="primary" plain size="small" @click="exportTableData">
          导出<el-icon class="el-icon--right"><Download /></el-icon>
        </el-button>
      </view>
      <el-table v-loading="tableLoading" :data="tableData" class="wp-100" border>
        <el-table-column prop="shopName" label="门店" align="center" min-width="120" />
        <el-table-column prop="employeeName" label="顾问姓名" align="center" min-width="120" />

        <el-table-column label="顾问劳效" align="center">
          <el-table-column prop="currentPeriodConsultantPerformance" label="实际" align="center" min-width="120">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'currentPeriodConsultantPerformance') }} </template>
          </el-table-column>
          <el-table-column prop="consultantPerformanceIncreasePer" label="同比(%)" align="center" min-width="150">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'consultantPerformanceIncreasePer') }} </template>
          </el-table-column>
        </el-table-column>

        <el-table-column label="服务人次" align="center">
          <el-table-column prop="currentPeriodConsultantServicePerPerson" label="实际" align="center" min-width="120">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'currentPeriodConsultantServicePerPerson') }} </template>
          </el-table-column>
          <el-table-column prop="consultantServicePerPersonIncreasePer" label="同比(%)" align="center" min-width="150">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'consultantServicePerPersonIncreasePer') }} </template>
          </el-table-column>
        </el-table-column>

        <el-table-column label="服务人数" align="center">
          <el-table-column prop="currentPeriodConsultantServicePersonCount" label="实际" align="center" min-width="120">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'currentPeriodConsultantServicePersonCount') }} </template>
          </el-table-column>
          <el-table-column prop="consultantServicePersonCountIncreasePer" label="同比(%)" align="center" min-width="150">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'consultantServicePersonCountIncreasePer') }} </template>
          </el-table-column>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<!-- 顾问个人效能 管理表 -->
<script setup lang="ts" name="shopConsultant">
import {
  getConsultantEfficiencyTablePort,
  exportConsultantEfficiencyTablePort,
  ConsultantEfficiencyTableItemType
} from '@/api/modules/shop';
import { SearchParamsType } from '@/components/rub-search-form/interfaces';
import { handleFilterTableRow } from '@/utils';
import { ElMessageBox } from 'element-plus';
import { useDownload } from '@/hooks/useDownload';

const searchParams = ref<SearchParamsType>({} as SearchParamsType);
const handleSearch = (data: SearchParamsType) => {
  searchParams.value = data;
  getTableData(data);
};

const handleReset = (data: SearchParamsType) => {
  tableData.value = [];
  handleSearch(data);
};

const tableData = ref<ConsultantEfficiencyTableItemType[]>([]);
const tableLoading = ref(false);
const getTableData = async (args: SearchParamsType) => {
  try {
    tableLoading.value = true;
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = { shopIdList, startMonth, endMonth };
    let { val: data, success } = await getConsultantEfficiencyTablePort(params);
    if (success === '0') {
      tableData.value = data;
    }
  } catch (e) {
    console.log('e : ', e);
  } finally {
    tableLoading.value = false;
  }
};

// 导出顾问个人效能表
const exportTableData = () => {
  let { shopIdList, startMonth, endMonth } = toValue(searchParams),
    params = { shopIdList, startMonth, endMonth };
  ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
    useDownload({
      port: exportConsultantEfficiencyTablePort,
      fileName: '顾问个人效能表',
      params
    })
  );
};
</script>
