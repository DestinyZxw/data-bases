<!-- 生美销售双美卡明细表 -->
<script lang="ts" setup name="ShengMeiTable">
import type { CascaderProps } from 'element-plus';
import { shopRegionPort, basicShopItem } from '@/api/modules/base';
import { Download } from '@element-plus/icons-vue';
import {
  getShengMeiTableDataPort,
  exportShengMeiTablePort,
  getShengMeiTotalAmountPort,
  DoubleBeautifulCardItemType
} from '@/api/modules/shop';
import { useButtonAuth } from '@/hooks/useButtonAuth';
import type { ShengMeiSearchFormType, ShengMeiSearchParamsType } from '@/views/shop/interfaces';
import { useTable } from '@/hooks/useTable';

// 按钮权限
const { isDisabledRead, isDisabledExport } = useButtonAuth({
  read: 'OPERATION_ZY_SALES_DETAIL_READ',
  exports: 'OPERATION_ZY_SALES_DETAIL_EXPORT'
});

onMounted(() => {
  getShopRegionData();
});

/**
 * 门店相关逻辑
 */
type ShopOptionType = {
  shopId: number | string;
  shopName: string;
  shopRegionList: basicShopItem[];
};

// 门店 options
const shopOptions = ref<ShopOptionType[]>([]);
const getShopRegionData = async () => {
  try {
    let { val: data, success } = await shopRegionPort();
    if (success === '0') {
      shopOptions.value = data.map(item => {
        let tmp: ShopOptionType = {
          shopId: item.region,
          shopName: item.region,
          shopRegionList: item.shopRegionList
        };
        return tmp;
      });
    }
  } catch (e) {
    console.log('e : ', e);
  }
};

// 门店 props
const shopProps: CascaderProps = {
  label: 'shopName',
  value: 'shopId',
  children: 'shopRegionList',
  multiple: true,
  expandTrigger: 'hover'
};

/**
 * 搜索表单相关逻辑
 */
const initFormData = (): ShengMeiSearchFormType => ({
  memberCode: '',
  range: null,
  shopList: []
});

// 搜索表单
const searchForm = ref<ShengMeiSearchFormType>(initFormData());

// 购卡日期选择区域截止到当天
const disabledDate = (time: Date) => {
  const current = Date.now();
  const selected = new Date(time).getTime();
  return selected > current;
};

// 搜索表单转译后参数
const searchParams = computed<ShengMeiSearchParamsType>(() => {
  let { shopList = [], memberCode, range } = toValue(searchForm);
  let shopIdList: number[] = [];
  let startDate = '';
  let endDate = '';

  // 店铺多选
  if (shopList.length) {
    for (let [, id] of shopList) {
      id && shopIdList.push(id as number);
    }
  }

  // 购卡日期
  if (range && (range as string[]).length) {
    [startDate, endDate] = range as string[];
  }
  return { memberCode, shopIdList, startDate, endDate };
});

/**
 * 数据表格相关逻辑
 */
const table = useTable<DoubleBeautifulCardItemType, ShengMeiSearchParamsType>({
  port: getShengMeiTableDataPort,
  searchForm: searchParams,
  exportPort: exportShengMeiTablePort,
  exportExcelName: '生美销售双美卡明细表'
});

const { tableData, tableLoading, pagination, handleExport } = table;

const handleSearch = () => {
  table.handleSearch();
  getTotalAmount();
};

const handleReset = () => {
  searchForm.value = initFormData();
  table.handleReset();
  getTotalAmount();
};

/**
 * 获取表格总额
 */
const totalAmount = ref<number>(0);
const getTotalAmount = async () => {
  try {
    const { val: data, success } = await getShengMeiTotalAmountPort(searchParams.value);
    if (success === '0') {
      totalAmount.value = data;
    }
  } catch (e) {
    console.log('e : ', e);
  }
};
</script>

<template>
  <div class="table-box">
    <div class="card table-search">
      <el-form ref="searchFormRef" :model="searchForm" label-width="70">
        <el-row :gutter="10">
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="门店">
              <el-cascader
                class="wp-100"
                v-model="searchForm.shopList"
                :props="shopProps"
                :options="shopOptions"
                :clearable="true"
                collapse-tags
                collapse-tags-tooltip
                filterable
              />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="客户号">
              <el-input v-model="searchForm.memberCode" placeholder="请输入" />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="购卡日期">
              <el-date-picker
                v-model="searchForm.range"
                type="daterange"
                start-placeholder="起始日期"
                end-placeholder="结束日期"
                unlink-panels
                format="YYYY-MM-DD"
                value-format="YYYY-MM-DD"
                :disabled-date="disabledDate"
                @change="handleSearch"
              />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item>
              <el-space>
                <el-button type="primary" @click="handleSearch" :disabled="isDisabledRead">搜索</el-button>
                <el-button type="success" @click="handleReset" :disabled="isDisabledRead">重置</el-button>
                <el-button type="primary" :icon="Download" plain @click="handleExport" :disabled="isDisabledExport">
                  导出
                </el-button>
              </el-space>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <div class="card table-main">
      <el-table v-loading="tableLoading" :data="tableData" style="width: 100%" border>
        <el-table-column prop="shopName" label="门店" align="center" min-width="100" fixed />
        <el-table-column prop="memberName" label="客户名称" align="center" min-width="120" />
        <el-table-column prop="saleOrderCode" label="销售单号" align="center" min-width="120" />
        <el-table-column prop="memberCode" label="顾客号" align="center" min-width="120" />
        <el-table-column prop="saleDate" label="购卡日期" align="center" min-width="140" />
        <el-table-column prop="itemName" label="卡名称" align="center" min-width="120" />
        <el-table-column prop="cardType" label="卡分类" align="center" min-width="120" />
        <el-table-column prop="amount" label="卡金额" align="center" min-width="120" />
        <el-table-column prop="belongTo" label="归属单位" align="center" min-width="120" />
      </el-table>
      <el-row :gutter="10">
        <el-col :xs="24" :sm="24" :md="24" :lg="6" :xl="6">
          <div class="fz14 mt20" style="color: var(--el-text-color-regular)">卡金额总合计：{{ totalAmount }}</div>
        </el-col>
        <el-col :xs="24" :sm="24" :md="24" :lg="18" :xl="18">
          <el-pagination
            background
            layout="total, sizes, prev, pager, next, jumper"
            :current-page="pagination.page"
            :page-size="pagination.pageSize"
            :page-sizes="pagination.pageSizes"
            :total="pagination.itemCount"
            @current-change="pagination.onChange"
            @size-change="pagination.onPageSizeChange"
          />
        </el-col>
      </el-row>
    </div>
  </div>
</template>
