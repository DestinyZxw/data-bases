<script setup lang="ts" name="wxRegister">
import { useUserStore } from '@/stores/modules/user';
import { getQueryString } from '@/utils';
import { wxLoginPort } from '@/api/modules/login';
import { HOME_URL } from '@/config';
import { ElLoading, ElMessage } from 'element-plus';

const router = useRouter();

onMounted(() => {
  init();
});

// 初始化
async function init() {
  const userStore = useUserStore();
  if (!userStore.token) {
    // 截取code
    let code = getQueryString('code');
    let state = getQueryString('state');
    console.log('code --------------- : ', code, 'state --------------- : ', state);
    if (code && state == 'A1') {
      const loading = ElLoading.service({ lock: true, text: 'Loading', background: 'rgba(0, 0, 0, 0.4)' });
      try {
        if (!userStore.token) {
          // 获取token 存入缓存
          let { val: token, success } = await wxLoginPort({ code });
          if (success === '0') {
            userStore.setToken(token);
            await router.push(HOME_URL);
          }
        }
      } catch (err) {
        console.log('catch error : ', err);
      } finally {
        loading.close();
      }
    } else {
      ElMessage.error('网络错误 ！');
    }
  } else {
    await router.push(HOME_URL);
  }
}
</script>

<template>
  <div class="content"></div>
</template>

<style lang="scss" scoped>
.content {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100vw;
  height: 100vh;
  overflow: hidden;
  background-color: #de5c8c;
  background-image: url('@/assets/images/wxwelcome.jpg');
  background-repeat: no-repeat;
  background-size: 100%;
}
</style>
