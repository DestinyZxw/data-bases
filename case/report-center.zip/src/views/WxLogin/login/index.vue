<script setup lang="ts" name="wxLogin">
import { CURRENT_OPTION } from '@/config';
import qs from 'qs';

onMounted(() => {
  window.sessionStorage.setItem('wxFlag', 'Yes');
  let url = getOAuthUrl();
  window.location.replace(url);
});

function getOAuthUrl() {
  let redirectUri = window.location.href.replace('wxLogin', 'wxRegister');
  const search = {
    appid: CURRENT_OPTION.corpId,
    redirect_uri: encodeURIComponent(redirectUri),
    response_type: 'code',
    scope: 'snsapi_base',
    agentid: CURRENT_OPTION.agentId,
    state: 'A1'
  };
  const searchParams = qs.stringify(search);
  return `https://open.weixin.qq.com/connect/oauth2/authorize?${searchParams}#wechat_redirect`;
}
</script>

<template>
  <div class="content"></div>
</template>

<style lang="scss" scoped>
.content {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100vw;
  height: 100vh;
  overflow: hidden;
  background-color: #de5c8c;
  background-image: url('@/assets/images/wxwelcome.jpg');
  background-repeat: no-repeat;
  background-size: 100%;
}
</style>
