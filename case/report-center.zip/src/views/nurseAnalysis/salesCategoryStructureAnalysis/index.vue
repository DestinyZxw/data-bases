<template>
  <RubPage>
    <template #header>
      <div class="card pb0">
        <RubSearchForm
          read-auth-code="MENU_TREATMENT_TYPE_STRUCT_READ"
          @init="handleSearch"
          @search="handleSearch"
          @reset="handleReset"
        />
      </div>
    </template>
    <el-row :gutter="14">
      <!--  销售类别结构 -- 部位  -->
      <el-col :xs="24" :sm="24" :md="14" :lg="16" class="mt14">
        <el-card shadow="hover">
          <template #header>
            <div class="flex items-center justify-between h-30">
              <div class="font-bold">销售类别结构 -- 部位</div>
              <div class="fz14" style="color: var(--el-text-color-secondary)">单位: 万元</div>
            </div>
          </template>
          <view class="flex justify-end mb16">
            <el-button type="primary" plain size="small" @click="exportNursingSaleAnalyseTableData">
              导出<el-icon class="el-icon--right"><Download /></el-icon>
            </el-button>
          </view>
          <el-table :data="tableData" class="wp-100" border style="height: 600px">
            <el-table-column prop="nursingServicePositionName" label="部位" align="center" width="140">
              <template #default="{ row }"> {{ handleFilterTableRow(row, 'nursingServicePositionName') }} </template>
            </el-table-column>
            <el-table-column prop="subtotalSalesCount" label="销售数量" align="center">
              <template #default="{ row }">{{ handleFilterTableRow(row, 'subtotalSalesCount') }}</template>
            </el-table-column>
            <el-table-column prop="salesCountRatio" label="数量结构(%)" align="center">
              <template #default="{ row }">{{ handleFilterTableRow(row, 'salesCountRatio') }}</template>
            </el-table-column>
            <el-table-column prop="subtotalSalesAmount" label="销售金额" align="center">
              <template #default="{ row }">{{ handleFilterTableRow(row, 'subtotalSalesAmount') }}</template>
            </el-table-column>
            <el-table-column prop="salesAmountRatio" label="销售结构(%)" align="center">
              <template #default="{ row }">{{ handleFilterTableRow(row, 'salesAmountRatio') }}</template>
            </el-table-column>
            <el-table-column prop="grossMargin" label="毛利率" align="center">
              <template #default="{ row }">{{ handleFilterTableRow(row, 'grossMargin') }}</template>
            </el-table-column>
            <el-table-column prop="grossMarginSigma" label="∑毛利率" align="center">
              <template #default="{ row }">{{ handleFilterTableRow(row, 'grossMarginSigma') }}</template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>

      <!--  销售结构(%)  -->
      <el-col :xs="24" :sm="24" :md="10" :lg="8" class="mt14">
        <el-card shadow="hover">
          <template #header>
            <div class="font-bold h-30 lht30">销售结构(%)</div>
          </template>
          <RubEmptyTip :show="pieChartsStatus">
            <el-scrollbar>
              <RubPieChart v-bind="pieChartsData" class="pieChart" style="height: 640px" />
            </el-scrollbar>
          </RubEmptyTip>
        </el-card>
      </el-col>

      <!--  销售类别结构 -- 分类  -->
      <el-col :span="24" class="mt14">
        <el-card shadow="hover">
          <template #header>
            <div class="flex items-center justify-between h-30">
              <div class="font-bold">销售类别结构 -- 分类</div>
              <div class="fz14" style="color: var(--el-text-color-secondary)">单位: 万元</div>
            </div>
          </template>
          <el-table :data="salesStructureTableData" class="wp-100" border style="height: 600px">
            <el-table-column prop="classification" label="分类" align="center" width="140" />
            <el-table-column prop="salesAmount" label="销售收入" align="center">
              <template #default="{ row }">{{ handleFilterTableRow(row, 'salesAmount') }}</template>
            </el-table-column>
            <el-table-column prop="grossProfit" label="毛利额" align="center">
              <template #default="{ row }">{{ handleFilterTableRow(row, 'grossProfit') }}</template>
            </el-table-column>
            <el-table-column prop="grossProfitRatio" label="综合毛利率" align="center">
              <template #default="{ row }">{{ handleFilterTableRow(row, 'grossProfitRatio') }}</template>
            </el-table-column>
            <el-table-column prop="salesStructure" label="销售结构%" align="center">
              <template #default="{ row }">{{ handleFilterTableRow(row, 'salesStructure') }}</template>
            </el-table-column>
            <el-table-column prop="grossProfitStructure" label="毛利贡献%" align="center">
              <template #default="{ row }">{{ handleFilterTableRow(row, 'grossProfitStructure') }}</template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>
    </el-row>
  </RubPage>
</template>

<!-- 护理销售类别结构 页面 -->
<script setup lang="ts" name="nurseSalesCategoryStructureAnalysis">
import {
  getNursingSaleAnalyseTablePort,
  exportNursingSaleAnalysePort,
  NursingSaleAnalyseTableItemType
} from '@/api/modules/shop';
import { getNursingSalesStructurePort, NursingSalesStructureItemType } from '@/api/modules/nurseAnalysis';
import { SearchParamsType } from '@/components/rub-search-form/interfaces';
import { Chart } from '@/typings/global';
import { handleFilterTableRow } from '@/utils';
import { ElMessageBox } from 'element-plus';
import { useDownload } from '@/hooks/useDownload';

const searchParams = ref<SearchParamsType>({} as SearchParamsType);
const handleSearch = (data: SearchParamsType) => {
  searchParams.value = data;
  getTableData(data);
  getNursingSalesStructureData(data);
};

const handleReset = (data: SearchParamsType) => {
  handleSearch(data);
};

// table表格数据
const tableData = ref<NursingSaleAnalyseTableItemType[]>([]);

// pie 饼图数据
const pieChartsStatus = ref(false);
const pieChartsData = ref<Chart.PieChartType>({} as Chart.PieChartType);

const getTableData = async (args: SearchParamsType) => {
  try {
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = { shopIdList, startMonth, endMonth };
    let { val: data, success } = await getNursingSaleAnalyseTablePort(params);
    if (success === '0') {
      // 表格数据
      tableData.value = data;

      pieChartsStatus.value = !!data.length;
      if (!data.length) return;

      let pieData = data.reduce(
        (accumulator, current) => (
          current.nursingServicePositionName !== '总计' &&
            accumulator.push({
              name: current.nursingServicePositionName,
              value: current.salesAmountRatio
            }),
          accumulator
        ),
        [] as { name: string; value: number }[]
      );

      // 饼图分布图 数据
      pieChartsData.value = {
        position: 'outside',
        data: pieData,
        colors: ['#A38FBC', '#FBC191', '#B1B1B1', '#FFD660', '#84B2DF', '#78B153']
      };
    }
  } catch (e) {
    console.log('e : ', e);
  }
};

// 导出销售类别结构table数据
const exportNursingSaleAnalyseTableData = () => {
  const { shopIdList, startMonth, endMonth } = toValue(searchParams);
  const params = { shopIdList, startMonth, endMonth };

  ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
    useDownload({
      port: exportNursingSaleAnalysePort,
      fileName: '销售类别结构-部位分析表',
      params
    })
  );
};

const salesStructureTableData = ref<NursingSalesStructureItemType[]>([]);
const getNursingSalesStructureData = async (args: SearchParamsType) => {
  try {
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = { shopIdList, startMonth, endMonth };
    let { val: data, success } = await getNursingSalesStructurePort(params);
    if (success === '0') {
      salesStructureTableData.value = data.nursingSalesStructureItemVOS;
    }
  } catch {}
};
</script>
