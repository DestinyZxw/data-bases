<template>
  <div class="table-box">
    <div class="card table-search pb0">
      <RubSearchForm
        read-auth-code="MENU_TREATMENT_SALE_DETAIL_READ"
        isNurseType
        @init="handleSearch"
        @search="handleSearch"
        @reset="handleReset"
      />
    </div>

    <el-card
      shadow="hover"
      :body-style="{
        padding: '15px',
        flex: 1,
        height: 'calc(100% - 80px)',
        display: 'flex',
        flexDirection: 'column',
        boxSizing: 'border-box'
      }"
      class="table-main"
    >
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold">销售明细结构表</div>
          <el-button type="primary" plain size="small" @click="exportTableData">
            导出<el-icon class="el-icon--right"><Download /></el-icon>
          </el-button>
        </div>
      </template>
      <el-table v-loading="tableLoading" :data="tableData" class="wp-100" border>
        <el-table-column prop="bigType" label="大类" align="center" min-width="120" v-bind="isMobile ? {} : { fixed: 'left' }" />
        <el-table-column prop="itemName" label="护理名称" align="center" min-width="260">
          <template #default="{ row }">
            <div class="tl">{{ handleFilterTableRow(row, 'itemName') }}</div>
          </template>
        </el-table-column>
        <el-table-column prop="grossMargin" label="毛利率" align="center" min-width="120">
          <template #default="{ row }"> {{ handleFilterTableRow(row, 'grossMargin') }} </template>
        </el-table-column>
        <el-table-column prop="saleCount" align="center" min-width="180">
          <template #header>
            <div class="fz-12 tc" style="color: var(--el-text-color-secondary)">
              <span class="fz-15 font-bold" style="color: var(--el-text-color-primary)">护理销售数量</span>(不含免单)
            </div>
          </template>
          <template #default="{ row }"> {{ handleFilterTableRow(row, 'saleCount') }} </template>
        </el-table-column>
        <el-table-column prop="saleCountRate" label="销售数量%" align="center" min-width="120">
          <template #default="{ row }"> {{ handleFilterTableRow(row, 'saleCountRate') }} </template>
        </el-table-column>
        <el-table-column prop="saleAmount" label="实付金额（元）" align="center" min-width="140">
          <template #default="{ row }"> {{ handleFilterTableRow(row, 'saleAmount') }} </template>
        </el-table-column>
        <el-table-column prop="saleAmountRate" label="实付额%" align="center" min-width="120">
          <template #default="{ row }"> {{ handleFilterTableRow(row, 'saleAmountRate') }} </template>
        </el-table-column>
        <el-table-column prop="personCountAmount" label="平均值项:客单" align="center" min-width="120">
          <template #default="{ row }"> {{ handleFilterTableRow(row, 'personCountAmount') }} </template>
        </el-table-column>
        <el-table-column prop="price" label="平均值项:单价" align="center" min-width="120">
          <template #default="{ row }"> {{ handleFilterTableRow(row, 'price') }} </template>
        </el-table-column>
        <el-table-column prop="freeSaleCount" label="护理免单数量" align="center" min-width="120">
          <template #default="{ row }"> {{ handleFilterTableRow(row, 'freeSaleCount') }} </template>
        </el-table-column>
        <el-table-column prop="hourGrossAmount" label="小时毛利（元）" align="center" min-width="140">
          <template #default="{ row }"> {{ handleFilterTableRow(row, 'hourGrossAmount') }} </template>
        </el-table-column>
        <el-table-column prop="amountRank" label="销售金额排名" align="center" min-width="140">
          <template #default="{ row }"> {{ handleFilterTableRow(row, 'amountRank') }} </template>
        </el-table-column>
        <el-table-column prop="pricePersonCountAmountRate" label="销售价与客单价比" align="center" min-width="150">
          <template #default="{ row }"> {{ handleFilterTableRow(row, 'pricePersonCountAmountRate') }} </template>
        </el-table-column>
        <el-table-column prop="freeSaleCountRate" label="免单占销量数量比" align="center" min-width="150">
          <template #default="{ row }"> {{ handleFilterTableRow(row, 'freeSaleCountRate') }} </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<!-- 销售明细 管理表 -->
<script setup lang="ts" name="shopSalesSheet">
import { getSalesAnalyseTablePort, exportSalesAnalyseTablePort, SalesAnalyseTableItemType } from '@/api/modules/shop';
import { SearchParamsType } from '@/components/rub-search-form/interfaces';
import { handleFilterTableRow } from '@/utils';
import { useGlobalStore } from '@/stores/modules/global';
import { ElMessageBox } from 'element-plus';
import { useDownload } from '@/hooks/useDownload';

const globalStore = useGlobalStore();
const isMobile = computed(() => globalStore.device === 'mobile');

const searchParams = ref<SearchParamsType>({} as SearchParamsType);
const handleSearch = (data: SearchParamsType) => {
  searchParams.value = data;
  getTableData(data);
};

const handleReset = (data: SearchParamsType) => {
  tableData.value = [];
  handleSearch(data);
};

const tableData = ref<SalesAnalyseTableItemType[]>([]);
const tableLoading = ref(false);
const getTableData = async (args: SearchParamsType) => {
  if (tableLoading.value) return;
  tableLoading.value = true;
  try {
    let { shopIdList, startMonth, endMonth, tableType } = toValue(args);
    let params = {
      shopIdList,
      startMonth,
      endMonth,
      newFlag: '',
      type: '护理',
      twoOrder: tableType
    };
    let { val: data, success } = await getSalesAnalyseTablePort(params);
    if (success === '0') {
      tableData.value = data;
    }
  } catch {
  } finally {
    tableLoading.value = false;
  }
};

const exportTableData = () => {
  let { shopIdList, startMonth, endMonth, tableType } = toValue(searchParams);
  let params = {
    shopIdList,
    startMonth,
    endMonth,
    newFlag: '',
    type: '护理',
    twoOrder: tableType
  };
  ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
    useDownload({
      port: exportSalesAnalyseTablePort,
      fileName: '护理销售明细结构表',
      params
    })
  );
};
</script>
