<template>
  <RubPage>
    <!-- 一、护理上市时间 -->
    <el-card shadow="hover" :body-style="{ padding: '14px 14px 8px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz20">一、护理上市时间</div>
        </div>
      </template>
      <el-card class="mb10">
        <RubEmptyTip :show="chartStatus">
          <el-scrollbar>
            <RubBaseChart v-bind="chartData" class="chart" style="height: 520px" />
          </el-scrollbar>
        </RubEmptyTip>
      </el-card>
    </el-card>
  </RubPage>
</template>

<!-- 护理上市时间 页面 -->
<script setup lang="ts" name="nurseMarketTimeAnalysis">
import { Chart } from '@/typings/global';
import { getTreatmentPublishTimePort } from '@/api/modules/nurseAnalysis';
import { useButtonAuth } from '@/hooks/useButtonAuth';

// 按钮权限
useButtonAuth({
  read: 'MENU_TREATMENT_SALE_DATE_READ',
  initFn: () => getTreatmentPublishTimeData()
});

// 客装SKU 图表数据
const chartStatus = ref(false);
const chartData = ref<Chart.BaseChartType>({});

const getTreatmentPublishTimeData = async () => {
  try {
    const { val: data, success } = await getTreatmentPublishTimePort();
    if (success === '0') {
      chartStatus.value = !!data.length;
      if (!data.length) return;

      let axis: string[] = [],
        list: number[] = [];
      for (let item of data) {
        axis.push(item.statYear + '年');
        list.push(item.count);
      }
      chartData.value = {
        title: '疗程上市时间',
        tooltip: { axisPointer: { type: 'shadow' } },
        xAxisBoundaryGap: true,
        xAxisLabelRotate: 0,
        grid: { top: '10%', bottom: '5%' },
        axis,
        series: [{ type: 'bar', data: list, label: { show: true, position: 'top' }, barMaxWidth: 40 }]
      };
    }
  } catch {}
};
</script>
