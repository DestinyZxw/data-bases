<template>
  <RubPage>
    <template #header>
      <div class="card pb0">
        <RubSearchForm
          read-auth-code="MENU_TREATMENT_SALE_DECISION_READ"
          @init="handleSearch"
          @search="handleSearch"
          @reset="handleReset"
        />
      </div>
    </template>

    <el-card shadow="hover" class="mt14" :body-style="{ 'padding-bottom': '6px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold">波士顿矩阵及帕累托分析</div>
        </div>
      </template>
      <el-row :gutter="10" class="mb4">
        <el-col :xs="24" :sm="24" :md="24" :lg="12" :xl="12">
          <div class="selector">
            <div class="name">品类筛选</div>
            <RubSelector v-model="propertyValue" :options="propertyOptions" auth-code="MENU_TREATMENT_SALE_DECISION_READ" />
          </div>
        </el-col>
        <el-col :xs="24" :sm="24" :md="24" :lg="12" :xl="12">
          <div class="selector">
            <div class="name">护理类别</div>
            <RubSelector v-model="kindValue" :options="kindOptions" auth-code="MENU_TREATMENT_SALE_DECISION_READ" />
          </div>
        </el-col>
      </el-row>
      <el-card class="mb24" v-loading="nursingServiceAnalyseLoading">
        <RubEmptyTip :show="nurseParetoStatus">
          <!--<el-scrollbar>
            <RubDoubleYAxisChart v-bind="nurseParetoChartData" class="chart pt10" />
          </el-scrollbar>-->
          <RubDoubleYAxisChart v-bind="nurseParetoChartData" class="pt10" />
        </RubEmptyTip>
      </el-card>
      <el-row :gutter="10">
        <el-col :xs="24" :sm="24" :md="14" :lg="16">
          <div style="color: var(--el-color-white); background-color: #5b9bd5" class="lht30 fz16 mb14 pl10">
            从销量和毛利额来看
          </div>
          <el-card v-loading="nursingServiceAnalyseLoading" class="mb14">
            <RubEmptyTip :show="nurseParetoStatus">
              <el-scrollbar>
                <FourQuadrantChart v-bind="faceGrossProfitMarginData" key="first" />
              </el-scrollbar>
            </RubEmptyTip>
          </el-card>
          <el-card v-loading="nursingServiceAnalyseLoading" class="mb14">
            <RubEmptyTip :show="nurseParetoStatus">
              <el-scrollbar>
                <FourQuadrantChart v-bind="faceGrossProfitRateData" key="second" />
              </el-scrollbar>
            </RubEmptyTip>
          </el-card>
        </el-col>
        <el-col :xs="24" :sm="24" :md="10" :lg="8">
          <div style="color: var(--el-color-white); background-color: #1f4e78" class="lht30 fz16 mb14 pl10">小时毛利排名</div>
          <el-card v-loading="nurseHourlyGrossProfitLoading" class="mb14" :body-style="{ padding: '20px 10px' }">
            <RubEmptyTip :show="verticalBarChartsStatus">
              <el-scrollbar>
                <RubVerticalBarChart
                  v-bind="verticalBarChartsData"
                  :style="{ width: device === 'mobile' ? '500px' : '100%', height: '1416px' }"
                />
              </el-scrollbar>
            </RubEmptyTip>
          </el-card>
        </el-col>
      </el-row>
    </el-card>
  </RubPage>
</template>

<!-- 护理上下市决策 页面 -->
<script setup lang="ts" name="nurseMarketDecisionAnalysis">
import { getNursingSalesAnalysePort, getNursingSalesHourlyGrossProfitPort } from '@/api/modules/nurseAnalysis';
import { SearchParamsType } from '@/components/rub-search-form/interfaces';
import { Chart } from '@/typings/global';
import { useGlobalStore } from '@/stores/modules/global';
import FourQuadrantChart from '@/views/shop/components/four-quadrant-chart.vue';
import type { ModelValueType, SelectorOptionItemType } from '@/components/rub-selector/index.vue';

const globalStore = useGlobalStore();
const { device } = storeToRefs(globalStore);
const isMobile = computed(() => globalStore.device === 'mobile');

const searchParams = ref<SearchParamsType>({} as SearchParamsType);
const handleSearch = (data: SearchParamsType) => {
  searchParams.value = data;
  getNursingServiceAnalyseData();
  getNursingServiceHourlyGrossProfitData();
};

const handleReset = (data: SearchParamsType) => {
  // selectKitType.value = 'A';
  handleSearch(data);
};

const propertyValue = ref<ModelValueType>('独立');
const kindValue = ref<ModelValueType>('面部');
const kindOptions: SelectorOptionItemType[] = [
  { name: '面部', value: '面部' },
  { name: '身体', value: '身体' },
  { name: '仪器', value: '仪器' }
];
const propertyOptions: SelectorOptionItemType[] = [
  { name: '独立', value: '独立' },
  { name: '叠加', value: '叠加' }
];

watch([kindValue, propertyValue], () => {
  getNursingServiceAnalyseData();
  getNursingServiceHourlyGrossProfitData();
});

type ChartType = Chart.FourQuadrantChartType;
const nurseParetoStatus = ref(false);
// 面部 -- 独立高频帕累托 当前数据
const nurseParetoChartData = ref<Chart.DoubleYAxisChartType>({});
//  面部 -- 独立高频项矩阵 --> 毛利额
const faceGrossProfitMarginData = ref<ChartType>({} as ChartType);
//  面部 -- 独立高频项矩阵 --> 毛利率
const faceGrossProfitRateData = ref<ChartType>({} as ChartType);

// 获取面部 - 独立图标及矩阵数据
const nursingServiceAnalyseLoading = ref(false);
const getNursingServiceAnalyseData = async () => {
  if (nursingServiceAnalyseLoading.value) return;
  nursingServiceAnalyseLoading.value = true;
  try {
    let { shopIdList, startMonth, endMonth } = toValue(searchParams);
    let params = {
      shopIdList,
      startMonth,
      endMonth,
      workHourProperty: propertyValue.value === '独立' ? 'A' : 'D',
      serviceTypeName: kindValue.value === '仪器' ? kindValue.value : `手工${kindValue.value}`
    };
    let { val: data, success } = await getNursingSalesAnalysePort(params);
    if (success === '0') {
      nurseParetoStatus.value = !!data.length;
      if (!data.length) return;

      let axis: string[] = [];
      let amountArray = []; // 客单价增长 集合
      let rateArray = []; // 客单价增长率 集合
      let originalGrossProfitMarginData: Chart.FourQuadrantChartItem[] = []; // 面部 - 毛利额
      let originalGrossProfitRateData: Chart.FourQuadrantChartItem[] = []; // 面部 - 毛利率

      for (let item of data) {
        axis.push(item.serviceName);
        amountArray.push(+(item.salesAmount ?? 0).toFixed(2));
        rateArray.push(+(item.cumulative ?? 0).toFixed(2));

        originalGrossProfitMarginData.push({
          name: item.serviceName,
          data: [item.salesCount || 0, item.salesAmount || 0]
        });

        originalGrossProfitRateData.push({
          name: item.serviceName,
          data: [item.salesCount || 0, item.grossMargin || 0]
        });
      }

      let oneScreenValue = isMobile.value ? 5 : 40, // 横向 一屏数据展示的基准值
        dataZoom = [
          {
            type: isMobile.value ? 'inside' : 'slider',
            start: 0,
            end: Math.floor((oneScreenValue * 100) / (axis.length || oneScreenValue)),
            zoomLock: !isMobile.value,
            zoomOnMouseWheel: false,
            brushSelect: false,
            padding: [10, 20, 10, 20]
          }
        ];

      // 帕累托图表数据
      nurseParetoChartData.value = {
        title: `${kindValue.value} -- ${propertyValue.value}帕累托`,
        yAxisRightUnit: '%',
        colors: ['#40699c', '#ff0000'],
        axis,
        series: [
          { name: '销售额(万元)', type: 'bar', data: amountArray, barMaxWidth: 48 },
          { name: '销售权重(%)', type: 'line', data: rateArray, yAxisIndex: 1, smooth: true }
        ],
        // 导轨
        ...(axis.length > oneScreenValue ? { dataZoom } : {})
      };

      // 面部 - 毛利额
      faceGrossProfitMarginData.value = {
        title: `${kindValue.value} -- ${propertyValue.value}项矩阵`,
        originalData: originalGrossProfitMarginData
      };

      // 面部 - 毛利率
      faceGrossProfitRateData.value = {
        title: `${kindValue.value} -- ${propertyValue.value}项矩阵`,
        yAxisTipsName: '毛利率',
        yAxisUnit: '%',
        originalData: originalGrossProfitRateData
      };
    }
  } catch {
  } finally {
    nursingServiceAnalyseLoading.value = false;
  }
};

// 获取小时毛利数据
const verticalBarChartsStatus = ref(false);
const verticalBarChartsData = ref<Chart.VerticalBarChartType>({} as Chart.VerticalBarChartType);
const nurseHourlyGrossProfitLoading = ref(false);
const getNursingServiceHourlyGrossProfitData = async () => {
  if (nurseHourlyGrossProfitLoading.value) return;
  nurseHourlyGrossProfitLoading.value = true;
  try {
    let { shopIdList, startMonth, endMonth } = toValue(searchParams);
    let params = {
      shopIdList,
      startMonth,
      endMonth,
      workHourProperty: propertyValue.value === '独立' ? 'A' : 'D',
      serviceTypeName: kindValue.value === '仪器' ? kindValue.value : `手工${kindValue.value}`
    };
    let { val: data, success } = await getNursingSalesHourlyGrossProfitPort(params);
    if (success === '0') {
      verticalBarChartsStatus.value = !!data.length;
      if (!data.length) return;

      let axis: string[] = [],
        seriesData: number[] = [];
      for (let item of data) {
        axis.push(item.serviceName);
        seriesData.push(item.hourlyGrossProfit || 0);
      }
      verticalBarChartsData.value = {
        title: `${kindValue.value} -- ${propertyValue.value}高频小时毛利排名`,
        axis,
        seriesData,
        inverse: true,
        grid: { top: '4%' }
      };
    }
  } catch {
  } finally {
    nurseHourlyGrossProfitLoading.value = false;
  }
};
</script>
