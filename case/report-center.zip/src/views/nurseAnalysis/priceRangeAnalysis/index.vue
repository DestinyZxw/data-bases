<template>
  <RubPage>
    <template #header>
      <div class="card pb0">
        <RubSearchForm
          read-auth-code="MENU_TREATMENT_PRICE_READ"
          @init="handleSearch"
          @search="handleSearch"
          @reset="handleReset"
        />
      </div>
    </template>

    <!-- 价格带 -->
    <el-card shadow="hover" class="mt14 pr" :body-style="{ padding: '14px 14px 8px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz20">{{ categoryValue }}项价格带</div>
        </div>
      </template>
      <el-row :gutter="10" class="mb4">
        <el-col :xs="24" :sm="24" :md="24" :lg="12" :xl="12">
          <div class="selector">
            <div class="name">品类筛选</div>
            <RubSelector v-model="categoryValue" :options="categoryOptions" auth-code="MENU_TREATMENT_PRICE_READ" />
          </div>
        </el-col>
        <el-col :xs="24" :sm="24" :md="24" :lg="12" :xl="12">
          <div class="selector">
            <div class="name">护理属性</div>
            <RubSelector v-model="propertyValue" :options="propertyOptions" auth-code="MENU_TREATMENT_PRICE_READ" />
          </div>
        </el-col>
      </el-row>
      <el-card v-loading="rangeLoading" class="mb14">
        <RubEmptyTip :show="priceChartStatus">
          <el-scrollbar>
            <RubDoubleYAxisChart v-bind="priceChartData" class="chart" style="height: 680px" />
          </el-scrollbar>
        </RubEmptyTip>
      </el-card>
      <el-card v-loading="rangeLoading" class="mb14">
        <RubEmptyTip :show="kindChartStatus">
          <el-scrollbar>
            <RubDoubleYAxisChart v-bind="kindChartData" class="chart" style="height: 680px" />
          </el-scrollbar>
        </RubEmptyTip>
      </el-card>
    </el-card>
  </RubPage>
</template>

<!-- 护理价格带分析 页面 -->
<script setup lang="ts" name="nursePriceRangeAnalysis">
import {
  getNursingPriceRangeForEffectPort,
  getNursingPriceRangeForPositionPort,
  NursingRangeItemType
} from '@/api/modules/nurseAnalysis';
import type { SearchParamsType } from '@/components/rub-search-form/interfaces';
import { Chart } from '@/typings/global';
import echarts from '@/utils/echarts';
import type { ModelValueType, SelectorOptionItemType } from '@/components/rub-selector/index.vue';

let cacheSearchParams: SearchParamsType = {} as SearchParamsType;
const handleSearch = (data: SearchParamsType) => {
  cacheSearchParams = data;
  getNursingPriceRangeData(data);
};

const handleReset = (data: SearchParamsType) => {
  handleSearch(data);
};

const categoryValue = ref<ModelValueType>('独立');
const propertyValue = ref<ModelValueType>('功效');
const categoryOptions: SelectorOptionItemType[] = [
  { name: '独立', value: '独立' },
  { name: '叠加', value: '叠加' }
];
const propertyOptions: SelectorOptionItemType[] = [
  { name: '功效', value: '功效' },
  { name: '部位', value: '部位' }
];

// 对selector属性进行监听
watch([categoryValue, propertyValue], () => {
  getNursingPriceRangeData(cacheSearchParams);
});

// 图表数据  ---  价格带打底
const priceChartStatus = ref(false);
const priceChartData = ref<Chart.DoubleYAxisChartType>({});

// 图表数据  ---  种类打底
const kindChartStatus = ref(false);
const kindChartData = ref<Chart.DoubleYAxisChartType>({});

// 图表的标题
const chartTitle = computed(() => `${categoryValue.value}--${propertyValue.value}价格带`);

// chart options 工厂函数
const chartOptionsFactory = (xAxisName: string, data: NursingRangeItemType[]) => {
  let axis: string[] = [];
  let maps = new Map();
  for (let item of data) {
    let entries = Object.entries(item);
    for (let [key, value] of entries) {
      if (key === xAxisName) {
        axis.push(item[key] as string);
      } else {
        if (maps.has(key)) {
          let mapItem: Chart.SeriesItem = maps.get(key);
          key === '销售数量'
            ? mapItem.data.push(value as number)
            : mapItem.data.push({
                value: value as number,
                label: { show: (value as number) !== 0, position: 'inside' }
              });
        } else {
          let mapItem: Chart.SeriesItem =
            key === '销售数量'
              ? {
                  type: 'line',
                  name: key,
                  data: [value as number],
                  label: { show: true, position: 'top' },
                  yAxisIndex: 0,
                  smooth: true,
                  areaStyle: {
                    color: new echarts.graphic.LinearGradient(
                      0,
                      0,
                      0,
                      1,
                      [
                        { offset: 0, color: 'rgba(255,167,166,0.66)' },
                        { offset: 1, color: 'rgba(255,167,166, 0.1)' }
                      ],
                      false
                    )
                  }
                }
              : {
                  type: 'bar',
                  name: key,
                  data: [
                    {
                      value: value as number,
                      label: { show: (value as number) !== 0, position: 'inside' }
                    }
                  ],
                  barMaxWidth: 40,
                  yAxisIndex: 1,
                  stack: 'one'
                };
          maps.set(key, mapItem);
        }
      }
    }
  }
  return {
    title: chartTitle.value,
    tooltip: { axisPointer: { type: 'shadow' } },
    grid: { top: '20%', bottom: '8%' },
    xAxisBoundaryGap: true,
    xAxisLabelRotate: 30,
    yAxisNameVisible: false,
    yAxisLeftColor: '',
    yAxisLeftTickVisible: false,
    yAxisLeftLineVisible: false,
    yAxisRightVisible: false,
    colors: [
      '#FFA6A5',
      '#4F7FBA',
      '#DDFDAE',
      '#CBB7E9',
      '#A3EBFF',
      '#FFC18C',
      '#64D9D6',
      '#409EFF',
      '#FCCEFB',
      '#A5A5A5',
      '#9E480E',
      '#ED7D31',
      '#5B9BD5'
    ],
    axis,
    series: [...maps.values()]
  };
};

const rangeLoading = ref(false);
const getNursingPriceRangeData = async (args: SearchParamsType) => {
  rangeLoading.value = true;
  try {
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = { shopIdList, startMonth, endMonth, workHourProperty: categoryValue.value === '独立' ? 'A' : 'D' };
    let port = propertyValue.value === '功效' ? getNursingPriceRangeForEffectPort : getNursingPriceRangeForPositionPort;
    let { val: data, success } = await port(params);
    if (success === '0') {
      priceChartStatus.value = !!data.nursingPriceRange.length;
      data.nursingPriceRange.length && (priceChartData.value = chartOptionsFactory('价格带', data.nursingPriceRange));

      kindChartStatus.value = !!data.anotherOneRange.length;
      data.anotherOneRange.length &&
        (kindChartData.value = chartOptionsFactory(`${propertyValue.value}带`, data.anotherOneRange));
    }
  } catch {
  } finally {
    rangeLoading.value = false;
  }
};
</script>
