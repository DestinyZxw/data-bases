<template>
  <RubPage>
    <!-- 一、功效分类 -->
    <el-card shadow="hover" :body-style="{ padding: '14px 14px 8px' }" class="mb14">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz20">一、功效分类</div>
        </div>
      </template>
      <el-row :gutter="10">
        <el-col :xs="24" :sm="24" :md="24" :lg="10" :xl="8" class="mb10">
          <el-card shadow="hover">
            <RubEmptyTip :show="effectSkuStatus" style="min-height: 480px">
              <view class="flex justify-end mb16">
                <el-button type="primary" plain size="small" @click="exportTableData('effect')">
                  导出<el-icon class="el-icon--right"><Download /></el-icon>
                </el-button>
              </view>
              <el-table :data="effectSkuTableData" show-summary class="wp-100" border style="height: 440px">
                <el-table-column
                  v-for="(value, key, index) in effectSkuTableData[0] ?? {}"
                  align="center"
                  min-width="120"
                  :prop="key"
                  :label="effectSkuMaps[key as SkuKeyType] || key"
                  :key="index"
                >
                  <template #default="{ row }">
                    {{ Number(row[key]) ? Number(row[key]) : row[key] || row[key] === 0 ? row[key] : '/' }}
                  </template>
                </el-table-column>
              </el-table>
            </RubEmptyTip>
          </el-card>
        </el-col>
        <el-col :xs="24" :sm="24" :md="24" :lg="14" :xl="16" class="mb10">
          <el-card shadow="hover">
            <RubEmptyTip :show="effectSkuStatus" style="height: 480px">
              <RubBaseChart v-bind="effectSkuChartData" style="height: 480px" />
            </RubEmptyTip>
          </el-card>
        </el-col>
      </el-row>
    </el-card>

    <!-- 二、部位分类 -->
    <el-card shadow="hover" :body-style="{ padding: '14px 14px 8px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz20">二、部位分类</div>
        </div>
      </template>
      <el-row :gutter="10">
        <el-col :xs="24" :sm="24" :md="24" :lg="10" :xl="8" class="mb10">
          <el-card shadow="hover">
            <RubEmptyTip :show="partSkuStatus" style="min-height: 480px">
              <view class="flex justify-end mb16">
                <el-button type="primary" plain size="small" @click="exportTableData('part')">
                  导出<el-icon class="el-icon--right"><Download /></el-icon>
                </el-button>
              </view>
              <el-table :data="partSkuTableData" show-summary class="wp-100" border style="height: 440px">
                <el-table-column
                  v-for="(value, key, index) in partSkuTableData[0] ?? {}"
                  align="center"
                  min-width="120"
                  :prop="key"
                  :label="partSkuMaps[key as SkuKeyType] || key"
                  :key="index"
                >
                  <template #default="{ row }">
                    {{ Number(row[key]) ? Number(row[key]) : row[key] || row[key] === 0 ? row[key] : '/' }}
                  </template>
                </el-table-column>
              </el-table>
            </RubEmptyTip>
          </el-card>
        </el-col>
        <el-col :xs="24" :sm="24" :md="24" :lg="14" :xl="16" class="mb10">
          <el-card shadow="hover">
            <RubEmptyTip :show="partSkuStatus" style="height: 480px">
              <RubBaseChart v-bind="partSkuChartData" style="height: 480px" />
            </RubEmptyTip>
          </el-card>
        </el-col>
        <el-col :span="24" class="mb10">
          <el-card shadow="hover">
            <RubEmptyTip :show="partSkuStatus" style="height: 480px">
              <view class="flex justify-end mb16">
                <el-button type="primary" plain size="small" @click="exportTableData('cross')">
                  导出<el-icon class="el-icon--right"><Download /></el-icon>
                </el-button>
              </view>
              <el-table :data="partCrossTableData" show-summary class="wp-100" border style="height: 440px">
                <el-table-column
                  v-for="(value, key, index) in partCrossTableData[0] ?? {}"
                  align="center"
                  min-width="120"
                  :prop="key as string"
                  :label="key as string"
                  :key="index"
                  v-bind="isMobile ? {} : { fixed: index === 0 }"
                >
                  <template #default="{ row }">
                    {{ Number(row[key]) ? Number(row[key]) : row[key] || row[key] === 0 ? row[key] : '/' }}
                  </template>
                </el-table-column>
              </el-table>
            </RubEmptyTip>
          </el-card>
        </el-col>
      </el-row>
    </el-card>
  </RubPage>
</template>

<!-- 护理SKU分布 页面 -->
<script setup lang="ts" name="nurseSkuAnalysis">
import {
  getDistributionOfNursingCategorySkuPort,
  exportEffectSkuTableDataPort,
  exportPartSkuTableDataPort,
  exportCrossSkuTableDataPort,
  NursingCategorySkuItemType
} from '@/api/modules/nurseAnalysis';
import { Chart } from '@/typings/global';
import { useGlobalStore } from '@/stores/modules/global';
import { useButtonAuth } from '@/hooks/useButtonAuth';
import { ElMessageBox } from 'element-plus';
import { useDownload } from '@/hooks/useDownload';

type SkuKeyType = 'itemName' | 'overlay' | 'independent';

const globalStore = useGlobalStore();
const isMobile = computed(() => globalStore.device === 'mobile');

// 按钮权限
useButtonAuth({
  read: 'MENU_TREATMENT_SKU_DISTRIBUTE_READ',
  initFn: () => getDistributionOfNursingCategorySkuData()
});

/**
 * 护理功效sku
 */
// 护理功效 SKU table数据
const effectSkuMaps: Record<SkuKeyType, string> = {
  itemName: '产品名称',
  independent: '独立',
  overlay: '叠加'
};
const effectSkuStatus = ref<boolean>(false);
const effectSkuTableData = ref<NursingCategorySkuItemType[]>([]);

// 护理功效 SKU 图表数据
const effectSkuChartData = ref<Chart.BaseChartType>({});

/**
 * 护理部位sku
 */
// 护理功效 SKU table数据
const partSkuMaps: Record<SkuKeyType, string> = {
  itemName: '部位',
  overlay: '叠加',
  independent: '独立'
};
const partSkuStatus = ref<boolean>(false);
const partSkuTableData = ref<NursingCategorySkuItemType[]>([]);

// 护理功效 SKU 图表数据
const partSkuChartData = ref<Chart.BaseChartType>({});

const partCrossTableStatus = ref<boolean>(false);
const partCrossTableData = ref<{ [key: string]: number | string }[]>([]);

// chart options 工厂函数
const chartOptionFactory = (axis: string[], data1: number[], data2: number[]): Chart.BaseChartType => {
  let oneScreenValue = isMobile.value ? 5 : 18, // 横向 一屏数据展示的基准值
    dataZoom = [
      {
        type: isMobile.value ? 'inside' : 'slider',
        start: 0,
        end: Math.floor((oneScreenValue * 100) / (axis.length || oneScreenValue)),
        zoomLock: !isMobile.value,
        zoomOnMouseWheel: false,
        brushSelect: false,
        padding: [10, 20, 10, 20]
      }
    ];
  return {
    tooltip: { axisPointer: { type: 'shadow' } },
    xAxisBoundaryGap: true,
    xAxisLabelRotate: 45,
    yAxisVisible: false,
    grid: { top: '20%', bottom: '5%' },
    axis: axis,
    colors: ['#ED7D31', '#4472C4'],
    series: [
      {
        type: 'bar',
        name: '独立',
        data: data1.map(item => ({
          value: item,
          label: { show: item !== 0, position: 'inside' }
        })),
        barMaxWidth: 40,
        stack: 'one'
      },
      {
        type: 'bar',
        name: '叠加',
        data: data2.map(item => ({
          value: item,
          label: { show: item !== 0, position: 'inside' }
        })),
        barMaxWidth: 40,
        stack: 'one'
      }
    ],
    // 导轨
    ...(axis.length > oneScreenValue ? { dataZoom } : {})
  };
};

const getDistributionOfNursingCategorySkuData = async () => {
  try {
    let { val: data, success } = await getDistributionOfNursingCategorySkuPort();
    if (success === '0') {
      // 功效分类数据
      effectSkuStatus.value = !!data.nursingEffect.length;
      if (data.nursingEffect.length) {
        effectSkuTableData.value = data.nursingEffect;
        let effectAxis: string[] = [],
          effectIndependents: number[] = [],
          effectOverlay: number[] = [];
        for (let item of data.nursingEffect) {
          effectAxis.push(item.itemName);
          effectIndependents.push(item.independent);
          effectOverlay.push(item.overlay);
        }
        effectSkuChartData.value = chartOptionFactory(effectAxis, effectIndependents, effectOverlay);
      }

      // 部位分类数据
      partSkuStatus.value = !!data.nursingPosition.length;
      if (data.nursingPosition.length) {
        partSkuTableData.value = data.nursingPosition;
        let partAxis: string[] = [],
          partIndependents: number[] = [],
          partOverlay: number[] = [];
        for (let item of data.nursingPosition) {
          partAxis.push(item.itemName);
          partIndependents.push(item.independent);
          partOverlay.push(item.overlay);
        }
        partSkuChartData.value = chartOptionFactory(partAxis, partIndependents, partOverlay);
      }

      // 部位分类 table数据
      partCrossTableStatus.value = !!data.crossing.length;
      if (data.crossing.length) {
        partCrossTableData.value = data.crossing.slice(0, -1);
      }
    }
  } catch {}
};

// 导出 table 数据
const exportTableData = (name: string) => {
  const port =
    name === 'effect' ? exportEffectSkuTableDataPort : name === 'part' ? exportPartSkuTableDataPort : exportCrossSkuTableDataPort;
  const fileName = name === 'effect' ? '护理功效SKU表' : name === 'part' ? '护理部位SKU表' : '护理交叉SKU表';
  ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
    useDownload({
      port,
      fileName
    })
  );
};
</script>
