<template>
  <RubPage>
    <template #header>
      <el-card shadow="hover">
        <el-row :gutter="10">
          <el-col :xs="24" :sm="12">
            <div class="fz22 fb nurse-title">利润分析表</div>
          </el-col>
          <el-col :xs="24" :sm="12" class="tr">
            <el-space>
              <el-date-picker
                style="width: 100%"
                v-model="range"
                type="monthrange"
                format="YYYY-MM"
                value-format="YYYY-MM"
                placeholder="请选择日期"
              />
              <el-button type="primary" :disabled="isDisabledRead" @click="getTendDetails">搜索</el-button>
            </el-space>
          </el-col>
        </el-row>
      </el-card>
    </template>

    <div class="main-content pl12 pr12 mt14">
      <!--   面部护理销量利润分析   -->
      <el-card class="proCard pl10 pr10 mb20" shadow="hover">
        <template #header>
          <div class="flex items-center justify-between h-30">
            <div class="font-bold fz18">面部护理销量利润分析</div>
          </div>
        </template>
        <el-scrollbar>
          <FourQuadrantChart v-bind="faceSalesCountData" />
        </el-scrollbar>
      </el-card>

      <!--   身体护理销量利润分析   -->
      <el-card class="proCard pl10 pr10 mb20" shadow="hover">
        <template #header>
          <div class="flex items-center justify-between h-30">
            <div class="font-bold fz18">身体护理销量利润分析</div>
          </div>
        </template>
        <el-scrollbar>
          <FourQuadrantChart v-bind="bodySalesCountData" />
        </el-scrollbar>
      </el-card>

      <!--   仪器护理销量利润分析   -->
      <el-card class="proCard pl10 pr10 mb20" shadow="hover">
        <template #header>
          <div class="flex items-center justify-between h-30">
            <div class="font-bold fz18">仪器护理销量利润分析</div>
          </div>
        </template>
        <el-scrollbar>
          <FourQuadrantChart v-bind="machineSalesCountData" />
        </el-scrollbar>
      </el-card>

      <!--   面部护理客单价利润分析   -->
      <el-card class="proCard pl10 pr10 mb20" shadow="hover">
        <template #header>
          <div class="flex items-center justify-between h-30">
            <div class="font-bold fz18">面部护理客单价利润分析</div>
          </div>
        </template>
        <el-scrollbar>
          <FourQuadrantChart v-bind="faceAmountCountData" />
        </el-scrollbar>
      </el-card>

      <!--   身体护理客单价利润分析   -->
      <el-card class="proCard pl10 pr10 mb20" shadow="hover">
        <template #header>
          <div class="flex items-center justify-between h-30">
            <div class="font-bold fz18">身体护理客单价利润分析</div>
          </div>
        </template>
        <el-scrollbar>
          <FourQuadrantChart v-bind="bodyAmountCountData" />
        </el-scrollbar>
      </el-card>

      <!--   仪器护理客单价利润分析   -->
      <el-card class="proCard pl10 pr10 mb50" shadow="hover">
        <template #header>
          <div class="flex items-center justify-between h-30">
            <div class="font-bold fz18">仪器护理客单价利润分析</div>
          </div>
        </template>
        <el-scrollbar>
          <FourQuadrantChart v-bind="machineAmountCountData" />
        </el-scrollbar>
      </el-card>
    </div>
  </RubPage>
</template>

<script lang="ts" setup name="profitAnalysisTable">
import { getProfitAnalysisInfoPort } from '@/api/modules/nurseProject';
import dayjs from 'dayjs';
import { Chart } from '@/typings/global';
import { useButtonAuth } from '@/hooks/useButtonAuth';
import FourQuadrantChart from '@/views/nurseProject/components/four-quadrant-chart.vue';
import { NurseItem } from '@/api/modules/nurseProject';

// 按钮权限
const { isDisabledRead } = useButtonAuth({
  read: 'OPERATION_PROFIT_ANALYSIS_READ',
  initFn: () => getTendDetails() // 获取护理详情数据
});

const startDate = dayjs().subtract(3, 'year').format('YYYY-MM');
const endDate = dayjs().format('YYYY-MM');
const range = ref<any>([startDate, endDate]);
const router = useRouter();

type ChartType = Chart.FourQuadrantChartType<NurseItem>;

//  面部护理销量利润分析
const faceSalesCountData = ref<ChartType>({} as ChartType);
// 身体护理销量利润分析
const bodySalesCountData = ref<ChartType>({} as ChartType);
// 内购护理销量利润分析
const machineSalesCountData = ref<ChartType>({} as ChartType);
//  面部护理客单价利润分析
const faceAmountCountData = ref<ChartType>({} as ChartType);
// 身体护理客单价利润分析
const bodyAmountCountData = ref<ChartType>({} as ChartType);
// 内购护理客单价利润分析
const machineAmountCountData = ref<ChartType>({} as ChartType);

// 获取护理详情数据
async function getTendDetails() {
  const [startDate, endDate] = unref(range);
  const days = dayjs(endDate).daysInMonth();
  let params = {
    shopId: '',
    startDate: `${startDate}-01`,
    endDate: `${endDate}-${days}`
  };
  try {
    let { val: data, success } = await getProfitAnalysisInfoPort(params);
    if (success === '0') {
      // 面部护理销量利润分析 相关图表
      faceSalesCountData.value = {
        originalData: data.faceSaleCountProfitModel,
        routeCallback: handleRouteToTendDetailPage
      };

      // 身体护理销量利润分析 相关图表
      bodySalesCountData.value = {
        originalData: data.bodySaleCountProfitModel,
        routeCallback: handleRouteToTendDetailPage
      };

      // 内疗护理销量利润分析 相关图表
      machineSalesCountData.value = {
        originalData: data.machineSaleCountProfitModel,
        routeCallback: handleRouteToTendDetailPage
      };

      // 面部护理客单价利润分析 相关图表
      faceAmountCountData.value = {
        yAxisTipsName: '客单价',
        yAxisUnit: '元',
        originalData: data.faceAmountProfitModel,
        routeCallback: handleRouteToTendDetailPage
      };

      // 身体护理客单价利润分析 相关图表
      bodyAmountCountData.value = {
        yAxisTipsName: '客单价',
        yAxisUnit: '元',
        originalData: data.bodyAmountProfitModel,
        routeCallback: handleRouteToTendDetailPage
      };

      // 内购护理客单价利润分析 相关图表
      machineAmountCountData.value = {
        yAxisTipsName: '客单价',
        yAxisUnit: '元',
        originalData: data.machineAmountProfitModel,
        routeCallback: handleRouteToTendDetailPage
      };
    }
  } catch (e) {
    console.log('e : ', e);
  }
}

// 跳转到 护理详情页
function handleRouteToTendDetailPage(data: any) {
  let [, , name, code] = data.value;
  let [startDate, endDate] = range.value;
  let params = {
    nursingServiceCode: code,
    tabTitle: name,
    startDate,
    endDate
  };
  router.push({ name: 'nurseDetail', params });
}
</script>
<style lang="scss" scoped>
.mobile {
  .nurse-title {
    margin-bottom: 15px;
  }
}
</style>
