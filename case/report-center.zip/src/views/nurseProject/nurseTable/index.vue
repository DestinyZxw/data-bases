<template>
  <div class="table-box">
    <div class="card table-search">
      <el-form ref="searchFormRef" :model="searchForm" :rules="searchRules" label-width="80">
        <el-row :gutter="15">
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="销售门店">
              <el-select v-model="searchForm.shopId" class="wp-100" clearable filterable>
                <el-option v-for="({ shopId, shopName }, index) in shopOptions" :key="index" :label="shopName" :value="shopId" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="日期区间" prop="range">
              <el-date-picker
                class="wp-100"
                v-model="searchForm.range"
                type="monthrange"
                format="YYYY-MM"
                value-format="YYYY-MM"
                placeholder="请选择日期"
              />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item>
              <el-space>
                <el-button type="primary" @click="handleSearch" :disabled="isDisabledRead">搜索</el-button>
                <el-button type="success" @click="handleReset" :disabled="isDisabledRead">重置</el-button>
              </el-space>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <div class="card table-main">
      <el-table
        v-loading="tableLoading"
        class="wp-100"
        border
        :data="tableData"
        row-class-name="pointer"
        @row-dblclick="handleRowDbClick"
      >
        <el-table-column
          label="#"
          align="center"
          type="index"
          :index="(i: number) => pagination.pageSize * (pagination.page - 1) + (i + 1)"
          fixed="left"
          width="60"
        />
        <el-table-column
          label="模块"
          prop="moduleName"
          align="center"
          width="200"
          v-bind="device === 'mobile' ? {} : { fixed: 'left' }"
        />
        <el-table-column
          label="项目编号"
          prop="nursingServiceCode"
          align="center"
          width="120"
          v-bind="device === 'mobile' ? {} : { fixed: 'left' }"
        >
          <template #default="{ row }">
            <div style="color: var(--el-color-primary-light-3)" class="font-bold f14">{{ row.nursingServiceCode }}</div>
          </template>
        </el-table-column>
        <el-table-column label="仪器" prop="device" align="center" width="120" />
        <el-table-column label="护理时间(分钟)" prop="spendTime" align="center" width="140" />
        <el-table-column label="项目名称" prop="nursingServiceName" align="center" width="140" />
        <el-table-column label="上市时间" prop="onSaleDate" align="center" width="160" />
        <el-table-column label="护理金占比(%)" prop="totalAmountRate" align="center" width="140" />
        <el-table-column label="会员占比(%)" prop="memberRate" align="center" width="140" />
        <el-table-column label="复购率(%)" prop="memberRate" align="center" width="140" />
        <el-table-column label="吊牌价(元)" prop="price" align="center" width="140" />
        <el-table-column label="实付价(元)" prop="avgPrice" align="center" width="140" />
        <el-table-column label="利润" prop="profitRate" align="center" width="140">
          <template #header>
            <el-popover trigger="hover" placement="top" width="auto">
              <template #default>
                <div>{{ '<55%低，55-65%中，>65%高' }}</div>
              </template>
              <template #reference>
                <div class="flex items-center justify-center wp-100">
                  <span>利润</span>
                  <el-icon size="16"><QuestionFilled /></el-icon>
                </div>
              </template>
            </el-popover>
          </template>
        </el-table-column>
        <el-table-column label="毛利率(%)" prop="profit" align="center" width="140" />
        <el-table-column label="免单(次)" prop="freeCount" align="center" width="140" />
        <el-table-column label="免单率(%)" prop="freeRate" align="center" width="140" />
        <el-table-column label="销量(不含免单)" prop="netCount" align="center" width="140" />
        <el-table-column label="实际销售额/万元" prop="totalAmount" align="center" width="140" />
      </el-table>
      <el-pagination
        background
        layout="total, sizes, prev, pager, next, jumper"
        :current-page="pagination.page"
        :page-size="pagination.pageSize"
        :page-sizes="pagination.pageSizes"
        :total="pagination.itemCount"
        @current-change="pagination.onChange"
        @size-change="pagination.onPageSizeChange"
      />
    </div>
  </div>
</template>

<!-- 护理列表 -->
<script lang="ts" setup name="nurseTable">
import { FormInstance, FormRules } from 'element-plus';
import { basicShopItem, fetchMemberShopListPort } from '@/api/modules/base';
import { getNurseTablePort, NurseTableItemType } from '@/api/modules/nurseProject';
import { QuestionFilled } from '@element-plus/icons-vue';
import dayjs from 'dayjs';
import { useButtonAuth } from '@/hooks/useButtonAuth';
import { useGlobalStore } from '@/stores/modules/global';
import { NurseFormType, NurseParamsType } from '@/views/nurseProject/interfaces';
import { useTable } from '@/hooks/useTable';

const globalStore = useGlobalStore();
const { device } = storeToRefs(globalStore);

// 按钮权限
const { isDisabledRead } = useButtonAuth({
  read: 'OPERATION_NURSING_LIFE_CYCLE_READ',
  initFn: () => getTableData()
});

const router = useRouter();

onMounted(() => {
  getShopOptionsData();
});

const searchFormRef = ref<FormInstance | null>();
const shopOptions = ref<{ shopId: number; shopName: string }[]>([]);
const getShopOptionsData = async () => {
  try {
    let res = await fetchMemberShopListPort();
    shopOptions.value = (res.shops as basicShopItem[]).map(({ shopId, shopName }) => ({ shopId, shopName }));
  } catch (e) {
    console.log('e : ', e);
  }
};

const startDate = dayjs().subtract(3, 'year').format('YYYY-MM');
const endDate = dayjs().format('YYYY-MM');
const initFormData = (): NurseFormType => ({
  range: [startDate, endDate],
  shopId: ''
});
const searchForm = ref<NurseFormType>(initFormData());
const searchParams = computed<NurseParamsType>(() => {
  const { shopId, range } = toValue(searchForm);
  const [startDate, endDate] = range as string[];
  const days = dayjs(endDate).daysInMonth();
  return {
    shopId,
    startDate: `${startDate}-01`,
    endDate: `${endDate}-${days}`
  };
});

const searchRules = reactive<FormRules>({
  range: [{ required: true, message: '请选择日期', trigger: 'change' }]
});

const table = useTable<NurseTableItemType, NurseParamsType>({
  port: getNurseTablePort,
  searchForm: searchParams
});

const { tableData, tableLoading, pagination, getTableData } = table;

const handleSearch = () => {
  searchFormRef.value?.validate((valid, fields) => {
    if (valid) {
      table.handleSearch();
    } else {
      console.log('error submit!', fields);
    }
  });
};

const handleReset = () => {
  searchForm.value = initFormData();
  searchFormRef.value?.resetFields();
  table.handleReset();
};

const handleRowDbClick = (row: NurseTableItemType) => {
  let { range = [] } = toValue(searchForm);
  let params: {
    nursingServiceCode: string;
    tabTitle: string;
    startDate?: string;
    endDate?: string;
  } = {
    nursingServiceCode: row.nursingServiceCode,
    tabTitle: row.nursingServiceName
  };
  if ((range as string[]).length > 0) {
    const [startDate = '', endDate = ''] = range as string[];
    params = { ...params, startDate, endDate };
  }
  router.push({ name: 'nurseDetail', params });
};
</script>
