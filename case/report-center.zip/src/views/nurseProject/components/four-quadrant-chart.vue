<!-- 四象限图表 -->
<script lang="ts" setup name="FourQuadrantChart">
import { useEcharts } from '@/hooks/useEcharts';
import type { EChartsOption } from 'echarts';
import { NurseItem } from '@/api/modules/nurseProject';

type Props = {
  yAxisTipsName?: string;
  yAxisUnit?: string;
  originalData?: Array<NurseItem>;
  colors?: string[];
  routeCallback?: (data: any) => void;
  title?: string;
};

const props = withDefaults(defineProps<Props>(), {
  title: '',
  yAxisTipsName: '销量',
  yAxisUnit: '次',
  originalData: () => [],
  colors: () => ['#18a058', '#2d8cf0', '#f0a020', '#d03050'],
  routeCallback: () => {}
});

const chartRef = ref<HTMLDivElement | null>(null);
const chartECharts = useEcharts(chartRef as Ref<HTMLDivElement>);

watch(
  () => props.originalData,
  () => {
    renderEChartsGraph();
  },
  { immediate: false }
);

// 面部护理销量利润分析 相关图表
function renderEChartsGraph() {
  let currentEchartsIns = chartECharts.getInstance();
  let data = transformEchartsData(props.originalData);
  let toolboxStatus = false; // 提示框显示
  let iterates = [
    { name: `高${props.yAxisTipsName}高利润`, data: data.topRights, color: '#18a058' },
    { name: `高${props.yAxisTipsName}低利润`, data: data.topLefts, color: '#2d8cf0' },
    { name: `低${props.yAxisTipsName}高利润`, data: data.bottomRights, color: '#f0a020' },
    { name: `低${props.yAxisTipsName}低利润`, data: data.bottomLefts, color: '#d03050' }
  ];
  let series: any = iterates.map((item, index) => ({
    id: `scatter_${index}`,
    name: item.name,
    type: 'scatter',
    data: item.data,
    symbolSize: 18,
    itemStyle: {
      //当前数据的样式
      // color: item.color
    },
    label: {
      show: toolboxStatus,
      position: 'top',
      formatter(params: any): string {
        let [profit, count, name] = params.data;
        return [`{a|${name}}{abg|}`, '{hr|}', `  {b|${props.yAxisTipsName}: ${count}} {per|${profit}%}`].join('\n');
      },
      backgroundColor: '#F6F8FC',
      borderColor: '#8C8D8E',
      borderWidth: 1,
      borderRadius: 4,
      rich: {
        a: {
          color: item.color,
          lineHeight: 22,
          padding: [3, 4],
          align: 'center'
        },
        hr: {
          borderColor: '#8C8D8E',
          width: '100%',
          borderWidth: 0.5,
          height: 0
        },
        b: {
          color: '#4C5058',
          fontSize: 14,
          fontWeight: 'bold',
          lineHeight: 33
        },
        per: {
          color: '#fff',
          backgroundColor: '#4C5058',
          padding: [3, 4],
          borderRadius: 4
        }
      }
    },
    markLine: {
      // 标记线设置
      symbolSize: 0, // 控制箭头和原点的大小、官方默认的标准线会带远点和箭头
      data: [
        // 设置两条标准线——x=10 和 y=10
        {
          xAxis: data.percentBaseLine,
          lineStyle: {
            type: 'solid',
            color: '#556EAA'
          }
        },
        {
          yAxis: data.countBaseLine,
          lineStyle: {
            type: 'solid',
            color: '#DB442D'
          }
        }
      ]
    }
  }));
  let option = {
    color: props.colors,
    legend: props.title ? { top: '8%' } : {},
    title: {
      text: props.title,
      left: 'center',
      show: !!props.title,
      textStyle: {
        fontSize: '24px'
      }
    },
    grid: {
      left: '3%',
      right: '8%',
      bottom: '5%',
      top: '14%',
      containLabel: true
    },
    tooltip: {
      show: !toolboxStatus,
      showDelay: 0,
      position: 'top',
      alwaysShowContent: !toolboxStatus,
      formatter(params: any) {
        let [profit, count, name] = params.data;
        return `
          <span style="text-align: center">${name}</span>
          <hr size=1 style="margin: 3px 0">
          <span>${props.yAxisTipsName} : ${count}</span><br>
          <span>利润 : ${profit}%</span>
        `;
      }
    },
    toolbox: {
      show: true,
      right: 80,
      feature: {
        dataZoom: {
          show: false
        },
        dataView: {
          show: false
        },
        magicType: {
          show: false
        },
        restore: {
          show: false
        },
        saveAsImage: {
          show: false
        },
        iconSize: 30, // 图标字体大小
        iconStyle: {
          color: '#5ABE64' // 图标默认颜色
        },
        emphasis: {
          iconStyle: {
            color: '#54C3F1' // 图标hover颜色
          }
        },
        myTool1: {
          show: true,
          title: '提示框',
          icon: 'path://M384 682.633463h298.832685A170.633463 170.633463 0 0 0 853.366537 512V170.633463A170.633463 170.633463 0 0 0 682.633463 0h-512A170.633463 170.633463 0 0 0 0 170.633463V512a170.633463 170.633463 0 0 0 170.633463 170.633463v170.733074zM42.633463 512V170.633463A128.099611 128.099611 0 0 1 170.633463 42.633463h512a128 128 0 0 1 128 128V512a128 128 0 0 1-128 128H369.058366l-155.691829 124.513619v-124.513619h-42.733074A128 128 0 0 1 42.633463 512zM341.366537 810.633463h85.366537v42.633463h-85.366537z,M938.633463 213.366537v42.633463a42.733074 42.733074 0 0 1 42.733074 42.832685v383.800778a128 128 0 0 1-128 128h-42.733074v124.61323L654.941634 810.633463H512v42.733074h128l213.366537 170.633463V853.366537a170.633463 170.633463 0 0 0 170.633463-170.733074V298.832685a85.366537 85.366537 0 0 0-85.366537-85.466148zM170.633463 170.633463h170.633463v42.633463H170.633463zM170.633463 426.633463H512v42.633463H170.633463zM170.633463 298.633463h512v42.633463h-512zM426.633463 170.633463h256v42.633463h-256z',
          onclick() {
            toolboxStatus = !toolboxStatus;
            let currentSeries = iterates.map((_, i) => ({
              id: `scatter_${i}`,
              label: {
                show: toolboxStatus,
                distance: toolboxStatus ? 5 : 8000
              }
            }));
            currentEchartsIns?.setOption({
              tooltip: {
                show: !toolboxStatus,
                alwaysShowContent: !toolboxStatus
              },
              series: currentSeries
            });
          }
        }
      }
    },
    xAxis: [
      {
        type: 'value',
        name: '利润率(%)',
        scale: true,
        axisLabel: {
          formatter: '{value}'
        },
        axisTick: {
          //刻度线样式
          show: true
        }
      }
    ],
    yAxis: [
      {
        type: 'value',
        name: `${props.yAxisTipsName}(${props.yAxisUnit})`,
        scale: true,
        axisLabel: {
          formatter: '{value}'
        },
        axisTick: {
          show: false
        }
      }
    ],
    series
  } as EChartsOption;
  chartECharts.setOptions(option);

  // 跳转到 护理详情页面
  currentEchartsIns?.on('click', 'series.scatter', props.routeCallback);
}

// 对源数据进行转换
function transformEchartsData(originalData: NurseItem[]) {
  let counts: number[] = [];
  let data = originalData.reduce((tp: [number, number, string, string][], item: NurseItem) => {
    let arr = item.data.pop() || [0, 0];
    counts.push(arr[0] as number); // 搜集销量 or 客单价
    arr.reverse();
    tp.push([...arr, item.nursingServiceName, item.nursingServiceCode]);
    return tp;
  }, []);

  let totalCount: number = counts.reduce((p: number, n: number) => p + n, 0);
  let countBaseLine = Math.floor(totalCount / counts.length); // 销量 || 客单价 的基线
  let percentBaseLine = 60; // 利润率的基线（%）
  let topRights = []; // 上 、右区间   高销量 高利润
  let topLefts = []; // 上 、左区间   高销量  低利润
  let bottomRights = []; // 下 、右区间  低销量  高利润
  let bottomLefts = []; // 下 、左区间  低销量  低利润

  for (let item of data) {
    let [profit, num] = item;
    if (num >= countBaseLine) {
      if (profit >= percentBaseLine) {
        topRights.push([...item]);
      } else {
        topLefts.push([...item]);
      }
    } else {
      if (profit >= percentBaseLine) {
        bottomRights.push([...item]);
      } else {
        bottomLefts.push([...item]);
      }
    }
  }
  return { topRights, topLefts, bottomRights, bottomLefts, countBaseLine, percentBaseLine };
}
</script>

<template>
  <div ref="chartRef" class="chart" style="width: 100%; height: 680px" />
</template>
