<template>
  <RubPage ref="pageBoxRef">
    <template #header>
      <el-card shadow="hover">
        <el-row>
          <el-col :xs="24" :sm="6" :md="6" class="header-col">
            <div class="fz20 font-bold">{{ routeParams.tabTitle }}</div>
          </el-col>
          <el-col :xs="24" :sm="6" :md="10" class="tr header-col">
            <el-radio-group v-model="type" @change="getNurseDetailsData" class="mr10">
              <el-radio-button label="year">按年</el-radio-button>
              <el-radio-button label="month">按月</el-radio-button>
            </el-radio-group>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" class="tr">
            <el-space>
              <el-date-picker
                style="width: 100%"
                v-model="range"
                type="monthrange"
                format="YYYY-MM"
                value-format="YYYY-MM"
                placeholder="请选择日期"
                :clearable="false"
              />
              <el-button type="primary" @click="getNurseDetailsData">搜索</el-button>
            </el-space>
          </el-col>
        </el-row>
      </el-card>
    </template>

    <div class="main-content pl12 pr12">
      <el-row :gutter="14">
        <el-col :xs="24" :sm="12" :md="6" class="mt15">
          <div class="card flex flex-col items-center justify-center">
            <div class="fz16 mb10">{{ tabParams.totalSaleCount || 0 }}次</div>
            <div class="fz18 font-bold">总销量</div>
          </div>
        </el-col>
        <el-col :xs="24" :sm="12" :md="6" class="mt15">
          <div class="card flex flex-col items-center justify-center">
            <div class="fz16 mb10">{{ tabParams.totalSaleAmount || 0 }}</div>
            <div class="fz18 font-bold">总销售额</div>
          </div>
        </el-col>
        <el-col :xs="24" :sm="12" :md="6" class="mt15">
          <div class="card flex flex-col items-center justify-center">
            <div class="fz16 mb10">{{ tabParams.repurchaseMemberCount || '0元' }}</div>
            <div class="fz18 font-bold inline-flex items-center pointer">
              复购人数
              <el-tooltip content="开单数大于3的人数" placement="top" trigger="hover">
                <el-icon>
                  <QuestionFilled />
                </el-icon>
              </el-tooltip>
            </div>
          </div>
        </el-col>
        <el-col :xs="24" :sm="12" :md="6" class="mt15">
          <div class="card flex flex-col items-center justify-center">
            <div class="fz16 mb10">{{ tabParams.repurchaseRate || 0 }}%</div>
            <div class="fz18 font-bold inline-flex items-center pointer">
              复购率
              <el-tooltip content="复购人数在所有人数的占比" placement="top" trigger="hover">
                <el-icon>
                  <QuestionFilled />
                </el-icon>
              </el-tooltip>
            </div>
          </div>
        </el-col>
      </el-row>

      <!-- 标签及描述 -->
      <el-row :gutter="14">
        <el-col :xs="24" :sm="12" class="mt15">
          <el-card>
            <el-space wrap>
              <el-tag v-for="(item, index) in nurseDetail.tagList" :key="index">
                {{ item }}
              </el-tag>
            </el-space>
          </el-card>
        </el-col>
        <el-col :xs="24" :sm="12" class="mt15">
          <el-card>
            <div style="font-size: var(--el-font-size-small); line-height: 24px; color: var(--el-text-color-regular)">
              {{ nurseDetail.description || '描述：暂无' }}
            </div>
          </el-card>
        </el-col>
      </el-row>

      <!--   BOM   -->
      <el-card class="mt14" shadow="hover">
        <template #header>
          <div class="flex items-center justify-between h-30">
            <div class="font-bold fz18">BOM</div>
          </div>
        </template>
        <div class="flex items-center justify-end mb20">
          <div class="fz14 pr10 lht30 h-30">配料表</div>
          <el-select v-model="bomSheetCode" placeholder="请选择" class="w-220">
            <el-option
              v-for="{ sheetName, sheetCode } in nurseDetail.nursingServiceSheetModelList"
              :label="sheetName"
              :value="sheetCode"
              :key="sheetCode"
            />
          </el-select>
        </div>

        <!--  BOM 数据表格  -->
        <el-table :data="bomTableData" border class="wp-100" height="360">
          <el-table-column prop="stepSeq" label="序号" align="center" width="60" fixed />
          <el-table-column prop="seqName" label="流程名" align="center" min-width="120" />
          <el-table-column prop="productName" label="产品名称" align="center" min-width="120" />
          <el-table-column prop="productCode" label="产品编号" align="center" min-width="120" />
          <el-table-column prop="dosage" label="用量" align="center" min-width="120" />
          <el-table-column prop="remark" label="研发备注" align="center" min-width="120" />
          <el-table-column prop="accessory" label="辅料" align="center" min-width="120" />
        </el-table>
      </el-card>

      <!--   护理看板   -->
      <el-card class="mt14">
        <template #header>
          <div class="flex items-center justify-between h-30">
            <div class="font-bold fz18">护理看板</div>
          </div>
        </template>
        <!--  数据表格  -->
        <el-table :data="nurseTableData" border class="wp-100" height="500">
          <el-table-column prop="stepSeq" label="序号" align="center" min-width="60" fixed>
            <template #default="{ $index }">{{ $index + 1 }}</template>
          </el-table-column>
          <el-table-column prop="year" label="年度" align="center" min-width="120" />
          <el-table-column prop="device" label="仪器名称" align="center" min-width="120" />
          <el-table-column prop="price" label="吊牌价" align="center" min-width="120" />
          <el-table-column prop="totalCount" label="年销售量" align="center" min-width="120" />
          <el-table-column prop="totalAmount" label="年销售额" align="center" min-width="120" />
          <el-table-column prop="freeCount" label="免单数量" align="center" min-width="120" />
          <el-table-column prop="freeRate" label="免单率" align="center" min-width="120" />
          <el-table-column prop="avgPrice" label="平均客单价" align="center" min-width="120" />
          <el-table-column prop="discountRate" label="销售额折扣率" align="center" min-width="140" />
          <el-table-column prop="cost" label="护理综合成本" align="center" min-width="140" />
          <el-table-column prop="profit" label="毛利率" align="center" min-width="100" />
          <el-table-column prop="netCount" label="销量(不含免单)" align="center" min-width="140" />
          <el-table-column
            prop="memberLevelRate"
            label="主要客层占比"
            align="center"
            min-width="140"
            v-bind="device === 'mobile' ? {} : { fixed: 'right' }"
          >
            <template #default="{ row }">
              <div class="wp-100 tc fz16">
                <template v-for="(key, value, index) in row.memberLevelRate" :key="index">
                  <div class="tc fz14">{{ `${key}: ${value}%` }}</div>
                </template>
              </div>
            </template>
          </el-table-column>
        </el-table>
      </el-card>

      <!--   开单销量分布   -->
      <el-card class="mt14">
        <template #header>
          <div class="flex items-center justify-between h-30">
            <div class="font-bold fz18">开单销量分布</div>
          </div>
        </template>
        <el-scrollbar>
          <div ref="salesRef" class="chart" style="height: 500px" />
        </el-scrollbar>
      </el-card>

      <!--   开单客层占比   -->
      <el-card class="mt14" shadow="hover">
        <template #header>
          <div class="fz18 color_333 font-bold inline-flex items-center pointer">
            开单客层占比<el-tooltip content="客层购买此护理的开单数占所有开单数的占比" placement="top" trigger="hover">
              <el-icon>
                <QuestionFilled />
              </el-icon>
            </el-tooltip>
          </div>
        </template>
        <el-scrollbar>
          <div ref="billingRatioNestRef" class="chart" style="height: 600px" />
        </el-scrollbar>
      </el-card>

      <!--   开单客层分布   -->
      <el-card class="mt14">
        <template #header>
          <div class="fz18 color_333 font-bold inline-flex items-center pointer">
            开单客层分布<el-tooltip content="客层购买此护理的开单数的分布" placement="top" trigger="hover">
              <el-icon>
                <QuestionFilled />
              </el-icon>
            </el-tooltip>
          </div>
        </template>
        <el-scrollbar>
          <div ref="billingLayoutRef" class="chart" style="height: 600px" />
        </el-scrollbar>
      </el-card>

      <!--   开单新老客分布   -->
      <el-card class="mt14">
        <template #header>
          <div class="fz18 color_333 font-bold inline-flex items-center pointer">
            开单新老客分布<el-tooltip class="fz0" content="新老客购买此护理的开单数的分布" placement="top" trigger="hover">
              <el-icon>
                <QuestionFilled />
              </el-icon>
            </el-tooltip>
          </div>
        </template>
        <el-scrollbar>
          <div ref="billingMemberRef" class="chart" style="height: 800px" />
        </el-scrollbar>
      </el-card>

      <!--   门店销量排行   -->
      <el-card class="mt14">
        <template #header>
          <div class="flex items-center justify-between h-30">
            <div class="font-bold fz18">门店销量排行</div>
          </div>
        </template>
        <el-scrollbar>
          <RubVerticalBarChart class="chart" v-bind="shopSaleCountEchartsData" />
        </el-scrollbar>
      </el-card>
    </div>
  </RubPage>
</template>

<script lang="ts" setup name="nurseDetail">
import {
  getNurseDetailPort,
  getNurseDetailTablePort,
  NurseDetailType,
  BomTableItemType,
  NurseDetailTableItemType,
  PieChartItemType
} from '@/api/modules/nurseProject';
import dayjs from 'dayjs';
import { useEcharts } from '@/hooks/useEcharts';
import type { EChartsOption } from 'echarts';
import { formatNumber } from '@/utils';
import { useGlobalStore } from '@/stores/modules/global';
import RubPage from '@/components/rub-page/index.vue';
import { Chart } from '@/typings/global';
import { ModelValueType } from 'element-plus';

const globalStore = useGlobalStore();
const { device } = storeToRefs(globalStore);

onMounted(() => {
  getNurseDetailsData();
  getNurseTableData();
});

const pageBoxRef = ref<InstanceType<typeof RubPage> | null>(null);

const type = ref('year');
const threeYearsAgo = dayjs().subtract(3, 'year').format('YYYY-MM');
const currentDate = dayjs().format('YYYY-MM');
const range = ref<ModelValueType>([threeYearsAgo, currentDate]);

const route = useRoute();
const routeParams = reactive(route.params);

const tabParams = ref({
  totalSaleCount: '',
  totalSaleAmount: '',
  repurchaseMemberCount: '',
  repurchaseRate: ''
});

const nurseDetail = ref<NurseDetailType>({} as NurseDetailType);

const bomTableData = ref<BomTableItemType[]>([]);
const bomSheetCode = ref('');
// 监听 BOM的 bomSheetCode
watch(bomSheetCode, (n: string, o: string) => {
  if (n !== o) {
    let item = nurseDetail.value.nursingServiceSheetModelList?.find(it => it.sheetCode === n);
    bomTableData.value = item ? item.nursingServiceSheetDtlModelList : [];
  }
});

const getNurseDetailsData = async () => {
  let [startDate, endDate] = range.value as string[];
  let days = dayjs(endDate).daysInMonth();
  let params = {
    type: type.value,
    startDate: `${startDate}-01`,
    endDate: `${endDate}-${days}`,
    nursingServiceCode: routeParams.nursingServiceCode
  };
  try {
    let { val: data, success } = await getNurseDetailPort(params);
    if (success === '0') {
      nurseDetail.value = data;
      tabParams.value = {
        totalSaleCount: formatNumber(data.totalSaleCount),
        totalSaleAmount: filterSalesAmount(data.totalSaleAmount),
        repurchaseMemberCount: formatNumber(data.repurchaseMemberCount),
        repurchaseRate: formatNumber(data.repurchaseRate)
      };
      // BOM表格数据
      let [firstBom] = data.nursingServiceSheetModelList;
      if (firstBom) {
        bomSheetCode.value = firstBom.sheetCode;
      }

      // 渲染销售额相关的图表
      renderSalesEChartGraph({
        saleCountData: data.saleCountData,
        saleAmountData: data.saleAmountData,
        netAmountData: data.netAmountData
      });

      // 渲染开单客层占比相关图表
      /*renderBillingRatioEChartsGraph({
        data: data.memberLevelPieData,
      });*/

      // 渲染开单客层占比 nest内外双环 相关图表
      renderBillingRatioNestEChartsGraph({
        greatCircleData: data.prefixMemberLevelPieData,
        smallCircleData: data.suffixMemberLevelXPieData
      });

      // 渲染开单客层分布 相关图表
      billingLayoutEChartsGraph(data.memberLevelSaleCountData);

      // 渲染开单新老客分布 相关图表
      billingMemberEChartsGraph(data.memberTypeData);

      // 渲染shop销售排行榜 相关图表
      // renderShopSaleEChartsGraph(data.shopSaleCountRankData);

      shopSaleCountEchartsData.value = {
        axis: data.shopSaleCountRankData.axisData,
        seriesData: data.shopSaleCountRankData.seriesData,
        inverse: true,
        labelShow: true
      };
    }
  } catch (e) {
    console.log('e : ', e);
  } finally {
    pageBoxRef.value?.scrollTo(0);
  }
};

//  销售 echarts
const salesRef = ref<HTMLDivElement | null>(null);
const salesECharts = useEcharts(salesRef as Ref<HTMLDivElement>);

//  开单客层占比 echarts
const billingRatioNestRef = ref<HTMLDivElement | null>(null);
const billingRatioNestECharts = useEcharts(billingRatioNestRef as Ref<HTMLDivElement>);

//  开单客层分布 echarts
const billingLayoutRef = ref<HTMLDivElement | null>(null);
const billingLayoutECharts = useEcharts(billingLayoutRef as Ref<HTMLDivElement>);

//  开单新老客分布 echarts
const billingMemberRef = ref<HTMLDivElement | null>(null);
const billingMemberECharts = useEcharts(billingMemberRef as Ref<HTMLDivElement>);

//  门店销量排行 echarts
const shopSaleCountEchartsData = ref<Chart.VerticalBarChartType>({} as Chart.VerticalBarChartType);

// 渲染销售额相关的图表
function renderSalesEChartGraph({
  saleCountData,
  saleAmountData,
  netAmountData
}: Pick<NurseDetailType, 'saleCountData' | 'saleAmountData' | 'netAmountData'>) {
  let colors = ['#5470C6', '#91CC75', '#EE6666'];
  let options = {
    color: colors,
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'cross'
      }
    },
    grid: { left: '5%', right: '10%' },
    legend: {
      data: ['销量', '销售额', '实付额']
    },
    xAxis: [
      {
        type: 'category',
        axisTick: {
          alignWithLabel: true
        },
        data: saleCountData.axisData
      }
    ],
    yAxis: [
      {
        type: 'value',
        name: '销量',
        position: 'right',
        alignTicks: true,
        axisLine: {
          show: true,
          lineStyle: {
            color: colors[0]
          }
        },
        axisLabel: {
          formatter: '{value} 次'
        }
      },
      {
        type: 'value',
        name: '销售额',
        position: 'right',
        alignTicks: true,
        offset: 80,
        axisLine: {
          show: true,
          lineStyle: {
            color: colors[1]
          }
        },
        axisLabel: {
          formatter: '{value} 万元'
        }
      },
      {
        type: 'value',
        name: '实付额',
        position: 'left',
        alignTicks: true,
        axisLine: {
          show: true,
          lineStyle: {
            color: colors[2]
          }
        },
        axisLabel: {
          formatter: '{value} 万元'
        }
      }
    ],
    series: [
      {
        name: '销量',
        type: 'line',
        data: saleCountData.seriesData,
        itemStyle: {
          color: colors[0]
        },
        // barMaxWidth: 80,
        markLine: {
          data: [{ type: 'average', name: 'Avg' }]
        },
        smooth: true
      },
      {
        name: '销售额',
        type: 'line',
        yAxisIndex: 1,
        data: saleAmountData.seriesData,
        itemStyle: {
          color: colors[1]
        },
        // barMaxWidth: 80,
        markLine: {
          data: [{ type: 'average', name: 'Avg' }]
        },
        smooth: true
      },
      {
        name: '实付额',
        type: 'line',
        yAxisIndex: 2,
        data: netAmountData.seriesData,
        itemStyle: {
          color: colors[2]
        },
        markLine: {
          data: [{ type: 'average', name: 'Avg' }]
        },
        smooth: true
      }
    ]
  } as EChartsOption;

  salesECharts.setOptions(options);
}

// 渲染开单客层占比 nest 相关图表
function renderBillingRatioNestEChartsGraph({
  greatCircleData,
  smallCircleData
}: Record<'greatCircleData' | 'smallCircleData', PieChartItemType[]>) {
  let tempData = [...greatCircleData, ...smallCircleData];
  let legendData = tempData.reduce((temp, it) => (!temp.includes(it.name) && temp.push(it.name), temp), [] as string[]);

  let options = {
    tooltip: {
      trigger: 'item',
      formatter: '{a} <br/>{b}: {c} ({d}%)'
    },
    legend: {
      data: legendData
    },
    series: [
      {
        name: '开单客层占比',
        type: 'pie',
        selectedMode: 'single',
        radius: [0, '30%'],
        label: {
          position: 'inner',
          fontSize: 14
        },
        labelLine: {
          show: false
        },
        data: smallCircleData
      },
      {
        name: '开单客层占比',
        type: 'pie',
        radius: ['45%', '60%'],
        labelLine: {
          length: 30
        },
        label: {
          formatter: '{a|{a}}{abg|}\n{hr|}\n  {b|{b}：}{c}  {per|{d}%}  ',
          backgroundColor: '#F6F8FC',
          borderColor: '#8C8D8E',
          borderWidth: 1,
          borderRadius: 4,
          rich: {
            a: {
              color: '#6E7079',
              lineHeight: 22,
              align: 'center'
            },
            hr: {
              borderColor: '#8C8D8E',
              width: '100%',
              borderWidth: 1,
              height: 0
            },
            b: {
              color: '#4C5058',
              fontSize: 14,
              fontWeight: 'bold',
              lineHeight: 33
            },
            per: {
              color: '#fff',
              backgroundColor: '#4C5058',
              padding: [3, 4],
              borderRadius: 4
            }
          }
        },
        data: greatCircleData
      }
    ]
  } as EChartsOption;

  billingRatioNestECharts.setOptions(options);
}

// 渲染开单客层分布相关图表
function billingLayoutEChartsGraph(data: NurseDetailType['memberLevelSaleCountData']) {
  let legendData = data.series.map(it => it.name);
  let series = data.series.map(it => ({ ...it, type: 'line', /*stack: 'Total', */ smooth: true }));
  let options = {
    tooltip: {
      trigger: 'axis'
    },
    legend: {
      data: legendData
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      containLabel: true
    },
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data: data.axis
    },
    yAxis: {
      type: 'value'
    },
    series
  } as EChartsOption;
  billingLayoutECharts.setOptions(options);
}

// 渲染开单新老客分布相关图表
function billingMemberEChartsGraph(data: NurseDetailType['memberTypeData']) {
  let series = data.reduce(
    (tp, it, index) => {
      index === data.length - 1
        ? tp.push({
            type: 'pie',
            id: 'pie',
            radius: '30%',
            center: ['50%', '25%'],
            emphasis: {
              focus: 'self'
            },
            label: {
              formatter: `{b}: {@${data[0][1]}} ({d}%)`
            },
            encode: {
              itemName: data[0][0],
              value: data[0][1],
              tooltip: data[0][1]
            }
          })
        : tp.push({
            type: 'line',
            smooth: true,
            seriesLayoutBy: 'row',
            emphasis: { focus: 'series' }
          });
      return tp;
    },
    [] as Array<EChartsOption['series']>
  );

  let options = {
    legend: {},
    tooltip: {
      trigger: 'axis',
      showContent: false
    },
    dataset: {
      source: data
    },
    xAxis: { type: 'category' },
    yAxis: { gridIndex: 0 },
    grid: { top: '55%' },
    series
  } as EChartsOption;

  billingMemberECharts.setOptions(options);

  let echartsInstance = billingMemberECharts.getInstance();
  echartsInstance?.on('updateAxisPointer', function (event: any) {
    const xAxisInfo = event?.axesInfo[0];
    if (xAxisInfo) {
      const dimension = xAxisInfo.value + 1;
      echartsInstance?.setOption({
        series: {
          id: 'pie',
          label: {
            formatter: '{b}: {@[' + dimension + ']} ({d}%)'
          },
          encode: {
            value: dimension,
            tooltip: dimension
          }
        }
      });
    }
  });
}

// 对门店的销售总额进行过滤
function filterSalesAmount(amount: string | number): string {
  amount = Number(amount);
  if (amount < 10000) {
    amount = formatNumber(amount);
    return `${amount}元`;
  }
  amount = amount / 10000;
  amount = formatNumber(amount);
  return `${amount}万元`;
}

const nurseTableData = ref<NurseDetailTableItemType[]>([]);
// 护理详情页面 护理表格的信息
async function getNurseTableData() {
  let params = {
    nursingServiceCode: routeParams.nursingServiceCode
  };
  try {
    let { val: data, success } = await getNurseDetailTablePort(params);
    if (success === '0') {
      nurseTableData.value = data;
    }
  } catch (e) {
    console.log('e : ', e);
  }
}
</script>
<style lang="scss" scoped>
.chart {
  width: 100%;
}
.mobile {
  .chart {
    width: 1000px;
  }
  .header-col {
    margin-bottom: 15px;
    text-align: left !important;
  }
}
</style>
