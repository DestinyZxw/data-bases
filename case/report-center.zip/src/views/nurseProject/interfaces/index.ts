import { ModelValueType } from 'element-plus';

export type NurseFormType = {
  shopId: string | number;
  range: ModelValueType;
};
export type NurseParamsType = {
  shopId: string | number;
  startDate: string;
  endDate: string;
};
