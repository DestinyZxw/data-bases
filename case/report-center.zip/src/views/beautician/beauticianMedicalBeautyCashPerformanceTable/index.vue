<template>
  <div class="table-box">
    <div class="card table-search">
      <el-form ref="searchFormRef" :model="searchForm" :rules="searchRules" label-width="80">
        <el-row :gutter="15">
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="门店">
              <el-select v-model="searchForm.shopIds" class="wp-100" clearable multiple collapse-tags>
                <el-option v-for="({ shopId, shopName }, index) in shopOptions" :key="index" :label="shopName" :value="shopId" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="收款/退款日期" prop="beginTime" label-width="120">
              <el-date-picker
                v-model="dateRange"
                type="daterange"
                range-separator="-"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
              />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="员工号">
              <el-input v-model="searchForm.empCode" placeholder="请输入" maxlength="12" />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="员工姓名">
              <el-input v-model="searchForm.empName" placeholder="请输入" maxlength="30" />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="R6顾客号">
              <el-input v-model="searchForm.memberCode" placeholder="请输入" maxlength="30" />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="医美订单号" label-width="100">
              <el-input v-model="searchForm.orderNumber" placeholder="请输入" />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item>
              <el-space>
                <el-button type="primary" @click="handleSearch" :disabled="isDisabledRead">搜索</el-button>
                <el-button type="success" @click="handleReset" :disabled="isDisabledRead">重置</el-button>
              </el-space>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <div class="card table-main">
      <div class="table-header">
        <el-button type="primary" :icon="Download" plain @click="handleExport" :disabled="isDisabledExport">导出</el-button>
      </div>
      <el-table v-loading="tableLoading" :data="tableData" style="width: 100%" border>
        <el-table-column prop="empCode" label="员工号" align="center" width="120" />
        <el-table-column prop="empName" label="员工姓名" align="center" width="150" />
        <el-table-column prop="shopName" label="门店" align="center" width="120" />
        <el-table-column prop="positionName" label="职位" align="center" width="120" />
        <el-table-column prop="memberCode" label="R6顾客号" align="center" width="100" />
        <el-table-column prop="memberName" label="R6顾客姓名" align="center" width="120" />
        <el-table-column prop="exclusiveType" label="专属类型" align="center" width="100" />
        <el-table-column prop="medicalBeautyClinic" label="医美诊所" align="center" width="150" />
        <el-table-column prop="medicalBeautyMemberCode" label="医美顾客号" align="center" width="120" />
        <el-table-column prop="medicalBeautyMemberName" label="医美顾客姓名" align="center" width="120" />
        <el-table-column prop="medicalBeautyOrderNo" label="医美订单号" align="center" width="120" />
        <el-table-column prop="orderTime" label="开单日期" align="center" width="100" />
        <el-table-column prop="paymentOrderNo" label="收款/退款单号" align="center" width="180" />
        <el-table-column prop="paymentTime" label="收款/退款日期" align="center" width="120" />
        <el-table-column prop="amount" label="收款/退款金额" align="center" width="120" />
      </el-table>
      <el-pagination
        background
        layout="total, sizes, prev, pager, next, jumper"
        :current-page="pagination.page"
        :page-size="pagination.pageSize"
        :page-sizes="pagination.pageSizes"
        :total="pagination.itemCount"
        @current-change="pagination.onChange"
        @size-change="pagination.onPageSizeChange"
      />
    </div>
  </div>
</template>
<!-- 熟客明细表 -->
<script lang="ts" setup name="beauticianMedicalBeautyCashPerformance">
import { FormInstance, FormRules } from 'element-plus';
import { basicShopItem, fetchMemberShopListPort } from '@/api/modules/base';
import { Download } from '@element-plus/icons-vue';
import {
  fetchBeauticianYmCashTablePort,
  BeauticianYmCashTableItemType,
  exportBeauticianYmCashTablePort
} from '@/api/modules/beautician';
import dayjs from 'dayjs';
import { useButtonAuth } from '@/hooks/useButtonAuth';
import { beauticianYMCashPerformanceFormType } from '@/views/beautician/interfaces';
import { useTable } from '@/hooks/useTable';

// 按钮权限
const { isDisabledRead, isDisabledExport } = useButtonAuth({
  read: 'BEAUTICIAN_MEDICAL_BEAUTY_CASH_PERFORMANCE_READ',
  exports: 'BEAUTICIAN_MEDICAL_BEAUTY_CASH_PERFORMANCE_EXPORT',
  initFn: () => getTableData()
});

onMounted(() => {
  searchForm.value.beginTime = `${dayjs().startOf('month')}`;
  searchForm.value.endTime = `${dayjs().format('YYYY-MM-DD')}`;
  dateRange.value = [`${dayjs().startOf('month')}`, `${dayjs().format('YYYY-MM-DD')}`];
  getShopOptionsData();
});

const searchFormRef = ref<FormInstance | null>();
const shopOptions = ref<{ shopId: number; shopName: string }[]>([]);
const getShopOptionsData = async () => {
  try {
    let res = await fetchMemberShopListPort();
    shopOptions.value = (res.shops as basicShopItem[]).map(({ shopId, shopName }) => ({ shopId, shopName }));
  } catch (e) {
    console.log('e : ', e);
  }
};

const initFormData = (): beauticianYMCashPerformanceFormType => ({
  shopIds: [],
  beginTime: '',
  endTime: '',
  empCode: '',
  empName: '',
  memberCode: '',
  orderNumber: ''
});

const dateRange = ref<any>();

const searchForm = ref<beauticianYMCashPerformanceFormType>(initFormData());
const searchParams = computed<beauticianYMCashPerformanceFormType>(() => ({
  ...searchForm.value,
  beginTime: dateRange.value ? dayjs(dateRange.value[0]).format('YYYY-MM-DD') : '',
  endTime: dateRange.value ? dayjs(dateRange.value[1]).format('YYYY-MM-DD') : ''
}));

const searchRules = reactive<FormRules>({
  beginTime: [{ required: false, message: '请选择收款/退款日期', trigger: 'change' }]
});

const table = useTable<BeauticianYmCashTableItemType, beauticianYMCashPerformanceFormType>({
  port: fetchBeauticianYmCashTablePort,
  searchForm: searchParams,
  exportPort: exportBeauticianYmCashTablePort,
  exportExcelName: '美容师医美现金业绩明细表'
});

const { tableData, tableLoading, pagination, getTableData } = table;

const handleSearch = () => {
  searchFormRef.value?.validate((valid, fields) => {
    if (valid) {
      table.handleSearch();
    } else {
      console.log('error submit!', fields);
    }
  });
};

const handleReset = () => {
  searchForm.value = initFormData();
  searchFormRef.value?.resetFields();
  dateRange.value = [`${dayjs().startOf('month')}`, `${dayjs().format('YYYY-MM-DD')}`];
  table.handleReset();
};

const handleExport = () => {
  searchFormRef.value?.validate((valid, fields) => {
    if (valid) {
      table.handleExport();
    } else {
      console.log('error submit!', fields);
    }
  });
};
</script>
