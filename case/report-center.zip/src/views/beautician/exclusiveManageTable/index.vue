<template>
  <div class="table-box">
    <div class="card table-search">
      <el-form ref="searchFormRef" :model="searchForm" :rules="searchRules" label-width="60">
        <el-row :gutter="15">
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="月份" prop="queryDate">
              <el-date-picker
                class="wp-100"
                v-model="searchForm.queryDate"
                type="month"
                format="YYYY-MM"
                value-format="YYYY-MM"
                placeholder="请选择日期"
              />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="门店">
              <el-select v-model="searchForm.shopIds" class="wp-100" clearable multiple collapse-tags>
                <el-option v-for="({ shopId, shopName }, index) in shopOptions" :key="index" :label="shopName" :value="shopId" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="美容师">
              <el-input v-model="searchForm.empId" placeholder="请输入" />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item>
              <el-space>
                <el-button type="primary" @click="handleSearch" :disabled="isDisabledRead">搜索</el-button>
                <el-button type="success" @click="handleReset" :disabled="isDisabledRead">重置</el-button>
              </el-space>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <div class="card table-main">
      <div class="table-header">
        <el-button type="primary" :icon="Download" plain @click="handleExport" :disabled="isDisabledExport">导出</el-button>
      </div>
      <el-table v-loading="tableLoading" :data="tableData" style="width: 100%" border>
        <el-table-column prop="shopName" label="门店" align="center" min-width="120" />
        <el-table-column prop="empId" label="员工号" align="center" min-width="120" />
        <el-table-column prop="beauticianName" label="美容师" align="center" min-width="120" />
        <el-table-column prop="positionName" label="岗位" align="center" min-width="120" />
        <el-table-column prop="newExclusiveNum" label="新客专属人数" align="center" min-width="120" />
      </el-table>
      <el-pagination
        background
        layout="total, sizes, prev, pager, next, jumper"
        :current-page="pagination.page"
        :page-size="pagination.pageSize"
        :page-sizes="pagination.pageSizes"
        :total="pagination.itemCount"
        @current-change="pagination.onChange"
        @size-change="pagination.onPageSizeChange"
      />
    </div>
  </div>
</template>
<!-- 专属管理统计人数明细表 -->
<script lang="ts" setup name="exclusiveManageTable">
import { FormInstance, FormRules } from 'element-plus';
import { basicShopItem, fetchMemberShopListPort } from '@/api/modules/base';
import { RoleItem } from '@/api/interface';
import { Download } from '@element-plus/icons-vue';
import { getExclusiveManageTablePort, exportExclusiveManageTablePort } from '@/api/modules/beautician';
import dayjs from 'dayjs';
import { useButtonAuth } from '@/hooks/useButtonAuth';
import { exclusiveManageFormType } from '@/views/beautician/interfaces';
import { useTable } from '@/hooks/useTable';

// 按钮权限
const { isDisabledRead, isDisabledExport } = useButtonAuth({
  read: 'OPERATION_EXCLUSIVE_MANAGEMENT_READ',
  exports: 'OPERATION_EXCLUSIVE_MANAGEMENT_EXPORT',
  initFn: () => getTableData()
});

onMounted(() => {
  getShopOptionsData();
});

const searchFormRef = ref<FormInstance | null>();
const shopOptions = ref<{ shopId: number; shopName: string }[]>([]);
const getShopOptionsData = async () => {
  try {
    let res = await fetchMemberShopListPort();
    shopOptions.value = (res.shops as basicShopItem[]).map(({ shopId, shopName }) => ({ shopId, shopName }));
  } catch (e) {
    console.log('e : ', e);
  }
};
const initFormData = (): exclusiveManageFormType => ({
  empId: '',
  queryDate: dayjs().format('YYYY-MM'),
  shopIds: []
});

const searchForm = ref<exclusiveManageFormType>(initFormData());

const searchParams = computed<exclusiveManageFormType>(() => ({
  ...searchForm.value,
  queryDate: `${searchForm.value.queryDate}-01`
}));

const searchRules = reactive<FormRules>({
  queryDate: [{ required: true, message: '请选择月份', trigger: 'change' }]
});

const table = useTable<RoleItem, exclusiveManageFormType>({
  port: getExclusiveManageTablePort,
  searchForm: searchParams,
  exportPort: exportExclusiveManageTablePort,
  exportExcelName: '美容师专属管理人数统计表'
});

const { tableData, tableLoading, pagination, getTableData } = table;

const handleSearch = () => {
  searchFormRef.value?.validate((valid, fields) => {
    if (valid) {
      table.handleSearch();
    } else {
      console.log('error submit!', fields);
    }
  });
};

const handleReset = () => {
  searchForm.value = initFormData();
  searchFormRef.value?.resetFields();
  table.handleReset();
};

const handleExport = () => {
  searchFormRef.value?.validate((valid, fields) => {
    if (valid) {
      table.handleExport();
    } else {
      console.log('error submit!', fields);
    }
  });
};
</script>
