import { ModelValueType } from 'element-plus';

// 熟客明细表 表单类型
export type RegularGuestFormType = {
  beauticianName: string;
  memberCode: string;
  memberName: string;
  queryMonth: ModelValueType;
  shopIds: (number | string)[];
};

// 熟客业绩明细表 表单类型
export type RegularGuestPerformanceFormType = {
  beauticianName: string;
  range: ModelValueType;
  shopIds: (number | string)[];
};
export type RegularGuestPerformanceParamsType = {
  empId: string;
  shopIds: (number | string)[];
  startDate: string;
  endDate: string;
};

// 专属管理人数统计表 表单类型
export type exclusiveManageFormType = {
  empId: string;
  queryDate: ModelValueType;
  shopIds: (string | number)[];
};

// 专属业绩明细表 表单类型
export type exclusivePerformanceFormType = RegularGuestPerformanceFormType;
export type exclusivePerformanceParamsType = RegularGuestPerformanceParamsType;

// 初级美容师学员 表单类型
export type juniorBeauticianFormType = {
  beauticianName: string;
  memberCode: string;
  dates: ModelValueType;
};

export type juniorBeauticianParamsType = {
  startDate: string;
  endDate: string;
} & Omit<juniorBeauticianFormType, 'dates'>;

export type juniorBeauticianTabNameType = 'firstTable' | 'secondTable' | 'thirdTable';

// 美容师医美现金业绩 表单类型
export type beauticianYMCashPerformanceFormType = {
  shopIds: (number | string)[];
  beginTime: string;
  endTime: string;
  empCode: string;
  empName: string;
  memberCode: string;
  orderNumber: string;
};
