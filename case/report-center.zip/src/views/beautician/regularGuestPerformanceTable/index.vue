<template>
  <div class="table-box">
    <div class="card table-search">
      <el-form ref="searchFormRef" :model="searchForm" label-width="70">
        <el-row :gutter="15">
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="销售门店">
              <el-select v-model="searchForm.shopIds" class="wp-100" clearable multiple collapse-tags>
                <el-option v-for="({ shopId, shopName }, index) in shopOptions" :key="index" :label="shopName" :value="shopId" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="美容师">
              <el-input v-model="searchForm.beauticianName" placeholder="请输入" />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="日期区间">
              <el-date-picker
                v-model="searchForm.range"
                type="daterange"
                start-placeholder="起始日期"
                end-placeholder="结束日期"
                format="YYYY-MM-DD"
                value-format="YYYY-MM-DD"
                unlink-panels
              />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item>
              <el-space>
                <el-button type="primary" @click="handleSearch" :disabled="isDisabledRead">搜索</el-button>
                <el-button type="success" @click="handleReset" :disabled="isDisabledRead">重置</el-button>
              </el-space>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <div class="card table-main">
      <div class="table-header">
        <el-button type="primary" :icon="Download" plain @click="handleExport" :disabled="isDisabledExport">导出</el-button>
      </div>
      <el-table v-loading="tableLoading" :data="tableData" style="width: 100%" border>
        <el-table-column prop="saleShop" label="销售门店" align="center" />
        <el-table-column prop="saleDate" label="日期" align="center" />
        <el-table-column prop="saleOrderCode" label="顾客单号" align="center" />
        <el-table-column prop="memberCode" label="顾客号" align="center" />
        <el-table-column prop="memberName" label="顾客姓名" align="center" />
        <el-table-column prop="productCommission" label="熟客产品业绩" align="center" />
        <el-table-column prop="empId" label="员工号" align="center" />
        <el-table-column prop="beauticianName" label="美容师姓名" align="center" />
      </el-table>
      <el-pagination
        background
        layout="total, sizes, prev, pager, next, jumper"
        :current-page="pagination.page"
        :page-size="pagination.pageSize"
        :page-sizes="pagination.pageSizes"
        :total="pagination.itemCount"
        @current-change="pagination.onChange"
        @size-change="pagination.onPageSizeChange"
      />
    </div>
  </div>
</template>
<!-- 熟客业绩明细表 -->
<script lang="ts" setup name="regularGuestPerformanceTable">
import { fetchMemberShopListPort, basicShopItem } from '@/api/modules/base';
import { Download } from '@element-plus/icons-vue';
import {
  getRegularGuestPerformanceTablePort,
  exportRegularGuestPerformanceTablePort,
  RegularGuestPerformanceItemType
} from '@/api/modules/beautician';
import dayjs from 'dayjs';
import { useButtonAuth } from '@/hooks/useButtonAuth';
import { RegularGuestPerformanceFormType, RegularGuestPerformanceParamsType } from '@/views/beautician/interfaces';
import { useTable } from '@/hooks/useTable';

// 按钮权限
const { isDisabledRead, isDisabledExport } = useButtonAuth({
  read: 'OPERATION_FAMILIAR_CUSTOMER_ACHIEVEMENT_READ',
  exports: 'OPERATION_FAMILIAR_CUSTOMER_ACHIEVEMENT_EXPORT',
  initFn: () => getTableData()
});

onMounted(() => {
  getShopOptionsData();
});

const shopOptions = ref<{ shopId: number; shopName: string }[]>([]);
const getShopOptionsData = async () => {
  try {
    let res = await fetchMemberShopListPort();
    shopOptions.value = (res.shops as basicShopItem[]).map(({ shopId, shopName }) => ({ shopId, shopName }));
  } catch (e) {
    console.log('e : ', e);
  }
};

const currentDate = dayjs().format('YYYY-MM-DD');
const lastYearDate = dayjs().subtract(1, 'year').format('YYYY-MM-DD');
const initFormData = (): RegularGuestPerformanceFormType => ({
  beauticianName: '',
  range: [lastYearDate, currentDate],
  shopIds: []
});

const searchForm = ref<RegularGuestPerformanceFormType>(initFormData());

const searchParams = computed<RegularGuestPerformanceParamsType>(() => {
  let { shopIds, beauticianName, range = [] } = toValue(searchForm);
  let [startDate = '', endDate = ''] = range as string[];
  return { empId: beauticianName, shopIds, startDate, endDate };
});

const table = useTable<RegularGuestPerformanceItemType, RegularGuestPerformanceParamsType>({
  port: getRegularGuestPerformanceTablePort,
  searchForm: searchParams,
  exportPort: exportRegularGuestPerformanceTablePort,
  exportExcelName: '美容师熟客业绩报表'
});

const { tableData, tableLoading, pagination, getTableData, handleSearch, handleExport } = table;

const handleReset = () => {
  searchForm.value = initFormData();
  table.handleReset();
};
</script>
