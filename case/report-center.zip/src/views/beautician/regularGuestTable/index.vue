<template>
  <div class="table-box">
    <div class="card table-search">
      <el-form ref="searchFormRef" :model="searchForm" :rules="searchRules" label-width="80">
        <el-row :gutter="15">
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="月份" prop="queryMonth">
              <el-date-picker
                v-model="searchForm.queryMonth"
                type="month"
                format="YYYY-MM"
                value-format="YYYY-MM"
                placeholder="请选择日期"
              />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="会籍门店">
              <el-select v-model="searchForm.shopIds" class="wp-100" clearable multiple collapse-tags>
                <el-option v-for="({ shopId, shopName }, index) in shopOptions" :key="index" :label="shopName" :value="shopId" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="美容师">
              <el-input v-model="searchForm.beauticianName" placeholder="请输入" />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="顾客号">
              <el-input v-model="searchForm.memberCode" placeholder="请输入" />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="顾客姓名">
              <el-input v-model="searchForm.memberName" placeholder="请输入" />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item>
              <el-space>
                <el-button type="primary" @click="handleSearch" :disabled="isDisabledRead">搜索</el-button>
                <el-button type="success" @click="handleReset" :disabled="isDisabledRead">重置</el-button>
              </el-space>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <div class="card table-main">
      <div class="table-header">
        <el-button type="primary" :icon="Download" plain @click="handleExport" :disabled="isDisabledExport">导出</el-button>
      </div>
      <el-table v-loading="tableLoading" :data="tableData" style="width: 100%" border>
        <el-table-column prop="shopName" label="会籍门店" align="center" />
        <el-table-column prop="memberCode" label="顾客号" align="center" />
        <el-table-column prop="memberName" label="顾客姓名" align="center" />
        <el-table-column prop="joinMemberDate" label="入会日期" align="center" />
        <el-table-column prop="empCode" label="员工号" align="center" />
        <el-table-column prop="beauticianName" label="美容师" align="center" />
        <el-table-column prop="beauticianShopName" label="美容师门店" align="center" />
        <el-table-column prop="productPerformance" label="产品业绩" align="center" />
      </el-table>
      <el-pagination
        background
        layout="total, sizes, prev, pager, next, jumper"
        :current-page="pagination.page"
        :page-size="pagination.pageSize"
        :page-sizes="pagination.pageSizes"
        :total="pagination.itemCount"
        @current-change="pagination.onChange"
        @size-change="pagination.onPageSizeChange"
      />
    </div>
  </div>
</template>
<!-- 熟客明细表 -->
<script lang="ts" setup name="regularGuestTable">
import { FormInstance, FormRules } from 'element-plus';
import { basicShopItem, fetchMemberShopListPort } from '@/api/modules/base';
import { Download } from '@element-plus/icons-vue';
import { getRegularGuestTablePort, RegularGuestTableItemType, exportRegularGuestTablePort } from '@/api/modules/beautician';
import dayjs from 'dayjs';
import { useButtonAuth } from '@/hooks/useButtonAuth';
import { RegularGuestFormType } from '@/views/beautician/interfaces';
import { useTable } from '@/hooks/useTable';

// 按钮权限
const { isDisabledRead, isDisabledExport } = useButtonAuth({
  read: 'OPERATION_FAMILIAR_CUSTOMER_DETAIL_READ',
  exports: 'OPERATION_FAMILIAR_CUSTOMER_DETAIL_EXPORT',
  initFn: () => getTableData()
});

onMounted(() => {
  getShopOptionsData();
});

const searchFormRef = ref<FormInstance | null>();
const shopOptions = ref<{ shopId: number; shopName: string }[]>([]);
const getShopOptionsData = async () => {
  try {
    let res = await fetchMemberShopListPort();
    shopOptions.value = (res.shops as basicShopItem[]).map(({ shopId, shopName }) => ({ shopId, shopName }));
  } catch (e) {
    console.log('e : ', e);
  }
};

const initFormData = (): RegularGuestFormType => ({
  beauticianName: '',
  memberCode: '',
  memberName: '',
  queryMonth: dayjs().format('YYYY-MM'),
  shopIds: []
});

const searchForm = ref<RegularGuestFormType>(initFormData());
const searchParams = computed<RegularGuestFormType>(() => ({
  ...searchForm.value,
  queryMonth: `${searchForm.value.queryMonth}-01`
}));

const searchRules = reactive<FormRules>({
  queryMonth: [{ required: true, message: '请选择月份', trigger: 'change' }]
});

const table = useTable<RegularGuestTableItemType, RegularGuestFormType>({
  port: getRegularGuestTablePort,
  searchForm: searchParams,
  exportPort: exportRegularGuestTablePort,
  exportExcelName: '美容师熟客报表'
});

const { tableData, tableLoading, pagination, getTableData } = table;

const handleSearch = () => {
  searchFormRef.value?.validate((valid, fields) => {
    if (valid) {
      table.handleSearch();
    } else {
      console.log('error submit!', fields);
    }
  });
};

const handleReset = () => {
  searchForm.value = initFormData();
  searchFormRef.value?.resetFields();
  table.handleReset();
};

const handleExport = () => {
  searchFormRef.value?.validate((valid, fields) => {
    if (valid) {
      table.handleExport();
    } else {
      console.log('error submit!', fields);
    }
  });
};
</script>
