<template>
  <div class="table-box">
    <div class="card table-search">
      <el-form :model="searchForm" label-width="80">
        <el-row :gutter="15">
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="日期区间">
              <el-date-picker
                v-model="searchForm.dates"
                type="daterange"
                format="YYYY-MM-DD"
                value-format="YYYY-MM-DD"
                placeholder="请选择日期"
                unlink-panels
              />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="美容师">
              <el-input v-model="searchForm.beauticianName" placeholder="请输入" clearable />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="顾客号">
              <el-input v-model="searchForm.memberCode" placeholder="请输入" clearable />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item>
              <el-space>
                <el-button type="primary" @click="handleSearch" :disabled="isDisabledRead">搜索</el-button>
                <el-button type="danger" plain @click="handleReset" :disabled="isDisabledRead">重置</el-button>
                <el-button type="warning" plain @click="handleExport" :disabled="isDisabledExport">导出</el-button>
              </el-space>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <el-card :body-style="{ paddingTop: '8px', height: '100%', boxSizing: 'border-box' }" shadow="hover" class="table-main">
      <el-tabs v-model="tabName">
        <template v-for="(table, name, index) in tableMaps" :key="index">
          <el-tab-pane :label="['买卡明细', '全套面部护理明细', '叠加护理明细'][index]" :name="name">
            <!-- 请注意，仅当 ref 是模板渲染上下文的顶层属性时才适用自动“解包”。否则需要.value手动解包-->
            <!-- https://cn.vuejs.org/guide/essentials/reactivity-fundamentals.html#ref-unwrapping-in-templates  -->
            <el-table v-loading="table.tableLoading.value" :data="table.tableData.value" class="wp-100" border>
              <el-table-column prop="shopName" label="销售门店" align="center" min-width="120" />
              <el-table-column prop="saleDate" label="销售日期" align="center" min-width="120" />
              <el-table-column prop="saleOrderCode" label="销售单号" align="center" min-width="120" />
              <el-table-column prop="memberCode" label="顾客号" align="center" min-width="120" />
              <el-table-column prop="memberName" label="顾客姓名" align="center" min-width="120" />
              <template v-if="name === 'firstTable'">
                <el-table-column prop="purchaseType" label="购买类型" align="center" min-width="120" />
                <el-table-column prop="itemName" label="购买项目" align="center" min-width="120" />
              </template>
              <template v-else>
                <el-table-column prop="itemCode" label="护理编号" align="center" min-width="120" />
                <el-table-column prop="itemName" label="护理名称" align="center" min-width="120" />
                <el-table-column prop="count" label="数量" align="center" min-width="60" />
                <el-table-column prop="unitPrice" label="单价" align="center" min-width="80" />
              </template>
              <el-table-column prop="netAmount" label="实付额" align="center" min-width="100" />
              <el-table-column prop="payMethod" label="支付方式" align="center" min-width="120" />
              <el-table-column prop="beauticianName" label="美容师" align="center" min-width="120" />
            </el-table>
            <el-pagination
              background
              layout="total, sizes, prev, pager, next, jumper"
              :current-page="table.pagination.page"
              :page-size="table.pagination.pageSize"
              :page-sizes="table.pagination.pageSizes"
              :total="table.pagination.itemCount"
              @current-change="table.pagination.onChange"
              @size-change="table.pagination.onPageSizeChange"
            />
          </el-tab-pane>
        </template>
      </el-tabs>
    </el-card>
  </div>
</template>

<!-- 熟客明细表 -->
<script lang="ts" setup name="juniorBeauticianTable">
import {
  getJuniorBeauticianBuyCardTablePort,
  getJuniorBeauticianFaceTreatmentTablePort,
  getJuniorBeauticianOverlayTreatmentTablePort,
  exportJuniorBeauticianBuyCardTablePort,
  exportJuniorBeauticianFaceTreatmentTablePort,
  exportJuniorBeauticianOverlayTreatmentTablePort,
  JuniorBeauticianTableItemType
} from '@/api/modules/beautician';
import dayjs from 'dayjs';
import { useButtonAuth } from '@/hooks/useButtonAuth';
import { juniorBeauticianFormType, juniorBeauticianTabNameType, juniorBeauticianParamsType } from '@/views/beautician/interfaces';
import { useTable, UseTableType } from '@/hooks/useTable';

// 按钮权限
const { isDisabledRead, isDisabledExport } = useButtonAuth({
  read: 'OPERATION_JUNIOR_BEAUTICIAN_TRAINEES_READ',
  exports: 'OPERATION_JUNIOR_BEAUTICIAN_TRAINEES_EXPORT',
  initFn: () => {
    // 初始化加载第一个tab-panel的表格数据
    getTableData();
  }
});

// 当前日期
const currentMonthFirstDay = dayjs().startOf('month').format('YYYY-MM-DD'); // 当前月份第一天
const currentMonthToday = dayjs().format('YYYY-MM-DD'); // 当前月份当天

// 查询表单数据初始化- 工厂函数
const initFormData = (): juniorBeauticianFormType => ({
  beauticianName: '',
  memberCode: '',
  dates: [currentMonthFirstDay, currentMonthToday]
});

const searchForm = ref<juniorBeauticianFormType>(initFormData());

const searchFormParams = computed<juniorBeauticianParamsType>(() => {
  const { beauticianName, memberCode, dates } = toValue(searchForm);
  const [startDate, endDate] = dates as string[];
  return { beauticianName, memberCode, startDate, endDate };
});

// 对查询表单进行 监听
watch(
  searchForm,
  () => {
    // 表单数据更新后，切换tab时更新table数据
    for (const key in tableMaps) {
      tableMaps[key as juniorBeauticianTabNameType].updateTableStatus.value = true;
    }
  },
  { deep: true }
);

// 当前tab面板name值
const tabName = ref<juniorBeauticianTabNameType>('firstTable');

// 切换tab-pane时 监听
watch(tabName, name => {
  if (isDisabledRead.value) return;
  // 切换tab pane 如果查询的form数据有更新 则重新重新数据
  const updateTableStatus = tableMaps[name].updateTableStatus.value;
  if (updateTableStatus) {
    return handleSearch();
  }
  // 如果当前table表格有数据，不再调用接口查询数据
  const tableData = tableMaps[name].tableData.value;
  if (tableData.length) return;
  getTableData();
});

// table相关数据的映射
const tableMaps: Record<juniorBeauticianTabNameType, UseTableType<JuniorBeauticianTableItemType>> = {
  firstTable: useTable<JuniorBeauticianTableItemType, juniorBeauticianParamsType>({
    port: getJuniorBeauticianBuyCardTablePort,
    searchForm: searchFormParams,
    exportPort: exportJuniorBeauticianBuyCardTablePort,
    exportExcelName: '初级美容师学员买卡明细表'
  }),
  secondTable: useTable<JuniorBeauticianTableItemType, juniorBeauticianParamsType>({
    port: getJuniorBeauticianFaceTreatmentTablePort,
    searchForm: searchFormParams,
    exportPort: exportJuniorBeauticianFaceTreatmentTablePort,
    exportExcelName: '初级美容师学员全套面部护理明细表'
  }),
  thirdTable: useTable<JuniorBeauticianTableItemType, juniorBeauticianParamsType>({
    port: getJuniorBeauticianOverlayTreatmentTablePort,
    searchForm: searchFormParams,
    exportPort: exportJuniorBeauticianOverlayTreatmentTablePort,
    exportExcelName: '初级美容师学员叠加护理明细表'
  })
};

// 获取table表格数据
const getTableData = () => {
  tableMaps[tabName.value].getTableData();
};

const handleSearch = () => {
  tableMaps[tabName.value].handleSearch();
};

const handleReset = () => {
  // 初始化相关数据
  searchForm.value = initFormData();
  tableMaps[tabName.value].handleReset();
};

// 导出table表格数据
const handleExport = () => {
  tableMaps[tabName.value].handleExport();
};
</script>
