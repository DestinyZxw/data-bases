<template>
  <div class="table-box">
    <div class="card table-search">
      <el-form ref="searchFormRef" :model="searchForm" label-width="60">
        <el-row :gutter="10">
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="月份">
              <el-date-picker v-model="searchForm.queryMonth" type="month" format="YYYY-MM" value-format="YYYY-MM" />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="门店">
              <el-cascader
                class="wp-100"
                v-model="searchForm.shopList"
                :props="shopProps"
                :options="shopOptions"
                collapse-tags
                collapse-tags-tooltip
                filterable
              />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="顾问">
              <el-input v-model="searchForm.consultantName" placeholder="请输入" />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item>
              <el-space>
                <el-button type="primary" :icon="Search" @click="handleSearch" :disabled="isDisabledRead">搜索</el-button>
                <el-button type="warning" :icon="Refresh" @click="handleReset" :disabled="isDisabledRead">重置</el-button>
                <el-button type="success" :icon="Download" plain @click="handleExport" :disabled="isDisabledExport">
                  导出
                </el-button>
              </el-space>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <div class="card table-main">
      <!--<div class="table-header">
        <el-button type="primary" :icon="Download" plain @click="handleExport" :disabled="isDisabledExport">导出</el-button>
      </div>-->
      <el-table v-loading="tableLoading" :data="tableData" style="width: 100%" border>
        <el-table-column label="顾客基本信息" align="center">
          <el-table-column prop="memberCode" label="卡号" align="center" min-width="120" fixed="left" />
          <el-table-column prop="memberName" label="会员姓名" align="center" min-width="120" />
          <el-table-column prop="age" label="年龄" align="center" min-width="120" />
          <el-table-column prop="vipLevel" label="客户等级" align="center" min-width="120" />
          <el-table-column prop="membershipYear" label="入会年限" align="center" min-width="120" />
          <el-table-column prop="manageStr" label="专属/专管" align="center" min-width="120" />
        </el-table-column>
        <el-table-column label="年度预收款及消耗额" align="center">
          <el-table-column prop="spCashAmount" label="上年全年现金收款总额" align="center" min-width="120" />
          <el-table-column prop="cashAmount" label="当年累积现金收款总额" align="center" min-width="120" />
          <el-table-column prop="spTreatmentAmount" label="上年全年开单总额" align="center" min-width="120" />
          <el-table-column prop="treatmentAmount" label="当年累积开单总额" align="center" min-width="120" />
          <el-table-column prop="spProductAmount" label="上年全年产品总额" align="center" min-width="120" />
          <el-table-column prop="productAmount" label="当年累积产品总额" align="center" min-width="120" />
        </el-table-column>
        <el-table-column label="会员账户余额" align="center">
          <el-table-column prop="quarterTreatmentRest" label="上季度会员账户护理总余额" align="center" min-width="120" />
          <el-table-column prop="quarterProductRest" label="上季度会员账户产品总余额" align="center" min-width="120" />
        </el-table-column>
        <el-table-column label="现金" align="center">
          <el-table-column prop="quarterCashAmount" label="上季度现金收款总额" align="center" min-width="120" />
        </el-table-column>
        <el-table-column label="消耗" align="center">
          <el-table-column prop="quarterTreatmentAmount" label="上季度开单额" align="center" min-width="120" />
          <el-table-column prop="quarterProductAmount" label="上季度产品额" align="center" min-width="120" />
          <el-table-column prop="quarterConsumeCount" label="上季度到店次数" align="center" min-width="120" />
        </el-table-column>
      </el-table>
      <el-pagination
        background
        layout="total, sizes, prev, pager, next, jumper"
        :current-page="pagination.page"
        :page-size="pagination.pageSize"
        :page-sizes="pagination.pageSizes"
        :total="pagination.itemCount"
        @current-change="pagination.onChange"
        @size-change="pagination.onPageSizeChange"
      />
    </div>
  </div>
</template>
<!-- 专属业绩明细表 -->
<script lang="ts" setup name="customerInventoryConsultant">
import { basicShopItem, shopRegionPort } from '@/api/modules/base';
import type { CascaderProps, CascaderNodePathValue } from 'element-plus';
import { Download, Search, Refresh } from '@element-plus/icons-vue';
import {
  getExclusiveMemberTablePort,
  ExclusiveMemberTableItemType,
  exportExclusiveMemberPort
} from '@/api/modules/customerInventory';
import dayjs from 'dayjs';
import { useButtonAuth } from '@/hooks/useButtonAuth';
import { SearchFormType, SearchParamsType } from '@/views/customerInventory/interfaces';
import { useTable } from '@/hooks/useTable';

// 按钮权限
const { isDisabledRead, isDisabledExport } = useButtonAuth({
  read: 'MENU_EMPLOYEE_MEMBER_TOOL_READ',
  exports: 'MENU_EMPLOYEE_MEMBER_TOOL_EXPORT',
  initFn: () => getTableData()
});

onMounted(() => {
  getShopRegionData();
});

type ShopOptionType = {
  shopId: number | string;
  shopName: string;
  shopRegionList: basicShopItem[];
};

// 门店 options
const shopOptions = ref<ShopOptionType[]>([]);

// 门店 props
const shopProps: CascaderProps = {
  label: 'shopName',
  value: 'shopId',
  children: 'shopRegionList',
  multiple: false,
  expandTrigger: 'hover'
};

const getShopRegionData = async () => {
  try {
    let { val: data, success } = await shopRegionPort();
    if (success === '0') {
      shopOptions.value = data.map(item => {
        let tmp: ShopOptionType = {
          shopId: item.region,
          shopName: item.region,
          shopRegionList: item.shopRegionList
        };
        return tmp;
      });
    }
  } catch (e) {
    console.log('e : ', e);
  }
};

const currentMonth = dayjs().format('YYYY-MM');
const initFormData = (): SearchFormType => ({
  consultantName: '',
  shopList: [],
  queryMonth: currentMonth
});

const searchForm = ref<SearchFormType>(initFormData());

const searchParams = computed<SearchParamsType>(() => {
  let { shopList, consultantName, queryMonth } = toValue(searchForm);
  // 店铺单选
  let [, shopId] = shopList as CascaderNodePathValue;
  return { consultantName, queryMonth, shopId: shopId as number };
});

const table = useTable<ExclusiveMemberTableItemType, SearchParamsType>({
  port: getExclusiveMemberTablePort,
  searchForm: searchParams,
  exportPort: exportExclusiveMemberPort,
  exportExcelName: '顾问季度盘点表'
});

const { tableData, tableLoading, pagination, getTableData, handleSearch, handleExport } = table;

const handleReset = () => {
  searchForm.value = initFormData();
  table.handleReset();
};
</script>
<style scoped lang="scss">
:deep(.el-table) {
  //  设置 el-table 中 header 文字不换行，并省略
  .el-table__header .el-table__cell > .cell {
    white-space: unset !important;
  }
}
</style>
