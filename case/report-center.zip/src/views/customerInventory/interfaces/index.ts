import { CascaderNodePathValue, ModelValueType } from 'element-plus';

export interface SearchFormType {
  shopList: CascaderNodePathValue;
  consultantName?: string;
  queryMonth: ModelValueType;
}

export type SearchParamsType = {
  shopId: number;
} & Omit<SearchFormType, 'shopList'>;
