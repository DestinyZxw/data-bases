<template>
  <div class="table-box">
    <div class="card table-search pb0">
      <RubSearchForm
        read-auth-code="MENU_PRODUCT_RANKING_LIST_READ"
        :is-cross-year="true"
        @init="handleSearch"
        @search="handleSearch"
        @reset="handleReset"
      />
    </div>

    <el-card
      shadow="hover"
      :body-style="{
        padding: '15px',
        flex: 1,
        height: 'calc(100% - 80px)',
        display: 'flex',
        flexDirection: 'column',
        boxSizing: 'border-box'
      }"
      class="table-main"
    >
      <template #header>
        <div class="flex items-center justify-between">
          <div class="font-bold">产品销售排行榜</div>
          <div class="fz14" style="color: var(--el-text-color-secondary)">单位: 元</div>
        </div>
      </template>
      <div class="selector mb20">
        <div class="name flex items-center justify-between">
          <span>品类筛选</span>
          <el-button type="primary" plain size="small" @click="exportTableData">
            导出<el-icon class="el-icon--right"><Download /></el-icon>
          </el-button>
        </div>
        <RubSelector v-model="categoryValue" :options="categoryOptions" auth-code="MENU_PRODUCT_RANKING_LIST_READ" />
      </div>
      <el-table v-loading="tableLoading" :data="tableData" class="wp-100" border>
        <el-table-column
          prop="productCode"
          label="产品编号"
          align="center"
          min-width="120"
          v-bind="isMobile ? {} : { fixed: 'left' }"
        >
          <template #default="{ row }">{{ handleFilterTableRow(row, 'productCode') }}</template>
        </el-table-column>
        <el-table-column prop="productName" label="产品名称" align="center" min-width="160">
          <template #default="{ row }">
            <div class="tl">{{ handleFilterTableRow(row, 'productName') }}</div>
          </template>
        </el-table-column>
        <el-table-column prop="brandEnName" label="品牌" align="center" min-width="120">
          <template #default="{ row }">{{ handleFilterTableRow(row, 'brandEnName') }}</template>
        </el-table-column>
        <el-table-column prop="price" label="吊牌价" align="center" min-width="120">
          <template #default="{ row }">{{ handleFilterTableRow(row, 'price') }}</template>
        </el-table-column>
        <el-table-column prop="salesCount" label="销售数量" align="center" min-width="120">
          <template #default="{ row }">{{ handleFilterTableRow(row, 'salesCount') }}</template>
        </el-table-column>
        <el-table-column prop="preSaleRevenue" label="折前销售额" align="center" min-width="120">
          <template #default="{ row }">{{ handleFilterTableRow(row, 'preSaleRevenue') }}</template>
        </el-table-column>
        <el-table-column prop="actualSalesRevenue" label="实际销售额" align="center" min-width="120">
          <template #default="{ row }">{{ handleFilterTableRow(row, 'actualSalesRevenue') }}</template>
        </el-table-column>
        <el-table-column prop="perPersonPrice" label="实际客单价" align="center" min-width="120">
          <template #default="{ row }">{{ handleFilterTableRow(row, 'perPersonPrice') }}</template>
        </el-table-column>
        <el-table-column prop="discount" label="折扣" align="center" min-width="120">
          <template #default="{ row }">{{ handleFilterTableRow(row, 'discount') }}</template>
        </el-table-column>
        <el-table-column prop="grossMargin" label="毛利率" align="center" min-width="120">
          <template #default="{ row }">{{ handleFilterTableRow(row, 'grossMargin') }}</template>
        </el-table-column>
        <el-table-column prop="actualSalesRanking" label="实际销售额排名" align="center" min-width="140">
          <template #default="{ row }">{{ handleFilterTableRow(row, 'actualSalesRanking') }}</template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<!-- 产品销售排行榜 页面 -->
<script setup lang="ts" name="productSalesRankingAnalysis">
import {
  getProductSalesRankingTablePort,
  exportProductSalesRankingTablePort,
  ProductSalesRankingTableItemType
} from '@/api/modules/productAnalysis';
import { SearchParamsType } from '@/components/rub-search-form/interfaces';
import type { ModelValueType, SelectorOptionItemType } from '@/components/rub-selector/index.vue';
import { handleFilterTableRow } from '@/utils';
import { useGlobalStore } from '@/stores/modules/global';
import { ElMessageBox } from 'element-plus';
import { useDownload } from '@/hooks/useDownload';

const globalStore = useGlobalStore();
const isMobile = computed(() => globalStore.device === 'mobile');
// 缓存的表单的参数
let cacheSearchParams: SearchParamsType = {} as SearchParamsType;

const handleSearch = (data: SearchParamsType) => {
  cacheSearchParams = data;
  getTableData(data);
};

const handleReset = (data: SearchParamsType) => {
  if (categoryValue.value === '客装') {
    handleSearch(data);
  } else {
    cacheSearchParams = data;
    categoryValue.value = '客装';
  }
};

// selector选择器相关参数
const categoryValue = ref<ModelValueType>('客装');
const categoryOptions: SelectorOptionItemType[] = [
  { name: '客装', value: '客装' },
  { name: '院装', value: '院装' },
  { name: '客院两用', value: '客院两用' }
];

watch(categoryValue, () => {
  getTableData(cacheSearchParams);
});

const tableData = ref<ProductSalesRankingTableItemType[]>([]);
const tableLoading = ref(false);

const getTableData = async (args: SearchParamsType) => {
  try {
    tableLoading.value = true;
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = { shopIdList, startMonth, endMonth, productPackTypeNameList: [categoryValue.value] };
    let { val: data, success } = await getProductSalesRankingTablePort(params);
    if (success === '0') {
      tableData.value = data;
    }
  } catch (e) {
    console.log('e : ', e);
  } finally {
    tableLoading.value = false;
  }
};

// 导出表格数据
const exportTableData = () => {
  const { shopIdList, startMonth, endMonth } = toValue(cacheSearchParams);
  const params = { shopIdList, startMonth, endMonth, productPackTypeNameList: [categoryValue.value] };
  ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
    useDownload({
      port: exportProductSalesRankingTablePort,
      fileName: `${categoryValue.value}产品销售排行榜分析表`,
      params
    })
  );
};
</script>
