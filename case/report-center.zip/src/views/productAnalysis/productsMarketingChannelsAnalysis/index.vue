<template>
  <div class="table-box">
    <div class="card table-search pb0">
      <RubSearchForm read-auth-code="MENU_MEMBER_SUMMARY_READ" @init="handleSearch" @search="handleSearch" @reset="handleReset" />
    </div>

    <el-card
      shadow="hover"
      :body-style="{
        padding: '15px',
        flex: 1,
        height: 'calc(100% - 80px)',
        display: 'flex',
        flexDirection: 'column',
        boxSizing: 'border-box'
      }"
      class="table-main"
    >
      <template #header>
        <div class="flex items-center justify-between">
          <div class="font-bold">产品销售排行榜</div>
          <div class="fz14" style="color: var(--el-text-color-secondary)">单位: 元</div>
        </div>
      </template>
      <el-table v-loading="tableLoading" :data="tableData" class="wp-100" border>
        <el-table-column
          prop="spAmount"
          label="产品编号"
          align="center"
          min-width="120"
          v-bind="isMobile ? {} : { fixed: 'left' }"
        />
        <el-table-column label="线上销售" align="center">
          <el-table-column prop="spAmount" label="品牌活动" align="center" min-width="120" />
          <el-table-column prop="spAmount" label="商城活动" align="center" min-width="120" />
          <el-table-column prop="spAmount" label="正常折扣" align="center" min-width="120" />
          <el-table-column prop="spAmount" label="小计" align="center" min-width="120" />
        </el-table-column>
        <el-table-column label="线下销售" align="center">
          <el-table-column prop="spAmount" label="品牌活动" align="center" min-width="120" />
          <el-table-column prop="spAmount" label="商城活动" align="center" min-width="120" />
          <el-table-column prop="spAmount" label="小计" align="center" min-width="120" />
        </el-table-column>
        <el-table-column prop="spAmount" label="其他销售" align="center" min-width="120" />
        <el-table-column prop="spAmount" label="产品销售合计" align="center" min-width="120" />
        <el-table-column prop="spAmount" label="结构(%)" align="center" min-width="120" />
        <el-table-column prop="spAmount" label="类别毛利率" align="center" min-width="120" />
      </el-table>
      <div class="flex justify-end">
        <el-pagination
          background
          layout="total, sizes, prev, pager, next, jumper"
          :current-page="balanceAlarmPagination.page"
          :page-size="balanceAlarmPagination.pageSize"
          :page-sizes="balanceAlarmPagination.pageSizes"
          :total="balanceAlarmPagination.itemCount"
          @current-change="balanceAlarmPagination.onChange"
          @size-change="balanceAlarmPagination.onPageSizeChange"
        />
      </div>
    </el-card>
  </div>
</template>

<!-- 产品销售渠道 页面 -->
<script setup lang="ts" name="productsMarketingChannelsAnalysis">
import { getShopCustomerReportTablePort, CustomerReportTableItemType } from '@/api/modules/shop';
import { SearchParamsType } from '@/components/rub-search-form/interfaces';
import { PaginationType } from '@/hooks/useTable';
import { useGlobalStore } from '@/stores/modules/global';

const globalStore = useGlobalStore();
const isMobile = computed(() => globalStore.device === 'mobile');

const balanceAlarmPagination: PaginationType = reactive({
  page: 1,
  pageSize: 15,
  pageSizes: [15, 20, 30, 40, 50],
  itemCount: 0,
  onChange: (page: number) => {
    balanceAlarmPagination.page = page;
  },
  onPageSizeChange: (pageSize: number) => {
    balanceAlarmPagination.page = 1;
    balanceAlarmPagination.pageSize = pageSize;
  }
});

const handleSearch = (data: SearchParamsType) => {
  getTableData(data);
};

const handleReset = (data: SearchParamsType) => {
  tableData.value = [];
  handleSearch(data);
};

const tableData = ref<CustomerReportTableItemType[]>([]);
const tableLoading = ref(false);

const getTableData = async (args: SearchParamsType) => {
  try {
    tableLoading.value = true;
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = { shopIdList, startMonth, endMonth };
    let { val: data, success } = await getShopCustomerReportTablePort(params);
    if (success === '0') {
      const tmp: CustomerReportTableItemType[] = [];
      for (let it of data) {
        if (it.type === '体验顾客人数') {
          tmp.push({ type: '体验顾客' } as CustomerReportTableItemType);
          tmp.push(it);
        } else if (it.type === '复购人数') {
          tmp.push({ type: '新会员' } as CustomerReportTableItemType);
          tmp.push(it);
        } else if (it.type === '人均护理产出=180天') {
          tmp.push({ type: '人均护理业绩产出' } as CustomerReportTableItemType);
          tmp.push({ ...it, type: '=180天' });
        } else if (it.type === '人均护理产出=360天') {
          tmp.push({ ...it, type: '=360天' });
        } else if (it.type === '人均产品产出=180天') {
          tmp.push({ type: '人均产品业绩产出' } as CustomerReportTableItemType);
          tmp.push({ ...it, type: '=180天' });
        } else if (it.type === '人均产品产出=360天') {
          tmp.push({ ...it, type: '=360天' });
        } else if (it.type === '老会员人次') {
          tmp.push({ type: '老会员' } as CustomerReportTableItemType);
          tmp.push(it);
        } else {
          tmp.push(it);
        }
      }
      tableData.value = tmp;
    }
  } catch (e) {
    console.log('e : ', e);
  } finally {
    tableLoading.value = false;
  }
};
</script>
