<template>
  <RubPage>
    <!-- 一、客装产品 -->
    <el-card shadow="hover" :body-style="{ padding: '14px 14px 8px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz20">一、客装产品</div>
        </div>
      </template>
      <el-card class="mb10">
        <RubEmptyTip :show="customPackagingSkuStatus">
          <el-scrollbar>
            <RubBaseChart v-bind="customPackagingSkuChartData" class="chart" style="height: 520px" />
          </el-scrollbar>
        </RubEmptyTip>
      </el-card>
    </el-card>

    <!-- 一、院装及客院两用 -->
    <el-card shadow="hover" class="mt14 pr" :body-style="{ padding: '14px 14px 8px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz20">二、院装及客院两用</div>
        </div>
      </template>
      <el-card class="mb20">
        <RubEmptyTip :show="salonOnlySkuStatus">
          <el-scrollbar>
            <RubBaseChart v-bind="salonOnlySkuChartData" class="chart" style="height: 520px" />
          </el-scrollbar>
        </RubEmptyTip>
      </el-card>
      <el-card class="mb10">
        <RubEmptyTip :show="dualPurposeSkuStatus">
          <el-scrollbar>
            <RubBaseChart v-bind="dualPurposeSkuChartData" class="chart" style="height: 520px" />
          </el-scrollbar>
        </RubEmptyTip>
      </el-card>
    </el-card>
  </RubPage>
</template>

<!-- 产品SKU分布 页面 -->
<script setup lang="ts" name="productSkuAnalysis">
import { getProductSkuSystemPort, ProductSkuSystemItemType } from '@/api/modules/productAnalysis';
import { Chart } from '@/typings/global';
import { useButtonAuth } from '@/hooks/useButtonAuth';

type FactoryParamsType = { title: string; data: ProductSkuSystemItemType[]; color: string };

// 按钮权限
useButtonAuth({
  read: 'MENU_PRODUCT_SKU_DISTRIBUTE_READ',
  initFn: () => getProductSkuSystemData()
});

// 客装SKU 图表数据
const customPackagingSkuStatus = ref(false);
const customPackagingSkuChartData = ref<Chart.BaseChartType>({});

// 院装SKU数 图表数据
const salonOnlySkuStatus = ref(false);
const salonOnlySkuChartData = ref<Chart.BaseChartType>({});

// 院客两用SKU数 图表数据
const dualPurposeSkuStatus = ref(false);
const dualPurposeSkuChartData = ref<Chart.BaseChartType>({});

// chart图表 option工厂函数
const chartOptionsFactory = ({ title, data, color }: FactoryParamsType) => {
  let axis: string[] = [],
    list: number[] = [];
  for (let item of data) {
    axis.push(item.effectName);
    list.push(item.skuCount);
  }
  return {
    title,
    xAxisBoundaryGap: true,
    xAxisLabelRotate: 45,
    yAxisVisible: false,
    grid: { top: '10%', bottom: '5%' },
    colors: [color],
    axis,
    series: [
      {
        type: 'bar',
        data: list,
        label: { show: true, position: 'top' },
        barMaxWidth: 40
      }
    ]
  };
};

// 获取sku分布的数据
const getProductSkuSystemData = async () => {
  try {
    let { val: data, success } = await getProductSkuSystemPort();
    if (success === '0') {
      // 客装SKU数
      customPackagingSkuStatus.value = !!data.customerPackage.length;
      data.customerPackage.length &&
        (customPackagingSkuChartData.value = chartOptionsFactory({
          title: '客装SKU数',
          data: data.customerPackage,
          color: '#4F81BD'
        }));

      // 院装SKU数
      salonOnlySkuStatus.value = !!data.beautySalonPackage.length;
      data.beautySalonPackage.length &&
        (salonOnlySkuChartData.value = chartOptionsFactory({
          title: '院装SKU数',
          data: data.beautySalonPackage,
          color: '#F79646'
        }));

      // 院装SKU数
      dualPurposeSkuStatus.value = !!data.dualUsePackage.length;
      data.dualUsePackage.length &&
        (dualPurposeSkuChartData.value = chartOptionsFactory({
          title: '院客两用SKU数',
          data: data.dualUsePackage,
          color: '#B3A2C7'
        }));
    }
  } catch (error) {
    console.log('error : ', error);
  }
};
</script>
