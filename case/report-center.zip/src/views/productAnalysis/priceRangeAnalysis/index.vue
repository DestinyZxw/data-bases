<template>
  <RubPage>
    <template #header>
      <div class="card pb0">
        <RubSearchForm
          read-auth-code="MENU_PRODUCT_PRICE_READ"
          :is-cross-year="true"
          @init="handleSearch"
          @search="handleSearch"
          @reset="handleReset"
        />
      </div>
    </template>

    <!-- 产品价格带 -->
    <el-card shadow="hover" class="mt14 pr" :body-style="{ padding: '14px 14px 8px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz20">
            产品价格带
            <el-tooltip class="box-item" effect="dark" placement="top">
              <template #content>
                <div style="max-width: 360px">{{ getQuestionMapItem(143) }}</div>
              </template>
              <el-icon class="pointer" size="20" color="#333">
                <Warning />
              </el-icon>
            </el-tooltip>
          </div>
        </div>
      </template>
      <div class="selector">
        <div class="name">品类筛选</div>
        <RubSelector v-model="categoryValue" :options="categoryOptions" auth-code="MENU_PRODUCT_PRICE_READ" />
      </div>
      <el-card v-loading="loading" class="mb20">
        <RubEmptyTip :show="priceChartStatus" style="min-height: 600px">
          <el-scrollbar>
            <RubDoubleYAxisChart v-bind="priceChartData" class="chart" style="height: 600px" />
          </el-scrollbar>
        </RubEmptyTip>
      </el-card>
      <el-card v-loading="loading" class="mb10">
        <RubEmptyTip :show="productChartStatus" style="min-height: 600px">
          <el-scrollbar>
            <RubDoubleYAxisChart v-bind="productChartData" class="chart" style="height: 600px" />
          </el-scrollbar>
        </RubEmptyTip>
      </el-card>
    </el-card>
  </RubPage>
</template>

<!-- 产品价格带分析 页面 -->
<script setup lang="ts" name="productPriceRangeAnalysis">
import { getProductPriceRangePort, ProductRangeItemType } from '@/api/modules/productAnalysis';
import { SearchParamsType } from '@/components/rub-search-form/interfaces';
import { Chart } from '@/typings/global';
import echarts from '@/utils/echarts';
import type { ModelValueType, SelectorOptionItemType } from '@/components/rub-selector/index.vue';
import { getQuestionMapItem } from '@/utils';

// 缓存的表单的参数
let cacheSearchParams: SearchParamsType = {} as SearchParamsType;

const handleSearch = (data: SearchParamsType) => {
  cacheSearchParams = data;
  getProductPriceRangeData(data);
};

const handleReset = (data: SearchParamsType) => {
  if (categoryValue.value === '客装') {
    handleSearch(data);
  } else {
    cacheSearchParams = data;
    categoryValue.value = '客装';
  }
};

// selector选择器相关参数
const categoryValue = ref<ModelValueType>('客装');
const categoryOptions: SelectorOptionItemType[] = [
  { name: '客装', value: '客装' },
  { name: '院装', value: '院装' },
  { name: '客院两用', value: '客院两用' }
];

watch(categoryValue, () => {
  getProductPriceRangeData(cacheSearchParams);
});

// 客装价格带 图表数据  ---  价格带打底
const priceChartStatus = ref(false);
const priceChartData = ref<Chart.DoubleYAxisChartType>({});

// 客装价格带 图表数据  ---  产品名打底
const productChartStatus = ref(false);
const productChartData = ref<Chart.DoubleYAxisChartType>({});

// chart options 工厂函数
const chartOptionsFactory = (xAxisName: string, data: ProductRangeItemType[]) => {
  let axis: string[] = [];
  let maps = new Map();
  for (let item of data) {
    let entries = Object.entries(item);
    for (let [key, value] of entries) {
      if (key === xAxisName) {
        axis.push(item[key] as string);
      } else {
        if (maps.has(key)) {
          let mapItem: Chart.SeriesItem = maps.get(key);
          key === '销售数量'
            ? mapItem.data.push(value as number)
            : mapItem.data.push({
                value: value as number,
                label: { show: (value as number) !== 0, position: 'inside' }
              });
        } else {
          let mapItem: Chart.SeriesItem =
            key === '销售数量'
              ? {
                  type: 'line',
                  name: key,
                  data: [value as number],
                  label: { show: true, position: 'top' },
                  yAxisIndex: 0,
                  smooth: true,
                  areaStyle: {
                    color: new echarts.graphic.LinearGradient(
                      0,
                      0,
                      0,
                      1,
                      [
                        { offset: 0, color: 'rgba(255,167,166,0.66)' },
                        { offset: 1, color: 'rgba(255,167,166, 0.1)' }
                      ],
                      false
                    )
                  }
                }
              : {
                  type: 'bar',
                  name: key,
                  data: [
                    {
                      value: value as number,
                      label: { show: (value as number) !== 0, position: 'inside' }
                    }
                  ],
                  barMaxWidth: 40,
                  yAxisIndex: 1,
                  stack: 'one'
                };
          maps.set(key, mapItem);
        }
      }
    }
  }
  return {
    title: `${categoryValue.value}价格带`,
    tooltip: { axisPointer: { type: 'shadow' } },
    grid: { top: '20%', bottom: '8%' },
    xAxisBoundaryGap: true,
    xAxisLabelRotate: 30,
    yAxisNameVisible: false,
    yAxisLeftColor: '',
    yAxisLeftTickVisible: false,
    yAxisLeftLineVisible: false,
    yAxisRightVisible: false,
    colors: [
      '#FFA6A5',
      '#4F7FBA',
      '#DDFDAE',
      '#CBB7E9',
      '#A3EBFF',
      '#FFC18C',
      '#64D9D6',
      '#409EFF',
      '#FCCEFB',
      '#A5A5A5',
      '#9E480E',
      '#ED7D31',
      '#5B9BD5'
    ],
    axis,
    series: [...maps.values()]
  };
};

// 获取产品价格带的数据
const loading = ref(false);
const getProductPriceRangeData = async (args: SearchParamsType) => {
  if (loading.value) return;
  loading.value = true;
  try {
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = { shopIdList, startMonth, endMonth, productPackTypeNameList: [categoryValue.value] };
    let { val: data, success } = await getProductPriceRangePort(params);
    if (success === '0') {
      const productPriceRange: ProductRangeItemType[] = data.productPriceRange ?? [];
      priceChartStatus.value = !!productPriceRange.length;
      productPriceRange.length && (priceChartData.value = chartOptionsFactory('价格带', productPriceRange));

      const anotherOneRange: ProductRangeItemType[] = data.anotherOneRange ?? [];
      productChartStatus.value = !!anotherOneRange.length;
      anotherOneRange.length && (productChartData.value = chartOptionsFactory('产品类型带', anotherOneRange));
    }
  } catch {
  } finally {
    loading.value = false;
  }
};
</script>
