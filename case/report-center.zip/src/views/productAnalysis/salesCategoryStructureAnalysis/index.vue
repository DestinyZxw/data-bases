<template>
  <RubPage>
    <template #header>
      <div class="card pb0">
        <RubSearchForm
          read-auth-code="MENU_PRODUCT_TYPE_STRUCT_READ"
          :is-cross-year="true"
          @init="handleSearch"
          @search="handleSearch"
          @reset="handleReset"
        />
      </div>
    </template>

    <el-card shadow="hover" class="mt14">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold">有效产品销售大类分布</div>
          <div class="fz14" style="color: var(--el-text-color-secondary)">单位: 元</div>
        </div>
      </template>
      <RubEmptyTip :show="productCategoriesTableStatus" style="min-height: 440px">
        <el-table :data="productCategoriesTableData" class="wp-100" border>
          <el-table-column
            v-for="(value, key, index) in productCategoriesTableData[0] ?? {}"
            align="center"
            min-width="120"
            :prop="key as string"
            :label="(ProductCategoriesMaps[key as ProductCategoriesKeyType] as string) || (key as string)"
            :key="index"
          >
            <template #default="{ row }">{{ filterProductCategoriesValue(key as string, row) }}</template>
          </el-table-column>
        </el-table>
      </RubEmptyTip>
    </el-card>

    <el-row :gutter="14">
      <el-col :xs="24" :sm="24" :md="14" :lg="16" class="mt14">
        <el-card shadow="hover">
          <template #header>
            <div class="flex items-center h-30">
              <div class="font-bold">产品的SKU数分布</div>
            </div>
          </template>
          <RubEmptyTip :show="productSkuTableStatus" style="min-height: 400px">
            <el-table :data="productSkuTableData" show-summary class="wp-100" border style="height: 400px">
              <el-table-column
                v-for="(value, key, index) in productSkuTableData[0] ?? {}"
                align="center"
                min-width="120"
                :prop="key as string"
                :label="(ProductSkuMaps[key as ProductSkuKeyType] as string) || (key as string)"
                :key="index"
              >
                <template #default="{ row }">
                  {{ Number(row[key]) || Number(row[key]) === 0 ? Number(row[key]) : row[key] ?? '/' }}
                </template>
              </el-table-column>
            </el-table>
          </RubEmptyTip>
        </el-card>
      </el-col>
      <el-col :xs="24" :sm="24" :md="10" :lg="8" class="mt14">
        <el-card shadow="hover">
          <template #header>
            <div class="font-bold h-30 lht30">产品客院装销售占比</div>
          </template>
          <RubEmptyTip :show="pieChartsStatus">
            <el-scrollbar>
              <RubPieChart v-bind="pieChartsData" class="pieChart" />
            </el-scrollbar>
          </RubEmptyTip>
        </el-card>
      </el-col>
    </el-row>
  </RubPage>
</template>

<!-- 产品销售大类结构分析 页面 -->
<script setup lang="ts" name="productSalesCategoryStructureAnalysis">
import {
  getProductCategoriesSalesTablePort,
  ProductCategoriesSalesTableItemType,
  getProductSkuTablePort,
  getProductSalesRatioPort
} from '@/api/modules/shop';
import { SearchParamsType } from '@/components/rub-search-form/interfaces';
import { Chart } from '@/typings/global';

// 缓存的数据
const searchParams = ref<SearchParamsType>({} as SearchParamsType);
const handleSearch = (data: SearchParamsType) => {
  searchParams.value = data;
  getProductCategoriesTableData(data);
  getProductSkuTableData(data);
  getProductSalesRatioData(data);
};

const handleReset = (data: SearchParamsType) => {
  searchParams.value = data;
  handleSearch(data);
};

// 有效产品销售大类分布相关代码
const productCategoriesTableStatus = ref(false);
const productCategoriesTableData = ref<ProductCategoriesSalesTableItemType[]>([]);
type ProductCategoriesKeyType = 'productTypeName' | 'productTypeRatio' | 'subTotalAmount';
const ProductCategoriesMaps: Record<ProductCategoriesKeyType, string> = {
  productTypeName: '产品名称',
  productTypeRatio: '品类结构(%)',
  subTotalAmount: '总计'
};
const getProductCategoriesTableData = async (args: SearchParamsType) => {
  try {
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = { shopIdList, startMonth, endMonth };
    let { val: data, success } = await getProductCategoriesSalesTablePort(params);
    if (success === '0') {
      productCategoriesTableStatus.value = !!data.length;
      productCategoriesTableData.value = data;
    }
  } catch (e) {
    console.log('e : ', e);
  }
};

// 对产品大类的值进行
const filterProductCategoriesValue = (key: string, row: ProductCategoriesSalesTableItemType) => {
  const value = Number(row[key]);
  return value ? (key.includes('Ratio') ? value.toFixed(2) + '%' : value.toFixed(2)) : row[key] || '/';
};

// 产品SKU数分布相关代码
const productSkuTableStatus = ref(false);
const productSkuTableData = ref<ProductCategoriesSalesTableItemType[]>([]);
type ProductSkuKeyType = 'productTypeName' | 'subTotalCount';
const ProductSkuMaps: Record<ProductSkuKeyType, string> = {
  productTypeName: '产品名称',
  subTotalCount: '总计'
};
const getProductSkuTableData = async (args: SearchParamsType) => {
  try {
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = { shopIdList, startMonth, endMonth };
    let { val: data, success } = await getProductSkuTablePort(params);
    if (success === '0') {
      productSkuTableStatus.value = !!data.length;
      productSkuTableData.value = data;
    }
  } catch (e) {
    console.log('e : ', e);
  }
};

// 产品客院装销售占比相关代码  pie饼图数据
const pieChartsStatus = ref<boolean>(false);
const pieChartsData = ref<Chart.PieChartType>({} as Chart.PieChartType);
const getProductSalesRatioData = async (args: SearchParamsType) => {
  try {
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = { shopIdList, startMonth, endMonth };
    const { val: data, success } = await getProductSalesRatioPort(params);
    if (success === '0') {
      pieChartsStatus.value = !!data.length;
      if (!data.length) return;
      const tmp: { name: string; value: number }[] = [];
      for (let item of data) {
        item.productPackTypeName !== '试用装' &&
          tmp.push({
            name: item.productPackTypeName,
            value: (item.subTotalAmount * 100) / item.totalAmount
          });
      }
      pieChartsData.value = {
        position: 'outside',
        data: tmp,
        colors: ['#A38FBC', '#FBC191', '#8DCADB']
      };
    }
  } catch (e) {
    console.log('e : ', e);
  }
};
</script>
