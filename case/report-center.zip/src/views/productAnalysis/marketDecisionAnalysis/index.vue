<template>
  <RubPage>
    <template #header>
      <div class="card pb0">
        <RubSearchForm
          read-auth-code="MENU_PRODUCT_SALE_DECISION_READ"
          :is-cross-year="true"
          @init="handleSearch"
          @search="handleSearch"
          @reset="handleReset"
        />
      </div>
    </template>

    <el-card shadow="hover" class="mt14" :body-style="{ 'padding-bottom': '6px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold">{{ selectorValue }}产品分析</div>
        </div>
      </template>
      <div class="selector mb14">
        <div class="name">品类筛选</div>
        <RubSelector v-model="selectorValue" :options="selectorOptions" auth-code="MENU_PRODUCT_SALE_DECISION_READ" />
      </div>
      <el-card class="mb14" shadow="hover">
        <RubEmptyTip :show="chartEmptyStatus">
          <!--<el-scrollbar>
            <RubDoubleYAxisChart v-bind="productParetoChartData" class="chart pt10" style="height: 900px" />
          </el-scrollbar>-->
          <RubDoubleYAxisChart v-bind="productParetoChartData" class="pt10" style="height: 900px" />
        </RubEmptyTip>
      </el-card>
      <el-card class="mb14" shadow="hover">
        <RubEmptyTip :show="chartEmptyStatus">
          <el-scrollbar>
            <FourQuadrantChart v-bind="productFourQuadrantData" />
          </el-scrollbar>
        </RubEmptyTip>
      </el-card>
    </el-card>
  </RubPage>
</template>

<!-- 产品上下市决策页面  -->
<script setup lang="ts" name="productMarketDecisionAnalysis">
import { getProductPackTypeAnalysePort } from '@/api/modules/shop';
import { SearchParamsType } from '@/components/rub-search-form/interfaces';
import { Chart } from '@/typings/global';
import FourQuadrantChart from '@/views/shop/components/four-quadrant-chart.vue';
import { useGlobalStore } from '@/stores/modules/global';

const globalStore = useGlobalStore();
const isMobile = computed(() => globalStore.device === 'mobile');

// 缓存的数据
const searchParams = ref<SearchParamsType>({} as SearchParamsType);
const handleSearch = (data: SearchParamsType) => {
  searchParams.value = data;
  getProductPackTypeAnalyseData();
};

const handleReset = (data: SearchParamsType) => {
  handleSearch(data);
};

const selectorValue = ref<string>('客装');
const selectorOptions = [
  { name: '客装', value: '客装' },
  { name: '院装', value: '院装' },
  { name: '客院两用', value: '客院两用' }
];

// 对品类筛选进行监听
watch(selectorValue, () => {
  getProductPackTypeAnalyseData();
});

/** 产品波士顿矩阵及帕累托图  相关代码 */
const chartEmptyStatus = ref(false);
// 客装帕累托图
const productParetoChartData = ref<Chart.DoubleYAxisChartType>({});

// 客装产品矩阵图
const productFourQuadrantData = ref<Chart.FourQuadrantChartType>({} as Chart.FourQuadrantChartType);
const productAnalyseLoading = ref<boolean>(false);
const getProductPackTypeAnalyseData = async () => {
  if (productAnalyseLoading.value) return;
  productAnalyseLoading.value = true;
  try {
    let { shopIdList, startMonth, endMonth } = toValue(searchParams);
    let params = { shopIdList, startMonth, endMonth, productPackTypeNameList: [selectorValue.value] };
    let { val: data, success } = await getProductPackTypeAnalysePort(params);
    if (success === '0') {
      chartEmptyStatus.value = !!data.length;
      if (!data.length) return;

      let axis = [];
      let amountArray = []; // 销售额 集合
      let rateArray = []; // 销售权重 集合
      let originalData: Chart.FourQuadrantChartItem[] = [];

      for (let item of data) {
        axis.push(item.productName);
        amountArray.push(+item.subTotalAmount.toFixed(2));
        rateArray.push(+item.cumulative.toFixed(2));
        originalData.push({
          name: item.productName,
          code: item.productCode,
          data: [item.subSalesCount || 0, item.subGrossTotalAmount || 0]
        });
      }

      let oneScreenValue = isMobile.value ? 5 : 40, // 横向 一屏数据展示的基准值
        dataZoom = [
          {
            type: isMobile.value ? 'inside' : 'slider',
            start: 0,
            end: Math.floor((oneScreenValue * 100) / (axis.length || oneScreenValue)),
            zoomLock: !isMobile.value,
            zoomOnMouseWheel: false,
            brushSelect: false,
            padding: [10, 20, 10, 20]
          }
        ];

      // 客装帕累托图 数据
      productParetoChartData.value = {
        title: `${selectorValue.value}--帕累托图`,
        xAxisLabelRotate: 75,
        yAxisRightUnit: '%',
        colors: ['#40699c', '#ff0000'],
        axis,
        grid: { bottom: '30%' },
        series: [
          { name: '销售额(万元)', type: 'bar', data: amountArray, barMaxWidth: 48 },
          { name: '销售权重(%)', type: 'line', data: rateArray, yAxisIndex: 1, smooth: true }
        ],
        // 导轨
        ...(axis.length > oneScreenValue ? { dataZoom } : {})
      };

      // 客装产品矩阵 数据
      productFourQuadrantData.value = { title: `${selectorValue.value}--产品矩阵`, originalData };
    }
  } catch (e) {
    console.log('e : ', e);
  } finally {
    productAnalyseLoading.value = false;
  }
};
</script>
