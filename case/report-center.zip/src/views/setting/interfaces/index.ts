import { ModelValueType } from 'element-plus';

// 访问记录 表单类型
export type AccessRecordFormType = {
  dateRange: ModelValueType;
  reportName: string;
  empId: string;
};
// 访问记录 表单类型
export type AccessRecordFormParamsType = {
  startTime: string;
  endTime: string;
} & Omit<AccessRecordFormType, 'dateRange'>;
