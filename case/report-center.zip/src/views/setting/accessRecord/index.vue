<template>
  <div class="table-box">
    <!--  form表单  -->
    <div class="card table-search">
      <el-form ref="searchFormRef" :model="searchForm" label-width="70">
        <el-row :gutter="15">
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="访问时间">
              <el-date-picker
                v-model="searchForm.dateRange"
                type="datetimerange"
                range-separator="-"
                start-placeholder="开始时间"
                end-placeholder="结束时间"
                format="YYYY-MM-DD HH:mm:ss"
                value-format="YYYY-MM-DD HH:mm:ss"
              />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="员工编号">
              <el-input v-model="searchForm.empId" placeholder="请输入" />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="报表名称">
              <el-input v-model="searchForm.reportName" placeholder="请输入" />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item>
              <el-space>
                <el-button type="primary" @click="handleSearch" :disabled="isDisabledRead">搜索</el-button>
                <el-button type="warning" @click="handleReset" :disabled="isDisabledRead">重置</el-button>
                <el-button type="success" @click="handleExport" :disabled="isDisabledExport">导出</el-button>
              </el-space>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <!--  table表格  -->
    <div class="card table-main">
      <el-table v-loading="tableLoading" :data="tableData" border class="wp-100">
        <el-table-column prop="empId" label="员工编号" align="center" min-width="100" fixed />
        <el-table-column prop="empName" label="姓名" align="center" min-width="100" />
        <el-table-column prop="positionName" label="岗位" align="center" min-width="140" />
        <el-table-column prop="deptName" label="部门" align="center" min-width="140" />
        <el-table-column prop="modelName" label="访问板块名称" align="center" min-width="140" />
        <el-table-column prop="reportName" label="访问报表名称" align="center" min-width="100" />
        <el-table-column prop="viewTime" label="访问时间" align="center" min-width="140" />
      </el-table>
      <el-pagination
        background
        layout="total, sizes, prev, pager, next, jumper"
        :current-page="pagination.page"
        :page-size="pagination.pageSize"
        :page-sizes="pagination.pageSizes"
        :total="pagination.itemCount"
        @current-change="pagination.onChange"
        @size-change="pagination.onPageSizeChange"
      />
    </div>
  </div>
</template>

<!-- 用户 访问记录 -->
<script lang="ts" setup name="userAccessRecord">
import type { AccessRecordFormType, AccessRecordFormParamsType } from '../interfaces';
import { type AccessRecordItemType, getAccessRecordListPort, exportAccessRecordPort } from '@/api/modules/setting';
import { useButtonAuth } from '@/hooks/useButtonAuth';
import { useTable } from '@/hooks/useTable';

// 按钮权限
const { isDisabledRead, isDisabledExport } = useButtonAuth({
  read: 'OPERATION_USER_ACCESS_RECORD_READ',
  exports: 'OPERATION_USER_ACCESS_RECORD_EXPORT',
  initFn: () => getTableData()
});

/** 查询条件 相关代码*/
const initSearchForm = (): AccessRecordFormType => ({
  empId: '',
  reportName: '',
  dateRange: ''
});
const searchForm = ref<AccessRecordFormType>(initSearchForm());
const searchParams = computed<AccessRecordFormParamsType>(() => {
  let { dateRange, reportName, empId } = searchForm.value;
  let startTime = '';
  let endTime = '';
  if (Array.isArray(dateRange) && dateRange.length === 2) {
    [startTime, endTime] = dateRange as string[];
  }
  return { reportName, empId, startTime, endTime };
});

// 搜索
const handleSearch = () => {
  pagination.page = 1;
  getTableData();
};

// 重置
const handleReset = () => {
  searchForm.value = initSearchForm();
  table.handleReset();
};

/**
 *  table 相关代码
 */
const table = useTable<AccessRecordItemType, AccessRecordFormParamsType>({
  port: getAccessRecordListPort,
  searchForm: searchParams,
  exportPort: exportAccessRecordPort,
  exportExcelName: '访问记录表'
});

const { tableData, tableLoading, pagination, getTableData, handleExport } = table;
</script>
