<template>
  <div class="table-box">
    <!--  form表单  -->
    <div class="card table-search">
      <el-form ref="searchFormRef" :model="searchForm" label-width="70">
        <el-row :gutter="15">
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="看板名称">
              <el-input v-model="searchForm.reportName" placeholder="请输入" />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="6" :xl="4">
            <el-form-item>
              <el-space>
                <el-button type="primary" @click="handleSearch" :disabled="isDisabledRead">搜索</el-button>
                <el-button type="warning" @click="handleReset" :disabled="isDisabledRead">重置</el-button>
              </el-space>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <!--  table表格  -->
    <div class="card table-main">
      <div class="table-header">
        <el-button type="primary" :icon="Plus" plain :disabled="isDisabledWrite" @click="handleOperateDialog('add')">
          新增
        </el-button>
      </div>
      <el-table v-loading="tableLoading" :data="tableData" border class="wp-100">
        <el-table-column prop="department" label="所属部门" align="center" min-width="100" fixed />
        <el-table-column prop="type" label="内容类别" align="center" min-width="100" />
        <el-table-column prop="reportName" label="看板名称" align="center" min-width="100" />
        <el-table-column prop="reportUrl" label="地址链接" align="center" min-width="140" />
        <el-table-column label="操作" align="center" min-width="80">
          <template #default="{ row }">
            <!--<el-button type="success" :icon="View" size="small" @click="handleViewDetail(row.reportUrl, row.reportName)" />-->
            <el-link
              class="ml5 mr5"
              type="primary"
              size="small"
              :disabled="isDisabledWrite"
              @click="handleOperateDialog('edit', row)"
            >
              编辑
            </el-link>
            <el-link class="ml5 mr5" type="danger" size="small" :disabled="isDisabledDel" @click="handleDelete(row.id)">
              删除
            </el-link>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        background
        layout="total, sizes, prev, pager, next, jumper"
        :current-page="pagination.page"
        :page-size="pagination.pageSize"
        :page-sizes="pagination.pageSizes"
        :total="pagination.itemCount"
        @current-change="pagination.onChange"
        @size-change="pagination.onPageSizeChange"
      />
    </div>

    <!--  dialog 弹窗 -->
    <el-dialog
      v-model="dialog.visible"
      :title="dialog.title"
      width="520"
      draggable
      destroy-on-close
      @close="handleOperateDialog('close')"
    >
      <el-scrollbar>
        <el-form ref="dialogFormRef" :model="dialog.form" :rules="dialogFormRules">
          <el-form-item label="所属部门" prop="department">
            <el-select v-model="dialog.form.department" placeholder="请选择" class="wp-100">
              <el-option label="品牌部" value="品牌部" />
              <el-option label="品牌部-门店" value="品牌部-门店" />
              <el-option label="推广部" value="推广部" />
              <el-option label="CRM部" value="CRM部" />
            </el-select>
          </el-form-item>
          <el-form-item label="内容类别" prop="type">
            <el-input v-model="dialog.form.type" placeholder="请输入" />
          </el-form-item>
          <el-form-item label="看板名称" prop="reportName">
            <el-input v-model="dialog.form.reportName" placeholder="请输入" />
          </el-form-item>
          <el-form-item label="链接地址" prop="reportUrl">
            <el-input v-model="dialog.form.reportUrl" placeholder="请输入" />
          </el-form-item>
        </el-form>
      </el-scrollbar>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="handleOperateDialog('close')">取消</el-button>
          <el-button type="primary" :loading="dialog.btnLoading" @click="handleSetDialog">确定</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<!-- Bi 报表管理 -->
<script lang="ts" setup name="BiReportManagement">
import type { FormRules, FormInstance } from 'element-plus';
import {
  type ReportConfigItemType,
  getReportConfigListPort,
  deleteReportConfigPort,
  addReportConfigPort,
  editReportConfigPort
} from '@/api/modules/setting';
import { useButtonAuth } from '@/hooks/useButtonAuth';
import { useTable } from '@/hooks/useTable';
import { Plus /*, EditPen, Delete , View*/ } from '@element-plus/icons-vue';
import { checkUrlAddress } from '@/utils/eleValidate';
import { /*ElMessage,*/ ElMessageBox } from 'element-plus';

// 按钮权限
const { isDisabledRead, isDisabledWrite, isDisabledDel } = useButtonAuth({
  read: 'MENU_BI_REPORT_CONFIG_READ',
  write: 'MENU_BI_REPORT_CONFIG_WRITE',
  deletes: 'MENU_BI_REPORT_CONFIG_DELETE',
  initFn: () => getTableData()
});

/**
 * 查询条件 相关代码
 */
type SearchFormType = {
  reportName: string;
};
const searchForm = ref<SearchFormType>({
  reportName: ''
});

// 搜索
const handleSearch = () => {
  pagination.page = 1;
  getTableData();
};

// 重置
const handleReset = () => {
  searchForm.value.reportName = '';
  table.handleReset();
};

/**
 *  table 相关代码
 */
const table = useTable<ReportConfigItemType, SearchFormType>({
  port: getReportConfigListPort,
  searchForm: searchForm
});

const { tableData, tableLoading, pagination, getTableData } = table;

/*
const router = useRouter();
const handleViewDetail = (reportUrl: string, reportName: string) => {
  router.push({ name: 'BiBoardDetail', params: { url: reportUrl, name: reportName } });
};
*/

/**
 *  dialog 相关代码
 */
// 模板引用
const dialogFormRef = ref<FormInstance | null>();

const initDialogForm = () => ({
  id: 0, // 主键
  department: '', // 部门名称
  type: '', // 内容类别
  reportName: '', // 看板名称
  reportUrl: '' // 地址链接
});

const dialog = reactive({
  title: '新增看板',
  type: 'add',
  visible: false,
  btnLoading: false,
  form: initDialogForm()
});

// 搜索表单规则
const dialogFormRules = reactive<FormRules>({
  department: [{ required: true, trigger: 'change', message: '请选择部门' }],
  type: [{ required: true, trigger: 'blur', message: '请填写内容类别' }],
  reportName: [{ required: true, trigger: 'blur', message: '请填写看板名称' }],
  reportUrl: [{ required: true, trigger: 'blur', validator: checkUrlAddress }]
});

// 操作弹窗
const handleOperateDialog = (type: string, row = {} as ReportConfigItemType) => {
  if (type === 'close') {
    dialog.visible = false;
    dialog.form = initDialogForm();
    return;
  }

  dialog.visible = true;
  dialog.type = type;
  dialog.title = type === 'add' ? '新增看板' : '编辑看板';

  if (type === 'edit') {
    dialog.form = {
      id: row.id,
      department: row.department,
      type: row.type,
      reportName: row.reportName,
      reportUrl: row.reportUrl
    };
  }
};

// 提交弹窗
const handleSetDialog = () => {
  dialogFormRef.value?.validate(async (valid, fields) => {
    if (valid) {
      try {
        dialog.btnLoading = true;
        const port = dialog.type === 'add' ? addReportConfigPort : editReportConfigPort;
        const { success } = await port(dialog.form);
        if (success === '0') {
          handleOperateDialog('close');
          getTableData();
        }
      } catch {
      } finally {
        dialog.btnLoading = false;
      }
    } else {
      console.log('error submit!', fields);
    }
  });
};

const handleDelete = (id: number) => {
  ElMessageBox({
    title: '提示',
    message: '确定删除此条看板数据吗？',
    showCancelButton: true,
    confirmButtonText: '确认',
    cancelButtonText: '取消',
    beforeClose: async (action, instance, done) => {
      if (action === 'confirm') {
        try {
          instance.confirmButtonLoading = true;
          instance.confirmButtonText = '执行中...';
          let res = await deleteReportConfigPort({ id });
          if (res.success === '0') {
            if (pagination.page > 1 && tableData.value.length === 1) {
              pagination.page--;
            }
            done();
            await getTableData();
          }
        } catch (e) {
          console.log('e : ', e);
        } finally {
          instance.confirmButtonLoading = false;
          done();
        }
      } else {
        done();
      }
    }
  });
};
</script>
