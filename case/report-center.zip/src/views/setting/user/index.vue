<template>
  <div class="table-box">
    <div class="card table-search">
      <el-form ref="searchFormRef" :model="searchForm" label-width="70">
        <el-row :gutter="15">
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="员工编号">
              <el-input v-model="searchForm.userNo" placeholder="请输入" />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="姓名">
              <el-input v-model="searchForm.userName" placeholder="请输入" />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="状态">
              <el-select v-model="searchForm.userStatus" class="wp-100" clearable>
                <el-option label="全部" value="" />
                <el-option label="激活" :value="1" />
                <el-option label="未激活" :value="0" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item>
              <el-space>
                <el-button type="primary" @click="handleSearch" :disabled="isDisabledRead">搜索</el-button>
                <el-button type="success" @click="handleReset" :disabled="isDisabledRead">重置</el-button>
              </el-space>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <div class="card table-main">
      <el-table v-loading="tableLoading" :data="tableData" border class="wp-100">
        <el-table-column prop="userNo" label="员工编号" align="center" min-width="100" fixed />
        <el-table-column prop="name" label="姓名" align="center" min-width="100" />
        <el-table-column prop="postName" label="岗位" align="center" min-width="140" />
        <el-table-column label="角色" align="center" min-width="140">
          <template #default="{ row }">
            {{ (row as UserItem).roleList.map(e => e.roleName).join('、') || '暂无' }}
          </template>
        </el-table-column>
        <el-table-column label="最后登录时间" align="center" min-width="140">
          <template #default="{ row }">
            {{ (row as UserItem).lastLoginTime || '-' }}
          </template>
        </el-table-column>
        <el-table-column label="状态" align="center" min-width="100">
          <template #default="{ row }">
            {{ (row as UserItem).haveAppPermission === 0 ? '未激活' : '激活' }}
          </template>
        </el-table-column>
        <el-table-column label="操作" align="center" min-width="140">
          <template #default="{ row }">
            <el-space>
              <el-link type="primary" @click="handleOperateUserDialog('edit', row)" :disabled="isDisabledWrite">编辑</el-link>
              <el-link
                type="success"
                :loading="userDialog.btnLoading"
                @click="handleOperateRoleDialog('edit', row)"
                :disabled="isDisabledWrite"
              >
                设置角色
              </el-link>
            </el-space>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        background
        layout="total, sizes, prev, pager, next, jumper"
        :current-page="pagination.page"
        :page-size="pagination.pageSize"
        :page-sizes="pagination.pageSizes"
        :total="pagination.itemCount"
        @current-change="pagination.onChange"
        @size-change="pagination.onPageSizeChange"
      />
    </div>

    <!--  员工dialog  -->
    <el-dialog title="编辑" v-model="userDialog.visible" width="500" draggable @close="handleOperateUserDialog('close')">
      <el-scrollbar>
        <el-form :model="userDialog">
          <el-form-item label="员工编号">
            <el-input v-model="userDialog.userNo" placeholder="请输入" disabled />
          </el-form-item>
          <el-form-item label="员工姓名">
            <el-input v-model="userDialog.userName" placeholder="请输入" disabled />
          </el-form-item>
          <el-form-item label="员工岗位">
            <el-input v-model="userDialog.postName" placeholder="请输入" disabled />
          </el-form-item>
          <el-form-item label="当前状态">
            <el-radio-group v-model="userDialog.userStatus">
              <el-radio :label="0">未激活</el-radio>
              <el-radio :label="1">已激活</el-radio>
            </el-radio-group>
          </el-form-item>
        </el-form>
      </el-scrollbar>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="handleOperateUserDialog('close')">取消</el-button>
          <el-button type="primary" @click="handleSetUserDialog">确定</el-button>
        </span>
      </template>
    </el-dialog>

    <!--  角色 dialog  -->
    <el-dialog title="设置角色" v-model="roleDialog.visible" width="700" draggable destroy-on-close>
      <el-scrollbar>
        <el-form :model="roleDialog">
          <el-form-item label="员工编号 : ">{{ roleDialog.userNo }}</el-form-item>
          <el-form-item label="员工姓名 : ">{{ roleDialog.userName }}</el-form-item>
          <el-form-item label="员工角色 : ">
            <el-transfer
              v-model="roleDialog.roles"
              class="inline-block"
              filterable
              :titles="['列表', '已选']"
              :data="roleOptions"
              :props="{ key: 'id', label: 'roleName' }"
              :left-default-checked="roleDialog.leftDefaultChecked"
              :right-default-checked="roleDialog.rightDefaultChecked"
            />
          </el-form-item>
        </el-form>
      </el-scrollbar>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="roleDialog.visible = false">取消</el-button>
          <el-button type="primary" :loading="roleDialog.btnLoading" @click="handleSetRoleDialog">确定</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<!-- 用户管理 -->
<script lang="ts" setup name="userManagement">
import { getUserTablePort, UserItem, updateUserStatusPort, getRolesTablePort, updateUserRolesPort } from '@/api/modules/setting';
import { RoleItem } from '@/api/interface';
import { useButtonAuth } from '@/hooks/useButtonAuth';

// 按钮权限
const { isDisabledRead, isDisabledWrite } = useButtonAuth({
  read: 'OPERATION_USER_MANAGEMENT_READ',
  write: 'OPERATION_USER_MANAGEMENT_WRITE',
  initFn: () => getTableData()
});

const searchForm = ref({ userNo: null, userName: null, userStatus: '' });

const handleSearch = () => {
  pagination.page = 1;
  getTableData();
};

const handleReset = () => {
  searchForm.value = { userNo: null, userName: null, userStatus: '' };
  handleSearch();
};

/**
 *  table 相关代码
 */
const tableData = ref<UserItem[]>([]);
const tableLoading = ref(false);
const pagination = reactive({
  page: 1,
  pageSize: 15,
  pageSizes: [15, 20, 30, 40, 50],
  itemCount: 0,
  onChange: (page: number) => {
    pagination.page = page;
    getTableData();
  },
  onPageSizeChange: (pageSize: number) => {
    pagination.page = 1;
    pagination.pageSize = pageSize;
    getTableData();
  }
});

const getTableData = async () => {
  try {
    tableLoading.value = true;
    let params = {
      ...searchForm.value,
      pageIndex: pagination.page,
      pageSize: pagination.pageSize
    };

    let { val: data, success } = await getUserTablePort(params);
    if (success === '0') {
      tableData.value = data.data;
      pagination.itemCount = data.total;
    }
  } catch (e) {
    console.log('e : ', e);
  } finally {
    tableLoading.value = false;
  }
};

/**
 *  user dialog 相关代码
 */
const userDialog = ref({
  userNo: '',
  userName: '',
  postName: '',
  userStatus: 0,
  btnLoading: false,
  visible: false
});
const handleOperateUserDialog = (type: string, row = {} as UserItem) => {
  let { userNo = '', name = '', postName = '', haveAppPermission = 0 } = row;
  userDialog.value.visible = type !== 'close';
  userDialog.value = {
    ...unref(userDialog),
    userNo,
    userName: name,
    postName,
    userStatus: haveAppPermission
  };
};
const handleSetUserDialog = async () => {
  let { userNo, userName, userStatus } = userDialog.value;
  let params = { userNo, userName, userStatus };
  try {
    userDialog.value.btnLoading = true;
    let res = await updateUserStatusPort(params);
    if (res.success === '0') {
      handleOperateUserDialog('close');
      await getTableData();
    }
  } catch (e) {
    console.log('e : ', e);
  } finally {
    userDialog.value.btnLoading = false;
  }
};

/**
 *  role dialog 相关代码
 */
const roleDialog = ref({
  userNo: '',
  userName: '',
  roles: [] as number[],
  btnLoading: false,
  visible: false,
  leftDefaultChecked: [] as (string | number)[],
  rightDefaultChecked: [] as (string | number)[]
});

const roleOptions = ref<RoleItem[]>([]);
// 获取角色列表
const getRoleList = async () => {
  let params = { roleName: '', pageIndex: 1, pageSize: 100 };
  try {
    let res = await getRolesTablePort(params);
    if (res.success === '0') {
      roleOptions.value = res.val.data;
    }
  } catch (e) {
    console.log('e : ', e);
  }
};

const handleOperateRoleDialog = (type: string, row = {} as UserItem) => {
  let { userNo = '', name = '', roleList = [] as RoleItem[] } = row;

  roleDialog.value.visible = type !== 'close';
  roleDialog.value = {
    ...unref(roleDialog),
    userNo,
    userName: name,
    roles: roleList.map(e => e.id),
    leftDefaultChecked: [],
    rightDefaultChecked: []
  };

  !roleOptions.value.length && getRoleList();
};

const handleSetRoleDialog = async () => {
  try {
    let { userNo, roles } = roleDialog.value;
    let params = {
      userNo,
      roleIdList: roles
    };
    roleDialog.value.btnLoading = true;
    let res = await updateUserRolesPort(params);
    if (res.success === '0') {
      handleOperateRoleDialog('close');
      await getTableData();
    }
  } catch (e) {
    console.log('e : ', e);
  } finally {
    roleDialog.value.btnLoading = false;
  }
};
</script>
