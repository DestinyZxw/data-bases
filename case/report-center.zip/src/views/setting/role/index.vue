<template>
  <div class="table-box">
    <div class="card table-search">
      <el-form ref="searchFormRef" :model="searchForm" label-width="70">
        <el-row :gutter="15">
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="角色名称">
              <el-input v-model="searchForm.roleName" placeholder="请输入" />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item>
              <el-space>
                <el-button :disabled="isDisabledRead" type="primary" @click="handleSearch">搜索</el-button>
                <el-button :disabled="isDisabledRead" type="warning" @click="handleReset">重置</el-button>
              </el-space>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <div class="card table-main">
      <div class="table-header">
        <el-button type="primary" :icon="CirclePlus" plain :disabled="isDisabledWrite" @click="handleOperateRoleDialog('add')">
          新增用户
        </el-button>
      </div>
      <el-table v-loading="tableLoading" :data="tableData" style="width: 100%" border>
        <el-table-column prop="roleName" label="角色" align="center" />
        <el-table-column label="操作" align="center">
          <template #default="{ row }">
            <el-space>
              <el-link type="primary" :disabled="isDisabledWrite" @click="handleOperateRoleDialog('edit', row)">
                设置用户
              </el-link>
              <el-link type="warning" :disabled="isDisabledWrite" @click="handleOperateAuthDialog('edit', row)">
                功能权限
              </el-link>
              <el-link type="danger" :disabled="isDisabledDel" @click="deleteRole(row)"> 删除 </el-link>
            </el-space>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        background
        layout="total, sizes, prev, pager, next, jumper"
        :current-page="pagination.page"
        :page-size="pagination.pageSize"
        :page-sizes="pagination.pageSizes"
        :total="pagination.itemCount"
        @current-change="pagination.onChange"
        @size-change="pagination.onPageSizeChange"
      />
    </div>

    <!--  角色 dialog  -->
    <el-dialog
      :title="roleDialog.title"
      v-model="roleDialog.visible"
      :width="roleDialog.title === '设置用户' ? 700 : 480"
      draggable
      destroy-on-close
      @close="handleOperateRoleDialog('close')"
    >
      <el-scrollbar>
        <el-form :model="roleDialog">
          <el-form-item label="角色 : ">
            <el-input v-model="roleDialog.roleName" :disabled="roleDialog.title === '设置用户'" placeholder="请输入" />
          </el-form-item>
          <el-form-item label="用户 : " v-if="roleDialog.title === '设置用户'">
            <el-transfer
              v-model="roleDialog.userNoList"
              class="inline-block"
              filterable
              :titles="['列表', '已选']"
              :data="userOptions"
            />
          </el-form-item>
        </el-form>
      </el-scrollbar>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="handleOperateRoleDialog('close')">取消</el-button>
          <el-button type="primary" :loading="roleDialog.btnLoading" @click="handleSetRoleDialog">确定</el-button>
        </span>
      </template>
    </el-dialog>

    <!--  功能权限设置 dialog  -->
    <el-dialog
      title="功能权限设置"
      class="auth-dialog"
      v-model="authDialog.visible"
      width="700"
      draggable
      @close="handleOperateRoleDialog('close')"
    >
      <el-scrollbar style="height: 600px">
        <div class="mb15 fz16 font-bold">角色：{{ authDialog.roleName }}</div>
        <el-checkbox-group v-model="selectedPermissions">
          <el-collapse v-model="authDialog.activeNames">
            <template v-for="(a, index) in authDialog.auths" :key="a.permissionId">
              <el-collapse-item :title="a.permissionName" :name="index">
                <template v-for="b in a.childPermission" :key="b.permissionId">
                  <!-- 三级页面 -->
                  <template v-if="b.childPermission.every(c => c.permissionType !== 4)">
                    <el-collapse class="el-collapse_children pl16" v-model="b.permissionId" accordion>
                      <el-collapse-item :title="b.permissionName" :name="b.permissionId">
                        <template v-for="c in b.childPermission" :key="c.permissionId">
                          <div class="flex items-center justify-between pl16">
                            <h2>{{ c.permissionName }}</h2>
                            <el-space>
                              <!-- 子级按钮权限 -->
                              <template v-for="d in c.childPermission" :key="d.permissionId">
                                <el-checkbox :value="d.permissionId">{{ d.permissionName }}</el-checkbox>
                              </template>
                            </el-space>
                          </div>
                        </template>
                      </el-collapse-item>
                    </el-collapse>
                  </template>
                  <!-- 二级页面 -->
                  <template v-else>
                    <div class="flex items-center justify-between pl16">
                      <h2>{{ b.permissionName }}</h2>
                      <el-space>
                        <!-- 子级按钮权限 -->
                        <template v-for="c in b.childPermission" :key="c.permissionId">
                          <el-checkbox :value="c.permissionId">{{ c.permissionName }}</el-checkbox>
                        </template>
                      </el-space>
                    </div>
                  </template>
                </template>
              </el-collapse-item>
            </template>
          </el-collapse>
        </el-checkbox-group>
        <!--<el-tree
          ref="treeRef"
          :data="authDialog.auths"
          :props="treeDefaultProps"
          node-key="permissionId"
          show-checkbox
          default-expand-all
        />-->
      </el-scrollbar>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="handleOperateAuthDialog('close')">取消</el-button>
          <el-button type="primary" :loading="authDialog.btnLoading" @click="handleSetAuthDialog">确定</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<!-- 用户管理 -->
<script lang="ts" setup name="roleManagement">
import {
  getRolesTablePort,
  getUserTablePort,
  getRoleUserListPort,
  addRoleInfoPort,
  updateRoleInfoPort,
  deleteRoleInfoPort,
  getRoleAuthListPort,
  PermissionsItemType,
  getTotalAuthListPort,
  updateRoleUserListPort
} from '@/api/modules/setting';
import { CirclePlus } from '@element-plus/icons-vue';
import { RoleItem } from '@/api/interface';
import { ElMessage, ElMessageBox } from 'element-plus';
import { useTabsStore } from '@/stores/modules/tabs';
import { filterPermissionsKey } from '@/utils';
import { useButtonAuth } from '@/hooks/useButtonAuth';
import { initDynamicRouter } from '@/routers/dynamicRouter';
// import { ElTree } from 'element-plus';

const tabsStore = useTabsStore();

// 按钮权限
const { isDisabledRead, isDisabledWrite, isDisabledDel } = useButtonAuth({
  read: 'OPERATION_ROLE_MANAGEMENT_READ',
  write: 'OPERATION_ROLE_MANAGEMENT_WRITE',
  deletes: 'OPERATION_ROLE_MANAGEMENT_DELETE',
  initFn: () => getTableData()
});

onMounted(() => {
  getUserOptionsList();
  getTotalAuthList();
});

// const authStore = useAuthStore();

const searchForm = ref({ roleName: '' });
const handleSearch = () => {
  pagination.page = 1;
  getTableData();
};

const handleReset = () => {
  searchForm.value = { roleName: '' };
  handleSearch();
};

/**
 * table 相关代码
 */
const tableData = ref<RoleItem[]>([]);
const tableLoading = ref(false);
const pagination = reactive({
  page: 1,
  pageSize: 15,
  pageSizes: [15, 20, 30, 40, 50],
  itemCount: 0,
  onChange: (page: number) => {
    pagination.page = page;
    getTableData();
  },
  onPageSizeChange: (pageSize: number) => {
    pagination.page = 1;
    pagination.pageSize = pageSize;
    getTableData();
  }
});
const getTableData = async () => {
  try {
    tableLoading.value = true;
    let params = {
      ...searchForm.value,
      pageIndex: pagination.page,
      pageSize: pagination.pageSize
    };

    let res = await getRolesTablePort(params);
    if (res.success === '0') {
      tableData.value = res.val.data;
      pagination.itemCount = res.val.total;
    }
  } catch (e) {
    console.log('e : ', e);
  } finally {
    tableLoading.value = false;
  }
};

/**
 * 新增 or 编辑角色 相关代码
 */
type RoleDialogType = {
  roleId: number | null;
  title: string;
  roleName: string;
  userNoList: string[];
  btnLoading: boolean;
  visible: boolean;
};

const roleDialog = ref<RoleDialogType>({
  roleId: null,
  title: '',
  roleName: '',
  userNoList: [],
  btnLoading: false,
  visible: false
});

const userOptions = ref<{ label: string; key: string }[]>([]);

const handleOperateRoleDialog = (type: string, row = {} as RoleItem) => {
  roleDialog.value.visible = type !== 'close';
  let { id = 0, roleName = '' } = row;
  if (type === 'add') {
    roleDialog.value.title = '新增用户';
  } else if (type === 'edit') {
    roleDialog.value.title = '设置用户';
    roleDialog.value.roleId = id;
    roleDialog.value.roleName = roleName;
    getSelectedUserList(id);
  } else if (type === 'close') {
    roleDialog.value.roleId = null;
    roleDialog.value.roleName = '';
    roleDialog.value.userNoList = [];
  }
};

const getSelectedUserList = async (roleId: number) => {
  try {
    let res = await getRoleUserListPort({ roleId });
    if (res.success === '0') {
      roleDialog.value.userNoList = res.val.map(e => e.userNo);
    }
  } catch (e) {
    console.log('e : ', e);
  }
};

const getUserOptionsList = async () => {
  try {
    let params = {
      pageIndex: 1,
      pageSize: 2000
    };
    let res = await getUserTablePort(params);
    if (res.success === '0') {
      let tmp = [];
      let data = res.val.data;
      for (let item of data) {
        tmp.push({ label: `${item.userNo}/${item.name}`, key: item.userNo });
      }
      userOptions.value = tmp;
    }
  } catch (e) {
    console.log('e : ', e);
  }
};

const handleSetRoleDialog = async () => {
  try {
    roleDialog.value.btnLoading = true;
    let { roleName, roleId, userNoList, title } = unref(roleDialog);
    if (!roleDialog.value.roleName) {
      return ElMessage.error('请填写角色名称');
    }
    let params = title === '新增用户' ? { roleName, roleCode: roleName } : { roleId, userNoList };
    let port = title === '新增用户' ? addRoleInfoPort : updateRoleUserListPort;
    let res = await port(params);
    if (res.success === '0') {
      handleOperateRoleDialog('close');
      await getTableData();
    } else {
      ElMessage.error(res.msg);
    }
  } catch (e) {
    console.log('e : ', e);
  } finally {
    roleDialog.value.btnLoading = false;
  }
};

const deleteRole = ({ id, userCount }: RoleItem) => {
  if (userCount && userCount > 0) {
    return ElMessage.error('角色已被使用，无法删除');
  }
  ElMessageBox({
    title: '提示',
    message: '确定删除此角色？',
    showCancelButton: true,
    confirmButtonText: '确认',
    cancelButtonText: '取消',
    beforeClose: async (action, instance, done) => {
      if (action === 'confirm') {
        try {
          instance.confirmButtonLoading = true;
          instance.confirmButtonText = '执行中...';
          let res = await deleteRoleInfoPort({ roleId: id });
          if (res.success === '0') {
            if (pagination.page > 1 && tableData.value.length === 1) {
              pagination.page--;
            }
            done();
            await getTableData();
          }
        } catch (e) {
          console.log('e : ', e);
        } finally {
          instance.confirmButtonLoading = false;
        }
      } else {
        done();
      }
    }
  });
};

/**
 *  设置权限 相关代码
 */
/*const treeDefaultProps = {
  children: 'childPermission',
  label: 'permissionName'
};*/

// const treeRef = ref<InstanceType<typeof ElTree> | null>(null);

const authDialog = ref<{
  roleId: number | null;
  roleName: string;
  auths: PermissionsItemType[];
  activeNames: number[];
  btnLoading: boolean;
  visible: boolean;
}>({
  roleId: null,
  roleName: '',
  auths: [],
  btnLoading: false,
  visible: false,
  activeNames: []
});

const selectedPermissions = ref<number[]>([]);
const handleOperateAuthDialog = (type: string, row = {} as RoleItem) => {
  authDialog.value.visible = type !== 'close';
  let { id, roleName = '' } = row;
  if (type === 'edit') {
    authDialog.value.roleId = id;
    authDialog.value.roleName = roleName;
    getRoleAuthList(id);
  } else if (type === '') {
    authDialog.value = {
      ...unref(authDialog),
      roleId: null,
      roleName: '',
      activeNames: []
    };
  }
};
// 获取角色下的权限列表
const getRoleAuthList = async (roleId: number) => {
  try {
    let { val: data, success } = await getRoleAuthListPort({ roleId });
    if (success === '0') {
      if (data.permissionId && data.childPermission) {
        selectedPermissions.value = filterPermissionsKey<PermissionsItemType, 'childPermission', 'permissionId'>({
          target: data,
          children: 'childPermission',
          key: 'permissionId'
        });
      } else {
        selectedPermissions.value = [];
      }

      // 设置tree组件 默认节点
      // treeRef.value!.setCheckedKeys(selectedPermissions.value, true);
    }
  } catch (e) {
    console.log('e : ', e);
  }
};

const getTotalAuthList = async () => {
  try {
    let res = await getTotalAuthListPort();
    if (res.success === '0') {
      authDialog.value.auths = res.val.childPermission;
      authDialog.value.activeNames = res.val.childPermission.map((_, i) => i);
    }
  } catch (e) {
    console.log('e : ', e);
  }
};

const handleSetAuthDialog = async () => {
  // let permissionIdList = treeRef.value!.getCheckedKeys(true); // 获取已选择的 tree key
  try {
    authDialog.value.btnLoading = true;
    let { roleId, roleName } = unref(authDialog);
    let params = {
      permissionIdList: unref(selectedPermissions),
      // permissionIdList,
      roleId,
      roleName
    };
    let res = await updateRoleInfoPort(params);
    if (res.success === '0') {
      handleOperateAuthDialog('close');
      await getTableData();
      // authStore.getPermissionList();
      await initDynamicRouter();
      tabsStore.resetTabs();
    }
  } catch (e) {
    console.log('e : ', e);
  } finally {
    authDialog.value.btnLoading = false;
  }
};
</script>

<style lang="scss" scoped>
/* reset el-collapse */
:deep(.el-collapse-item__header) {
  font-size: var(--el-font-size-base);
  font-weight: bold;
  color: var(--el-text-color-primary);
}
.el-collapse_children {
  border-top: none !important;
  border-bottom: none !important;

  --el-collapse-header-height: 32px;
  :deep(.el-collapse-item__header) {
    border-bottom: none;
  }
  :deep(.el-collapse-item__wrap) {
    border-bottom: none;
    .el-collapse-item__content {
      padding-bottom: 0;
    }
  }
}

/* reset el-dialog */
:deep(.el-dialog) {
  &.auth-dialog {
    .el-dialog__body {
      padding-top: 10px;
      padding-right: 5px;
      padding-bottom: 10px;
    }
    .el-scrollbar {
      padding-right: 15px;
    }
  }
}
</style>
