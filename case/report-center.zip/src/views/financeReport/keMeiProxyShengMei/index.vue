<!-- 生美收款分类汇总表 -->
<script lang="ts" setup name="financeReportKeMeiIncome">
// import { keMeiShopsPort, type KeMeiShopItemType } from '@/api/modules/base';
import { Download } from '@element-plus/icons-vue';
import { getKeMeiProxyShengMeiTableIPort, exportKeMeiProxyShengMeiTableIPort, ProxyItemType } from '@/api/modules/financeReport';
import { useButtonAuth } from '@/hooks/useButtonAuth';
import type { KeMeiSearchFormType, KeMeiSearchParamsType } from '@/views/financeReport/interfaces';
import { useTable } from '@/hooks/useTable';
import dayjs from 'dayjs';

// 按钮权限
const { isDisabledRead, isDisabledExport } = useButtonAuth({
  read: 'OPERATION_KM_PAYMENT_SUMMARY_READ',
  exports: 'OPERATION_KM_PAYMENT_SUMMARY_EXPORT',
  initFn: () => getTableData()
});

/*onMounted(() => {
  getKeMeiShops();
});*/

/**
 * 门店相关逻辑
 */
// 门店 props
/*const shopProps = {
  label: 'name',
  value: 'id'
};

// 科美门店列表
const shopOptions = ref<KeMeiShopItemType[]>([]);
const getKeMeiShops = async () => {
  try {
    let { val: data, success } = await keMeiShopsPort();
    if (success === '0') {
      shopOptions.value = data;
    }
  } catch (e) {
    console.log('e : ', e);
  }
};*/

/**
 * 搜索表单相关逻辑
 */
const startDate = dayjs().format('YYYY-MM-01');
const endDate = dayjs().format('YYYY-MM-DD');
const initFormData = (): KeMeiSearchFormType => ({
  memberCode: '',
  range: [startDate, endDate],
  shopIdList: []
});

// 搜索表单
const searchForm = ref<KeMeiSearchFormType>(initFormData());
const disabledDate = (time: Date) => {
  const current = Date.now();
  const selected = new Date(time).getTime();
  return selected > current;
};

// 搜索表单转译后参数
const searchParams = computed<KeMeiSearchParamsType>(() => {
  let { shopIdList = [], memberCode, range } = toValue(searchForm);
  let startDate = '',
    endDate = '';
  // 购卡日期
  if (range && (range as string[]).length) {
    [startDate, endDate] = range as string[];
  }
  return { memberCode, shopIdList, startDate, endDate };
});

/**
 * 数据表格相关逻辑
 */
const table = useTable<ProxyItemType, KeMeiSearchParamsType>({
  port: getKeMeiProxyShengMeiTableIPort,
  searchForm: searchParams,
  exportPort: exportKeMeiProxyShengMeiTableIPort,
  exportExcelName: '医美代收生美收款方式表'
});

const { tableData, tableLoading, handleExport, handleSearch, getTableData } = table;

const handleReset = () => {
  searchForm.value = initFormData();
  table.handleReset();
};
</script>
<template>
  <div class="table-box">
    <div class="card table-search">
      <el-form ref="searchFormRef" :model="searchForm" label-width="70">
        <el-row :gutter="10">
          <!--<el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="门店">
              <el-select-v2
                v-model="searchForm.shopIdList"
                :options="shopOptions"
                :props="shopProps"
                placeholder="请选择"
                clearable
                filterable
                multiple
                collapse-tags
                collapse-tags-tooltip
              />
            </el-form-item>
          </el-col>-->
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="日期">
              <el-date-picker
                v-model="searchForm.range"
                type="daterange"
                start-placeholder="起始日期"
                end-placeholder="结束日期"
                unlink-panels
                format="YYYY-MM-DD"
                value-format="YYYY-MM-DD"
                :disabled-date="disabledDate"
                @change="handleSearch"
              />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item>
              <el-space>
                <el-button type="primary" @click="handleSearch" :disabled="isDisabledRead">搜索</el-button>
                <el-button type="success" @click="handleReset" :disabled="isDisabledRead">重置</el-button>
                <el-button type="primary" :icon="Download" plain @click="handleExport" :disabled="isDisabledExport">
                  导出
                </el-button>
              </el-space>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <div class="card table-main">
      <el-table v-loading="tableLoading" :data="tableData" class="wp-100" border show-summary>
        <el-table-column prop="receiver" label="门店主体" align="center" min-width="100" />
        <el-table-column prop="zfbpos" label="支付宝POS机" align="center" min-width="120" />
        <el-table-column prop="wxpos" label="微信POS机" align="center" min-width="120" />
        <el-table-column prop="creditCard" label="银行卡" align="center" min-width="120" />
        <el-table-column prop="cash" label="现金" align="center" min-width="120" />
        <el-table-column prop="totalAmount" label="合计" align="center" min-width="120" />
      </el-table>
    </div>
  </div>
</template>
