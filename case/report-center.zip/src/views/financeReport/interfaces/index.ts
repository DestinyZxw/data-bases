/*双美卡生美销售表*/
import { CascaderNodePathValue, ModelValueType } from 'element-plus';

export interface ShengMeiSearchFormType {
  shopList: CascaderNodePathValue[];
  range: ModelValueType;
}
export interface ShengMeiSearchParamsType {
  shopIdList: number[];
  startDate: string;
  endDate: string;
}

// 科美销售双美卡明细表搜索表单类型.
export interface KeMeiSearchFormType {
  memberCode: string;
  shopIdList: string[];
  range: ModelValueType;
}
export type KeMeiSearchParamsType = Omit<KeMeiSearchFormType, 'range'> & {
  startDate: string;
  endDate: string;
};
