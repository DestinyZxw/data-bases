<template>
  <RubPage>
    <template #header>
      <div class="card pb0">
        <RubSearchForm
          read-auth-code="MENU_MEMBER_CONSUMER_PERFERENCES_MONITOR_READ"
          :is-months="false"
          @init="handleSearch"
          @search="handleSearch"
          @reset="handleReset"
        />
      </div>
    </template>

    <el-card shadow="hover" class="mt14 pr" :body-style="{ paddingTop: '10px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz20">
            一、会员消费偏好
            <el-tooltip class="box-item" effect="dark" placement="top">
              <template #content>
                <div style="max-width: 360px">{{ getQuestionMapItem(144) }}</div>
              </template>
              <el-icon class="pointer" size="20" color="#333">
                <Warning />
              </el-icon>
            </el-tooltip>
          </div>
        </div>
      </template>
      <el-tabs v-model="nursePreferenceTabName">
        <el-tab-pane v-loading="nurseLoading" label="独立护理" name="A">
          <div class="selector">
            <div class="name">会员层级</div>
            <RubSelector
              v-model="independentTierValue"
              :options="tierOptions"
              auth-code="MENU_MEMBER_CONSUMER_PERFERENCES_MONITOR_READ"
            />
          </div>
          <div class="selector mb20">
            <div class="name">vip等级</div>
            <RubSelector
              v-model="independentVipValue"
              :options="vipOptions"
              auth-code="MENU_MEMBER_CONSUMER_PERFERENCES_MONITOR_READ"
            />
          </div>
          <RubEmptyTip :show="independentTreeMapStatus">
            <el-scrollbar>
              <RubTreeMapChart v-bind="independentTreeMapChartData" class="chart" />
            </el-scrollbar>
          </RubEmptyTip>
        </el-tab-pane>
        <el-tab-pane v-loading="nurseLoading" label="叠加护理" name="D">
          <div class="selector">
            <div class="name">会员层级</div>
            <RubSelector
              v-model="overlayTierValue"
              :options="tierOptions"
              auth-code="MENU_MEMBER_CONSUMER_PERFERENCES_MONITOR_READ"
            />
          </div>
          <div class="selector mb20">
            <div class="name">vip等级</div>
            <RubSelector
              v-model="overlayVipValue"
              :options="vipOptions"
              auth-code="MENU_MEMBER_CONSUMER_PERFERENCES_MONITOR_READ"
            />
          </div>
          <RubEmptyTip :show="overlayTreeMapStatus">
            <el-scrollbar>
              <RubTreeMapChart v-bind="overlayTreeMapChartData" class="chart" />
            </el-scrollbar>
          </RubEmptyTip>
        </el-tab-pane>
      </el-tabs>
    </el-card>

    <el-row :gutter="10">
      <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12" class="mb14">
        <el-card shadow="hover" class="mt14 pr">
          <template #header>
            <div class="flex items-center justify-between h-30">
              <div class="font-bold">
                独立护理会员属性渗透
                <el-tooltip class="box-item" effect="dark" placement="top">
                  <template #content>
                    <div style="max-width: 360px">{{ getQuestionMapItem(145) }}</div>
                  </template>
                  <el-icon class="pointer" size="20" color="#333">
                    <Warning />
                  </el-icon>
                </el-tooltip>
              </div>
              <el-button type="primary" plain size="small" @click="exportIndependentMemberAttributes">
                导出<el-icon class="el-icon--right"><Download /></el-icon>
              </el-button>
            </div>
          </template>
          <RubEmptyTip :show="IndependentMemberAttributeTableStatus" style="min-height: 480px">
            <el-table :data="IndependentMemberAttributeTableData" class="wp-100" border style="height: 480px">
              <el-table-column
                v-for="(value, key, index) in IndependentMemberAttributeTableData[0] ?? {}"
                align="center"
                min-width="120"
                :prop="key as string"
                :label="key as string"
                :key="index"
                v-bind="isMobile ? {} : { fixed: index === 0 }"
              >
                <template #default="{ row }">
                  {{ Number(row[key]) || Number(row[key]) === 0 ? Number(row[key]) + '%' : row[key] ?? '/' }}
                </template>
              </el-table-column>
            </el-table>
          </RubEmptyTip>
        </el-card>
      </el-col>
      <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12" class="mb14">
        <el-card shadow="hover" class="mt14 pr">
          <template #header>
            <div class="flex items-center justify-between h-30">
              <div class="font-bold">独立护理&搭配销量</div>
            </div>
          </template>
          <RubEmptyTip :show="memberTypePerformanceChartStatus">
            <el-scrollbar>
              <RubDoubleYAxisChart v-bind="memberTypePerformanceChartData" class="chart" style="height: 480px" />
            </el-scrollbar>
          </RubEmptyTip>
        </el-card>
      </el-col>
    </el-row>

    <el-card>
      <el-tabs v-model="productsTabsName">
        <el-tab-pane v-loading="productLoading" name="first">
          <template #label>
            <span class="custom-tabs-label">
              <span>产品品类偏好</span>
              <el-tooltip class="box-item" effect="dark" placement="top">
                <template #content>
                  <div style="max-width: 360px">{{ getQuestionMapItem(148) }}</div>
                </template>
                <el-icon class="pointer" size="20" color="#333">
                  <Warning />
                </el-icon>
              </el-tooltip>
            </span>
          </template>
          <div class="selector">
            <div class="name">会员层级</div>
            <RubSelector
              v-model="categoryTierValue"
              :options="tierOptions"
              auth-code="MENU_MEMBER_CONSUMER_PERFERENCES_MONITOR_READ"
            />
          </div>
          <div class="selector mb20">
            <div class="name">vip等级</div>
            <RubSelector
              v-model="categoryVipValue"
              :options="vipOptions"
              auth-code="MENU_MEMBER_CONSUMER_PERFERENCES_MONITOR_READ"
            />
          </div>
          <RubEmptyTip :show="categoryPreferencePieStatus">
            <el-scrollbar>
              <RubPieChart v-bind="categoryPreferencePieChartData" class="pieChart" style="height: 600px" />
            </el-scrollbar>
          </RubEmptyTip>
        </el-tab-pane>
        <el-tab-pane v-loading="productLoading" name="second">
          <template #label>
            <span class="custom-tabs-label">
              <span>产品偏好</span>
              <el-tooltip class="box-item" effect="dark" placement="top">
                <template #content>
                  <div style="max-width: 360px">{{ getQuestionMapItem(150) }}</div>
                </template>
                <el-icon class="pointer" size="20" color="#333">
                  <Warning />
                </el-icon>
              </el-tooltip>
            </span>
          </template>
          <div class="selector mb20">
            <div class="name">品类</div>
            <RubSelector
              v-model="productNameValue"
              :options="productsOptions"
              auth-code="MENU_MEMBER_CONSUMER_PERFERENCES_MONITOR_READ"
            />
          </div>
          <RubEmptyTip :show="productTreeMapStatus">
            <el-scrollbar>
              <RubTreeMapChart v-bind="productTreeMapChartData" class="chart" />
            </el-scrollbar>
          </RubEmptyTip>
        </el-tab-pane>
      </el-tabs>
    </el-card>

    <el-row :gutter="10">
      <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12" class="mb10">
        <el-card shadow="hover" class="mt14">
          <template #header>
            <div class="flex items-center justify-between h-30">
              <div class="font-bold">
                产品品类会员属性渗透
                <el-tooltip class="box-item" effect="dark" placement="top">
                  <template #content>
                    <div style="max-width: 360px">{{ getQuestionMapItem(149) }}</div>
                  </template>
                  <el-icon class="pointer" size="20" color="#333">
                    <Warning />
                  </el-icon>
                </el-tooltip>
              </div>
              <el-button type="primary" plain size="small" @click="exportProductCategoryAttributes">
                导出<el-icon class="el-icon--right"><Download /></el-icon>
              </el-button>
            </div>
          </template>
          <RubEmptyTip :show="productCategoryAttributeTableStatus" style="min-height: 480px">
            <el-table :data="productCategoryAttributeTableData" class="wp-100" border style="height: 480px">
              <el-table-column
                v-for="(value, key, index) in productCategoryAttributeTableData[0] ?? {}"
                align="center"
                min-width="120"
                :prop="key as string"
                :label="key as string"
                :key="index"
                v-bind="isMobile ? {} : { fixed: index === 0 }"
              >
                <template #default="{ row }">
                  {{ Number(row[key]) || Number(row[key]) === 0 ? Number(row[key]) + '%' : row[key] ?? '/' }}
                </template>
              </el-table-column>
            </el-table>
          </RubEmptyTip>
        </el-card>
      </el-col>
      <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12" class="mb10">
        <el-card shadow="hover" class="mt14">
          <template #header>
            <div class="flex items-center justify-between h-30">
              <div class="font-bold">产品年龄分析</div>
            </div>
          </template>
          <RubEmptyTip :show="productAgePieChartStatus">
            <RubPieChart v-bind="productAgePieChartData" class="chart" style="height: 480px" />
          </RubEmptyTip>
        </el-card>
      </el-col>
    </el-row>
  </RubPage>
</template>

<!-- 会员消费偏好分析 页面 -->
<script setup lang="ts" name="memberPreferenceAnalysis">
import {
  getMemberConsumeNursingServicePreferencesPort,
  AttributePenetrationItemType,
  getMemberConsumeProductPreferencesPort,
  exportProductCategoryAttributeTablePort,
  exportIndependentMemberAttributePort
} from '@/api/modules/memberAnalysis';
import { SearchParamsType } from '@/components/rub-search-form/interfaces';
import { default as RubSelector, ModelValueType, SelectorOptionItemType } from '@/components/rub-selector/index.vue';
import type { Chart } from '@/typings/global';
import { useGlobalStore } from '@/stores/modules/global';
import { getQuestionMapItem } from '@/utils';
import { ElMessageBox } from 'element-plus';
import { useDownload } from '@/hooks/useDownload';

const globalStore = useGlobalStore();
const isMobile = computed(() => globalStore.device === 'mobile');

type OtherType = {
  levelId?: string[];
  memberClassify?: string[];
  productTypes?: string[];
  workHourProperty?: string; // A - 独立偏好，D - 叠加偏好
};

// 护理偏好 A - 独立偏好，D - 叠加偏好
const nursePreferenceTabName = ref('A');
const productsTabsName = ref('first');

// 分层 options
const tierOptions: SelectorOptionItemType[] = [
  { name: '沉默', value: '沉默会员' },
  { name: '发展', value: '发展会员' },
  { name: '价值', value: '价值会员' },
  { name: '流失', value: '流失会员' },
  { name: '睡眠', value: '睡眠会员' },
  { name: '新会员', value: '新会员' },
  { name: '一般', value: '一般会员' }
];

// vip等级 options
const vipOptions: SelectorOptionItemType[] = [
  { name: 'VIP1', value: '1' },
  { name: 'VIP2', value: '2' },
  { name: 'VIP3', value: '3' },
  { name: 'VIP4', value: '4' },
  { name: 'VIP5', value: '5' },
  { name: 'VIP6', value: '6' },
  { name: 'VIP7', value: '7' },
  { name: 'VIP8', value: '8' },
  { name: 'VIP9', value: '9' }
];

// 产品类名 options
const productsOptions: SelectorOptionItemType[] = [
  { name: '安瓶精华', value: '安瓶精华' },
  { name: '精华', value: '精华' },
  { name: '面膜类', value: '面膜类' },
  { name: '面霜', value: '面霜' },
  { name: '其他', value: '其他' },
  { name: '清洁', value: '清洁' },
  { name: '乳液', value: '乳液' },
  { name: '身体乳', value: '身体乳' },
  { name: '身体霜', value: '身体霜' },
  { name: '爽肤', value: '爽肤' },
  { name: '卸妆', value: '卸妆' },
  { name: '眼膜', value: '眼膜' },
  { name: '眼霜', value: '眼霜' }
];

const independentTierValue = ref<ModelValueType>(['沉默会员']);
const independentVipValue = ref<ModelValueType>(['1']);

const overlayTierValue = ref<ModelValueType>(['沉默会员']);
const overlayVipValue = ref<ModelValueType>(['1']);

let cacheSearchData: SearchParamsType = {} as SearchParamsType;
const handleSearch = (data: SearchParamsType) => {
  cacheSearchData = data;
  // 独立护理偏好
  getMemberConsumeNursingServicePreferencesData(data, {
    levelId: independentVipValue.value as string[],
    memberClassify: independentTierValue.value as string[],
    workHourProperty: 'A'
  });
  // 叠加护理偏好
  getMemberConsumeNursingServicePreferencesData(data, {
    levelId: overlayVipValue.value as string[],
    memberClassify: overlayTierValue.value as string[],
    workHourProperty: 'D'
  });
  // 产品偏好数据
  getMemberConsumeProductPreferencesData(data, {
    levelId: categoryVipValue.value as string[],
    memberClassify: categoryTierValue.value as string[],
    productTypes: productNameValue.value as string[]
  });
};

const handleReset = (data: SearchParamsType) => {
  handleSearch(data);
};

/** 护理偏好相关代码 */
const independentTreeMapStatus = ref<boolean>(false); // 状态加载状态
// 独立护理偏好数据
const independentTreeMapChartData = ref<Chart.TreeMapChartType>({ data: [] });

// 叠加护理偏好数据
const overlayTreeMapStatus = ref<boolean>(false);
const overlayTreeMapChartData = ref<Chart.TreeMapChartType>({});

// 独立护理会员属性渗透
const IndependentMemberAttributeTableStatus = ref(false);
const IndependentMemberAttributeTableData = ref<AttributePenetrationItemType[]>([]);

// 会员类型业绩贡献数据
const memberTypePerformanceChartStatus = ref(false);
const memberTypePerformanceChartData = ref<Chart.DoubleYAxisChartType>({});

watch([independentVipValue, independentTierValue, overlayTierValue, overlayVipValue], () => {
  const isIndependent = nursePreferenceTabName.value === 'A';
  const levelId = isIndependent ? independentVipValue.value : overlayVipValue.value;
  const memberClassify = isIndependent ? independentTierValue.value : overlayTierValue.value;
  getMemberConsumeNursingServicePreferencesData(cacheSearchData, {
    levelId: levelId as string[],
    memberClassify: memberClassify as string[],
    workHourProperty: nursePreferenceTabName.value
  });
});
const nurseLoading = ref(false);
const getMemberConsumeNursingServicePreferencesData = async (args: SearchParamsType, other: OtherType) => {
  try {
    nurseLoading.value = true;
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = { shopIdList, startMonth, endMonth, ...other };
    let { val: data, success } = await getMemberConsumeNursingServicePreferencesPort(params);
    if (success === '0') {
      let dataSet = data.nursingServicePreferences.map(item => ({
        name: item.nursingServiceName,
        value: item.orderCount
      }));
      if (other?.workHourProperty === 'A') {
        // 独立护理偏好
        independentTreeMapStatus.value = dataSet.length > 0;
        independentTreeMapChartData.value = { title: '独立护理偏好', data: dataSet };
      } else {
        // 叠加护理偏好
        overlayTreeMapStatus.value = dataSet.length > 0;
        overlayTreeMapChartData.value = { title: '叠加护理偏好', data: dataSet };
      }

      // 独立护理会员属性渗透
      IndependentMemberAttributeTableStatus.value = !!data.attributePenetration.length;
      IndependentMemberAttributeTableData.value = data.attributePenetration;

      // 叠加搭配销量数据
      memberTypePerformanceChartStatus.value = !!data.nursingServiceSalesVolume.length;
      if (!data.nursingServiceSalesVolume.length) return;
      let axis: string[] = [],
        data1: number[] = [],
        data2: number[] = [];
      for (let item of data.nursingServiceSalesVolume) {
        axis.push(item.nursingServiceName);
        data1.push(item.salesVolume);
        data2.push(item.salesVolumeRatio);
      }
      memberTypePerformanceChartData.value = {
        title: '叠加搭配销量',
        xAxisLabelRotate: 45,
        grid: { bottom: '18%' },
        yAxisRightUnit: '%',
        yAxisLeftVisible: false,
        yAxisRightVisible: false,
        yAxisNameVisible: false,
        axis,
        series: [
          {
            type: 'bar',
            name: '销量',
            data: data1,
            label: { show: true, position: 'insideBottom' },
            barMaxWidth: 40
          },
          {
            type: 'line',
            name: '占比(%)',
            data: data2,
            smooth: true,
            label: { show: true, formatter: '{c}%' },
            yAxisIndex: 1
          }
        ],
        colors: ['#4472C4', '#ED7B2E']
      };
    }
  } catch {
  } finally {
    nurseLoading.value = false;
  }
};

// 导出独立护理会员属性渗透
const exportIndependentMemberAttributes = () => {
  const isIndependent = nursePreferenceTabName.value === 'A';
  const { shopIdList, startMonth, endMonth } = toValue(cacheSearchData);
  const params = {
    shopIdList,
    startMonth,
    endMonth,
    levelId: isIndependent ? independentVipValue.value : overlayVipValue.value,
    memberClassify: isIndependent ? independentTierValue.value : overlayTierValue.value,
    workHourProperty: nursePreferenceTabName.value
  };
  ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
    useDownload({
      port: exportIndependentMemberAttributePort,
      fileName: '独立护理会员属性渗透表',
      params
    })
  );
};

/** 产品偏好相关代码 */
const categoryTierValue = ref<ModelValueType>(['沉默会员']);
const categoryVipValue = ref<ModelValueType>(['1']);

const productNameValue = ref<ModelValueType>(['安瓶精华']);

// 品类偏好 饼图数据
const categoryPreferencePieStatus = ref<boolean>(false);
const categoryPreferencePieChartData = ref<Chart.PieChartType>({});

// 产品偏好数据
const productTreeMapStatus = ref<boolean>(false);
const productTreeMapChartData = ref<Chart.TreeMapChartType>({});

// 产品品类属性渗透
const productCategoryAttributeTableStatus = ref<boolean>(false);
const productCategoryAttributeTableData = ref<AttributePenetrationItemType[]>([]);

// 产品年龄分析 饼图数据
const productAgePieChartStatus = ref(false);
const productAgePieChartData = ref<Chart.PieChartType>({});

watch([categoryTierValue, categoryVipValue, productNameValue], () => {
  getMemberConsumeProductPreferencesData(cacheSearchData, {
    levelId: categoryVipValue.value as string[],
    memberClassify: categoryTierValue.value as string[],
    productTypes: productNameValue.value as string[]
  });
});
const productLoading = ref(false);
const getMemberConsumeProductPreferencesData = async (args: SearchParamsType, other: OtherType) => {
  try {
    productLoading.value = true;
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = { shopIdList, startMonth, endMonth, ...other };
    let { val: data, success } = await getMemberConsumeProductPreferencesPort(params);
    if (success === '0') {
      let categories = data.productTypePreferences.map(item => ({
        name: item.productTypeName,
        value: item.countRatio
      }));
      categoryPreferencePieStatus.value = categories.length > 0;
      // 品类消费偏好 饼图数据
      categoryPreferencePieChartData.value = {
        name: '品类消费偏好',
        position: 'outside',
        data: categories,
        colors: ['#F4B183', '#E2F0D9', '#A9D18E', '#C00000', '#00B050', '#70AD47', '#FF0000', '#FF7C80']
      };

      // 产品偏好 图标数据
      let products = data.productPreferences.map(item => ({
        name: item.productName,
        value: item.subtotalCount
      }));
      productTreeMapStatus.value = !!products.length;
      if (products.length) {
        productTreeMapChartData.value = { title: '产品偏好', data: products };
      }

      // 产品品类属性渗透
      productCategoryAttributeTableStatus.value = !!data.productTypeAttributePenetration.length;
      productCategoryAttributeTableData.value = data.productTypeAttributePenetration;

      // 产品年龄分析 饼图数据
      productAgePieChartStatus.value = !!data.productByAgeRegion.length;
      if (!data.productByAgeRegion.length) return;
      let productAges = data.productByAgeRegion.map(item => ({
        name: item.ageRegion,
        value: item.ageRegionRatio
      }));
      productAgePieChartData.value = {
        position: 'outside',
        data: productAges,
        colors: ['#F4B183', '#E2F0D9', '#A9D18E', '#C00000', '#00B050', '#70AD47', '#FF0000']
      };
    }
  } catch {
  } finally {
    productLoading.value = false;
  }
};

const exportProductCategoryAttributes = () => {
  const { shopIdList, startMonth, endMonth } = toValue(cacheSearchData);
  const params = {
    shopIdList,
    startMonth,
    endMonth,
    levelId: categoryVipValue.value,
    memberClassify: categoryTierValue.value,
    productTypes: productNameValue.value
  };
  ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
    useDownload({
      port: exportProductCategoryAttributeTablePort,
      fileName: '产品品类会员属性渗透表',
      params
    })
  );
};
</script>
