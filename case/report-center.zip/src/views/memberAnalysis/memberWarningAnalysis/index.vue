<template>
  <RubPage>
    <template #header>
      <div class="card pb0">
        <RubSearchForm
          read-auth-code="MENU_MEMBER_ALERTS_ANALYSE_READ"
          :is-months="false"
          @init="handleSearch"
          @search="handleSearch"
          @reset="handleReset"
        />
      </div>
    </template>

    <!--  一、会员消费订单分析  -->
    <el-card shadow="hover" class="mt14 pr" :body-style="{ paddingBottom: '10px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz20">一、会员消费订单分析</div>
        </div>
      </template>
      <el-card class="mb10" v-loading="warningAnalyseLoading">
        <div class="selector mb20">
          <div class="name">
            消费项目
            <el-popover placement="top" :width="360" trigger="hover" effect="dark">
              <template #reference>
                <el-icon class="pointer" size="18" color="#333">
                  <Warning />
                </el-icon>
              </template>
              <div>
                <div style="margin-bottom: 10px" v-for="(item, index) in getQuestionMapObj([182])" :key="index">
                  <div class="font-bold">{{ item.name }}:</div>
                  <div>{{ item.description }}</div>
                </div>
              </div>
            </el-popover>
          </div>
          <RubSelector v-model="selectorValue" :options="selectorOptions" auth-code="MENU_MEMBER_ALERTS_ANALYSE_READ" />
        </div>
        <RubEmptyTip :show="mfMatrixStatus">
          <el-scrollbar>
            <ShopMatrixChart v-bind="mfMatrixChartData" />
          </el-scrollbar>
        </RubEmptyTip>
      </el-card>
    </el-card>

    <!--  二、免费权益分析  -->
    <el-card shadow="hover" class="mt14 pr" :body-style="{ paddingBottom: '10px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz20">
            二、免费权益分析
            <el-tooltip class="box-item" effect="dark" placement="top">
              <template #content>
                <div style="max-width: 360px">{{ getQuestionMapItem(183) }}</div>
              </template>
              <el-icon class="pointer" size="20" color="#333">
                <Warning />
              </el-icon>
            </el-tooltip>
          </div>
        </div>
      </template>
      <el-table v-loading="freeEquityLoading" :data="freeEquityAnalysisTableData" class="wp-100" border height="560">
        <el-table-column prop="rightsType" label="权益分类" align="center" min-width="120" />
        <el-table-column prop="rightsName" label="权益名称" align="center" min-width="120" />
        <el-table-column prop="cardType" label="卡类型" align="center" min-width="120" />
        <el-table-column prop="cardName" label="卡名称" align="center" min-width="120" />
        <el-table-column prop="freeCount" label="赠送次数" align="center" min-width="120" />
        <el-table-column prop="useCount" label="使用次数" align="center" min-width="120" />
        <el-table-column prop="remainingCount" label="剩余次数" align="center" min-width="120" />
        <el-table-column prop="usageRate" label="使用率" align="center" min-width="120">
          <template #default="{ row }">{{ handleFilterTableRow(row, 'usageRate') }}</template>
        </el-table-column>
      </el-table>
      <div class="flex justify-end mt15 mb10">
        <el-pagination
          background
          layout="total, sizes, prev, pager, next, jumper"
          :current-page="freeEquityPagination.page"
          :page-size="freeEquityPagination.pageSize"
          :page-sizes="freeEquityPagination.pageSizes"
          :total="freeEquityPagination.itemCount"
          @current-change="freeEquityPagination.onChange"
          @size-change="freeEquityPagination.onPageSizeChange"
        />
      </div>
    </el-card>

    <!--  三、余额预警  -->
    <el-card shadow="hover" class="mt14 pr" :body-style="{ paddingBottom: '10px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz20">三、余额预警</div>
          <el-button type="primary" plain size="small" @click="exportMemberBalanceWarningTableData">
            导出<el-icon class="el-icon--right"><Download /></el-icon>
          </el-button>
        </div>
      </template>
      <el-table v-loading="balanceAlarmLoading" :data="balanceAlarmAnalysisTableData" class="wp-100" border height="560">
        <el-table-column label="基础信息" align="center">
          <el-table-column prop="memberCode" label="卡号" align="center" min-width="120" />
          <el-table-column prop="memberName" label="姓名" align="center" min-width="120" />
          <!--<el-table-column prop="memberPhone" label="手机号" align="center" min-width="120" />-->
          <el-table-column prop="memberAge" label="年龄" align="center" min-width="120" />
          <el-table-column prop="shopName" label="会籍门店" align="center" min-width="120" />
          <el-table-column prop="joinYear" label="入会年限" align="center" min-width="120" />
          <el-table-column prop="memberLevel" label="VIP等级" align="center" min-width="120" />
          <el-table-column prop="memberClassify" label="会员类型" align="center" min-width="120" />
          <el-table-column prop="consultantName" label="专属顾问" align="center" min-width="120">
            <template #default="{ row }">{{ handleFilterTableRow(row, 'consultantName') ?? '/' }}</template>
          </el-table-column>
          <el-table-column prop="beauticianName" label="专属美容师" align="center" min-width="120">
            <template #default="{ row }">{{ handleFilterTableRow(row, 'beauticianName') ?? '/' }}</template>
          </el-table-column>
        </el-table-column>
        <el-table-column prop="lastBuyCardAmount" align="center" min-width="140">
          <template #header>
            <div>
              上次充值金额
              <el-tooltip class="box-item" effect="dark" placement="top">
                <template #content>
                  <div style="max-width: 360px">{{ getQuestionMapItem(184) }}</div>
                </template>
                <el-icon class="pointer" size="20" color="#333">
                  <Warning />
                </el-icon>
              </el-tooltip>
            </div>
          </template>
          <template #default="{ row }">{{ handleFilterTableRow(row, 'lastBuyCardAmount') }}</template>
        </el-table-column>
        <el-table-column prop="avgDateDiff" label="消费间隔" align="center" min-width="120" />
        <el-table-column prop="avgCount" label="月均消费频次" align="center" min-width="120">
          <template #default="{ row }">{{ handleFilterTableRow(row, 'avgCount') }}</template>
        </el-table-column>
        <el-table-column prop="mmPpt" label="客单" align="center" min-width="120">
          <template #default="{ row }">{{ handleFilterTableRow(row, 'mmPpt') }}</template>
        </el-table-column>
        <el-table-column prop="balanceAmount" label="卡内余额≤1000元" align="center" min-width="120">
          <template #default="{ row }">{{ handleFilterTableRow(row, 'balanceAmount') }}</template>
        </el-table-column>
      </el-table>
      <div class="flex justify-end mt15 mb10">
        <el-pagination
          background
          layout="total, sizes, prev, pager, next, jumper"
          :current-page="balanceAlarmPagination.page"
          :page-size="balanceAlarmPagination.pageSize"
          :page-sizes="balanceAlarmPagination.pageSizes"
          :total="balanceAlarmPagination.itemCount"
          @current-change="balanceAlarmPagination.onChange"
          @size-change="balanceAlarmPagination.onPageSizeChange"
        />
      </div>
    </el-card>
  </RubPage>
</template>

<!-- 会员预警分析 页面 -->
<script setup lang="ts" name="memberWarningAnalysis">
import {
  getMemberWarningAnalysePort,
  getMemberFreeRightsAnalysePort,
  MemberFreeRightsAnalyseItemType,
  MemberBalanceWarningItemType,
  getMemberBalanceWarningPort,
  exportMemberBalanceWarningPort,
  exportMemberWarningAnalyseChartDataPort
} from '@/api/modules/memberAnalysis';
import { SearchParamsType } from '@/components/rub-search-form/interfaces';
import { ModelValueType, SelectorOptionItemType } from '@/components/rub-selector/index.vue';
import ShopMatrixChart from '../components/shop-matrix-chart.vue';
import { handleFilterTableRow, getQuestionMapObj, getQuestionMapItem } from '@/utils';
import type { Chart } from '@/typings/global';
import type { PaginationType } from '@/hooks/useTable';
import { ElMessageBox } from 'element-plus';
import { useDownload } from '@/hooks/useDownload';

let cacheSearchData: SearchParamsType = {} as SearchParamsType;
const handleSearch = (data: SearchParamsType) => {
  cacheSearchData = data;
  getMemberWarningAnalyseData(data);
  getMemberFreeRightsAnalyseData(data);
  getMemberBalanceWarningData(data);
};
const handleReset = (data: SearchParamsType) => {
  handleSearch(data);
};

/**
 * 获取预警分析代码区域
 */
const selectorValue = ref<ModelValueType>(2);
// 层级 options
const selectorOptions: SelectorOptionItemType[] = [
  { name: '免费权益预警', value: 2 },
  { name: '入会未消费', value: 1 }
];
// 选择器进行监听
watch(selectorValue, () => {
  getMemberWarningAnalyseData(cacheSearchData);
});
const mfMatrixStatus = ref<boolean>(false);
const mfMatrixChartData = ref<Chart.FourQuadrantChartType<Chart.ShopMatrixItemType>>({});
const warningAnalyseLoading = ref(false);
const getMemberWarningAnalyseData = async (searchParams: SearchParamsType) => {
  if (warningAnalyseLoading.value) return;
  warningAnalyseLoading.value = true;
  try {
    let { shopIdList, startMonth, endMonth } = toValue(searchParams);
    let params = { shopIdList, startMonth, endMonth, warningAnalyseType: selectorValue.value };
    let { val: data, success } = await getMemberWarningAnalysePort(params);
    if (success === '0') {
      mfMatrixStatus.value = !!data.memberWarningAnalyse.length;
      if (!data.memberWarningAnalyse.length) return;

      const isFree = +selectorValue.value === 2;
      const title = isFree ? '免费权益预警会员管理跟踪' : '入会后未消费的会员管理跟踪';
      const xAxisTipsName = isFree ? '人均剩余次数' : '人均管理未消费人数';
      const yAxisTipsName = isFree ? '人均使用率' : '人均充值金额';
      const yAxisUnit = isFree ? '%' : '';
      const originalData = data.memberWarningAnalyse.map(item => ({
        xAxisValue: Number(item.x),
        yAxisValue: Number(item.y),
        name: item.shopName
      }));
      // 预警分析矩阵数据
      mfMatrixChartData.value = {
        title,
        xAxisTipsName,
        xAxisUnit: '',
        yAxisTipsName,
        yAxisUnit,
        originalData,
        grid: { top: '16%', bottom: originalData.length ? '5%' : '10%' },
        // 工具箱
        toolbox: {
          exportVisible: true,
          // 此处写导出逻辑
          exportPort: () => {
            ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
              useDownload({
                port: exportMemberWarningAnalyseChartDataPort,
                fileName: '会员消费订单分析',
                params
              })
            );
          }
        }
      };
    }
  } catch {
  } finally {
    warningAnalyseLoading.value = false;
  }
};

/**
 * 免费权益分析代码区域
 */
const freeEquityPagination: PaginationType = reactive({
  page: 1,
  pageSize: 15,
  pageSizes: [15, 20, 30, 40, 50],
  itemCount: 0,
  onChange: (page: number) => {
    freeEquityPagination.page = page;
    getMemberFreeRightsAnalyseData(cacheSearchData);
  },
  onPageSizeChange: (pageSize: number) => {
    freeEquityPagination.page = 1;
    freeEquityPagination.pageSize = pageSize;
    getMemberFreeRightsAnalyseData(cacheSearchData);
  }
});
const freeEquityLoading = ref(false);
const freeEquityAnalysisTableData = ref<MemberFreeRightsAnalyseItemType[]>([]);
const getMemberFreeRightsAnalyseData = async (searchParams: SearchParamsType) => {
  if (freeEquityLoading.value) return;
  freeEquityLoading.value = true;
  try {
    let { shopIdList, startMonth, endMonth } = toValue(searchParams);
    let { page, pageSize } = toRaw(freeEquityPagination);
    let params = { shopIdList, startMonth, endMonth, page, size: pageSize };
    let { val: data, success, pageInfo } = await getMemberFreeRightsAnalysePort(params);
    if (success === '0') {
      freeEquityAnalysisTableData.value = data;
      freeEquityPagination.itemCount = pageInfo?.count ?? 0;
    }
  } catch {
  } finally {
    freeEquityLoading.value = false;
  }
};

/**
 * 余额报警代码区域
 */
const balanceAlarmPagination: PaginationType = reactive({
  page: 1,
  pageSize: 15,
  pageSizes: [15, 20, 30, 40, 50],
  itemCount: 0,
  onChange: (page: number) => {
    balanceAlarmPagination.page = page;
    getMemberBalanceWarningData(cacheSearchData);
  },
  onPageSizeChange: (pageSize: number) => {
    balanceAlarmPagination.page = 1;
    balanceAlarmPagination.pageSize = pageSize;
    getMemberBalanceWarningData(cacheSearchData);
  }
});
const balanceAlarmLoading = ref(false);
const balanceAlarmAnalysisTableData = ref<MemberBalanceWarningItemType[]>([]);
const getMemberBalanceWarningData = async (searchParams: SearchParamsType) => {
  if (balanceAlarmLoading.value) return;
  balanceAlarmLoading.value = true;
  try {
    let { shopIdList, startMonth, endMonth } = toValue(searchParams);
    let { page, pageSize } = toRaw(balanceAlarmPagination);
    let params = { shopIdList, startMonth, endMonth, page, size: pageSize };
    let { val: data, success, pageInfo } = await getMemberBalanceWarningPort(params);
    if (success === '0') {
      balanceAlarmAnalysisTableData.value = data;
      balanceAlarmPagination.itemCount = pageInfo?.count ?? 0;
    }
  } catch {
  } finally {
    balanceAlarmLoading.value = false;
  }
};

// 导出预警分析table数据
const exportMemberBalanceWarningTableData = () => {
  const { shopIdList, startMonth, endMonth } = toValue(cacheSearchData);
  const params = { shopIdList, startMonth, endMonth };
  ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
    useDownload({
      port: exportMemberBalanceWarningPort,
      fileName: '会员余额预警分析表',
      params
    })
  );
};
</script>
