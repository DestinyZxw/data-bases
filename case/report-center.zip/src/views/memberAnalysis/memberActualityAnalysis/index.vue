<template>
  <RubPage>
    <template #header>
      <div class="card pb0">
        <RubSearchForm
          read-auth-code="MENU_MEMBER_STATUS_ANALYSE_READ"
          :is-months="false"
          @init="handleSearch"
          @search="handleSearch"
          @reset="handleReset"
        />
      </div>
    </template>

    <!--  一、会员概览  -->
    <el-card shadow="hover" class="mt14 pr">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz22">
            一、会员概览
            <el-popover placement="top" :width="360" trigger="hover" effect="dark">
              <template #reference>
                <el-icon class="pointer" size="18" color="#333">
                  <Warning />
                </el-icon>
              </template>
              <div>
                <div style="margin-bottom: 10px" v-for="(item, index) in getQuestionMapObj([73, 74, 75])" :key="index">
                  <div class="font-bold">{{ item.name }}:</div>
                  <div>{{ item.description }}</div>
                </div>
              </div>
            </el-popover>
          </div>
        </div>
      </template>
      <RubEmptyTip :show="memberChangeChartStatus">
        <el-row :gutter="10" class="selector mb20 pb0">
          <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12">
            <div class="tc pd10 radius6 mb10 pointer" style="background-color: #ffc000">
              新会员环比增长率 {{ memberTrend.newMemberRingRatio ?? 0 }}%
              <el-tooltip class="box-item" effect="dark" placement="top">
                <template #content>
                  <div style="max-width: 360px">{{ getQuestionMapItem(76) }}</div>
                </template>
                <el-icon class="pointer" size="20" color="#333">
                  <Warning />
                </el-icon>
              </el-tooltip>
            </div>
          </el-col>
          <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12">
            <div class="tc pd10 radius6 mb10 pointer" style="background-color: #5b9bd5">
              流失会员环比增长率 {{ memberTrend.churnMemberRingRatio ?? 0 }}%
              <el-tooltip class="box-item" effect="dark" placement="top">
                <template #content>
                  <div style="max-width: 360px">{{ getQuestionMapItem(77) }}</div>
                </template>
                <el-icon class="pointer" size="20" color="#333">
                  <Warning />
                </el-icon>
              </el-tooltip>
            </div>
          </el-col>
        </el-row>
        <el-scrollbar>
          <RubDoubleYAxisChart v-bind="memberChangeChartData" class="chart" style="height: 600px" />
        </el-scrollbar>
      </RubEmptyTip>
    </el-card>

    <!--  二、会员属性  -->
    <el-card shadow="hover" class="mt14 pr" :body-style="{ paddingBottom: '10px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz22">二、会员属性</div>
        </div>
      </template>
      <el-row :gutter="10">
        <!--  会员类型人数  -->
        <el-col :xs="24" :sm="24" :md="8" :lg="8" :xl="4" class="mb10">
          <el-card :body-style="{ padding: '20px 10px' }">
            <RubEmptyTip :show="memberTypeCountChartStatus">
              <RubDoubleYAxisChart v-bind="memberTypeCountChartData" style="height: 400px" />
            </RubEmptyTip>
          </el-card>
        </el-col>

        <!--  会员类型业绩贡献  -->
        <el-col :xs="24" :sm="24" :md="8" :lg="8" :xl="4" class="mb10">
          <el-card :body-style="{ padding: '20px 10px' }">
            <RubEmptyTip :show="memberTypePerformanceChartStatus">
              <RubDoubleYAxisChart v-bind="memberTypePerformanceChartData" style="height: 400px" />
            </RubEmptyTip>
          </el-card>
        </el-col>

        <!--  会员类型毛利贡献  -->
        <el-col :xs="24" :sm="24" :md="8" :lg="8" :xl="4" class="mb10">
          <el-card :body-style="{ padding: '20px 10px' }">
            <RubEmptyTip :show="memberTypeMaoriChartStatus">
              <RubDoubleYAxisChart v-bind="memberTypeMaoriChartData" style="height: 400px" />
            </RubEmptyTip>
          </el-card>
        </el-col>

        <!--  会员等级人数  -->
        <el-col :xs="24" :sm="24" :md="24" :lg="24" :xl="12" class="mb10">
          <el-card :body-style="{ padding: '20px 10px' }">
            <RubEmptyTip :show="memberLevelCountChartStatus">
              <RubDoubleYAxisChart v-bind="memberLevelCountChartData" style="height: 400px" />
            </RubEmptyTip>
          </el-card>
        </el-col>

        <!--  会员等级业绩贡献  -->
        <el-col :xs="24" :sm="24" :md="24" :lg="24" :xl="12" class="mb10">
          <el-card :body-style="{ padding: '20px 10px' }">
            <RubEmptyTip :show="memberLevelPerformanceChartStatus">
              <RubDoubleYAxisChart v-bind="memberLevelPerformanceChartData" style="height: 400px" />
            </RubEmptyTip>
          </el-card>
        </el-col>

        <!--  会员等级毛利贡献  -->
        <el-col :xs="24" :sm="24" :md="24" :lg="24" :xl="12" class="mb10">
          <el-card :body-style="{ padding: '20px 10px' }">
            <RubEmptyTip :show="memberLevelMaoriChartStatus">
              <RubDoubleYAxisChart v-bind="memberLevelMaoriChartData" style="height: 400px" />
            </RubEmptyTip>
          </el-card>
        </el-col>
      </el-row>
    </el-card>
  </RubPage>
</template>

<!-- 会员现状分析 页面 -->
<script setup lang="ts" name="memberActualityAnalysis">
import { getMemberTrendPort, MemberTrendType, getMemberAttributesPort } from '@/api/modules/memberAnalysis';
import { Chart } from '@/typings/global';
import { factoryDoubleYAxisOptions, FactoryOptionType } from '@/views/memberAnalysis/common';
import { SearchParamsType } from '@/components/rub-search-form/interfaces';
import { useGlobalStore } from '@/stores/modules/global';
import { getQuestionMapItem, getQuestionMapObj } from '@/utils';

const globalStore = useGlobalStore();
const isMobile = computed(() => globalStore.device === 'mobile');

const handleSearch = (data: SearchParamsType) => {
  getMemberTrendData(data);
  getMemberAttributesData(data);
};

const handleReset = (data: SearchParamsType) => {
  handleSearch(data);
};

const memberTrend = ref<MemberTrendType>({} as MemberTrendType);

// 会员变动趋势数据
const memberChangeChartStatus = ref<boolean>(false);
const memberChangeChartData = ref<Chart.DoubleYAxisChartType>({});

// 会员类型人数数据
const memberTypeCountChartStatus = ref<boolean>(false);
const memberTypeCountChartData = ref<Chart.DoubleYAxisChartType>({});

// 会员类型业绩贡献数据
const memberTypePerformanceChartStatus = ref<boolean>(false);
const memberTypePerformanceChartData = ref<Chart.DoubleYAxisChartType>({});

// 会员类型毛利贡献数据
const memberTypeMaoriChartStatus = ref<boolean>(false);
const memberTypeMaoriChartData = ref<Chart.DoubleYAxisChartType>({});

// 会员等晋人数数据
const memberLevelCountChartStatus = ref<boolean>(false);
const memberLevelCountChartData = ref<Chart.DoubleYAxisChartType>({});

// 会员等晋业绩贡献数据
const memberLevelPerformanceChartStatus = ref<boolean>(false);
const memberLevelPerformanceChartData = ref<Chart.DoubleYAxisChartType>({});

// 会员等晋毛利贡献数据
const memberLevelMaoriChartStatus = ref<boolean>(false);
const memberLevelMaoriChartData = ref<Chart.DoubleYAxisChartType>({});

// 会员趋势变动的数据
const getMemberTrendData = async (arg: SearchParamsType) => {
  try {
    const { shopIdList, startMonth, endMonth } = toValue(arg);
    const params = { shopIdList, startMonth, endMonth };
    const { val: data, success } = await getMemberTrendPort(params);
    if (success === '0') {
      memberTrend.value = data;

      memberChangeChartStatus.value = !!data.memberTrend?.length;
      if (!memberChangeChartStatus.value) return;

      let axis: string[] = [],
        churnMembers: number[] = [],
        newMembers: number[] = [],
        retentionMembers: number[] = [];

      if (data.memberTrend) {
        for (let item of data.memberTrend) {
          axis.push(item.timePeriod);
          churnMembers.push(item.churnMemberCount); // 流失会员
          newMembers.push(item.newMemberCount); // 新会员
          retentionMembers.push(item.retentionMemberCount); // 留存会员
        }
      }

      memberChangeChartData.value = {
        title: '会员变动趋势',
        xAxisLabelRotate: isMobile.value ? 45 : 0,
        yAxisNameVisible: false,
        yAxisRightUnit: '',
        grid: {
          top: '15%',
          bottom: '8%',
          right: isMobile.value ? '8%' : '5%',
          left: isMobile.value ? '8%' : '5%'
        },
        axis,
        series: [
          {
            name: '流失会员人数',
            type: 'bar',
            stack: 'one',
            data: churnMembers,
            label: { show: true, position: 'inside' },
            barMaxWidth: 48
          },
          {
            name: '新会员人数',
            type: 'bar',
            stack: 'one',
            data: newMembers,
            label: { show: true, position: 'inside' },
            barMaxWidth: 48
          },
          {
            name: '留存会员人数',
            type: 'line',
            data: retentionMembers,
            yAxisIndex: 1,
            smooth: true,
            label: { show: true }
          }
        ],
        colors: ['#5B9BD5', '#FFC000', '#ED7D31']
      };
    }
  } catch {}
};

// 解析会员数据
type ParseReturnType = { status: boolean } & Pick<FactoryOptionType, 'axis' | 'data1' | 'data2'>;
const parseMemberData = <T extends Object>(flag: 'memberType' | 'memberLevel', data: T): ParseReturnType => {
  let entries = Object.entries(data ?? {});
  let axis: string[] = [];
  let data1: number[] = [];
  let data2: number[] = [];
  if (entries.length) {
    for (let [key, value] of entries) {
      if (flag === 'memberType') {
        // 会员类型
        if (value !== null) key.includes('Ratio') ? data2.push(value) : data1.push(value);
      } else if (flag === 'memberLevel') {
        // 会员等级
        axis.push(key);
        data1.push(value.amount || value.count);
        data2.push(value.ratio);
      }
    }
  }
  return { status: entries.length !== 0, axis: flag === 'memberType' ? ['会员', '预备会员'] : axis, data1, data2 };
};

// 会员属性的数据
const getMemberAttributesData = async (arg: SearchParamsType) => {
  try {
    const { shopIdList, startMonth, endMonth } = toValue(arg);
    const params = { shopIdList, startMonth, endMonth };
    const { val: data, success } = await getMemberAttributesPort(params);
    if (success === '0') {
      /*  会员类型人数图表数据 */
      const memberTypeData = parseMemberData('memberType', data.memberType);
      memberTypeCountChartStatus.value = memberTypeData.status;
      if (memberTypeData.status) {
        const { axis, data1, data2 } = memberTypeData;
        memberTypeCountChartData.value = factoryDoubleYAxisOptions({
          title: '会员类型人数',
          axis,
          name1: '会员人数',
          data1,
          name2: '人数占比(%)',
          data2,
          colors: ['#4472C4', '#ED7B2E']
        });
      }

      /*  会员类型业绩贡献图表数据 */
      const performanceContributionData = parseMemberData('memberType', data.performanceContribution);
      memberTypePerformanceChartStatus.value = performanceContributionData.status;
      if (performanceContributionData.status) {
        const { axis, data1, data2 } = performanceContributionData;
        memberTypePerformanceChartData.value = factoryDoubleYAxisOptions({
          title: '会员类型业绩贡献',
          axis,
          name1: '消费金额',
          data1,
          name2: '消费金额占比(%)',
          data2,
          colors: ['#4472C4', '#ED7B2E']
        });
      }

      /*  会员类型业绩贡献图表数据 */
      const memberTypeGrossProfitData = parseMemberData('memberType', data.memberTypeGrossProfit);
      memberTypeMaoriChartStatus.value = memberTypeGrossProfitData.status;
      if (memberTypeGrossProfitData.status) {
        const { axis, data1, data2 } = memberTypeGrossProfitData;
        memberTypeMaoriChartData.value = factoryDoubleYAxisOptions({
          title: '会员类型毛利贡献',
          axis,
          name1: '毛利额',
          data1,
          name2: '毛利额占比(%)',
          data2,
          colors: ['#A5A5A5', '#ED7B2E']
        });
      }

      /* 会员等级人数图表数据 */
      const memberLevelCountData = parseMemberData('memberLevel', data.memberLevelCount);
      memberLevelCountChartStatus.value = memberLevelCountData.status;
      if (memberLevelCountData.status) {
        const { axis, data1, data2 } = memberLevelCountData;
        memberLevelCountChartData.value = factoryDoubleYAxisOptions({
          title: '会员等级人数',
          axis,
          name1: '会员人数',
          data1,
          name2: '人数占比(%)',
          data2,
          colors: ['#4472C4', '#ED7B2E']
        });
      }

      /* 会员等级业绩贡献图表数据 */
      const memberLevelAmountData = parseMemberData('memberLevel', data.memberLevelAmount);
      memberLevelPerformanceChartStatus.value = memberLevelAmountData.status;
      if (memberLevelAmountData.status) {
        const { axis, data1, data2 } = memberLevelAmountData;
        memberLevelPerformanceChartData.value = factoryDoubleYAxisOptions({
          title: '会员等级业绩贡献',
          axis,
          name1: '消费金额',
          data1,
          name2: '消费金额占比(%)',
          data2,
          colors: ['#4472C4', '#ED7B2E']
        });
      }

      /* 会员等级业绩贡献图表数据 */
      const memberLevelGrossProfitData = parseMemberData('memberLevel', data.memberLevelGrossProfit);
      memberLevelMaoriChartStatus.value = memberLevelGrossProfitData.status;
      if (memberLevelGrossProfitData.status) {
        const { axis, data1, data2 } = memberLevelGrossProfitData;
        memberLevelMaoriChartData.value = factoryDoubleYAxisOptions({
          title: '会员等级毛利贡献',
          axis,
          name1: '毛利额',
          data1,
          name2: '毛利额占比(%)',
          data2,
          colors: ['#A5A5A5', '#ED7B2E']
        });
      }
    }
  } catch {}
};
</script>
