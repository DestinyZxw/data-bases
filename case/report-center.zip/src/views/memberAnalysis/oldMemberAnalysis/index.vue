<template>
  <RubPage>
    <template #header>
      <div class="card pb0">
        <RubSearchForm
          read-auth-code="MENU_OLD_MEMBER_ANALYSE_READ"
          :is-months="false"
          @init="handleSearch"
          @search="handleSearch"
          @reset="handleReset"
        />
      </div>
    </template>

    <el-card shadow="hover" class="mt14 pr" :body-style="{ padding: '14px 14px 8px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz20">一、关键指标</div>
        </div>
      </template>
      <el-row :gutter="10">
        <el-col :xs="24" :sm="24" :md="24" :lg="24" :xl="12" class="mb10">
          <el-card>
            <RubEmptyTip :show="memberLevelMaoriChartStatus">
              <RubDoubleYAxisChart v-bind="memberLevelMaoriChartData" style="height: 506px" />
            </RubEmptyTip>
          </el-card>
        </el-col>
        <el-col :xs="24" :sm="24" :md="8" :lg="8" :xl="4" class="mb10">
          <div style="height: 544px">
            <el-row :gutter="10">
              <el-col :span="24" class="mb10">
                <el-card>
                  <div style="height: 134px" class="flex flex-col items-center justify-center">
                    <span>
                      消费金额（万元）
                      <el-tooltip class="box-item" effect="dark" placement="top">
                        <template #content>
                          <div style="max-width: 360px">{{ getQuestionMapItem(130) }}</div>
                        </template>
                        <el-icon class="pointer" size="20" color="#333">
                          <Warning />
                        </el-icon>
                      </el-tooltip>
                    </span>
                    <span class="font-bold pt10 pb10">{{ memberOtherData['消费金额'] ?? '--' }}</span>
                  </div>
                </el-card>
              </el-col>
              <el-col :span="24" class="mb10">
                <el-card>
                  <div style="height: 134px" class="flex flex-col items-center justify-center">
                    <span>
                      消费次数（次）
                      <el-tooltip class="box-item" effect="dark" placement="top">
                        <template #content>
                          <div style="max-width: 360px">{{ getQuestionMapItem(131) }}</div>
                        </template>
                        <el-icon class="pointer" size="20" color="#333">
                          <Warning />
                        </el-icon>
                      </el-tooltip>
                    </span>
                    <span class="font-bold pt10 pb10">{{ memberOtherData['消费次数'] ?? '--' }}</span>
                  </div>
                </el-card>
              </el-col>
              <el-col :span="24" class="mb10">
                <el-card>
                  <div style="height: 134px" class="flex flex-col items-center justify-center">
                    <span>
                      人次客单（元/次）
                      <el-tooltip class="box-item" effect="dark" placement="top">
                        <template #content>
                          <div style="max-width: 360px">{{ getQuestionMapItem(132) }}</div>
                        </template>
                        <el-icon class="pointer" size="20" color="#333">
                          <Warning />
                        </el-icon>
                      </el-tooltip>
                    </span>
                    <span class="font-bold pt10 pb10">{{ memberOtherData['人次客单'] ?? '--' }}</span>
                  </div>
                </el-card>
              </el-col>
            </el-row>
          </div>
        </el-col>
        <el-col :xs="24" :sm="24" :md="8" :lg="8" :xl="4" class="mb10">
          <div style="height: 544px">
            <el-row :gutter="10">
              <el-col :span="24" class="mb10">
                <el-card>
                  <div style="height: 134px" class="flex flex-col items-center justify-center">
                    <span>
                      人均到店间隔（天）
                      <el-tooltip class="box-item" effect="dark" placement="top">
                        <template #content>
                          <div style="max-width: 360px">{{ getQuestionMapItem(133) }}</div>
                        </template>
                        <el-icon class="pointer" size="20" color="#333">
                          <Warning />
                        </el-icon>
                      </el-tooltip>
                    </span>
                    <span class="font-bold pt10 pb10">{{ memberOtherData['人均到店间隔'] ?? '--' }}</span>
                  </div>
                </el-card>
              </el-col>
              <el-col :span="24" class="mb10">
                <el-card>
                  <div style="height: 134px" class="flex flex-col items-center justify-center">
                    <span>
                      消费频次（次/人/月）
                      <el-tooltip class="box-item" effect="dark" placement="top">
                        <template #content>
                          <div style="max-width: 360px">{{ getQuestionMapItem(134) }}</div>
                        </template>
                        <el-icon class="pointer" size="20" color="#333">
                          <Warning />
                        </el-icon>
                      </el-tooltip>
                    </span>
                    <span class="font-bold pt10 pb10">{{ memberOtherData['消费频次'] ?? '--' }}</span>
                  </div>
                </el-card>
              </el-col>
              <el-col :span="24" class="mb10">
                <el-card>
                  <div style="height: 134px" class="flex flex-col items-center justify-center">
                    <span>
                      人均叠加金额（元/人）
                      <el-tooltip class="box-item" effect="dark" placement="top">
                        <template #content>
                          <div style="max-width: 360px">{{ getQuestionMapItem(138) }}</div>
                        </template>
                        <el-icon class="pointer" size="20" color="#333">
                          <Warning />
                        </el-icon>
                      </el-tooltip>
                    </span>
                    <span class="font-bold pt10 pb10">{{ memberOtherData['人均叠加金额'] ?? '--' }}</span>
                  </div>
                </el-card>
              </el-col>
            </el-row>
          </div>
        </el-col>
        <el-col :xs="24" :sm="24" :md="8" :lg="8" :xl="4" class="mb10">
          <div style="height: 544px">
            <el-row :gutter="10">
              <el-col :span="24" class="mb10">
                <el-card>
                  <div style="height: 134px" class="flex flex-col items-center justify-center">
                    <span>
                      人均叠加客单（元/次）
                      <el-tooltip class="box-item" effect="dark" placement="top">
                        <template #content>
                          <div style="max-width: 360px">{{ getQuestionMapItem(139) }}</div>
                        </template>
                        <el-icon class="pointer" size="20" color="#333">
                          <Warning />
                        </el-icon>
                      </el-tooltip>
                    </span>
                    <span class="font-bold pt10 pb10">{{ memberOtherData['人均叠加客单'] ?? '--' }}</span>
                  </div>
                </el-card>
              </el-col>
              <el-col :span="24" class="mb10">
                <el-card>
                  <div style="height: 134px" class="flex flex-col items-center justify-center">
                    <span>
                      人均叠加率
                      <el-tooltip class="box-item" effect="dark" placement="top">
                        <template #content>
                          <div style="max-width: 360px">{{ getQuestionMapItem(140) }}</div>
                        </template>
                        <el-icon class="pointer" size="20" color="#333">
                          <Warning />
                        </el-icon>
                      </el-tooltip>
                    </span>
                    <span class="font-bold pt10 pb10">
                      {{
                        memberOtherData['人均叠加率'] || memberOtherData['人均叠加率'] === 0
                          ? memberOtherData['人均叠加率'] + '%'
                          : '--'
                      }}
                    </span>
                  </div>
                </el-card>
              </el-col>
              <el-col :span="24" class="mb10">
                <el-card>
                  <div style="height: 134px" class="flex flex-col items-center justify-center">
                    <span>
                      人均叠加数量
                      <el-tooltip class="box-item" effect="dark" placement="top">
                        <template #content>
                          <div style="max-width: 360px">{{ getQuestionMapItem(141) }}</div>
                        </template>
                        <el-icon class="pointer" size="20" color="#333">
                          <Warning />
                        </el-icon>
                      </el-tooltip>
                    </span>
                    <span class="font-bold pt10 pb10">{{ memberOtherData['人均叠加数量'] ?? '--' }}</span>
                  </div>
                </el-card>
              </el-col>
            </el-row>
          </div>
        </el-col>
      </el-row>
    </el-card>
  </RubPage>
</template>

<!-- 老会员分析 页面 -->
<script setup lang="ts" name="oldMemberAnalysis">
import { SearchParamsType } from '@/components/rub-search-form/interfaces';
import { Chart } from '@/typings/global';
import { factoryDoubleYAxisOptions } from '@/views/memberAnalysis/common';
import { getOldMemberKeyIndicatorPort, OldMemberKeyIndicatorOtherItemType } from '@/api/modules/memberAnalysis';
import { getQuestionMapItem } from '@/utils';

const handleSearch = (data: SearchParamsType) => {
  getMemberChartsData(data);
};

const handleReset = (data: SearchParamsType) => {
  handleSearch(data);
};

// 会员活跃度数据
const memberLevelMaoriChartStatus = ref(false);
const memberLevelMaoriChartData = ref<Chart.DoubleYAxisChartType>({});
// 会员关键指标 其他数据
const memberOtherData = ref<OldMemberKeyIndicatorOtherItemType>({} as OldMemberKeyIndicatorOtherItemType);

// 会员活跃度数据
const getMemberChartsData = async (arg: SearchParamsType) => {
  try {
    const { shopIdList, startMonth, endMonth } = toValue(arg);
    const params = { shopIdList, startMonth, endMonth, memberType: 0 };
    const { val: data, success } = await getOldMemberKeyIndicatorPort(params);
    if (success === '0') {
      memberOtherData.value = data.oldMemberOtherKeyIndicator;
      const oldMemberActivityEntries = Object.entries(data.oldMemberActivity ?? {});
      memberLevelMaoriChartStatus.value = !!oldMemberActivityEntries.length;
      if (!memberLevelMaoriChartStatus.value) return;

      let axis: string[] = [],
        data1: number[] = [],
        data2: number[] = [];
      for (const [key, value] of oldMemberActivityEntries) {
        axis.push(key);
        data1.push(value.keyIndicator ?? 0);
        data2.push(value.keyIndicatorIncreasePer ?? 0);
      }
      memberLevelMaoriChartData.value = factoryDoubleYAxisOptions({
        title: `活跃度(老会员总人数：${memberOtherData.value['总人数']})`,
        axis: axis,
        name1: '会员人数',
        data1: data1,
        name2: '复合同比(%)',
        data2: data2,
        colors: ['#5B9BD5', '#ED7D31']
      });
    }
  } catch {}
};
</script>
