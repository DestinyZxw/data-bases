<template>
  <RubPage>
    <template #header>
      <div class="card pb0">
        <RubSearchForm
          read-auth-code="MENU_MEMBER_CONSUMER_HABITS_READ"
          :is-months="false"
          @init="handleSearch"
          @search="handleSearch"
          @reset="handleReset"
        />
      </div>
    </template>

    <!--  一、会员消费时段分析  -->
    <el-card shadow="hover" class="mt14 pr" :body-style="{ padding: '14px 14px 8px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz20">
            一、会员消费时段分析
            <el-tooltip class="box-item" effect="dark" placement="top">
              <template #content>
                <div style="max-width: 360px">{{ getQuestionMapItem(142) }}</div>
              </template>
              <el-icon class="pointer" size="20" color="#333">
                <Warning />
              </el-icon>
            </el-tooltip>
          </div>
        </div>
      </template>
      <el-row :gutter="10">
        <el-col :xs="24" :sm="24" :md="24" :lg="12" :xl="12" class="mb10">
          <el-card v-loading="oldLoading">
            <div class="selector">
              <div class="name">会员层级</div>
              <RubSelector v-model="oldTierValue" :options="tierOldOptions" auth-code="MENU_MEMBER_CONSUMER_HABITS_READ" />
            </div>
            <div class="selector">
              <div class="name">vip等级</div>
              <RubSelector v-model="oldVipValue" :options="vipOptions" auth-code="MENU_MEMBER_CONSUMER_HABITS_READ" />
            </div>
            <RubEmptyTip :show="oldMemberChartStatus">
              <el-scrollbar>
                <RubBaseChart v-bind="oldMemberChartData" class="chart pt10" />
              </el-scrollbar>
            </RubEmptyTip>
          </el-card>
        </el-col>
        <el-col :xs="24" :sm="24" :md="24" :lg="12" :xl="12" class="mb10">
          <el-card v-loading="newLoading">
            <div class="selector">
              <div class="name">会员层级</div>
              <RubSelector v-model="newTierValue" :options="tierNewOptions" auth-code="MENU_MEMBER_CONSUMER_HABITS_READ" />
            </div>
            <div class="selector">
              <div class="name">vip等级</div>
              <RubSelector v-model="newVipValue" :options="vipOptions" auth-code="MENU_MEMBER_CONSUMER_HABITS_READ" />
            </div>
            <RubEmptyTip :show="newMemberChartStatus">
              <el-scrollbar>
                <RubBaseChart v-bind="newMemberChartData" class="chart pt10" />
              </el-scrollbar>
            </RubEmptyTip>
          </el-card>
        </el-col>
      </el-row>
    </el-card>

    <!--  二、会员消费订单分析  -->
    <el-card shadow="hover" class="mt14 pr" :body-style="{ paddingBottom: '10px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz20">
            二、会员消费订单分析
            <el-tooltip class="box-item" effect="dark" placement="top">
              <template #content>
                <div style="max-width: 360px">{{ getQuestionMapItem(143) }}</div>
              </template>
              <el-icon class="pointer" size="20" color="#333">
                <Warning />
              </el-icon>
            </el-tooltip>
          </div>
        </div>
      </template>
      <el-card v-loading="consumeLoading" class="mb10">
        <div class="selector">
          <div class="name">消费项目</div>
          <RubSelector v-model="consumeValue" :options="consumeOptions" auth-code="MENU_MEMBER_CONSUMER_HABITS_READ" />
        </div>
        <div class="selector">
          <div class="name">会员层级</div>
          <RubSelector v-model="tierValue" :options="tierOptions" auth-code="MENU_MEMBER_CONSUMER_HABITS_READ" />
        </div>
        <div class="selector">
          <div class="name">vip等级</div>
          <RubSelector v-model="vipValue" :options="vipOptions" auth-code="MENU_MEMBER_CONSUMER_HABITS_READ" />
        </div>
        <RubEmptyTip :show="verticalBarChartStatus">
          <RubVerticalBarChart v-bind="verticalBarChartData" class="mt20" />
        </RubEmptyTip>
      </el-card>
    </el-card>
  </RubPage>
</template>

<!-- 会员习惯偏好分析 页面 -->
<script setup lang="ts" name="memberHabitAnalysis">
import { getMemberConsumeTimePeriodAnalysePort, getMemberConsumeOrderAnalysePort } from '@/api/modules/memberAnalysis';
import { SearchParamsType } from '@/components/rub-search-form/interfaces';
import { default as RubSelector, ModelValueType, SelectorOptionItemType } from '@/components/rub-selector/index.vue';
import { Chart } from '@/typings/global';
import { getQuestionMapItem } from '@/utils';

type OtherType = {
  memberClassify: string[];
  levelId: string[];
  purchaseName?: string;
};

// 层级 options
const tierOldOptions: SelectorOptionItemType[] = [
  { name: '沉默', value: '沉默会员' },
  { name: '发展', value: '发展会员' },
  { name: '价值', value: '价值会员' },
  { name: '流失', value: '流失会员' },
  { name: '睡眠', value: '睡眠会员' },
  { name: '一般', value: '一般会员' }
];

const tierNewOptions: SelectorOptionItemType[] = [{ name: '新会员', value: '新会员', disabled: true }];

const tierOptions: SelectorOptionItemType[] = [
  { name: '沉默', value: '沉默会员' },
  { name: '发展', value: '发展会员' },
  { name: '价值', value: '价值会员' },
  { name: '流失', value: '流失会员' },
  { name: '睡眠', value: '睡眠会员' },
  { name: '新会员', value: '新会员' },
  { name: '一般', value: '一般会员' }
];

// vip等级 options
const vipOptions: SelectorOptionItemType[] = [
  { name: 'VIP1', value: '1' },
  { name: 'VIP2', value: '2' },
  { name: 'VIP3', value: '3' },
  { name: 'VIP4', value: '4' },
  { name: 'VIP5', value: '5' },
  { name: 'VIP6', value: '6' },
  { name: 'VIP7', value: '7' },
  { name: 'VIP8', value: '8' },
  { name: 'VIP9', value: '9' }
];

// 消费项目类型
const consumeOptions: SelectorOptionItemType[] = [
  { name: '产品消费', value: '产品消费' },
  { name: '护理消费', value: '护理消费' }
];

const oldTierValue = ref<ModelValueType>(['沉默会员', '发展会员', '价值会员', '流失会员', '睡眠会员', '一般会员']);
const oldVipValue = ref<ModelValueType>(['1', '2', '3', '4', '5', '6', '7', '8', '9']);
const oldLoading = ref(false);

const newTierValue = ref<ModelValueType>(['新会员']);
const newVipValue = ref<ModelValueType>(['1', '2', '3', '4', '5', '6', '7', '8', '9']);
const newLoading = ref(false);

const oldMemberChartStatus = ref(false);
const oldMemberChartData = ref<Chart.BaseChartType>({});
const newMemberChartStatus = ref(false);
const newMemberChartData = ref<Chart.BaseChartType>({});

let cacheSearchData: SearchParamsType = {} as SearchParamsType;
const handleSearch = (data: SearchParamsType) => {
  cacheSearchData = data;
  // 老会员数据
  getMemberConsumeTimePeriodAnalyseData(data, {
    memberClassify: oldTierValue.value as string[],
    levelId: oldVipValue.value as string[]
  });

  // 新会员数据
  getMemberConsumeTimePeriodAnalyseData(data, {
    memberClassify: newTierValue.value as string[],
    levelId: newVipValue.value as string[]
  });

  // 次客单分布数据
  getMemberConsumeOrderAnalyseData(data, {
    memberClassify: tierValue.value as string[],
    levelId: vipValue.value as string[],
    purchaseName: consumeValue.value as string
  });
};

const handleReset = (data: SearchParamsType) => {
  handleSearch(data);
};

// 对老会员监听
watch([oldTierValue, oldVipValue], () => {
  // 老会员数据
  getMemberConsumeTimePeriodAnalyseData(cacheSearchData, {
    memberClassify: oldTierValue.value as string[],
    levelId: oldVipValue.value as string[]
  });
});

// 新会员监听
watch([newVipValue], () => {
  // 新会员
  getMemberConsumeTimePeriodAnalyseData(cacheSearchData, {
    memberClassify: newTierValue.value as string[],
    levelId: newVipValue.value as string[]
  });
});

/**
 * 会员消费习惯-会员消费时段分析
 */
const getMemberConsumeTimePeriodAnalyseData = async (args: SearchParamsType, other: OtherType) => {
  const [name] = other.memberClassify;
  const isNew = name === '新会员';
  isNew ? (newLoading.value = true) : (oldLoading.value = true);
  try {
    const { shopIdList, startMonth, endMonth } = toValue(args);
    const params = { shopIdList, startMonth, endMonth, ...other };
    const { val: data, success } = await getMemberConsumeTimePeriodAnalysePort(params);
    if (success === '0') {
      if (isNew) {
        newMemberChartStatus.value = !!data.length;
      } else {
        oldMemberChartStatus.value = !!data.length;
      }

      if (!data.length) return;
      let axis: string[] = [],
        data1: number[] = [],
        data2: number[] = [],
        data3: number[] = [];
      for (let item of data) {
        axis.push(item.timePeriod);
        data1.push(item.holidayMemberCount);
        data2.push(item.workdayMemberCount);
        data3.push(item.restDayMemberCount);
      }

      let options = {
        title: `${isNew ? '新会员' : '老会员'} -- 日均消费人数监控`,
        xAxisBoundaryGap: true,
        yAxisUnit: '',
        grid: { top: '20%', bottom: 0 },
        axis: axis,
        series: [
          { type: 'bar', name: '节假日', data: data1, label: { show: true, position: 'insideBottom' }, barMaxWidth: 48 },
          { type: 'line', name: '工作日', data: data2, smooth: true, label: { show: true } },
          { type: 'line', name: '双休日', data: data3, smooth: true, label: { show: true } }
        ]
      };
      if (isNew) {
        newMemberChartData.value = options;
      } else {
        oldMemberChartData.value = options;
      }
    }
  } catch {
  } finally {
    isNew ? (newLoading.value = false) : (oldLoading.value = false);
  }
};

/**
 * 会员消费习惯-会员消费订单分析
 */
const consumeValue = ref<ModelValueType>('产品消费');
const tierValue = ref<ModelValueType>(['沉默会员', '发展会员', '价值会员', '流失会员', '睡眠会员', '新会员', '一般会员']);
const vipValue = ref<ModelValueType>(['1', '2', '3', '4', '5', '6', '7', '8', '9']);
const consumeLoading = ref(false);
const verticalBarChartStatus = ref(false);
const verticalBarChartData = ref<Chart.VerticalBarChartType>({});

// 对次客单分布进行监听
watch([consumeValue, tierValue, vipValue], () => {
  // 次客单分布数据
  getMemberConsumeOrderAnalyseData(cacheSearchData, {
    memberClassify: tierValue.value as string[],
    levelId: vipValue.value as string[],
    purchaseName: consumeValue.value as string
  });
});

const getMemberConsumeOrderAnalyseData = async (args: SearchParamsType, other: OtherType) => {
  consumeLoading.value = true;
  try {
    const { shopIdList, startMonth, endMonth } = toValue(args);
    const params = { shopIdList, startMonth, endMonth, ...other };
    const { val: data, success } = await getMemberConsumeOrderAnalysePort(params);
    if (success === '0') {
      verticalBarChartStatus.value = !!data.length;
      if (!data.length) return;

      let axis: string[] = [],
        seriesData: number[] = [];
      for (let item of data) {
        axis.push(item.pricePeriod);
        seriesData.push(item.orderCountRatio);
      }
      verticalBarChartData.value = {
        title: '次客单分布',
        colors: ['#5B9BD5'],
        axis,
        seriesData,
        labelShow: true,
        inverse: true,
        labelUnit: '%'
      };
    }
  } catch {
  } finally {
    consumeLoading.value = false;
  }
};
</script>
