<template>
  <RubPage>
    <template #header>
      <div class="card pb0">
        <RubSearchForm
          read-auth-code="MENU_VIP_ANALYSE_READ"
          :is-months="false"
          @init="handleSearch"
          @search="handleSearch"
          @reset="handleReset"
        />
      </div>
    </template>

    <el-card shadow="hover" class="mt14 pr" :body-style="{ padding: '14px 14px 8px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz20">一、大客户消费分析</div>
        </div>
      </template>
      <el-row :gutter="10">
        <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12" class="mb10">
          <el-card>
            <RubEmptyTip :show="bigCustomerComparativeAnalysisStatus" title="大客户消费对比分析" style="height: 520px">
              <RubDoubleYAxisChart v-bind="bigCustomerComparativeAnalysisChartData" style="height: 520px" />
            </RubEmptyTip>
          </el-card>
        </el-col>
        <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12" class="mb10">
          <el-card>
            <RubEmptyTip :show="largeCustomerPreferenceChartStatus">
              <RubBaseChart v-bind="largeCustomerPreferenceChartData" style="height: 520px" />
            </RubEmptyTip>
            <div style="position: absolute; top: 20px; right: 20px">
              <el-tooltip class="box-item" effect="dark" placement="top">
                <template #content>
                  <div style="max-width: 360px">{{ getQuestionMapItem(156) }}</div>
                </template>
                <el-icon class="pointer" size="20" color="#333">
                  <Warning />
                </el-icon>
              </el-tooltip>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </el-card>

    <el-card shadow="hover" class="mt14 pr" :body-style="{ paddingBottom: '10px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz20">二、大客户消费偏好</div>
        </div>
      </template>
      <el-card class="mb10 pr">
        <RubEmptyTip :show="independentTreeMapStatus" title="独立护理偏好">
          <el-scrollbar>
            <RubTreeMapChart v-bind="independentTreeMapChartData" class="chart" />
          </el-scrollbar>
        </RubEmptyTip>
        <div style="position: absolute; top: 20px; right: 20px">
          <el-tooltip class="box-item" effect="dark" placement="top">
            <template #content>
              <div style="max-width: 360px">{{ getQuestionMapItem(157) }}</div>
            </template>
            <el-icon class="pointer" size="20" color="#333">
              <Warning />
            </el-icon>
          </el-tooltip>
        </div>
      </el-card>
      <el-card class="mb10 pr">
        <RubEmptyTip :show="overlayTreeMapStatus" title="叠加护理偏好">
          <el-scrollbar>
            <RubTreeMapChart v-bind="overlayTreeMapChartData" class="chart" />
          </el-scrollbar>
        </RubEmptyTip>
        <div style="position: absolute; top: 20px; right: 20px">
          <el-tooltip class="box-item" effect="dark" placement="top">
            <template #content>
              <div style="max-width: 360px">{{ getQuestionMapItem(158) }}</div>
            </template>
            <el-icon class="pointer" size="20" color="#333">
              <Warning />
            </el-icon>
          </el-tooltip>
        </div>
      </el-card>
      <el-card class="mb10 pr">
        <RubEmptyTip :show="categoryPreferencePieStatus" title="品类消费偏好">
          <el-scrollbar>
            <RubPieChart v-bind="categoryPreferencePieChartData" class="pieChart" style="height: 600px" />
          </el-scrollbar>
        </RubEmptyTip>
        <div style="position: absolute; top: 20px; right: 20px">
          <el-tooltip class="box-item" effect="dark" placement="top">
            <template #content>
              <div style="max-width: 360px">{{ getQuestionMapItem(159) }}</div>
            </template>
            <el-icon class="pointer" size="20" color="#333">
              <Warning />
            </el-icon>
          </el-tooltip>
        </div>
      </el-card>
      <el-card class="mb10 pr">
        <RubEmptyTip :show="productTreeMapStatus" title="产品偏好">
          <el-scrollbar>
            <RubTreeMapChart v-bind="productTreeMapChartData" class="chart" />
          </el-scrollbar>
        </RubEmptyTip>
        <div style="position: absolute; top: 20px; right: 20px">
          <el-tooltip class="box-item" effect="dark" placement="top">
            <template #content>
              <div style="max-width: 360px">{{ getQuestionMapItem(160) }}</div>
            </template>
            <el-icon class="pointer" size="20" color="#333">
              <Warning />
            </el-icon>
          </el-tooltip>
        </div>
      </el-card>
    </el-card>

    <el-card shadow="hover" class="mt14 pr" :body-style="{ paddingBottom: '10px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz20">三、大客户贡献排名</div>
          <el-button type="primary" plain size="small" @click="exportBigMemberRankingTableData">
            导出<el-icon class="el-icon--right"><Download /></el-icon>
          </el-button>
        </div>
      </template>
      <el-table v-loading="bigMemberRankingTableLoading" :data="bigMemberRankingTableData" class="wp-100" border height="560">
        <el-table-column prop="memberCode" label="会员卡号" align="center" min-width="120" />
        <el-table-column prop="memberName" label="姓名" align="center" min-width="120" />
        <el-table-column prop="shopName" label="会籍门店" align="center" min-width="120" />
        <el-table-column prop="consultantName" label="专属顾问" align="center" min-width="120" />
        <el-table-column prop="beauticianName" label="专属美容师" align="center" min-width="120" />
        <el-table-column prop="joinDate" label="入会日期" align="center" min-width="120" />
        <el-table-column prop="yearDiff" label="入会年限" align="center" min-width="120" />
        <!-- <el-table-column prop="shopName" label="充值金额" align="center" min-width="120" /> -->
        <el-table-column prop="avgUpCounts" label="月均消费次数" align="center" min-width="120">
          <template #default="{ row }">{{ handleFilterTableRow(row, 'avgUpCounts') }}</template>
        </el-table-column>
        <el-table-column prop="bigMemberPpt" label="人次客单" align="center" min-width="120">
          <template #default="{ row }">{{ handleFilterTableRow(row, 'bigMemberPpt') }}</template>
        </el-table-column>
        <el-table-column prop="addUpAmount" label="消费金额" align="center" min-width="120">
          <template #default="{ row }">{{ handleFilterTableRow(row, 'addUpAmount') }}</template>
        </el-table-column>
        <el-table-column prop="btreAmount" label="护理消费金额" align="center" min-width="120">
          <template #default="{ row }">{{ handleFilterTableRow(row, 'btreAmount') }}</template>
        </el-table-column>
        <el-table-column prop="bprdAmount" label="产品消费金额" align="center" min-width="120">
          <template #default="{ row }">{{ handleFilterTableRow(row, 'bprdAmount') }}</template>
        </el-table-column>
        <el-table-column prop="productRate" label="产品占比%" align="center" min-width="120">
          <template #default="{ row }">{{ handleFilterTableRow(row, 'productRate') }}</template>
        </el-table-column>
        <el-table-column prop="contributionRatio" label="TOP贡献%" align="center" min-width="120">
          <template #default="{ row }">{{ handleFilterTableRow(row, 'contributionRatio') }}</template>
        </el-table-column>
      </el-table>
      <div class="flex justify-end mt15 mb10">
        <el-pagination
          background
          layout="total, sizes, prev, pager, next, jumper"
          :current-page="bigMemberPagination.page"
          :page-size="bigMemberPagination.pageSize"
          :page-sizes="bigMemberPagination.pageSizes"
          :total="bigMemberPagination.itemCount"
          @current-change="bigMemberPagination.onChange"
          @size-change="bigMemberPagination.onPageSizeChange"
        />
      </div>
    </el-card>
  </RubPage>
</template>

<!-- 大客户分析 页面 -->
<script setup lang="ts" name="bigCustomerAnalysis">
import { SearchParamsType } from '@/components/rub-search-form/interfaces';
import { Chart } from '@/typings/global';
import { factoryDoubleYAxisOptions } from '@/views/memberAnalysis/common';
import { handleFilterTableRow, getQuestionMapItem } from '@/utils';
import {
  bigMemberRankingOfContributionsItemType,
  getBigMemberConsumeComparisonAnalysisPort,
  getBigMemberConsumptionHabitPort,
  getBigMemberRankingOfContributionsPort,
  exportBigMemberRankingTableDataPort,
  getMemberConsumeTimePeriodAnalysePort
} from '@/api/modules/memberAnalysis';
import { PaginationType } from '@/hooks/useTable';
import { ElMessageBox } from 'element-plus';
import { useDownload } from '@/hooks/useDownload';

let cacheSearchData: SearchParamsType = {} as SearchParamsType;
const handleSearch = (data: SearchParamsType) => {
  cacheSearchData = data;
  getBigMemberConsumeComparisonAnalysisData(data);
  getMemberConsumeTimePeriodAnalyseData(data);
  getBigMemberConsumptionHabitData(data);
  getRankingTableData(data);
};

const handleReset = (data: SearchParamsType) => {
  handleSearch(data);
};

// 会员等晋毛利贡献数据
const bigCustomerComparativeAnalysisStatus = ref(false);
const bigCustomerComparativeAnalysisChartData = ref<Chart.BaseChartType>({});

// 大客户消费时段偏好
const largeCustomerPreferenceChartStatus = ref(false);
const largeCustomerPreferenceChartData = ref<Chart.BaseChartType>({});

// 独立护理偏好 数据
const independentTreeMapStatus = ref<boolean>(false);
const independentTreeMapChartData = ref<Chart.TreeMapChartType>({});

// 叠加护理偏好 数据
const overlayTreeMapStatus = ref<boolean>(false);
const overlayTreeMapChartData = ref<Chart.TreeMapChartType>({});

// 品类消费偏好 饼图数据
const categoryPreferencePieStatus = ref<boolean>(false);
const categoryPreferencePieChartData = ref<Chart.PieChartType>({});

// 产品偏好 数据
const productTreeMapStatus = ref<boolean>(false);
const productTreeMapChartData = ref<Chart.TreeMapChartType>({});

// 大客户消费对比分析
const getBigMemberConsumeComparisonAnalysisData = async (args: SearchParamsType) => {
  try {
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = { shopIdList, startMonth, endMonth };
    let { val: data, success } = await getBigMemberConsumeComparisonAnalysisPort(params);
    let status = !!data.consumeFreq || !!data.perPersonAmount;
    bigCustomerComparativeAnalysisStatus.value = status;
    if (!status) return;
    if (success === '0') {
      let axis: string[] = [],
        data1: number[] = [],
        data2: number[] = [];
      const consumeFreqEntries = Object.entries(data.consumeFreq);
      for (const [key, value] of consumeFreqEntries) {
        axis.push(key);
        data1.push(value ?? 0);
      }
      const perPersonAmountValues = Object.values(data.perPersonAmount);
      for (const value of perPersonAmountValues) {
        data2.push(value ?? 0);
      }
      bigCustomerComparativeAnalysisChartData.value = factoryDoubleYAxisOptions({
        title: '大客户消费对比分析',
        axis: axis,
        yAxisRightUnit: '',
        name1: '消费频次',
        data1: data1,
        name2: '人次客单',
        data2: data2,
        colors: ['#5B9BD5', '#ED7D31']
      });
    }
  } catch (e) {
    console.log('e : ', e);
  }
};

// 大客户消费时段偏好
const getMemberConsumeTimePeriodAnalyseData = async (args: SearchParamsType) => {
  try {
    const { shopIdList, startMonth, endMonth } = toValue(args);
    const params = { shopIdList, startMonth, endMonth, memberClassify: ['大客户'] };
    const { val: data, success } = await getMemberConsumeTimePeriodAnalysePort(params);
    if (success === '0') {
      largeCustomerPreferenceChartStatus.value = !!data.length;
      if (!data.length) return;
      let axis: string[] = [],
        data1: number[] = [],
        data2: number[] = [],
        data3: number[] = [];
      for (let item of data) {
        axis.push(item.timePeriod);
        data1.push(item.holidayMemberCount);
        data2.push(item.workdayMemberCount);
        data3.push(item.restDayMemberCount);
      }
      largeCustomerPreferenceChartData.value = {
        title: '大客户消费时段偏好',
        xAxisBoundaryGap: true,
        yAxisUnit: '',
        grid: { top: '20%', bottom: 0 },
        axis: axis,
        series: [
          { type: 'bar', name: '节假日', data: data1, label: { show: true, position: 'insideBottom' }, barMaxWidth: 48 },
          { type: 'line', name: '工作日', data: data2, smooth: true, label: { show: true } },
          { type: 'line', name: '双休日', data: data3, smooth: true, label: { show: true } }
        ]
      };
    }
  } catch {}
};

// 大客户消费偏好
const getBigMemberConsumptionHabitData = async (args: SearchParamsType) => {
  try {
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = { shopIdList, startMonth, endMonth };
    let { val: data, success } = await getBigMemberConsumptionHabitPort(params);
    if (success === '0') {
      independentTreeMapStatus.value = !!data.independentNursingPreferences.length;
      independentTreeMapChartData.value = {
        title: '独立护理偏好',
        data: data.independentNursingPreferences
          .filter(item => !!item)
          .map(item => ({
            name: item.nursingServiceName,
            value: item.orderCount
          }))
      };
      overlayTreeMapStatus.value = !!data.overlayNursingPreferences.length;
      overlayTreeMapChartData.value = {
        title: '叠加护理偏好',
        data: data.overlayNursingPreferences
          .filter(item => !!item)
          .map(item => ({
            name: item.nursingServiceName,
            value: item.orderCount
          }))
      };
      categoryPreferencePieStatus.value = !!data.productTypePreferences.length;
      categoryPreferencePieChartData.value = {
        name: '品类消费偏好',
        position: 'outside',
        data: data.productTypePreferences
          .filter(item => !!item)
          .map(item => ({
            name: item.productTypeName,
            value: item.countRatio
          })),
        colors: ['#F4B183', '#E2F0D9', '#A9D18E', '#C00000', '#00B050', '#70AD47', '#FF0000', '#FF7C80']
      };
      productTreeMapStatus.value = !!data.productPreferences.length;
      productTreeMapChartData.value = {
        title: '产品偏好',
        data: data.productPreferences
          .filter(item => !!item)
          .map(item => ({
            name: item.productName,
            value: item.subtotalCount
          }))
      };
    }
  } catch (e) {
    console.log('e : ', e);
  }
};

// 大客户贡献排名
const bigMemberPagination: PaginationType = reactive({
  page: 1,
  pageSize: 15,
  pageSizes: [15, 20, 30, 40, 50],
  itemCount: 0,
  onChange: (page: number) => {
    bigMemberPagination.page = page;
    getRankingTableData(cacheSearchData);
  },
  onPageSizeChange: (pageSize: number) => {
    bigMemberPagination.page = 1;
    bigMemberPagination.pageSize = pageSize;
    getRankingTableData(cacheSearchData);
  }
});
const bigMemberRankingTableData = ref<bigMemberRankingOfContributionsItemType[]>([]);
const bigMemberRankingTableLoading = ref(false);
const getRankingTableData = async (args: SearchParamsType) => {
  try {
    bigMemberRankingTableLoading.value = true;
    let { page, pageSize } = toRaw(bigMemberPagination);
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = { shopIdList, startMonth, endMonth, page, size: pageSize };
    let { val: data, success, pageInfo } = await getBigMemberRankingOfContributionsPort(params);
    if (success === '0') {
      bigMemberRankingTableData.value = data;
      bigMemberPagination.itemCount = pageInfo?.count ?? 0;
    }
  } catch (e) {
    console.log('e : ', e);
  } finally {
    bigMemberRankingTableLoading.value = false;
  }
};

// 导出大客户贡献排名 table data
const exportBigMemberRankingTableData = () => {
  const { shopIdList, startMonth, endMonth } = toValue(cacheSearchData);
  const params = { shopIdList, startMonth, endMonth };
  ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
    useDownload({
      port: exportBigMemberRankingTableDataPort,
      fileName: '大客户贡献排名分析表',
      params
    })
  );
};
</script>
