<template>
  <RubPage>
    <template #header>
      <div class="card pb0">
        <RubSearchForm
          read-auth-code="MENU_EXPERIENCE_MEMBER_ANALYSE_READ"
          :is-months="false"
          @init="handleSearch"
          @search="handleSearch"
          @reset="handleReset"
        />
      </div>
    </template>

    <!-- 一、关键指标 -->
    <el-card shadow="hover" class="mt14 pr" :body-style="{ padding: '14px 14px 8px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz20">一、关键指标</div>
        </div>
      </template>
      <el-row :gutter="10">
        <el-col :xs="24" :sm="24" :md="24" :lg="10" :xl="12" class="mb10">
          <el-card>
            <RubEmptyTip :show="pieChartsStatus">
              <el-scrollbar>
                <RubPieChart v-bind="pieChartsData" class="pieChart" />
              </el-scrollbar>
            </RubEmptyTip>
          </el-card>
        </el-col>
        <el-col :xs="24" :sm="24" :md="24" :lg="6" :xl="4" class="mb10">
          <div style="height: 440px">
            <el-row :gutter="10">
              <el-col :span="24" class="mb10">
                <el-card class="small-card">
                  <div style="height: 174px" class="flex flex-col items-center justify-center">
                    <div>
                      买卡金额（万元）
                      <el-tooltip class="box-item" effect="dark" placement="top">
                        <template #content>
                          <div style="max-width: 360px">{{ getQuestionMapItem(104) }}</div>
                        </template>
                        <el-icon class="pointer" size="20" color="#333">
                          <Warning />
                        </el-icon>
                      </el-tooltip>
                    </div>
                    <div class="font-bold pt10 pb10">{{ memberKeyIndicator.buyCardAmount ?? '--' }}</div>
                    <div>
                      复合同比:
                      <template v-if="memberKeyIndicator.buyCardAmountIncreasePer !== null">
                        <span :class="[memberKeyIndicator.buyCardAmountIncreasePer >= 0 ? 'upward' : 'downward']">
                          {{ memberKeyIndicator.buyCardAmountIncreasePer + '%' }}
                          {{ memberKeyIndicator.buyCardAmountIncreasePer >= 0 ? '↑' : '↓' }}
                        </span>
                      </template>
                      <template v-else>
                        {{ memberKeyIndicator.buyCardAmountIncreasePer ?? '--' }}
                      </template>
                    </div>
                  </div>
                </el-card>
              </el-col>
              <el-col :span="24" class="mb10">
                <el-card class="small-card">
                  <div style="height: 174px" class="flex flex-col items-center justify-center">
                    <div>
                      买卡客单（元/次）
                      <el-tooltip class="box-item" effect="dark" placement="top">
                        <template #content>
                          <div style="max-width: 360px">{{ getQuestionMapItem(105) }}</div>
                        </template>
                        <el-icon class="pointer" size="20" color="#333">
                          <Warning />
                        </el-icon>
                      </el-tooltip>
                    </div>
                    <div class="font-bold pt10 pb10">{{ memberKeyIndicator.personCountAmount ?? '--' }}</div>
                    <div>
                      复合同比:
                      <template v-if="memberKeyIndicator.personCountAmountIncreasePer !== null">
                        <span :class="[memberKeyIndicator.personCountAmountIncreasePer >= 0 ? 'upward' : 'downward']">
                          {{ memberKeyIndicator.personCountAmountIncreasePer + '%' }}
                          {{ memberKeyIndicator.personCountAmountIncreasePer >= 0 ? '↑' : '↓' }}
                        </span>
                      </template>
                      <template v-else>
                        {{ memberKeyIndicator.personCountAmountIncreasePer ?? '--' }}
                      </template>
                    </div>
                  </div>
                </el-card>
              </el-col>
            </el-row>
          </div>
        </el-col>
        <el-col :xs="24" :sm="24" :md="24" :lg="8" :xl="8" class="mb10">
          <el-card>
            <RubEmptyTip :show="funnelChartStatus">
              <RubFunnelChart v-bind="funnelChartData" style="height: 400px" />
            </RubEmptyTip>
          </el-card>
        </el-col>
      </el-row>
    </el-card>

    <!-- 二、入会渠道有效性 -->
    <el-card shadow="hover" class="mt14 pr" :body-style="{ paddingBottom: '10px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz20">二、入会渠道有效性</div>
        </div>
      </template>
      <el-row :gutter="10">
        <el-col :xs="24" :sm="24" :md="24" :lg="12" :xl="12" class="mb10">
          <el-card>
            <el-table v-loading="memberChannelTableLoading" :data="memberChannelTableData" class="wp-100" border height="500">
              <el-table-column
                prop="eventTypeName"
                label="渠道"
                align="center"
                min-width="120"
                v-bind="isMobile ? {} : { fixed: 'left' }"
              />
              <el-table-column label="体验顾客人数" align="center">
                <template #header>
                  体验顾客人数
                  <el-tooltip class="box-item" effect="dark" placement="top">
                    <template #content>
                      <div style="max-width: 360px">{{ getQuestionMapItem(102) }}</div>
                    </template>
                    <el-icon class="pointer" size="20" color="#333">
                      <Warning />
                    </el-icon>
                  </el-tooltip>
                </template>
                <el-table-column prop="experienceMemberCount" label="本年" align="center" min-width="120">
                  <template #default="{ row }">{{ handleFilterTableRow(row, 'experienceMemberCount') }}</template>
                </el-table-column>
                <el-table-column prop="experienceMemberCountIncreasePer" label="同比(%)" align="center" min-width="150">
                  <template #default="{ row }">{{ handleFilterTableRow(row, 'experienceMemberCountIncreasePer') }}</template>
                </el-table-column>
              </el-table-column>

              <el-table-column label="体验顾客买卡人数" align="center">
                <template #header>
                  体验顾客买卡人数
                  <el-tooltip class="box-item" effect="dark" placement="top">
                    <template #content>
                      <div style="max-width: 360px">{{ getQuestionMapItem(103) }}</div>
                    </template>
                    <el-icon class="pointer" size="20" color="#333">
                      <Warning />
                    </el-icon>
                  </el-tooltip>
                </template>
                <el-table-column prop="buyCardCount" label="本年" align="center" min-width="120">
                  <template #default="{ row }">{{ handleFilterTableRow(row, 'buyCardCount') }}</template>
                </el-table-column>
                <el-table-column prop="buyCardCountIncreasePer" label="同比(%)" align="center" min-width="150">
                  <template #default="{ row }">{{ handleFilterTableRow(row, 'buyCardCountIncreasePer') }}</template>
                </el-table-column>
              </el-table-column>

              <el-table-column label="买卡转化率" align="center">
                <template #header>
                  买卡转化率
                  <el-tooltip class="box-item" effect="dark" placement="top">
                    <template #content>
                      <div style="max-width: 360px">{{ getQuestionMapItem(106) }}</div>
                    </template>
                    <el-icon class="pointer" size="20" color="#333">
                      <Warning />
                    </el-icon>
                  </el-tooltip>
                </template>
                <el-table-column prop="buyCardConversionRate" label="本年" align="center" min-width="120">
                  <template #default="{ row }">{{ handleFilterTableRow(row, 'buyCardConversionRate') }}</template>
                </el-table-column>
                <el-table-column prop="buyCardConversionRateIncreasePer" label="同比(%)" align="center" min-width="150">
                  <template #default="{ row }">{{ handleFilterTableRow(row, 'buyCardConversionRateIncreasePer') }}</template>
                </el-table-column>
              </el-table-column>
            </el-table>
          </el-card>
        </el-col>
        <el-col :xs="24" :sm="24" :md="24" :lg="12" :xl="12" class="mb10">
          <el-card>
            <RubEmptyTip :show="channelBuyCardChartStatus">
              <RubBaseChart v-bind="channelBuyCardChartData" style="height: 500px" />
            </RubEmptyTip>
          </el-card>
        </el-col>
      </el-row>
    </el-card>

    <!--  三、买卡转化分析  -->
    <el-card shadow="hover" class="mt14 pr" :body-style="{ paddingBottom: '10px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz20">三、买卡转化分析</div>
        </div>
      </template>
      <div class="selector mb20">
        <div class="name">期间</div>
        <RubSelector v-model="selectorValue" :options="selectorOptions" auth-code="MENU_EXPERIENCE_MEMBER_ANALYSE_READ" />
      </div>
      <el-card class="mb10">
        <RubEmptyTip :show="shopsMatrixStatus">
          <el-scrollbar>
            <ShopMatrixChart v-bind="shopsMatrixData" key="first" />
          </el-scrollbar>
        </RubEmptyTip>
      </el-card>

      <el-card class="mb10">
        <RubEmptyTip :show="currentShopChartStatus">
          <RubBaseChart v-bind="currentShopChartData" style="height: 480px" />
        </RubEmptyTip>
      </el-card>

      <el-card class="mb10">
        <view class="flex justify-end mb16">
          <el-button type="primary" plain size="small" @click="exportMemberBuyCardConversionAnalyseData">
            导出<el-icon class="el-icon--right"><Download /></el-icon>
          </el-button>
        </view>
        <el-table :data="tableData" class="wp-100" border height="560">
          <el-table-column prop="employeeName" label="顾问" align="center" min-width="120" />
          <el-table-column label="当期" align="center">
            <el-table-column prop="buyCardCount" label="买卡人数" align="center" min-width="120">
              <template #default="{ row }">{{ handleFilterTableRow(row, 'buyCardCount') }}</template>
            </el-table-column>
            <el-table-column prop="buyCardConversionRate" label="买卡成功率" align="center" min-width="150">
              <template #default="{ row }">{{ handleFilterTableRow(row, 'buyCardConversionRate') }}</template>
            </el-table-column>
          </el-table-column>
          <el-table-column label="累计" align="center">
            <el-table-column prop="buyCardCountGrandTotal" label="买卡人数" align="center" min-width="120">
              <template #default="{ row }">{{ handleFilterTableRow(row, 'buyCardCountGrandTotal') }}</template>
            </el-table-column>
            <el-table-column prop="buyCardConversionRateGrandTotal" label="买卡成功率" align="center" min-width="150">
              <template #default="{ row }">{{ handleFilterTableRow(row, 'buyCardConversionRateGrandTotal') }}</template>
            </el-table-column>
          </el-table-column>
        </el-table>
      </el-card>
    </el-card>
  </RubPage>
</template>

<!-- 体验顾客分析 页面 -->
<script setup lang="ts" name="experienceCustomerAnalysis">
import {
  getMemberBuyCardConversionAnalysePort,
  getMemberBuyCardConversionForShopPort,
  exportMemberBuyCardConversionForShopPort,
  getMemberChannelEffectivenessPort,
  getMemberKeyIndicatorPort,
  MemberBuyCardConversionForEmployeeItemType,
  MemberChannelEffectivenessItemType,
  MemberKeyIndicatorType,
  exportMemberBuyCardConversionAnalyseChartDataPort
} from '@/api/modules/memberAnalysis';
import { SearchParamsType } from '@/components/rub-search-form/interfaces';
import { Chart } from '@/typings/global';
import ShopMatrixChart from '../components/shop-matrix-chart.vue';
import { ModelValueType, SelectorOptionItemType } from '@/components/rub-selector/index.vue';
import { handleFilterTableRow, getQuestionMapItem } from '@/utils';
import { useGlobalStore } from '@/stores/modules/global';
import { debounce } from 'lodash-es';
import { ElMessageBox } from 'element-plus';
import { useDownload } from '@/hooks/useDownload';

const globalStore = useGlobalStore();
const isMobile = computed(() => globalStore.device === 'mobile');

let cacheSearchData = {} as SearchParamsType; // 缓存查询数据
let cacheShopSearchData = {} as SearchParamsType; // 缓存与指定门店相关联的 门店复购率 查询参数

const handleSearch = (data: SearchParamsType) => {
  cacheSearchData = data;
  cacheShopSearchData = data;
  getMemberKeyIndicatorData(data);
  getMemberChannelEffectivenessData(data);
  getMemberBuyCardConversionAnalyseData(data);
  getMemberBuyCardConversionForShopData(data);
};

const handleReset = (data: SearchParamsType) => {
  handleSearch(data);
};

/** 体验顾客分析-关键指标数据 */
// 关键指标数据
const memberKeyIndicator = ref<MemberKeyIndicatorType>({} as MemberKeyIndicatorType);

// pie饼图数据
const pieChartsStatus = ref(false);
const pieChartsData = ref<Chart.PieChartType>({});

// funnel漏斗图数据
const funnelChartStatus = ref(false);
const funnelChartData = ref<Chart.FunnelChartType>({});
const getMemberKeyIndicatorData = async (arg: SearchParamsType) => {
  try {
    const { shopIdList, startMonth, endMonth } = toValue(arg);
    const params = { shopIdList, startMonth, endMonth };
    const { val: data, success } = await getMemberKeyIndicatorPort(params);
    if (success === '0') {
      // 关键指标数据
      memberKeyIndicator.value = data;

      // 入会渠道结构 饼图数据
      let memberChannelStructure: { name: string; value: number }[] = [];
      let memberChannelStructureEntries = Object.entries(data.memberChannelStructure ?? {});
      pieChartsStatus.value = !!memberChannelStructureEntries.length;
      if (memberChannelStructureEntries.length) {
        for (let [key, value] of memberChannelStructureEntries) {
          memberChannelStructure.push({ name: key, value: value.ratio });
        }
        pieChartsData.value = {
          name: '入会渠道结构',
          position: 'outside',
          data: memberChannelStructure,
          colors: ['#F4B183', '#E2F0D9', '#A9D18E', '#C00000', '#00B050', '#70AD47', '#FF0000', '#FF7C80']
        };
      }

      // 漏斗图数据
      funnelChartStatus.value = Boolean(
        data.experienceMemberCount ||
          data.experienceMemberCountIncreasePer ||
          data.buyCardCount ||
          data.buyCardCountIncreasePer ||
          data.buyCardConversionRate ||
          data.buyCardConversionRateIncreasePer
      );
      funnelChartData.value = {
        seriesData: [
          {
            value: 60,
            number: data.experienceMemberCount ?? 0,
            rate: data.experienceMemberCountIncreasePer ?? 0,
            name: '体验顾客',
            subName: '人数',
            unit: '%',
            itemStyle: {
              color: '#FFC000'
            }
          },
          {
            value: 30,
            number: data.buyCardCount ?? 0,
            rate: data.buyCardCountIncreasePer ?? 0,
            name: '体验顾客',
            subName: '买卡人数',
            unit: '%',
            itemStyle: {
              color: '#5B9BD5'
            }
          }
        ],
        markLines: [
          { value: 0, itemValue: '0%', rate: '0', show: false },
          {
            value: 346,
            itemValue: `${data.buyCardConversionRate ?? 0}%`,
            rate: `${data.buyCardConversionRateIncreasePer ?? 0}%`,
            show: true
          }
        ]
      };
    }
  } catch {}
};

/** 体验顾客分析-入会渠道有效性数据 */
const memberChannelTableLoading = ref<boolean>(false);
const memberChannelTableData = ref<MemberChannelEffectivenessItemType[]>([]);
// 渠道买卡转化率同比分析的图表数据
const channelBuyCardChartStatus = ref(false);
const channelBuyCardChartData = ref<Chart.BaseChartType>({});
const getMemberChannelEffectivenessData = async (arg: SearchParamsType) => {
  try {
    memberChannelTableLoading.value = true;
    const { shopIdList, startMonth, endMonth } = toValue(arg);
    const params = { shopIdList, startMonth, endMonth };
    const { val: data, success } = await getMemberChannelEffectivenessPort(params);
    if (success === '0') {
      // 渠道table表格数据
      memberChannelTableData.value = data;

      channelBuyCardChartStatus.value = !!data.length;
      if (!data.length) return;

      // 渠道买卡转化率同比分析图表数据
      let axis: string[] = [],
        barsData: number[] = [],
        linesData: number[] = [];
      for (let item of data) {
        axis.push(item.eventTypeName);
        barsData.push(item.buyCardConversionRate ?? 0);
        linesData.push(item.buyCardConversionRateIncreasePer ?? 0);
      }
      let oneScreenValue = isMobile.value ? 5 : 16, // 横向 一屏数据展示的基准值
        dataZoom = [
          {
            type: isMobile.value ? 'inside' : 'slider',
            start: 0,
            end: Math.floor((oneScreenValue * 100) / (axis.length || oneScreenValue)),
            zoomLock: !isMobile.value,
            zoomOnMouseWheel: false,
            brushSelect: false,
            padding: [10, 20, 10, 20]
          }
        ];
      channelBuyCardChartData.value = {
        title: '渠道买卡转化率同比分析',
        xAxisBoundaryGap: true,
        xAxisLabelRotate: 45,
        yAxisUnit: '%',
        grid: { top: '20%', bottom: '5%' },
        axis,
        series: [
          {
            type: 'bar',
            name: '买卡转化率(%)',
            data: barsData,
            label: { show: true, position: 'insideBottom', formatter: '{c}%' },
            barMaxWidth: 40
          },
          {
            type: 'line',
            name: '同比(%)',
            data: linesData,
            smooth: true,
            label: { show: true, formatter: '{c}%' }
          }
        ],
        tooltip: { axisPointer: { type: 'shadow' } },
        colors: ['#97B9E0', '#5089BC'],
        // 导轨
        ...(axis.length > oneScreenValue ? { dataZoom } : {})
      };
    }
  } catch {
  } finally {
    memberChannelTableLoading.value = false;
  }
};

/**体验顾客分析-买卡转化分析数据*/
//  各个店铺散点矩阵数据集
const shopsMatrixStatus = ref(false);
const shopsMatrixData = ref<Chart.FourQuadrantChartType<Chart.ShopMatrixItemType>>({});
const selectorValue = ref<ModelValueType>(1);
// 监听selector组件值
watch(selectorValue, () => {
  getMemberBuyCardConversionAnalyseData(cacheSearchData);
  getMemberBuyCardConversionForShopData(cacheShopSearchData);
});
// 消费项目类型
const selectorOptions: SelectorOptionItemType[] = [
  { name: '当期', value: 1 },
  { name: '累计', value: 2 }
];
const getMemberBuyCardConversionAnalyseData = async (arg: SearchParamsType) => {
  try {
    const { shopIdList, startMonth, endMonth } = toValue(arg);
    const params = { shopIdList, startMonth, endMonth, periodType: selectorValue.value };
    const { val: data, success } = await getMemberBuyCardConversionAnalysePort(params);
    if (success === '0') {
      shopsMatrixStatus.value = !!data.memberBuyCardConversion.length;
      if (!data.memberBuyCardConversion.length) return;

      shopsMatrixData.value = {
        title: '买卡转化矩阵',
        xAxisBaseLine: data.memberBuyCardConversionFourQuadrant.x,
        xAxisTipsName: '买卡转化率',
        xAxisUnit: '%',
        yAxisBaseLine: data.memberBuyCardConversionFourQuadrant.y,
        yAxisTipsName: '人均体验顾客买卡人数',
        yAxisUnit: '',
        originalData: data.memberBuyCardConversion.map(item => ({
          xAxisValue: item.buyCardConversionRate,
          yAxisValue: item.buyCardCount,
          name: item.shopName,
          shopId: +item.shopId
        })),
        routeCallback: debounce((data: any) => {
          let [, , name, shopId] = data.value;
          cacheShopSearchData = {
            ...cacheShopSearchData,
            shopIdList: [shopId as number],
            shopName: name as string
          };
          getMemberBuyCardConversionForShopData(cacheShopSearchData);
        }, 300),
        // 工具箱
        toolbox: {
          exportVisible: true,
          // 此处写导出逻辑
          exportPort: () => {
            ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
              useDownload({
                port: exportMemberBuyCardConversionAnalyseChartDataPort,
                fileName: '买卡转化分析',
                params
              })
            );
          }
        }
      };
    }
  } catch {}
};

/** 体验顾客分析-买卡转化门店数据 */
// 当前门店的买卡成功率的图表数据
const currentShopChartStatus = ref(false);
const currentShopChartData = ref<Chart.BaseChartType>({});
const tableData = ref<MemberBuyCardConversionForEmployeeItemType[]>([]);
const loading = ref(false);
const getMemberBuyCardConversionForShopData = async (arg: SearchParamsType) => {
  if (loading.value) return;
  try {
    loading.value = true;
    const { shopIdList, startMonth, endMonth /* , shopName  */ } = toValue(arg);
    const params = { shopIdList, startMonth, endMonth, periodType: selectorValue.value };
    const { val: data, success } = await getMemberBuyCardConversionForShopPort(params);
    if (success === '0') {
      currentShopChartStatus.value = !!data.memberBuyCardConversionForShop.length;
      if (currentShopChartStatus.value) {
        let axis: string[] = [];
        let barsData: number[] = [];
        let linesData: number[] = [];
        for (let item of data.memberBuyCardConversionForShop) {
          axis.push(item.saleMonth);
          barsData.push(item.buyCardConversionRate ?? 0);
          linesData.push(item.buyCardConversionRateIncreasePer ?? 0);
        }
        let oneScreenValue = isMobile.value ? 5 : 16, // 横向 一屏数据展示的基准值
          dataZoom = [
            {
              type: isMobile.value ? 'inside' : 'slider',
              start: 0,
              end: Math.floor((oneScreenValue * 100) / (axis.length || oneScreenValue)),
              zoomLock: !isMobile.value,
              zoomOnMouseWheel: false,
              brushSelect: false,
              padding: [10, 20, 10, 20]
            }
          ];
        currentShopChartData.value = {
          title: /* shopName */ '月度趋势图',
          xAxisBoundaryGap: true,
          xAxisLabelRotate: 30,
          yAxisUnit: '%',
          grid: { top: '20%', bottom: '4%' },
          axis,
          series: [
            {
              type: 'bar',
              name: '买卡成功率',
              data: barsData,
              label: { show: true, position: 'insideBottom', formatter: '{c}%' },
              barMaxWidth: 40
            },
            {
              type: 'line',
              name: '同比%',
              data: linesData,
              smooth: true,
              label: { show: true, formatter: '{c}%' }
            }
          ],
          tooltip: { axisPointer: { type: 'shadow' } },
          colors: ['#5B9BD5', '#ED7D31'],
          // 导轨
          ...(axis.length > oneScreenValue ? { dataZoom } : {})
        };
      }

      tableData.value = data.memberBuyCardConversionForEmployee;
    }
  } catch {
  } finally {
    loading.value = false;
  }
};

// 导出 门店买卡转化分析 table data
const exportMemberBuyCardConversionAnalyseData = () => {
  let { shopIdList, startMonth, endMonth } = toValue(cacheShopSearchData);
  let params = { shopIdList, startMonth, endMonth, periodType: selectorValue.value };
  ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
    useDownload({
      port: exportMemberBuyCardConversionForShopPort,
      fileName: '门店买卡转化分析表',
      params
    })
  );
};
</script>
