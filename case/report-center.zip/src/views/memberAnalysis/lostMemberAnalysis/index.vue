<template>
  <RubPage>
    <template #header>
      <div class="card pb0">
        <RubSearchForm
          read-auth-code="MENU_MEMBER_LOST_ANALYSE_READ"
          :is-months="false"
          @init="handleSearch"
          @search="handleSearch"
          @reset="handleReset"
        />
      </div>
    </template>
    <!--  一、基于MF消费能力-看R流失率  -->
    <el-card shadow="hover" class="mt14 pr" :body-style="{ paddingBottom: '10px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz20">一、基于MF消费能力-看R流失率</div>
        </div>
      </template>
      <RubEmptyTip :show="MFRMatrixChartStatus">
        <el-scrollbar>
          <RfmMatrixChart v-bind="MFRMatrixChartData" />
        </el-scrollbar>
      </RubEmptyTip>
      <div style="position: absolute; top: 20px; right: 20px">
        <el-tooltip class="box-item" effect="dark" placement="top">
          <template #content>
            <div style="max-width: 360px">{{ getQuestionMapItem(180) }}</div>
          </template>
          <el-icon class="pointer" size="20" color="#333">
            <Warning />
          </el-icon>
        </el-tooltip>
      </div>
    </el-card>
    <!--  二、已流失会员分析  -->
    <el-card shadow="hover" class="mt14 pr" :body-style="{ paddingBottom: '10px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz20">二、已流失会员分析</div>
        </div>
      </template>
      <el-card class="mb14 pr">
        <RubEmptyTip :show="lostMemberMatrixChartStatus">
          <el-scrollbar>
            <ShopMatrixChart v-bind="lostMemberMatrixChartData" />
          </el-scrollbar>
        </RubEmptyTip>
        <div style="position: absolute; top: 20px; right: 20px">
          <el-tooltip class="box-item" effect="dark" placement="top">
            <template #content>
              <div style="max-width: 360px">{{ getQuestionMapItem(181) }}</div>
            </template>
            <el-icon class="pointer" size="20" color="#333">
              <Warning />
            </el-icon>
          </el-tooltip>
        </div>
      </el-card>
      <el-card class="mb14 pr">
        <RubEmptyTip :show="shopLostMemberEChartStatus">
          <el-scrollbar>
            <RubDoubleYAxisChart v-bind="shopLostMemberEChartData" class="chart" style="height: 480px" />
          </el-scrollbar>
        </RubEmptyTip>
      </el-card>

      <el-row :gutter="14">
        <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12" class="mb10">
          <el-card>
            <view class="flex justify-end mb16">
              <el-button type="primary" plain size="small" @click="exportShopLostMemberData('consultant')">
                导出<el-icon class="el-icon--right"><Download /></el-icon>
              </el-button>
            </view>
            <el-table v-loading="loading" :data="consultantsTableData" class="wp-100" border height="560">
              <el-table-column prop="shopName" label="所属门店" align="center" min-width="120" />
              <el-table-column prop="empId" label="顾问工号" align="center" min-width="120" />
              <el-table-column prop="employeeName" label="顾问姓名" align="center" min-width="120" />
              <el-table-column prop="totalMemberCount" label="会员总数" align="center" min-width="120">
                <template #default="{ row }">{{ handleFilterTableRow(row, 'totalMemberCount') }}</template>
              </el-table-column>
              <el-table-column prop="newMemberCount" label="新增会员人数" align="center" min-width="120">
                <template #default="{ row }">{{ handleFilterTableRow(row, 'newMemberCount') }}</template>
              </el-table-column>
              <el-table-column prop="oldMemberCount" label="老会员人数" align="center" min-width="120">
                <template #default="{ row }">{{ handleFilterTableRow(row, 'oldMemberCount') }}</template>
              </el-table-column>
              <el-table-column prop="memberChurnCount" label="流失人数" align="center" min-width="120">
                <template #default="{ row }">{{ handleFilterTableRow(row, 'memberChurnCount') }}</template>
              </el-table-column>
              <el-table-column prop="memberChurnRatio" label="流失率" align="center" min-width="120">
                <template #default="{ row }">{{ handleFilterTableRow(row, 'memberChurnRatio') }}</template>
              </el-table-column>
            </el-table>
          </el-card>
        </el-col>
        <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="12" class="mb10">
          <el-card>
            <view class="flex justify-end mb16">
              <el-button type="primary" plain size="small" @click="exportShopLostMemberData('beautician')">
                导出<el-icon class="el-icon--right"><Download /></el-icon>
              </el-button>
            </view>
            <el-table v-loading="loading" :data="beauticiansTableData" class="wp-100" border height="560">
              <el-table-column prop="shopName" label="所属门店" align="center" min-width="120" />
              <el-table-column prop="empId" label="美容师工号" align="center" min-width="120" />
              <el-table-column prop="employeeName" label="美容师" align="center" min-width="120" />
              <el-table-column prop="employeeLevel" label="等级" align="center" min-width="120">
                <template #default="{ row }">{{ handleFilterTableRow(row, 'employeeLevel') ?? '/' }}</template>
              </el-table-column>
              <el-table-column prop="totalMemberCount" label="会员总数" align="center" min-width="120">
                <template #default="{ row }">{{ handleFilterTableRow(row, 'totalMemberCount') }}</template>
              </el-table-column>
              <el-table-column prop="newMemberCount" label="新增会员人数" align="center" min-width="120">
                <template #default="{ row }">{{ handleFilterTableRow(row, 'newMemberCount') }}</template>
              </el-table-column>
              <el-table-column prop="oldMemberCount" label="老会员人数" align="center" min-width="120">
                <template #default="{ row }">{{ handleFilterTableRow(row, 'oldMemberCount') }}</template>
              </el-table-column>
              <el-table-column prop="memberChurnCount" label="流失人数" align="center" min-width="120">
                <template #default="{ row }">{{ handleFilterTableRow(row, 'memberChurnCount') }}</template>
              </el-table-column>
              <el-table-column prop="memberChurnRatio" label="流失率" align="center" min-width="120">
                <template #default="{ row }">{{ handleFilterTableRow(row, 'memberChurnRatio') }}</template>
              </el-table-column>
            </el-table>
          </el-card>
        </el-col>
      </el-row>
    </el-card>
  </RubPage>
</template>

<!-- 流失会员分析 页面 -->
<script setup lang="ts" name="lostMemberAnalysis">
import { SearchParamsType } from '@/components/rub-search-form/interfaces';
import { Chart } from '@/typings/global';
import {
  getLostMemberChurnAnalysePort,
  MemberChurnRankingForBeauticianItemType,
  MemberChurnRankingForConsultantItemType,
  exportMemberChurnAnalyseChartDataPort,
  exportLostMemberForConsultantPort,
  exportLostMemberForBeauticianPort
} from '@/api/modules/memberAnalysis';
import { factoryDoubleYAxisOptions } from '@/views/memberAnalysis/common';
import RfmMatrixChart from '../components/rfm-matrix-chart.vue';
import ShopMatrixChart from '../components/shop-matrix-chart.vue';
import { handleFilterTableRow, getQuestionMapItem } from '@/utils';
import { ElMessageBox } from 'element-plus';
import { useDownload } from '@/hooks/useDownload';

let cacheSearchData: SearchParamsType = {} as SearchParamsType;
const handleSearch = (data: SearchParamsType) => {
  cacheSearchData = data;
  getLostMemberChurnAnalyseData(data);
};

const handleReset = (data: SearchParamsType) => {
  handleSearch(data);
};

//  基于MFR消费能力 矩阵数据
const MFRMatrixChartStatus = ref(false);
const MFRMatrixChartData = ref<Chart.FourQuadrantChartType<Chart.RfmMatrixItemType>>({});

// 已流失会员分析 矩阵数据
const lostMemberMatrixChartStatus = ref(false);
const lostMemberMatrixChartData = ref<Chart.FourQuadrantChartType<Chart.ShopMatrixItemType>>({});

// 对应店铺流失 echarts图表
const shopLostMemberEChartStatus = ref(false);
const shopLostMemberEChartData = ref<Chart.DoubleYAxisChartType>({});

// 顾问表格数据 table data
const consultantsTableData = ref<MemberChurnRankingForConsultantItemType[]>([]);

// 美容师表格数据 table data
const beauticiansTableData = ref<MemberChurnRankingForBeauticianItemType[]>([]);

const loading = ref(false);
const getLostMemberChurnAnalyseData = async (args: SearchParamsType) => {
  if (loading.value) return;
  try {
    loading.value = true;
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = { shopIdList, startMonth, endMonth };
    let { val: data, success } = await getLostMemberChurnAnalysePort(params);
    if (success === '0') {
      // 基于MF消费能力-看R流失率数据
      MFRMatrixChartStatus.value = !!data.mfrMatrix.length;
      if (data.mfrMatrix.length) {
        MFRMatrixChartData.value = {
          title: '活跃会员预警分析',
          xAxisBaseLine: data.mfrMatrixFourQuadrant.amount,
          xAxisTipsName: '月均消费金额',
          xAxisUnit: '元',
          yAxisBaseLine: data.mfrMatrixFourQuadrant.frequency,
          yAxisTipsName: '月均消费次数',
          yAxisUnit: '',
          // originalData: data.mfrMatrix.filter(item => item.amount || item.frequency)
          originalData: data.mfrMatrix.reduce((acc, item) => {
            if (item.amount || item.frequency) {
              acc.push({ xValue: item.amount, yValue: item.frequency });
            }
            return acc;
          }, [] as Chart.RfmMatrixItemType[])
        };
      }

      // 流失会员矩阵数据
      lostMemberMatrixChartStatus.value = !!data.memberChurnAnalyse.length;
      if (data.memberChurnAnalyse.length) {
        lostMemberMatrixChartData.value = {
          title: '流失会员矩阵',
          xAxisBaseLine: data.memberChurnAnalyseFourQuadrant.x,
          xAxisTipsName: '流失率',
          xAxisUnit: '%',
          yAxisBaseLine: data.memberChurnAnalyseFourQuadrant.y,
          yAxisTipsName: '人均流失人数',
          yAxisUnit: '',
          originalData: data.memberChurnAnalyse.map(item => ({
            xAxisValue: item.memberChurnRatio,
            yAxisValue: item.avgMemberChurnCount,
            name: item.shopName
          })),
          grid: { top: '16%', bottom: '5%' },
          // 工具箱
          toolbox: {
            exportVisible: true,
            // 此处写导出逻辑
            exportPort: () => {
              ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
                useDownload({
                  port: exportMemberChurnAnalyseChartDataPort,
                  fileName: '已流失会员分析',
                  params
                })
              );
            }
          }
        };
      }

      // 当前查询店铺的流失Chart图表数据
      shopLostMemberEChartStatus.value = !!data.memberChurnTrend.length;
      if (data.memberChurnTrend.length) {
        let axis: string[] = [],
          data1: number[] = [],
          data2: number[] = [];
        for (let item of data.memberChurnTrend) {
          axis.push(item.statMonth);
          data1.push(item.memberChurnCount);
          data2.push(item.memberChurnRatio);
        }
        shopLostMemberEChartData.value = factoryDoubleYAxisOptions({
          title: '门店流失分析',
          axis,
          name1: '流失人数',
          data1,
          name2: '流失率(%)',
          data2,
          colors: ['#4472C4', '#ED7B2E']
        });
      }

      // 顾问表格数据 table data
      consultantsTableData.value = data.memberChurnRankingForConsultant;
      // 美容师表格数据 table data
      beauticiansTableData.value = data.memberChurnRankingForBeautician;
    }
  } catch (e) {
    console.log('e : ', e);
  } finally {
    loading.value = false;
  }
};

// 导出流失会员table表格数据
const exportShopLostMemberData = (name: string) => {
  const port = name === 'consultant' ? exportLostMemberForConsultantPort : exportLostMemberForBeauticianPort;
  const fileName = name === 'consultant' ? '顾问' : '美容师';
  const { shopIdList, startMonth, endMonth } = toValue(cacheSearchData);
  const params = { shopIdList, startMonth, endMonth };
  ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
    useDownload({
      port,
      fileName: `流失会员分析-${fileName}表`,
      params
    })
  );
};
</script>
