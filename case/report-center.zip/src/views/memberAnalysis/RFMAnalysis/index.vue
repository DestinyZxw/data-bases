<template>
  <RubPage>
    <template #header>
      <div class="card pb0">
        <RubSearchForm
          read-auth-code="MENU_MEMBER_RFM_ANALYSE_READ"
          :is-months="false"
          @init="handleSearch"
          @search="handleSearch"
          @reset="handleReset"
        />
      </div>
    </template>

    <el-card shadow="hover" class="mt14 pr" :body-style="{ padding: '14px 14px 8px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz20">一、会员分层</div>
        </div>
      </template>
      <el-row :gutter="10">
        <el-col :xs="24" :sm="24" :md="6" :lg="4" :xl="4" class="mb10">
          <el-card>
            <RubDoubleYAxisChart v-bind="memberCountChartData" style="height: 600px" />
          </el-card>
        </el-col>
        <el-col :xs="24" :sm="24" :md="18" :lg="20" :xl="20" class="mb10">
          <el-card>
            <RubEmptyTip :show="treemapChartStatus">
              <el-scrollbar>
                <RubTreeMapChart v-bind="treemapChartData" class="chart" />
              </el-scrollbar>
            </RubEmptyTip>
          </el-card>
        </el-col>
        <el-col :xs="24" :sm="24" :md="24" :lg="24" :xl="12" class="mb10">
          <el-card>
            <RubEmptyTip :show="pieChartsStatus">
              <el-scrollbar>
                <RubPieChart v-bind="pieChartsData" class="pieChart" />
              </el-scrollbar>
            </RubEmptyTip>
          </el-card>
        </el-col>
        <el-col :xs="24" :sm="24" :md="24" :lg="24" :xl="12" class="mb10">
          <el-card>
            <RubEmptyTip :show="memberLevelChartStatus">
              <RubDoubleYAxisChart v-bind="memberLevelChartData" style="height: 400px" />
            </RubEmptyTip>
          </el-card>
        </el-col>
      </el-row>
    </el-card>

    <el-card shadow="hover" class="mt14 pr" :body-style="{ paddingBottom: '10px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz20">
            二、基于MF看R
            <el-popover placement="top" :width="360" trigger="hover" effect="dark">
              <template #reference>
                <el-icon class="pointer" size="18" color="#333">
                  <Warning />
                </el-icon>
              </template>
              <div>
                <div style="margin-bottom: 10px" v-for="(item, index) in getQuestionMapObj([94, 95])" :key="index">
                  <div class="font-bold">{{ item.name }}:</div>
                  <div>{{ item.description }}</div>
                </div>
              </div>
            </el-popover>
          </div>
        </div>
      </template>
      <RubEmptyTip :show="MFXMatrixStatus">
        <el-scrollbar>
          <RfmMatrixChart v-bind="MFXMatrixData" key="first" />
        </el-scrollbar>
      </RubEmptyTip>
    </el-card>
  </RubPage>
</template>

<!-- RFM分析 页面 -->
<script setup lang="ts" name="RFMAnalysis">
import { getMemberStratificationPort } from '@/api/modules/memberAnalysis';
import { SearchParamsType } from '@/components/rub-search-form/interfaces';
import { Chart } from '@/typings/global';
import RfmMatrixChart from '../components/rfm-matrix-chart.vue';
import { factoryDoubleYAxisOptions } from '@/views/memberAnalysis/common';
import { getQuestionMapObj } from '@/utils';

const handleSearch = (data: SearchParamsType) => {
  getMemberStratificationData(data);
};

const handleReset = (data: SearchParamsType) => {
  handleSearch(data);
};

// 会员类型人数数据
const memberCountChartData = ref<Chart.DoubleYAxisChartType>({});

// 会员分层数据
const treemapChartStatus = ref(false);
const treemapChartData = ref<Chart.TreeMapChartType>({});

// pie饼图数据
const pieChartsStatus = ref(false);
const pieChartsData = ref<Chart.PieChartType>({} as Chart.PieChartType);

// 会员分层贡献
const memberLevelChartStatus = ref(false);
const memberLevelChartData = ref<Chart.DoubleYAxisChartType>({});

//  RFM 矩阵数据
const MFXMatrixStatus = ref(false);
const MFXMatrixData = ref<Chart.FourQuadrantChartType<Chart.RfmMatrixItemType>>({});

// 获取RFM分层的数据
const getMemberStratificationData = async (arg: SearchParamsType) => {
  try {
    const { shopIdList, startMonth, endMonth } = toValue(arg);
    const params = { shopIdList, startMonth, endMonth };
    const { val: data, success } = await getMemberStratificationPort(params);
    if (success === '0') {
      // 颜色的映射
      const colorsMap = new Map([
        ['一般会员', '#F4B183'],
        ['新会员', '#E2F0D9'],
        ['发展会员', '#A9D18E'],
        ['流失会员', '#C00000'],
        ['大客户', '#00B050'],
        ['价值会员', '#70AD47'],
        ['沉默会员', '#FF0000'],
        ['睡眠会员', '#FF7C80']
      ]);

      // 会员人数 图表数据
      memberCountChartData.value = {
        title: '会员人数',
        xAxisVisible: false,
        xAxisLabelRotate: 0,
        yAxisRightUnit: '%',
        yAxisRightVisible: false,
        yAxisNameVisible: false,
        axis: ['人数'],
        grid: { left: '25%', top: '10%', bottom: '4%' },
        series: [{ type: 'bar', name: '', data: [data.totalCount], label: { show: true, position: 'inside' }, barMaxWidth: 40 }],
        colors: ['#44546A']
      };

      // RFM会员分层 图表数据
      let stratification: Chart.TreeMapItem[] = [];
      let stratificationEntries = Object.entries(data.stratification ?? {});
      treemapChartStatus.value = !!stratificationEntries.length;
      if (stratificationEntries.length) {
        for (let [key, value] of stratificationEntries) {
          stratification.push({ name: key, value, itemStyle: { color: colorsMap.get(key) as string } });
        }
        treemapChartData.value = { title: 'RFM会员分层', data: stratification };
      }

      // 会员分层人数占比 图表数据
      let stratificationCountRatio: Chart.PieSeriesItemType[] = [];
      let stratificationCountRatioEntries = Object.entries(data.stratificationCountRatio ?? {});
      pieChartsStatus.value = !!stratificationCountRatioEntries.length;
      if (stratificationCountRatioEntries.length) {
        for (let [key, value] of stratificationCountRatioEntries) {
          stratificationCountRatio.push({ name: key, value, itemStyle: { color: colorsMap.get(key) as string } });
        }
        pieChartsData.value = { name: '会员分层人数占比', position: 'outside', data: stratificationCountRatio };
      }

      // 会员分层贡献 图表数据
      let memberLevelAxis: string[] = Object.keys(data.stratificationContribute ?? {});
      memberLevelChartStatus.value = !!memberLevelAxis.length;
      if (memberLevelAxis.length) {
        let memberLevelAmounts: { value: number; itemStyle: { color: string } }[] = [];
        let memberLevelRatios: number[] = [];
        for (let i = 0; i < memberLevelAxis.length; i++) {
          const key = memberLevelAxis[i];
          const value = data.stratificationContribute[key];
          memberLevelAmounts.push({ value: value.amount, itemStyle: { color: colorsMap.get(key) as string } });
          memberLevelRatios.push(value.ratio ?? 0);
        }
        memberLevelChartData.value = factoryDoubleYAxisOptions({
          title: '会员分层贡献',
          axis: memberLevelAxis,
          name1: '消费金额',
          data1: memberLevelAmounts,
          name2: '消费金额占比(%)',
          data2: memberLevelRatios,
          colors: ['#A5A5A5', '#ED7B2E']
        });
      }

      // MF_R矩阵图 图表数据
      MFXMatrixStatus.value = !!data.mfrMatrix.length;
      if (!data.mfrMatrix.length) return;
      // let MFROriginData: Chart.RfmMatrixItemType[] = data.mfrMatrix.filter(item => item.amount || item.frequency);
      let MFROriginData = data.mfrMatrix.reduce((acc, item) => {
        if (item.amount || item.frequency) {
          acc.push({ xValue: item.amount, yValue: item.frequency });
        }
        return acc;
      }, [] as Chart.RfmMatrixItemType[]);
      MFXMatrixData.value = {
        title: 'MF_R矩阵图',
        xAxisBaseLine: data.memberMfrFourQuadrant.amount,
        xAxisTipsName: '消费金额',
        xAxisUnit: '元',
        yAxisBaseLine: data.memberMfrFourQuadrant.frequency,
        yAxisTipsName: '月消费频次',
        yAxisUnit: '',
        originalData: MFROriginData
      };
    }
  } catch {}
};
</script>
