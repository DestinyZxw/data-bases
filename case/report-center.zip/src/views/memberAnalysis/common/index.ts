export type FactoryOptionType = {
  title: string;
  axis: string[];
  yAxisRightUnit?: string;
  name1: string;
  data1: (number | { value: number; [key: string]: any })[];
  name2: string;
  data2: number[];
  colors: string[];
};

export const factoryDoubleYAxisOptions = (options: FactoryOptionType) => {
  const yAxisRightUnit = options.yAxisRightUnit ?? '%';
  return {
    title: options.title,
    xAxisLabelRotate: 0,
    yAxisRightUnit,
    yAxisLeftVisible: false,
    yAxisRightVisible: false,
    yAxisNameVisible: false,
    axis: options.axis,
    grid: { top: '20%', bottom: '5%' },
    series: [
      {
        type: 'bar',
        name: options.name1,
        data: options.data1,
        label: { show: true, position: 'insideBottom' },
        barMaxWidth: 40
      },
      {
        type: yAxisRightUnit === '%' ? 'line' : 'bar',
        name: options.name2,
        data: options.data2,
        smooth: true,
        label: { show: true, formatter: `{c}${yAxisRightUnit}` },
        ...(yAxisRightUnit === '%' ? {} : { barMaxWidth: 40 }),
        yAxisIndex: 1
      }
    ],
    colors: options.colors
  };
};
