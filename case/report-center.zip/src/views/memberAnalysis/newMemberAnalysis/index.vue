<template>
  <RubPage>
    <template #header>
      <div class="card pb0">
        <RubSearchForm
          read-auth-code="MENU_NEW_MEMBER_ANALYSE_READ"
          :is-months="false"
          @init="handleSearch"
          @search="handleSearch"
          @reset="handleReset"
        />
      </div>
    </template>

    <el-card shadow="hover" class="mt14 pr" :body-style="{ padding: '14px 14px 8px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz20">一、关键指标</div>
        </div>
      </template>
      <el-row :gutter="10">
        <el-col :xs="24" :sm="24" :md="8" :lg="8" :xl="4" class="mb10">
          <div style="height: 544px">
            <el-row :gutter="10">
              <el-col :span="24" class="mb10">
                <el-card class="small-card">
                  <div style="height: 134px" class="flex flex-col items-center justify-center">
                    <div>消费金额（万元）</div>
                    <div class="font-bold pt10 pb10">{{ keyIndicatorData.newMemberAmount ?? '--' }}</div>
                    <div>
                      复合同比:
                      <template v-if="keyIndicatorData.newMemberAmountIncreasePer !== null">
                        <span :class="[keyIndicatorData.newMemberAmountIncreasePer >= 0 ? 'upward' : 'downward']">
                          {{ keyIndicatorData.newMemberAmountIncreasePer + '%' }}
                          {{ keyIndicatorData.newMemberAmountIncreasePer >= 0 ? '↑' : '↓' }}
                        </span>
                      </template>
                      <template v-else>
                        {{ keyIndicatorData.newMemberAmountIncreasePer ?? '--' }}
                      </template>
                    </div>
                  </div>
                </el-card>
              </el-col>
              <el-col :span="24" class="mb10">
                <el-card class="small-card">
                  <div style="height: 134px" class="flex flex-col items-center justify-center">
                    <div>消费次数</div>
                    <div class="font-bold pt10 pb10">{{ keyIndicatorData.newMemberCounts ?? '--' }}</div>
                    <div>
                      复合同比:
                      <template v-if="keyIndicatorData.newMemberCountsIncreasePer !== null">
                        <span :class="[keyIndicatorData.newMemberCountsIncreasePer >= 0 ? 'upward' : 'downward']">
                          {{ keyIndicatorData.newMemberCountsIncreasePer + '%' }}
                          {{ keyIndicatorData.newMemberCountsIncreasePer >= 0 ? '↑' : '↓' }}
                        </span>
                      </template>
                      <template v-else>
                        {{ keyIndicatorData.newMemberCountsIncreasePer ?? '--' }}
                      </template>
                    </div>
                  </div>
                </el-card>
              </el-col>
              <el-col :span="24" class="mb10">
                <el-card class="small-card">
                  <div style="height: 134px" class="flex flex-col items-center justify-center">
                    <div>人次客单（元/次）</div>
                    <div class="font-bold pt10 pb10">{{ keyIndicatorData.perCapitaRevenue ?? '--' }}</div>
                    <div>
                      复合同比:
                      <template v-if="keyIndicatorData.perCapitaRevenueIncreasePer !== null">
                        <span :class="[keyIndicatorData.perCapitaRevenueIncreasePer >= 0 ? 'upward' : 'downward']">
                          {{ keyIndicatorData.perCapitaRevenueIncreasePer + '%' }}
                          {{ keyIndicatorData.perCapitaRevenueIncreasePer >= 0 ? '↑' : '↓' }}
                        </span>
                      </template>
                      <template v-else>
                        {{ keyIndicatorData.perCapitaRevenueIncreasePer ?? '--' }}
                      </template>
                    </div>
                  </div>
                </el-card>
              </el-col>
            </el-row>
          </div>
        </el-col>
        <el-col :xs="24" :sm="24" :md="8" :lg="8" :xl="4" class="mb10">
          <div style="height: 544px">
            <el-row :gutter="10">
              <el-col :span="24" class="mb10">
                <el-card class="small-card">
                  <div style="height: 134px" class="flex flex-col items-center justify-center">
                    <div>
                      新会员消费占比
                      <el-tooltip class="box-item" effect="dark" placement="top">
                        <template #content>
                          <div style="max-width: 360px">{{ getQuestionMapItem(114) }}</div>
                        </template>
                        <el-icon class="pointer" size="20" color="#333">
                          <Warning />
                        </el-icon>
                      </el-tooltip>
                    </div>
                    <div class="font-bold pt10 pb10">
                      {{ keyIndicatorData.newConsumeRate ? keyIndicatorData.newConsumeRate + '%' : '--' }}
                    </div>
                    <div>
                      复合同比:
                      <template v-if="keyIndicatorData.newConsumeRateIncreasePer !== null">
                        <span :class="[keyIndicatorData.newConsumeRateIncreasePer >= 0 ? 'upward' : 'downward']">
                          {{ keyIndicatorData.newConsumeRateIncreasePer + '%' }}
                          {{ keyIndicatorData.newConsumeRateIncreasePer >= 0 ? '↑' : '↓' }}
                        </span>
                      </template>
                      <template v-else>
                        {{ keyIndicatorData.newConsumeRateIncreasePer ?? '--' }}
                      </template>
                    </div>
                  </div>
                </el-card>
              </el-col>
              <el-col :span="24" class="mb10">
                <el-card class="small-card">
                  <div style="height: 134px" class="flex flex-col items-center justify-center">
                    <div>消费频次</div>
                    <div class="font-bold pt10 pb10">{{ keyIndicatorData.consumeFreq ?? '--' }}</div>
                    <div>
                      复合同比:
                      <template v-if="keyIndicatorData.consumeFreqIncreasePer !== null">
                        <span :class="[keyIndicatorData.consumeFreqIncreasePer >= 0 ? 'upward' : 'downward']">
                          {{ keyIndicatorData.consumeFreqIncreasePer + '%' }}
                          {{ keyIndicatorData.consumeFreqIncreasePer >= 0 ? '↑' : '↓' }}
                        </span>
                      </template>
                      <template v-else>
                        {{ keyIndicatorData.consumeFreqIncreasePer ?? '--' }}
                      </template>
                    </div>
                  </div>
                </el-card>
              </el-col>
              <el-col :span="24" class="mb10">
                <el-card class="small-card">
                  <div style="height: 134px" class="flex flex-col items-center justify-center">
                    <div>
                      复购充值人数
                      <el-tooltip class="box-item" effect="dark" placement="top">
                        <template #content>
                          <div style="max-width: 360px">{{ getQuestionMapItem(115) }}</div>
                        </template>
                        <el-icon class="pointer" size="20" color="#333">
                          <Warning />
                        </el-icon>
                      </el-tooltip>
                    </div>
                    <div class="font-bold pt10 pb10">{{ keyIndicatorData.repCounts ?? '--' }}</div>
                    <div>
                      复合同比:
                      <template v-if="keyIndicatorData.repCountsIncreasePer !== null">
                        <span :class="[keyIndicatorData.repCountsIncreasePer >= 0 ? 'upward' : 'downward']">
                          {{ keyIndicatorData.repCountsIncreasePer + '%' }}
                          {{ keyIndicatorData.repCountsIncreasePer >= 0 ? '↑' : '↓' }}
                        </span>
                      </template>
                      <template v-else>
                        {{ keyIndicatorData.repCountsIncreasePer ?? '--' }}
                      </template>
                    </div>
                  </div>
                </el-card>
              </el-col>
            </el-row>
          </div>
        </el-col>
        <el-col :xs="24" :sm="24" :md="8" :lg="8" :xl="4" class="mb10">
          <div style="height: 544px">
            <el-row :gutter="10">
              <el-col :span="24" class="mb10">
                <el-card class="small-card">
                  <div style="height: 134px" class="flex flex-col items-center justify-center">
                    <div>
                      复购充值金额（万元）
                      <el-tooltip class="box-item" effect="dark" placement="top">
                        <template #content>
                          <div style="max-width: 360px">{{ getQuestionMapItem(116) }}</div>
                        </template>
                        <el-icon class="pointer" size="20" color="#333">
                          <Warning />
                        </el-icon>
                      </el-tooltip>
                    </div>
                    <div class="font-bold pt10 pb10">{{ keyIndicatorData.repAmount ?? '--' }}</div>
                    <div>
                      复合同比:
                      <template v-if="keyIndicatorData.repAmountIncreasePer !== null">
                        <span :class="[keyIndicatorData.repAmountIncreasePer >= 0 ? 'upward' : 'downward']">
                          {{ keyIndicatorData.repAmountIncreasePer + '%' }}
                          {{ keyIndicatorData.repAmountIncreasePer >= 0 ? '↑' : '↓' }}
                        </span>
                      </template>
                      <template v-else>
                        {{ keyIndicatorData.repAmountIncreasePer ?? '--' }}
                      </template>
                    </div>
                  </div>
                </el-card>
              </el-col>
              <el-col :span="24" class="mb10">
                <el-card class="small-card">
                  <div style="height: 134px" class="flex flex-col items-center justify-center">
                    <div>
                      复购充值客单（元/次）
                      <el-tooltip class="box-item" effect="dark" placement="top">
                        <template #content>
                          <div style="max-width: 360px">{{ getQuestionMapItem(117) }}</div>
                        </template>
                        <el-icon class="pointer" size="20" color="#333">
                          <Warning />
                        </el-icon>
                      </el-tooltip>
                    </div>
                    <div class="font-bold pt10 pb10">{{ keyIndicatorData.prp ?? '--' }}</div>
                    <div>
                      复合同比:
                      <template v-if="keyIndicatorData.prpIncreasePer !== null">
                        <span :class="[keyIndicatorData.prpIncreasePer >= 0 ? 'upward' : 'downward']">
                          {{ keyIndicatorData.prpIncreasePer + '%' }}
                          {{ keyIndicatorData.prpIncreasePer >= 0 ? '↑' : '↓' }}
                        </span>
                      </template>
                      <template v-else>
                        {{ keyIndicatorData.prpIncreasePer ?? '--' }}
                      </template>
                    </div>
                  </div>
                </el-card>
              </el-col>
              <el-col :span="24" class="mb10">
                <el-card class="small-card">
                  <div style="height: 134px" class="flex flex-col items-center justify-center">
                    <div>
                      复购率
                      <el-tooltip class="box-item" effect="dark" placement="top">
                        <template #content>
                          <div style="max-width: 360px">{{ getQuestionMapItem(118) }}</div>
                        </template>
                        <el-icon class="pointer" size="20" color="#333">
                          <Warning />
                        </el-icon>
                      </el-tooltip>
                    </div>
                    <div class="font-bold pt10 pb10">
                      {{ keyIndicatorData.repeatBuyCardRate ? keyIndicatorData.repeatBuyCardRate + '%' : '--' }}
                    </div>
                    <div>
                      复合同比:
                      <template v-if="keyIndicatorData.repeatBuyCardRateIncreasePer !== null">
                        <span :class="[keyIndicatorData.repeatBuyCardRateIncreasePer >= 0 ? 'upward' : 'downward']">
                          {{ keyIndicatorData.repeatBuyCardRateIncreasePer + '%' }}
                          {{ keyIndicatorData.repeatBuyCardRateIncreasePer >= 0 ? '↑' : '↓' }}
                        </span>
                      </template>
                      <template v-else>
                        {{ keyIndicatorData.repeatBuyCardRateIncreasePer ?? '--' }}
                      </template>
                    </div>
                  </div>
                </el-card>
              </el-col>
            </el-row>
          </div>
        </el-col>
        <el-col :xs="24" :sm="24" :md="24" :lg="24" :xl="12" class="mb10">
          <el-card>
            <RubEmptyTip :show="consumptionIntervalChartStatus">
              <RubBaseChart v-bind="consumptionIntervalChartData" style="height: 506px" />
            </RubEmptyTip>
          </el-card>
        </el-col>
      </el-row>
    </el-card>

    <el-card shadow="hover" class="mt14 pr" :body-style="{ paddingBottom: '10px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz20">二、新会员复购买卡分析</div>
        </div>
      </template>

      <div class="selector mb20">
        <div class="name">期间</div>
        <RubSelector v-model="selectorValue" :options="selectorOptions" auth-code="MENU_NEW_MEMBER_ANALYSE_READ" />
      </div>

      <el-card class="mb10">
        <el-scrollbar>
          <RubEmptyTip :show="shopsMatrixStatus">
            <ShopMatrixChart v-bind="shopsMatrixData" key="first" />
          </RubEmptyTip>
        </el-scrollbar>
      </el-card>

      <el-card class="mb10">
        <RubEmptyTip :show="memberLevelChartStatus">
          <el-scrollbar>
            <RubBaseChart class="chart" v-bind="memberLevelChartData" style="height: 480px" />
          </el-scrollbar>
        </RubEmptyTip>
      </el-card>

      <el-card class="mb10">
        <view class="flex justify-end mb16">
          <el-button type="primary" plain size="small" @click="exportEmployeeRankingData">
            导出<el-icon class="el-icon--right"><Download /></el-icon>
          </el-button>
        </view>
        <el-table v-loading="employeeRankingTableLoading" :data="employeeRankingTableData" class="wp-100" border height="560">
          <el-table-column prop="employeeName" label="顾问" align="center" min-width="120" />
          <el-table-column label="当期" align="center">
            <el-table-column prop="repetitionBuyCardCount" label="复购人数" align="center" min-width="120">
              <template #default="{ row }">{{ handleFilterTableRow(row, 'repetitionBuyCardCount') }}</template>
            </el-table-column>
            <el-table-column prop="repetitionBuyCardRate" label="复购率" align="center" min-width="150">
              <template #default="{ row }">{{ handleFilterTableRow(row, 'repetitionBuyCardRate') }}</template>
            </el-table-column>
          </el-table-column>

          <el-table-column label="累计" align="center">
            <el-table-column prop="repetitionBuyCardCountGrandTotal" label="复购人数" align="center" min-width="120">
              <template #default="{ row }">{{ handleFilterTableRow(row, 'repetitionBuyCardCountGrandTotal') }}</template>
            </el-table-column>
            <el-table-column prop="repetitionBuyCardRateGrandTotal" label="复购率" align="center" min-width="150">
              <template #default="{ row }">{{ handleFilterTableRow(row, 'repetitionBuyCardRateGrandTotal') }}</template>
            </el-table-column>
          </el-table-column>
        </el-table>
      </el-card>
    </el-card>

    <el-card shadow="hover" class="mt14 pr" :body-style="{ paddingBottom: '10px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz20">三、新会员首次产品消费分析</div>
        </div>
      </template>
      <el-scrollbar>
        <RubEmptyTip :show="productMatrixChartStatus" class="mb10">
          <RfmMatrixChart v-bind="productMatrixChartData" key="first" />
        </RubEmptyTip>
      </el-scrollbar>
    </el-card>

    <el-card shadow="hover" class="mt14 pr" :body-style="{ paddingBottom: '10px' }">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz20">四、新会员复购护理买卡间隔</div>
        </div>
      </template>
      <el-scrollbar>
        <RubEmptyTip :show="nurseMatrixChartStatus" class="mb10">
          <RfmMatrixChart v-bind="nurseMatrixChartData" key="first" />
        </RubEmptyTip>
      </el-scrollbar>
    </el-card>
  </RubPage>
</template>

<!-- 新会员分析 页面 -->
<script setup lang="ts" name="newMemberAnalysis">
import { SearchParamsType } from '@/components/rub-search-form/interfaces';
import { Chart } from '@/typings/global';
import RfmMatrixChart from '../components/rfm-matrix-chart.vue';
import { ModelValueType, SelectorOptionItemType } from '@/components/rub-selector/index.vue';
import { debounce } from 'lodash-es';
import {
  getMemberFirstConsumeOfCardIntervalDaysPort,
  getMemberFirstConsumeOfProductIntervalDaysPort,
  getMemberRepetitionBuyCardOfShopPort,
  getNewMemberAnalysisKeyIndicatorDataPort,
  getNewMemberAnalysisMonthlyTrendAndEmployeeRankingPort,
  exportNewMemberAnalysisMonthlyTrendAndEmployeeRankingPort,
  NewMemberAnalysisEmployeeRankingType,
  NewMemberAnalysisKeyIndicatorType,
  exportMemberRepetitionBuyCardOfShopChartDataPort,
  exportMemberFirstConsumeOfProductIntervalDaysChartDataPort,
  exportMemberFirstConsumeOfCardIntervalDaysChartDataPort
} from '@/api/modules/memberAnalysis';
import ShopMatrixChart from '../components/shop-matrix-chart.vue';
import { handleFilterTableRow, getQuestionMapItem } from '@/utils';
import { ElMessageBox } from 'element-plus';
import { useDownload } from '@/hooks/useDownload';

let cacheSearchData = {} as SearchParamsType; // 缓存查询数据
let cacheShopSearchData = {} as SearchParamsType; // 缓存与指定门店相关联的 门店复购率 查询参数

const handleSearch = (data: SearchParamsType) => {
  cacheSearchData = data;
  cacheShopSearchData = data;
  getKeyIndicatorData(data);
  getMemberRepetitionBuyCardOfShopData(data);
  getEmployeeRankingData(data);
  getMemberFirstConsumeOfProductIntervalDaysData(data);
  getMemberFirstConsumeOfCardIntervalDaysData(data);
};

const handleReset = (data: SearchParamsType) => {
  handleSearch(data);
};

/** 关键指标 */
const keyIndicatorData = ref<NewMemberAnalysisKeyIndicatorType>({} as NewMemberAnalysisKeyIndicatorType);

// 消费间隔(天) 数据
const consumptionIntervalChartStatus = ref(false);
const consumptionIntervalChartData = ref<Chart.BaseChartType>({});

const getKeyIndicatorData = async (args: SearchParamsType) => {
  try {
    let { shopIdList, startMonth, endMonth, memberType } = toValue(args);
    let params = { shopIdList, startMonth, endMonth, memberType };
    let { val: data, success } = await getNewMemberAnalysisKeyIndicatorDataPort(params);
    if (success === '0') {
      keyIndicatorData.value = data;

      consumptionIntervalChartStatus.value = !!data.consumeInterval.length;
      if (!data.consumeInterval.length) return;

      const colors = ['#5B9BD5', '#ED7D31'];
      let axis: string[] = [];
      let consumptionInterval: { value: number; itemStyle: { color: string } }[] = []; // 消费间隔

      for (let i = 0; i < data.consumeInterval.length; i++) {
        let { typeName, consumeInterval } = data.consumeInterval[i];
        let color = colors[i];
        axis.push(typeName);
        consumptionInterval.push({ value: consumeInterval, itemStyle: { color } });
      }

      consumptionIntervalChartData.value = {
        title: '消费间隔(天)',
        xAxisBoundaryGap: true,
        xAxisLabelRotate: 0,
        yAxisVisible: false,
        grid: { top: '10%', bottom: '0' },
        axis: axis,
        series: [
          {
            type: 'bar',
            name: '',
            data: consumptionInterval,
            label: { show: true, position: 'top' },
            barMaxWidth: 40
          }
        ]
      };
    }
  } catch (e) {
    console.log('e : ', e);
  }
};

/** 新会员复购买卡分析 */
// 现金复购买卡矩阵
const shopsMatrixStatus = ref(false);
const shopsMatrixData = ref<Chart.FourQuadrantChartType<Chart.ShopMatrixItemType>>({});
const selectorValue = ref<ModelValueType>(1);
// 监听selector组件值
watch(selectorValue, () => {
  getMemberRepetitionBuyCardOfShopData(cacheSearchData);
  getEmployeeRankingData(cacheShopSearchData);
});
// 消费项目类型
const selectorOptions: SelectorOptionItemType[] = [
  { name: '当期', value: 1 },
  { name: '累计', value: 2 }
];
const getMemberRepetitionBuyCardOfShopData = async (args: SearchParamsType) => {
  try {
    const { shopIdList, startMonth, endMonth } = toValue(args);
    const params = { shopIdList, startMonth, endMonth, periodType: selectorValue.value };
    const { val: data, success } = await getMemberRepetitionBuyCardOfShopPort(params);
    if (success === '0') {
      shopsMatrixStatus.value = !!data.memberRepetitionBuyCardOfShop.length;
      if (!data.memberRepetitionBuyCardOfShop.length) return;

      shopsMatrixData.value = {
        title: '现金复购买卡矩阵',
        xAxisBaseLine: data.memberRepetitionBuyCardOfShopFourQuadrant.x,
        xAxisTipsName: '复购率',
        xAxisUnit: '%',
        yAxisBaseLine: data.memberRepetitionBuyCardOfShopFourQuadrant.y,
        yAxisTipsName: '复购人数',
        yAxisUnit: '',
        originalData: data.memberRepetitionBuyCardOfShop.map(item => ({
          xAxisValue: item.repetitionBuyCardRate,
          yAxisValue: item.repetitionBuyCardCount,
          name: item.shopName,
          shopId: +item.shopId
        })),
        routeCallback: debounce((data: any) => {
          let [, , name, shopId] = data.value;
          cacheShopSearchData = {
            ...cacheShopSearchData,
            shopIdList: [shopId as number],
            shopName: name as string
          }; // 缓存数据
          getEmployeeRankingData(cacheShopSearchData);
        }, 300),

        // 工具箱
        toolbox: {
          exportVisible: true,
          // 此处写导出逻辑
          exportPort: () => {
            ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
              useDownload({
                port: exportMemberRepetitionBuyCardOfShopChartDataPort,
                fileName: '新会员复购买卡分析',
                params
              })
            );
          }
        }
      };
    }
  } catch {}
};

// 月度趋势和顾问排名
const employeeRankingTableData = ref<NewMemberAnalysisEmployeeRankingType[]>([]);

// 会员等晋毛利贡献数据
const memberLevelChartStatus = ref(false);
const memberLevelChartData = ref<Chart.BaseChartType>({});

const employeeRankingTableLoading = ref(false);
const getEmployeeRankingData = async (args: SearchParamsType) => {
  try {
    employeeRankingTableLoading.value = true;
    let { shopIdList, startMonth, endMonth, shopName } = toValue(args);
    let params = { shopIdList, startMonth, endMonth, periodType: selectorValue.value };
    let { val: data, success } = await getNewMemberAnalysisMonthlyTrendAndEmployeeRankingPort(params);
    if (success === '0') {
      employeeRankingTableData.value = data.memberRepetitionBuyCardOfConsForEmployee;

      memberLevelChartStatus.value = !!data.memberRepetitionBuyCardOfConsForShop.length;
      if (!memberLevelChartStatus.value) return;

      let axis: string[] = [],
        barsData: number[] = [],
        linesData: number[] = [];
      for (let item of data.memberRepetitionBuyCardOfConsForShop) {
        axis.push(item.statMonth);
        barsData.push(item.repetitionBuyCardRate ?? 0);
        linesData.push(item.repetitionBuyCardRateIncreasePer ?? 0);
      }

      memberLevelChartData.value = {
        title: shopName,
        xAxisBoundaryGap: true,
        xAxisLabelRotate: 0,
        yAxisUnit: '%',
        grid: { top: '20%', bottom: '0' },
        axis: axis,
        series: [
          {
            type: 'bar',
            name: '复购率(%)',
            data: barsData,
            label: { show: true, position: 'insideBottom', formatter: '{c}%' },
            barMaxWidth: 40
          },
          {
            type: 'line',
            name: '同比(%)',
            data: linesData,
            smooth: true,
            label: { show: true, formatter: '{c}%' }
          }
        ],
        colors: ['#ED7D31', '#5B9BD5']
      };
    }
  } catch (e) {
    console.log('e : ', e);
  } finally {
    employeeRankingTableLoading.value = false;
  }
};

// 导出新会员复购买卡分析table数据
const exportEmployeeRankingData = () => {
  let { shopIdList, startMonth, endMonth } = toValue(cacheShopSearchData);
  let params = { shopIdList, startMonth, endMonth, periodType: selectorValue.value };
  ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
    useDownload({
      port: exportNewMemberAnalysisMonthlyTrendAndEmployeeRankingPort,
      fileName: '新会员复购买卡分析表',
      params
    })
  );
};

/** 新会员首次产品消费分析 */
// 首次产品消费间隔矩阵 数据
const productMatrixChartStatus = ref(false);
const productMatrixChartData = ref<Chart.FourQuadrantChartType<Chart.RfmMatrixItemType>>({});
const getMemberFirstConsumeOfProductIntervalDaysData = async (args: SearchParamsType) => {
  try {
    employeeRankingTableLoading.value = true;
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = { shopIdList, startMonth, endMonth };
    let { val: data, success } = await getMemberFirstConsumeOfProductIntervalDaysPort(params);
    if (success === '0') {
      productMatrixChartStatus.value = !!data.memberFirstConsumeOfProduct.length;
      if (!productMatrixChartStatus.value) return;

      let originalData = data.memberFirstConsumeOfProduct.reduce((acc, item) => {
        if (item.amount || item.days) {
          acc.push({ xValue: item.amount, yValue: item.days });
        }
        return acc;
      }, [] as Chart.RfmMatrixItemType[]);
      productMatrixChartData.value = {
        title: '首次产品消费间隔矩阵',
        xAxisBaseLine: data.memberFirstConsumeOfProductFourQuadrant.amount,
        xAxisTipsName: '首次产品消费客单',
        xAxisUnit: '',
        yAxisBaseLine: data.memberFirstConsumeOfProductFourQuadrant.days,
        yAxisTipsName: '首次产品消费间隔',
        yAxisUnit: '',
        originalData,
        // 工具箱
        toolbox: {
          exportVisible: true,
          // 此处写导出逻辑
          exportPort: () => {
            ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
              useDownload({
                port: exportMemberFirstConsumeOfProductIntervalDaysChartDataPort,
                fileName: '新会员首次产品消费间隔',
                params
              })
            );
          }
        }
      };
    }
  } catch (e) {
    console.log('e : ', e);
  } finally {
    employeeRankingTableLoading.value = false;
  }
};

// 现金复购矩阵 数据 getMemberFirstConsumeOfCardIntervalDaysPort
const nurseMatrixChartStatus = ref(false);
const nurseMatrixChartData = ref<Chart.FourQuadrantChartType<Chart.RfmMatrixItemType>>({});
const getMemberFirstConsumeOfCardIntervalDaysData = async (args: SearchParamsType) => {
  try {
    employeeRankingTableLoading.value = true;
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = { shopIdList, startMonth, endMonth };
    let { val: data, success } = await getMemberFirstConsumeOfCardIntervalDaysPort(params);
    if (success === '0') {
      nurseMatrixChartStatus.value = !!data.memberFirstConsumeOfCard.length;
      if (!nurseMatrixChartStatus.value) return;

      let originalData = data.memberFirstConsumeOfCard.reduce((acc, item) => {
        if (item.amount || item.days) {
          acc.push({ xValue: item.amount, yValue: item.days });
        }
        return acc;
      }, [] as Chart.RfmMatrixItemType[]);
      nurseMatrixChartData.value = {
        title: '复购护理买卡间隔矩阵',
        xAxisBaseLine: data.memberFirstConsumeOfCardFourQuadrant.amount,
        xAxisTipsName: '复购护理买卡客单',
        xAxisUnit: '',
        yAxisBaseLine: data.memberFirstConsumeOfCardFourQuadrant.days,
        yAxisTipsName: '复购护理买卡间隔',
        yAxisUnit: '',
        originalData,
        // 工具箱
        toolbox: {
          exportVisible: true,
          // 此处写导出逻辑
          exportPort: () => {
            ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
              useDownload({
                port: exportMemberFirstConsumeOfCardIntervalDaysChartDataPort,
                fileName: '新会员复购护理买卡间隔',
                params
              })
            );
          }
        }
      };
    }
  } catch (e) {
    console.log('e : ', e);
  } finally {
    employeeRankingTableLoading.value = false;
  }
};
</script>
