<!-- 四象限图表 -->
<script lang="ts" setup name="FourQuadrantChart">
import { useEcharts } from '@/hooks/useEcharts';
import type { EChartsOption } from 'echarts';
import { Chart } from '@/typings/global';

type Props = {
  title?: string;
  xAxisBaseLine?: number;
  xAxisTipsName?: string;
  xAxisUnit?: string;
  yAxisBaseLine?: number;
  yAxisTipsName?: string;
  yAxisUnit?: string;
  originalData?: Chart.RfmMatrixItemType[];
  colors?: string[];
  routeCallback?: (data: any) => void;
  toolbox?: Chart.Toolbox;
};

const props = withDefaults(defineProps<Props>(), {
  title: '',
  xAxisBaseLine: 0,
  xAxisTipsName: '销量',
  xAxisUnit: '',
  yAxisBaseLine: 0,
  yAxisTipsName: '毛利额',
  yAxisUnit: '万',
  originalData: () => [],
  colors: () => ['#18a058', '#2d8cf0', '#f0a020', '#d03050'],
  routeCallback: () => {},
  toolbox: () => ({
    exportVisible: false,
    exportPort: () => {}
  })
});

const chartRef = ref<HTMLDivElement | null>(null);
const chartECharts = useEcharts(chartRef as Ref<HTMLDivElement>);

watch(
  () => props.originalData,
  () => {
    renderEChartsGraph();
  },
  { immediate: false }
);

// 面部护理销量利润分析 相关图表
function renderEChartsGraph() {
  let currentEchartsIns = chartECharts.getInstance();
  let data = transformEchartsData(props.originalData);
  // let toolboxStatus = true; // 提示框显示
  let iterates = [
    // { name: '明星', data: data.topRights, color: '#18a058' },
    // { name: '问题', data: data.topLefts, color: '#2d8cf0' },
    // { name: '带客', data: data.bottomRights, color: '#f0a020' },
    // { name: '瘦狗', data: data.bottomLefts, color: '#d03050' }
    { name: '', data: data.topRights, color: '#18a058' },
    { name: '', data: data.topLefts, color: '#2d8cf0' },
    { name: '', data: data.bottomRights, color: '#f0a020' },
    { name: '', data: data.bottomLefts, color: '#d03050' }
  ];
  let series: any = iterates.map((item, index) => ({
    id: `scatter_${index}`,
    name: item.name,
    type: 'scatter',
    data: item.data,
    symbolSize: 8,
    itemStyle: {
      //当前数据的样式
      // color: item.color
    },
    /*label: {
      show: toolboxStatus,
      position: 'top',
      formatter(params: any): string {
        let [count, amount, name] = params.data;
        return [
          ...(name ? [`{a|${name}}{abg|}`, '{hr|}  '] : []),
          `{b|${props.yAxisTipsName}: ${amount}}  `,
          `{b|${props.xAxisTipsName}: ${count}${props.xAxisUnit}}`
        ].join('\n');
      },
      backgroundColor: '#F6F8FC',
      borderColor: '#8C8D8E',
      borderWidth: 1,
      borderRadius: 4,
      rich: {
        a: {
          color: item.color,
          lineHeight: 22,
          padding: [3, 4],
          align: 'center'
        },
        hr: {
          borderColor: '#8C8D8E',
          width: '100%',
          borderWidth: 0.5,
          height: 0
        },
        b: {
          color: '#4C5058',
          fontSize: 14,
          fontWeight: 'bold',
          lineHeight: 33,
          padding: [3, 6]
        }
      }
    },*/
    markLine: {
      // 标记线设置
      symbolSize: 0, // 控制箭头和原点的大小、官方默认的标准线会带远点和箭头
      data: [
        // 设置两条标准线——x=10 和 y=10
        {
          xAxis: props.xAxisBaseLine,
          lineStyle: {
            type: 'solid',
            color: '#556EAA'
          }
        },
        {
          yAxis: props.yAxisBaseLine,
          lineStyle: {
            type: 'solid',
            color: '#DB442D'
          }
        }
      ]
    }
  }));
  let option = {
    color: props.colors,
    legend: props.title ? { top: '8%' } : {},
    title: {
      text: props.title,
      left: 'center',
      show: !!props.title,
      textStyle: {
        fontSize: '18px'
      }
    },
    grid: {
      left: '6%',
      right: '8%',
      bottom: '5%',
      top: '14%',
      containLabel: true
    },
    tooltip: {
      show: true,
      showDelay: 0,
      position: 'top',
      alwaysShowContent: true,
      formatter(params: any) {
        if (!Array.isArray(params.data)) return `${params.value}`;
        let [count, amount, name] = params.data;
        return [
          ...(name ? [`<span style="text-align: center">${name}</span>`, '<hr size=1 style="margin: 3px 0">'] : []),
          `<span>${props.yAxisTipsName} : ${amount}${props.yAxisUnit}</span><br>`,
          `<span>${props.xAxisTipsName} : ${count}${props.xAxisUnit}</span>`
        ].join('');
      }
    },
    toolbox: {
      show: true,
      right: 80,
      feature: {
        iconSize: 30, // 图标字体大小
        iconStyle: {
          color: '#5ABE64' // 图标默认颜色
        },
        emphasis: {
          iconStyle: {
            color: '#54C3F1' // 图标hover颜色
          }
        },
        // 导出按钮
        myTool1: {
          show: props.toolbox.exportVisible,
          title: '导出',
          icon: 'path://M1177.713778 344.945778 740.408889 673.308444l0-230.968889c-418.360889 0-436.878222 253.667556-437.447111 288.199111 0-16.782222 0-82.460444 0-93.44 0-145.009778 84.849778-389.518222 437.447111-389.518222L740.408889 28.444444 1177.713778 344.945778zM355.697778 534.186667c0 0 87.808-140.544 396.458667-140.544 22.584889 0 46.392889 0 46.392889 0l0 170.410667 289.507556-219.107556L798.549333 137.671111l0 164.096c0 0-23.864889 0-46.392889 0C421.063111 301.767111 355.697778 534.186667 355.697778 534.186667zM302.961778 730.538667c0 2.474667 0 3.953778 0 3.953778S302.904889 733.041778 302.961778 730.538667zM186.311111 175.559111l0 706.019556c0 32.540444 26.112 58.823111 58.311111 58.823111l728.974222 0c32.199111 0 58.311111-26.311111 58.311111-58.823111l0-176.526222 58.339556 0 0 176.526222c0 64.967111-52.224 117.674667-116.650667 117.674667L244.650667 999.253333c-64.426667 0-116.650667-52.707556-116.650667-117.674667L128 175.559111c0-64.995556 52.224-117.674667 116.650667-117.674667l262.428444 0 0 58.823111L244.650667 116.707556C212.423111 116.707556 186.311111 143.047111 186.311111 175.559111z',
          onclick: () => {
            props.toolbox.exportPort();
          }
        }
      }
    },
    xAxis: [
      {
        type: 'value',
        name: `${props.xAxisTipsName}${props.xAxisUnit ? '(' + props.xAxisUnit + ')' : ''}`,
        scale: true,
        axisLabel: {
          formatter: '{value}'
        },
        axisTick: {
          //刻度线样式
          show: true
        },
        nameLocation: 'middle',
        nameGap: 30,
        nameTextStyle: {
          fontSize: 14
        }
      }
    ],
    yAxis: [
      {
        type: 'value',
        name: `${props.yAxisTipsName}${props.yAxisUnit ? '(' + props.yAxisUnit + ')' : ''}`,
        scale: true,
        axisLabel: {
          formatter: '{value}'
        },
        axisTick: {
          show: false
        },
        nameLocation: 'middle',
        nameGap: Math.max(String(data.yAxisValueMax).length * 10, 30),
        nameTextStyle: {
          fontSize: 14
        }
      }
    ],
    series
  } as EChartsOption;
  chartECharts.setOptions(option);

  // 跳转到 护理详情页面
  currentEchartsIns?.on('click', 'series.scatter', props.routeCallback);
}

// 对源数据进行转换
function transformEchartsData(originalData: Chart.RfmMatrixItemType[]) {
  let yAxisValueMax = 0;
  let data = originalData.reduce(
    (acc, item) => {
      let { xValue, yValue, name = '' } = item;
      yAxisValueMax = yValue >= yAxisValueMax ? yValue : yAxisValueMax;
      acc.push([xValue, yValue, name]);
      return acc;
    },
    [] as Array<[number, number, string]>
  );

  let topRights = []; // 上 、右区间   高销量 高利润
  let topLefts = []; // 上 、左区间   高销量  低利润
  let bottomRights = []; // 下 、右区间  低销量  高利润
  let bottomLefts = []; // 下 、左区间  低销量  低利润

  for (let item of data) {
    let [xValue, yValue] = item;
    if (xValue >= props.xAxisBaseLine) {
      if (yValue >= props.yAxisBaseLine) {
        topRights.push([...item]);
      } else {
        bottomRights.push([...item]);
      }
    } else {
      if (yValue >= props.yAxisBaseLine) {
        topLefts.push([...item]);
      } else {
        bottomLefts.push([...item]);
      }
    }
  }
  return { topRights, topLefts, bottomRights, bottomLefts, yAxisValueMax };
}
</script>

<template>
  <div ref="chartRef" class="chart" style="width: 100%; height: 680px" />
</template>
