<template>
  <BiReportBoard key="BiReportExtensionDepartment" :department="department" auth-code="MENU_PROMOTION_BI_REPORT_READ" />
</template>

<!-- Bi 报表 推广部 -->
<script lang="ts" setup name="BiReportExtensionDepartment">
import BiReportBoard from '../components/BiReportBoard.vue';
const route = useRoute();
const department = ref<string>((route.meta.title as string) ?? '');
</script>
