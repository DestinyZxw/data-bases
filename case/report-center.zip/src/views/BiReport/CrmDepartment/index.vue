<template>
  <BiReportBoard key="BiReportCrmDepartment" :department="department" auth-code="MENU_CRM_BI_REPORT_READ" />
</template>

<!-- Bi 报表 CRM部 -->
<script lang="ts" setup name="BiReportCrmDepartment">
import BiReportBoard from '../components/BiReportBoard.vue';
const route = useRoute();
const department = ref<string>((route.meta.title as string) ?? '');
</script>
