<template>
  <BiReportBoard key="BiReportBrandDepartment" :department="department" auth-code="MENU_BRAND_SHOP_BI_REPORT_READ" />
</template>

<!-- Bi 报表 品牌部-门店 -->
<script lang="ts" setup name="BiReportBrandDepartmentShop">
import BiReportBoard from '../components/BiReportBoard.vue';
const route = useRoute();
const department = ref<string>((route.meta.title as string) ?? '');
</script>
