<template>
  <div class="table-box">
    <!--  form表单  -->
    <el-card :body-style="{ padding: '10px 18px' }" class="mb10">
      <el-row :gutter="15">
        <el-col :xs="24" :sm="12" :md="8" :lg="6" :xl="4">
          <view class="flex items-center">
            <label class="fz14 lht32 pr10">看板名称</label>
            <el-cascader
              class="flex-1"
              v-model="reportValue"
              :props="reportProps"
              :options="reportOptions"
              :disabled="isDisabledRead"
              collapse-tags
              collapse-tags-tooltip
              filterable
              clearable
            />
          </view>
        </el-col>
      </el-row>
    </el-card>

    <!--  看板内容区域  -->
    <div class="card table-main" style="padding: 10px 15px">
      <template v-if="reportVisible">
        <el-tabs v-model="currentTabName" closable @tab-remove="removeTab" @tab-change="changeTab">
          <el-tab-pane v-for="item in tabList" :key="item.label" :label="item.label" :name="item.name">
            <iframe class="flex-1" :src="item.url" />
          </el-tab-pane>
        </el-tabs>
      </template>
      <template v-else>
        <RubEmptyTip :show="false" class="flex-1" tips="暂无看板数据" />
      </template>
    </div>
  </div>
</template>

<!-- Bi报表管理 公共组件 -->
<script lang="ts" setup>
import { type ReportConfigModelItemType, getReportConfigByDepartmentPort } from '@/api/modules/setting';
import type { CascaderProps, CascaderNodePathValue } from 'element-plus';
import { useButtonAuth } from '@/hooks/useButtonAuth';

type Props = {
  department?: string;
  authCode?: string;
};

const props = withDefaults(defineProps<Props>(), {
  department: '',
  authCode: ''
});

// 按钮权限
const { isDisabledRead } = useButtonAuth({
  read: props.authCode,
  initFn: () => getReportOptions()
});

/**
 * 级联下拉表 相关代码
 */
// 当前级联下拉表的value
const reportValue = ref<CascaderNodePathValue>([]);

// 级联下拉表props属性配置
const reportProps: CascaderProps = {
  label: 'reportName',
  value: 'reportUrl',
  children: 'reportConfigModelList',
  multiple: false,
  expandTrigger: 'hover'
};

type ReportOptionItemType = ReportConfigModelItemType & {
  reportConfigModelList: ReportConfigModelItemType[];
};

type ReportOptionFlatItemType = ReportConfigModelItemType & {
  typeName: string;
};

// 看板 options
const reportOptions = ref<ReportOptionItemType[]>([]);

// 看板 options 数据扁平化
const flatReportOptions = computed<ReportOptionFlatItemType[]>(() => {
  const options = reportOptions.value;
  if (options.length === 0) return [];
  return options.flatMap(({ reportName, reportConfigModelList: list }) => list.map(item => ({ ...item, typeName: reportName })));
});

// 看板展示
const reportVisible = ref(true);

const getReportOptions = async () => {
  try {
    const params = {
      department: props.department
    };
    const { val: data, success } = await getReportConfigByDepartmentPort(params);
    if (success === '0') {
      if (data.length === 0) {
        // 级联数据初始化
        reportOptions.value = [];
        reportValue.value = [];

        // 动态tabs数据初始化
        currentTabName.value = '';
        tabList.value = [];
        return;
      }

      const [{ typeName, reportConfigModelList }] = data;
      const [{ reportUrl }] = reportConfigModelList;

      reportValue.value = [typeName, reportUrl];
      reportOptions.value = data.map(item => ({
        reportName: item.typeName,
        reportUrl: item.typeName,
        reportConfigModelList: item.reportConfigModelList
      }));
    }
  } catch {}
};

/**
 * 动态tabs 相关代码
 */
type TabItemType = { label: string; name: string; url: string };
const currentTabName = ref('');
const tabList = ref<TabItemType[]>([]);

// 监听级联下拉表reportValue值变化, 同步添加动态tab panel
watch(reportValue, () => {
  if (!reportValue.value || reportValue.value.length === 0) return;
  const [typeName, reportUrl] = reportValue.value;
  const isExist = tabList.value.some(item => item.url === reportUrl);
  const item = flatReportOptions.value.find(item => item.reportUrl === reportUrl && item.typeName === typeName);
  if (item) {
    const name = `${item.typeName}-@-${item.reportUrl}`;
    currentTabName.value = name;
    // 如果tab存在，直接返回
    if (isExist) return;
    // 否则 添加新的tab
    tabList.value.push({ label: item.reportName, name, url: item.reportUrl });
  }
});

// 监听tabList, 用来同步 看板是否展示
watch(
  tabList,
  () => {
    reportVisible.value = !!tabList.value.length;
  },
  { deep: true }
);

// 切换tab
const changeTab = (name: string) => {
  reportValue.value = name ? name.split('-@-') : [];
};

// 删除tab
const removeTab = (name: string) => {
  let tabs = tabList.value;
  let activeName = currentTabName.value;

  // 如果删除的是当前tab
  if (activeName === name) {
    tabs.forEach((tab, index) => {
      if (tab.name === name) {
        // 取后一项 或 前一项
        const nextTab = tabs[index + 1] || tabs[index - 1];
        activeName = nextTab ? nextTab.name : '';
      }
    });
  }
  changeTab(activeName);
  currentTabName.value = activeName;
  // 过滤删除项
  tabList.value = tabs.filter(tab => tab.name !== name);
};
</script>
