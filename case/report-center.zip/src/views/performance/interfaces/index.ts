import { CascaderNodePathValue, ModelValueType } from 'element-plus';

// 表单类型
export type SearchFormType = {
  shopList: CascaderNodePathValue[];
  dateRange: ModelValueType;
  empCode: string;
  empName: string;
  memberCode: string;
  orderNumber: string;
};

// 表单参数类型
export type SearchParamsType = {
  shopIds: number[];
  beginTime: string;
  endTime: string;
} & Omit<SearchFormType, 'shopList' | 'dateRange'>;
