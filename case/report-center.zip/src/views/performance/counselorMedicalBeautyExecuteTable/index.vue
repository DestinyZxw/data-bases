<template>
  <div class="table-box">
    <div class="card table-search">
      <el-form :model="searchForm" label-width="100">
        <el-row :gutter="15">
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="门店">
              <el-cascader
                class="wp-100"
                v-model="searchForm.shopList"
                :props="shopProps"
                :options="shopOptions"
                clearable
                collapse-tags
                collapse-tags-tooltip
                filterable
              />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="执行日期">
              <el-date-picker
                v-model="searchForm.dateRange"
                type="daterange"
                range-separator="-"
                start-placeholder="开始日期"
                end-placeholder="结束日期"
                format="YYYY-MM-DD"
                value-format="YYYY-MM-DD"
                :clearable="false"
              />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="员工号">
              <el-input v-model="searchForm.empCode" placeholder="请输入" maxlength="12" />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="员工姓名">
              <el-input v-model="searchForm.empName" placeholder="请输入" maxlength="30" />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="R6顾客号">
              <el-input v-model="searchForm.memberCode" placeholder="请输入" maxlength="30" />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item label="医美执行单号">
              <el-input v-model="searchForm.orderNumber" placeholder="请输入" />
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="12" :md="8" :lg="8" :xl="6">
            <el-form-item>
              <el-space>
                <el-button type="primary" @click="handleSearch" :disabled="isDisabledRead">搜索</el-button>
                <el-button type="success" @click="handleReset" :disabled="isDisabledRead">重置</el-button>
                <el-button type="primary" :icon="Download" plain @click="handleExport" :disabled="isDisabledExport"
                  >导出</el-button
                >
              </el-space>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>

    <div class="card table-main">
      <el-table v-loading="tableLoading" :data="tableData" style="width: 100%" border>
        <el-table-column prop="empCode" label="员工号" align="center" min-width="120" />
        <el-table-column prop="empName" label="员工姓名" align="center" min-width="150" />
        <el-table-column prop="regionName" label="区域" align="center" min-width="120" />
        <el-table-column prop="shopName" label="门店" align="center" min-width="100" />
        <el-table-column prop="positionName" label="职位" align="center" min-width="100" />
        <el-table-column prop="memberCode" label="R6顾客号" align="center" min-width="100" />
        <el-table-column prop="memberName" label="R6顾客姓名" align="center" min-width="120" />
        <el-table-column prop="memberType" label="会员类型" align="center" min-width="100" />
        <el-table-column prop="exclusiveConsultantName" label="专属顾问" align="center" min-width="100" />
        <el-table-column prop="medicalBeautyClinic" label="医美诊所" align="center" min-width="100" />
        <el-table-column prop="medicalBeautyMemberCode" label="医美顾客号" align="center" min-width="120" />
        <el-table-column prop="medicalBeautyMemberName" label="医美顾客姓名" align="center" min-width="120" />
        <el-table-column prop="medicalBeautyExecutionOrderNo" label="医美执行单号" align="center" min-width="120" />
        <el-table-column prop="orderExecutionTime" label="执行日期" align="center" min-width="100" />
        <el-table-column prop="executionAmount" label="执行金额" align="center" min-width="120" />
      </el-table>
      <el-pagination
        background
        layout="total, sizes, prev, pager, next, jumper"
        :current-page="pagination.page"
        :page-size="pagination.pageSize"
        :page-sizes="pagination.pageSizes"
        :total="pagination.itemCount"
        @current-change="pagination.onChange"
        @size-change="pagination.onPageSizeChange"
      />
    </div>
  </div>
</template>
<!-- 顾问医美执行业绩明细表 -->
<script lang="ts" setup name="counselorMedicalBeautyExecute">
import { type CascaderProps } from 'element-plus';
import { basicShopItem, shopRegionPort } from '@/api/modules/base';
import { Download } from '@element-plus/icons-vue';
import {
  type CounselorYMExecuteTableTableItemType,
  fetchCounselorYMExecuteTableTablePort,
  exportCounselorYMExecuteTableTablePort
} from '@/api/modules/performance';
import dayjs from 'dayjs';
import { useButtonAuth } from '@/hooks/useButtonAuth';
import type { SearchFormType, SearchParamsType } from '@/views/performance/interfaces';
import { useTable } from '@/hooks/useTable';

// 按钮权限
const { isDisabledRead, isDisabledExport } = useButtonAuth({
  read: 'COUNSELOR_MEDICAL_BEAUTY_EXECUTE_READ',
  exports: 'COUNSELOR_MEDICAL_BEAUTY_EXECUTE_EXPORT',
  initFn: () => {
    getTableData();
    getShopRegionData();
  }
});

/** ---------------- 门店相关逻辑 开始 ---------------------------*/
// 门店 options props
const shopProps: CascaderProps = {
  label: 'shopName',
  value: 'shopId',
  children: 'shopRegionList',
  multiple: true,
  expandTrigger: 'hover'
};

// 门店 option type
type ShopOptionType = {
  shopId: number | string;
  shopName: string;
  shopRegionList: basicShopItem[];
};

// 门店 options list
const shopOptions = ref<ShopOptionType[]>([]);
const getShopRegionData = async () => {
  try {
    let { val: data, success } = await shopRegionPort();
    if (success === '0') {
      shopOptions.value = data.map(item => {
        let tmp: ShopOptionType = {
          shopId: item.region,
          shopName: item.region,
          shopRegionList: item.shopRegionList
        };
        return tmp;
      });
    }
  } catch (e) {
    console.log('e : ', e);
  }
};
/** ---------------- 门店相关逻辑 结束 ---------------------------*/

/** ----------------  搜索数据相关逻辑 开始 ---------------------------*/
// 搜索数据初始化
const initFormData = (): SearchFormType => {
  const beginTime = `${dayjs().startOf('month').format('YYYY-MM-DD')}`; // 开始时间 当前月的第一天
  const endTime = `${dayjs().format('YYYY-MM-DD')}`; // 结束时间 当前天
  return {
    shopList: [],
    dateRange: [beginTime, endTime],
    empCode: '',
    empName: '',
    memberCode: '',
    orderNumber: ''
  };
};
// 搜索表单 form 数据
const searchForm = ref<SearchFormType>(initFormData());

// 搜索表单 查询列表接口数据
const searchParams = computed<SearchParamsType>(() => {
  const { shopList, dateRange, empCode, empName, memberCode, orderNumber } = toValue(searchForm);
  let shopIds: number[] = [];
  // 店铺多选
  if (shopList.length > 0) {
    for (let [, id] of shopList) {
      id && shopIds.push(id as number);
    }
  }
  const [beginTime, endTime] = dateRange as string[];
  return { shopIds, beginTime, endTime, empCode, empName, memberCode, orderNumber };
});
/** ----------------  搜索数据相关逻辑 结束 ---------------------------*/

/** ----------------  数据列表相关逻辑 开始 ---------------------------*/
const table = useTable<CounselorYMExecuteTableTableItemType, SearchParamsType>({
  port: fetchCounselorYMExecuteTableTablePort,
  searchForm: searchParams,
  exportPort: exportCounselorYMExecuteTableTablePort,
  exportExcelName: '顾问医美执行业绩明细表'
});

const { tableData, tableLoading, pagination, getTableData, handleSearch, handleExport } = table;

const handleReset = () => {
  searchForm.value = initFormData();
  table.handleReset();
};
/** ----------------  数据列表相关逻辑 开始 ---------------------------*/
</script>
