<template>
  <RubPage>
    <template #header>
      <div class="card pb0 mb14">
        <RubSearchForm
          read-auth-code="MENU_BILLING_PERFORMANCE_READ"
          @init="handleSearch"
          @search="handleSearch"
          @reset="handleReset"
        />
      </div>
    </template>

    <el-card shadow="hover">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold fz18">开单业绩</div>
          <div class="fz14" style="color: var(--el-text-color-secondary)">单位: 万元</div>
        </div>
      </template>
      <el-table :data="tableData" style="width: 100%">
        <el-table-column prop="type" label="项目" align="center">
          <template #default="{ row }">
            <div class="tl">
              {{ (row as ProductTableItemType).type }}
              <el-tooltip class="box-item" effect="dark" placement="top">
                <template #content>
                  <div style="max-width: 360px">{{ getTipString(row.type) }}</div>
                </template>
                <el-icon class="pointer" size="20" color="#333">
                  <Warning />
                </el-icon>
              </el-tooltip>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="当期" align="center">
          <el-table-column prop="amount" label="当期实际" align="center">
            <template #default="{ row }"> {{ handleFilterTableCell(row, 'amount') }} </template>
          </el-table-column>
          <el-table-column prop="target" label="当期预算" align="center">
            <template #default="{ row }"> {{ handleFilterTableCell(row, 'target') }} </template>
          </el-table-column>
          <el-table-column prop="spAmount" label="上年同期" align="center">
            <template #default="{ row }"> {{ handleFilterTableCell(row, 'spAmount') }} </template>
          </el-table-column>
          <el-table-column prop="completionRate" label="目标达成率" align="center">
            <template #default="{ row }"> {{ handleFilterTableCell(row, 'completionRate') }} </template>
          </el-table-column>
          <el-table-column prop="increasePer" label="同比增长率" align="center">
            <template #default="{ row }"> {{ handleFilterTableCell(row, 'increasePer') }} </template>
          </el-table-column>
        </el-table-column>
        <el-table-column label="年度累计" align="center">
          <el-table-column prop="yearAmount" label="本年实际" align="center">
            <template #default="{ row }"> {{ handleFilterTableCell(row, 'yearAmount') }} </template>
          </el-table-column>
          <el-table-column prop="yearTarget" label="本年预算" align="center">
            <template #default="{ row }"> {{ handleFilterTableCell(row, 'yearTarget') }} </template>
          </el-table-column>
          <el-table-column prop="spYearAmount" label="同期累计" align="center">
            <template #default="{ row }"> {{ handleFilterTableCell(row, 'spYearAmount') }} </template>
          </el-table-column>
          <el-table-column prop="yearCompletionRate" label="目标达成率" align="center">
            <template #default="{ row }"> {{ handleFilterTableCell(row, 'yearCompletionRate') }} </template>
          </el-table-column>
          <el-table-column prop="yearIncreasePer" label="同比增长率" align="center">
            <template #default="{ row }"> {{ handleFilterTableCell(row, 'yearIncreasePer') }} </template>
          </el-table-column>
        </el-table-column>
      </el-table>
    </el-card>

    <!--  客流量与客单价贡献额 echarts  -->
    <el-card class="mt14" shadow="hover">
      <template #header>
        <div class="flex items-center h-30 fz18">
          <div class="font-bold">客流量与客单价贡献额</div>
        </div>
      </template>
      <el-scrollbar>
        <RubBaseChart v-bind="shopAmountChartData" class="chart pt10" style="height: 800px" />
      </el-scrollbar>
    </el-card>

    <!--  各店客单价(元/次/人) echarts  -->
    <el-card class="mt14 pr" shadow="hover">
      <template #header>
        <div class="flex items-center h-30 fz18">
          <div class="font-bold">各店客单价(元/次/人)</div>
        </div>
      </template>
      <RubSelectKit v-model:type="unitPriceType" :options="selectKitOptions" auth-code="MENU_BILLING_PERFORMANCE_READ" />
      <el-scrollbar>
        <RubBaseChart v-bind="unitPriceChartCurrentData" class="chart pt10" />
      </el-scrollbar>
    </el-card>

    <!--  客单价同比增长率 echarts  -->
    <el-card class="mt14 pr" shadow="hover">
      <template #header>
        <div class="flex items-center h-30 fz18">
          <div class="font-bold">客单价同比增长率</div>
        </div>
      </template>
      <RubSelectKit v-model:type="priceRateType" :options="selectKitOptions" auth-code="MENU_BILLING_PERFORMANCE_READ" />
      <el-scrollbar>
        <RubDoubleYAxisChart v-bind="priceRateChartCurrentData" class="chart pt10" />
      </el-scrollbar>
    </el-card>

    <!--  客流量同比增长率 echarts  -->
    <el-card class="mt14 pr" shadow="hover">
      <template #header>
        <div class="flex items-center h-30 fz18">
          <div class="font-bold">客流量同比增长率</div>
        </div>
      </template>
      <el-scrollbar>
        <RubDoubleYAxisChart v-bind="flowRateChartData" class="chart pt10" />
      </el-scrollbar>
    </el-card>

    <!--  床位周转率(人/次/天) echarts  -->
    <el-card class="mt14 pr" shadow="hover">
      <template #header>
        <div class="flex items-center h-30 fz18">
          <div class="font-bold">床位周转率(人/次/天)</div>
        </div>
      </template>
      <el-scrollbar>
        <RubBaseChart v-bind="conversionChartData" class="chart pt10" />
      </el-scrollbar>
    </el-card>
  </RubPage>
</template>

<!-- 丽妍雅集业绩管理表 -->
<script setup lang="ts" name="performanceBilling">
import {
  getBillingTablePort,
  getBillingChartsPort,
  ProductTableItemType,
  exportAverageOrderValueChartDataPort,
  exportAovIncreaseChartDataPort,
  exportConversionChartDataPort
} from '@/api/modules/performance';
import { SearchParamsType } from '@/components/rub-search-form/interfaces';
import { Chart } from '@/typings/global';
import { ElMessageBox } from 'element-plus';
import { useDownload } from '@/hooks/useDownload';
import { getQuestionMapItem } from '@/utils';

// 获取提示信息
const getTipString = (key: string) => {
  const maps: Map<string, number> = new Map([
    ['床位数', 43],
    ['护理项目开单金额', 44],
    ['护理项目免单金额', 45],
    ['免单占比', 46],
    ['客流量人次（不含全免单）', 47],
    ['人次客单（不含全免单）（元）', 48],
    ['床位坪效（元/床/月）', 49],
    ['产品购买人数', 62],
    ['人数客单', 63],
    ['产品实际毛利率', 64]
  ]);
  const id = maps.get(key) ?? 0;
  return getQuestionMapItem(id);
};

// 缓存搜索数据
let cacheSearchData: SearchParamsType = {} as SearchParamsType;

const tableData = ref<ProductTableItemType[]>([]);
const handleSearch = (data: SearchParamsType) => {
  cacheSearchData = data;
  getBillingTableData(data);
  getBillingChartData(data);
};

const handleReset = (data: SearchParamsType) => {
  tableData.value = [];
  handleSearch(data);
};

const getBillingTableData = async (args: SearchParamsType) => {
  try {
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = { shopIdList, startMonth, endMonth };
    let { val: data, success } = await getBillingTablePort(params);
    if (success === '0') {
      tableData.value = data;
    }
  } catch (e) {
    console.log('e : ', e);
  }
};

// 对 table 单元格的数据进行解析
const handleFilterTableCell = (row: ProductTableItemType, key: keyof ProductTableItemType) => {
  const maps = ['免单占比'];
  const value = row[key];
  if (maps.includes(row.type) || key.endsWith('Rate') || key.endsWith('Per')) {
    return value || value === 0 ? `${value}%` : '/';
  }
  return value || value === 0 ? value : '/';
};

// 客单价和客流量贡献额
const shopAmountChartData = ref<Chart.BaseChartType>({});
const selectKitOptions = [
  { name: '当期', value: 1 },
  { name: '累计', value: 2 }
];

// 各店客单价的切换类型
const unitPriceType = ref<number>(1);
watch(unitPriceType, type => {
  handleSwitchUnitPriceKit(type);
});

// 各店客单价当前数据
const unitPriceChartCurrentData = ref<Chart.BaseChartType>({});
// 各店客单价
const unitPriceChartData = ref<Chart.BaseChartType>({});
// 累计各店客单价
const aggregateUnitPriceChartData = ref<Chart.BaseChartType>({});

// 客单价同比增长率切换类型
const priceRateType = ref<number>(1);
watch(priceRateType, type => {
  handleSwitchRatePriceKit(type);
});

// 客单价同比增长率 当前数据
const priceRateChartCurrentData = ref<Chart.DoubleYAxisChartType>({});
// 客单价同比增长率
const priceRateChartData = ref<Chart.DoubleYAxisChartType>({});
// 累计客单价同比增长率
const aggregatePriceRateChartData = ref<Chart.DoubleYAxisChartType>({});

// 客流量同比增长率
const flowRateChartData = ref<Chart.DoubleYAxisChartType>({});

// 床位转化率 线图数据
const conversionChartData = ref<Chart.BaseChartType>({});

// 获取图标的echarts数据
const getBillingChartData = async (args: SearchParamsType) => {
  try {
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = { shopIdList, startMonth, endMonth };
    let { val: data, success } = await getBillingChartsPort(params);
    if (success === '0') {
      let axis = [];
      let ptContributionArray = []; // 客流量贡献额 集合
      let aovContributionArray = []; // 客单价贡献额 集合

      let averageOrderValueArray = []; // 客单价 集合
      let popAverageOrderValueArray = []; // 同期客单价 集合

      let yearAverageOrderValueArray = []; // 累计客单价 集合
      let yearPopAverageOrderValueArray = []; // 累计同期客单价 集合

      let aovIncreaseArray = []; // 客单价增长 集合
      let aovIncreaseRateArray = []; // 客单价增长率 集合

      let aovYearIncreaseArray = []; // 累计客单价增长 集合
      let aovYearIncreaseRateArray = []; // 累计客单价增长率 集合

      let ptIncreaseArray = []; // 客流量增长 集合
      let ptIncreaseRateArray = []; // 客流量增长率 集合

      let bedTurnoverRateArray = []; // 翻床率 集合
      let popBedTurnoverRateArray = []; // 同期翻床率 集合
      let btrIncreaseRateArray = []; // 翻床率增长率 集合

      for (let item of data) {
        axis.push(item.shopName);
        ptContributionArray.push(+item.ptContribution.toFixed(2));
        aovContributionArray.push(+item.aovContribution.toFixed(2));

        averageOrderValueArray.push(+item.averageOrderValue.toFixed(2));
        popAverageOrderValueArray.push(+item.popAverageOrderValue.toFixed(2));

        yearAverageOrderValueArray.push(+item.yearAverageOrderValue.toFixed(2));
        yearPopAverageOrderValueArray.push(+item.yearPopAverageOrderValue.toFixed(2));

        aovIncreaseArray.push(+item.aovIncrease.toFixed(2));
        aovIncreaseRateArray.push(+item.aovIncreaseRate.toFixed(2));

        aovYearIncreaseArray.push(+item.aovYearIncrease.toFixed(2));
        aovYearIncreaseRateArray.push(+item.aovYearIncreaseRate.toFixed(2));

        ptIncreaseArray.push(+item.ptIncrease.toFixed(2));
        ptIncreaseRateArray.push(+item.ptIncreaseRate.toFixed(2));

        bedTurnoverRateArray.push(+item.bedTurnoverRate.toFixed(2));
        popBedTurnoverRateArray.push(+item.popBedTurnoverRate.toFixed(2));
        btrIncreaseRateArray.push(+item.btrIncreaseRate.toFixed(2));
      }

      // 客流量 和 客单价
      shopAmountChartData.value = {
        xAxisLabelRotate: 45,
        xAxisBoundaryGap: true,
        axis,
        series: [
          {
            type: 'bar',
            name: '客流量贡献额',
            data: ptContributionArray.map(value => ({ value, label: { show: true, position: value > 0 ? 'top' : 'bottom' } })),
            emphasis: { focus: 'series' }
          },
          {
            type: 'bar',
            name: '客单价贡献额',
            data: aovContributionArray.map(value => ({ value, label: { show: true, position: value > 0 ? 'top' : 'bottom' } })),
            emphasis: { focus: 'series' }
          }
        ],
        colors: ['#4572a7', '#93a9cf'],
        tooltip: { axisPointer: { type: 'shadow' } }
      };

      // 当期各店客单价
      unitPriceChartData.value = {
        xAxisLabelRotate: 45,
        xAxisBoundaryGap: true,
        axis,
        series: [
          {
            type: 'bar',
            name: '客单价',
            data: averageOrderValueArray.map(value => ({ value, label: { show: true, position: value > 0 ? 'top' : 'bottom' } })),
            emphasis: { focus: 'series' }
          },
          {
            type: 'bar',
            name: '同期客单价',
            data: popAverageOrderValueArray.map(value => ({
              value,
              label: { show: true, position: value > 0 ? 'top' : 'bottom' }
            })),
            emphasis: { focus: 'series' }
          }
        ],
        colors: ['#4572a7', '#93a9cf'],
        tooltip: { axisPointer: { type: 'shadow' } }
      };

      // 累计各店客单价
      aggregateUnitPriceChartData.value = {
        xAxisLabelRotate: 45,
        xAxisBoundaryGap: true,
        axis,
        series: [
          {
            type: 'bar',
            name: '累计客单价',
            data: yearAverageOrderValueArray.map(value => ({
              value,
              label: { show: true, position: value > 0 ? 'top' : 'bottom' }
            })),
            emphasis: { focus: 'series' }
          },
          {
            type: 'bar',
            name: '累计同期客单价',
            data: yearPopAverageOrderValueArray.map(value => ({
              value,
              label: { show: true, position: value > 0 ? 'top' : 'bottom' }
            })),
            emphasis: { focus: 'series' }
          }
        ],
        colors: ['#4572a7', '#93a9cf'],
        tooltip: { axisPointer: { type: 'shadow' } }
      };

      // 客单价增长率
      priceRateChartData.value = {
        yAxisRightUnit: '%',
        colors: ['#40699c', '#ff0000'],
        axis,
        series: [
          { name: '增长', type: 'bar', data: aovIncreaseArray, label: { show: true } },
          {
            name: '客单价增长(%)',
            type: 'line',
            data: aovIncreaseRateArray,
            yAxisIndex: 1,
            label: { show: true, formatter: '{c}%' },
            smooth: true,
            lineStyle: { type: [2, 4], dashOffset: 2 }
          }
        ]
      };

      // 客单价增长率 - 累计
      aggregatePriceRateChartData.value = {
        yAxisRightUnit: '%',
        colors: ['#40699c', '#ff0000'],
        axis,
        series: [
          { name: '增长', type: 'bar', data: aovYearIncreaseArray, label: { show: true } },
          {
            name: '累计客单价增长(%)',
            type: 'line',
            data: aovYearIncreaseRateArray,
            yAxisIndex: 1,
            label: { show: true, formatter: '{c}%' },
            smooth: true,
            lineStyle: { type: [2, 4], dashOffset: 2 }
          }
        ]
      };

      // 客流量同比增长率
      flowRateChartData.value = {
        yAxisRightUnit: '%',
        colors: ['#9eb8d7', '#ff0000'],
        axis,
        series: [
          { name: '增长', type: 'bar', data: ptIncreaseArray, label: { show: true } },
          {
            name: '客流量增长(%)',
            type: 'line',
            data: ptIncreaseRateArray,
            yAxisIndex: 1,
            label: { show: true, formatter: '{c}%' },
            smooth: true,
            lineStyle: { type: [2, 4], dashOffset: 2 }
          }
        ]
      };

      // 床位周转率(人/次/天)
      conversionChartData.value = {
        // 初始状态 隐藏同期翻床率增长率
        legendSelected: {
          同期翻床率增长率: false
        },
        xAxisLabelRotate: 45,
        yAxisUnit: '%',
        axis,
        series: [
          {
            type: 'line',
            name: '翻床率',
            data: bedTurnoverRateArray,
            smooth: true,
            label: { show: true, formatter: '{c}' }
          },
          {
            type: 'line',
            name: '同期翻床率',
            data: popBedTurnoverRateArray,
            smooth: true,
            label: { show: true, formatter: '{c}' }
          },
          {
            type: 'line',
            name: '同期翻床率增长率',
            data: btrIncreaseRateArray,
            smooth: true,
            label: { show: true, formatter: '{c}%' },
            lineStyle: { type: [2, 4], dashOffset: 2 }
          }
        ],
        colors: ['#00ad48', '#335f95', '#ff0000'],
        // 工具箱
        toolbox: {
          exportVisible: true,
          // 此处写导出逻辑
          exportPort: () => {
            ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
              useDownload({
                port: exportConversionChartDataPort,
                fileName: '床位周转率',
                params
              })
            );
          }
        }
      };

      handleSwitchUnitPriceKit(unitPriceType.value);
      handleSwitchRatePriceKit(priceRateType.value);
    }
  } catch (e) {
    console.log('e : ', e);
  }
};

function handleSwitchUnitPriceKit(type: number) {
  unitPriceChartCurrentData.value = {
    ...(type === 1 ? unitPriceChartData.value : aggregateUnitPriceChartData.value),
    // 工具箱
    toolbox: {
      exportVisible: true,
      // 此处写导出逻辑
      exportPort: () => {
        const { shopIdList, startMonth, endMonth } = cacheSearchData;
        const params = { shopIdList, startMonth, endMonth };
        ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
          useDownload({
            port: exportAverageOrderValueChartDataPort,
            fileName: '各店客单价',
            params
          })
        );
      }
    }
  };
}

function handleSwitchRatePriceKit(type: number) {
  priceRateChartCurrentData.value = {
    ...(type === 1 ? priceRateChartData.value : aggregatePriceRateChartData.value),
    grid: {
      top: '12%'
    },
    // 工具箱
    toolbox: {
      exportVisible: true,
      // 此处写导出逻辑
      exportPort: () => {
        const { shopIdList, startMonth, endMonth } = cacheSearchData;
        const params = { shopIdList, startMonth, endMonth };
        ElMessageBox.confirm('确认导出?', '温馨提示').then(() =>
          useDownload({
            port: exportAovIncreaseChartDataPort,
            fileName: '客单价同比增长率',
            params
          })
        );
      }
    }
  };
}
</script>
