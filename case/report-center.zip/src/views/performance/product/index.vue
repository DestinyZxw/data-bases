<template>
  <RubPage>
    <template #header>
      <div class="card pb0">
        <RubSearchForm
          read-auth-code="MENU_PRODUCT_PERFORMANCE_READ"
          @init="handleSearch"
          @search="handleSearch"
          @reset="handleReset"
        />
      </div>
    </template>

    <el-card class="mt14">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold">产品业绩</div>
          <div class="fz14" style="color: var(--el-text-color-secondary)">单位: 万元</div>
        </div>
      </template>
      <el-table v-loading="tableLoading" :data="tableData" class="wp-100">
        <el-table-column prop="type" label="项目" align="center">
          <template #default="{ row }">
            <div class="tl" v-if="['产品购买人数', '人数客单（元）', '产品实际毛利率'].includes(row.type)">
              {{ row.type }}
              <el-tooltip class="box-item" effect="dark" placement="top">
                <template #content>
                  <div style="max-width: 360px">{{ getTipString(row.type) }}</div>
                </template>
                <el-icon class="pointer" size="20" color="#333">
                  <Warning />
                </el-icon>
              </el-tooltip>
            </div>
            <div class="tl" v-else>{{ row.type }}</div>
          </template>
        </el-table-column>
        <el-table-column label="当期" align="center">
          <el-table-column prop="amount" label="当期实际" align="center">
            <template #default="{ row }"> {{ handleFilterTableCell(row, 'amount') }} </template>
          </el-table-column>
          <el-table-column prop="target" label="当期预算" align="center">
            <template #default="{ row }"> {{ handleFilterTableCell(row, 'target') }} </template>
          </el-table-column>
          <el-table-column prop="spAmount" label="上年同期" align="center">
            <template #default="{ row }"> {{ handleFilterTableCell(row, 'spAmount') }} </template>
          </el-table-column>
          <el-table-column prop="completionRate" label="目标达成率" align="center">
            <template #default="{ row }"> {{ handleFilterTableCell(row, 'completionRate') }} </template>
          </el-table-column>
          <el-table-column prop="increasePer" label="同比增长率" align="center">
            <template #default="{ row }"> {{ handleFilterTableCell(row, 'increasePer') }} </template>
          </el-table-column>
        </el-table-column>

        <el-table-column label="年度累计" align="center">
          <el-table-column prop="yearAmount" label="本年实际" align="center">
            <template #default="{ row }"> {{ handleFilterTableCell(row, 'yearAmount') }} </template>
          </el-table-column>
          <el-table-column prop="yearTarget" label="本年预算" align="center">
            <template #default="{ row }"> {{ handleFilterTableCell(row, 'yearTarget') }} </template>
          </el-table-column>
          <el-table-column prop="spYearAmount" label="同期累计" align="center">
            <template #default="{ row }"> {{ handleFilterTableCell(row, 'spYearAmount') }} </template>
          </el-table-column>
          <el-table-column prop="yearCompletionRate" label="目标达成率" align="center">
            <template #default="{ row }"> {{ handleFilterTableCell(row, 'yearCompletionRate') }} </template>
          </el-table-column>
          <el-table-column prop="yearIncreasePer" label="同比增长率" align="center">
            <template #default="{ row }"> {{ handleFilterTableCell(row, 'yearIncreasePer') }} </template>
          </el-table-column>
        </el-table-column>
      </el-table>
    </el-card>

    <el-card shadow="hover" class="mt14 pr">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold">各店的产品业线对比图</div>
          <div class="fz14" style="color: var(--el-text-color-secondary)">单位: 元</div>
        </div>
      </template>
      <el-scrollbar>
        <RubBaseChart class="chart" v-bind="linesChartData" />
      </el-scrollbar>
    </el-card>
  </RubPage>
</template>

<!-- 丽妍雅集业绩管理表 -->
<script setup lang="ts" name="performanceProduct">
import { ProductTableItemType, getProductTablePort, ProductChartItemType, getProductChartPort } from '@/api/modules/performance';
import { SearchParamsType } from '@/components/rub-search-form/interfaces';
import { Chart } from '@/typings/global';
import { getQuestionMapItem } from '@/utils';

// 获取提示信息
const getTipString = (key: string) => {
  const maps: Map<string, number> = new Map([
    ['产品购买人数', 62],
    ['人数客单（元）', 63],
    ['产品实际毛利率', 64]
  ]);
  const id = maps.get(key) ?? 0;
  return getQuestionMapItem(id);
};

type LinesMapsEnums = keyof Omit<ProductChartItemType, 'saleMonth'>;

const handleSearch = (data: SearchParamsType) => {
  getProductTableData(data);
  getProductChartData(data);
};

const handleReset = (data: SearchParamsType) => {
  tableData.value = [];
  handleSearch(data);
};

const tableLoading = ref(false);
const tableData = ref<ProductTableItemType[]>([]);
const getProductTableData = async (args: SearchParamsType) => {
  tableLoading.value = true;
  try {
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = { shopIdList, startMonth, endMonth };
    let { val: data, success } = await getProductTablePort(params);
    if (success === '0') {
      tableData.value = data;
    }
  } catch (e) {
    console.log('e : ', e);
  } finally {
    tableLoading.value = false;
  }
};

// 对 table 单元格的数据进行解析
const handleFilterTableCell = (row: ProductTableItemType, key: keyof ProductTableItemType) => {
  const maps = ['产品实际毛利率'];
  const value = row[key];
  if (maps.includes(row.type) || key.endsWith('Rate') || key.endsWith('Per')) {
    return value || value === 0 ? `${value}%` : '/';
  }
  return value || value === 0 ? value : '/';
};

// 线上 or 线下 线图数据
const linesChartData = ref<Chart.BaseChartType>({});
const getProductChartData = async (args: SearchParamsType) => {
  try {
    let { shopIdList, startMonth, endMonth } = toValue(args);
    const params = { shopIdList, startMonth, endMonth };
    const { val: data, success } = await getProductChartPort(params);
    if (success === '0') {
      // 数据映射
      let lineChartMaps: Record<LinesMapsEnums, Chart.SeriesItem> = {
        activityAmount: { type: 'line', name: '活动销售', data: [], smooth: true },
        averageOrderValue: { type: 'line', name: '人数客单', data: [], smooth: true },
        buyProductMemberCount: { type: 'line', name: '产品购买人数', data: [], smooth: true },
        normalAmount: { type: 'line', name: '非活动销售', data: [], smooth: true },
        offlineAmount: { type: 'line', name: '线下', data: [], smooth: true },
        onlineAmount: { type: 'line', name: '线上', data: [], smooth: true },
        totalAmount: { type: 'line', name: '产品销售总额', data: [], smooth: true }
      };
      let axis: string[] = [];
      for (let item of data) {
        let keys = Object.keys(item);
        for (let key of keys) {
          if (key === 'saleMonth') {
            axis.push(item[key]);
          } else {
            lineChartMaps[key as LinesMapsEnums].data.push(item[key as LinesMapsEnums]);
          }
        }
      }
      const series: Chart.SeriesItem[] = [...Object.values(lineChartMaps)];
      linesChartData.value = { axis, series };
    }
  } catch (e) {
    console.log('e : ', e);
  }
};
</script>
