<template>
  <RubPage>
    <template #header>
      <div class="card pb0">
        <RubSearchForm
          :is-member="true"
          read-auth-code="MENU_CASH_COMPOSITION_READ"
          @init="handleSearch"
          @search="handleSearch"
          @reset="handleReset"
        />
      </div>
    </template>

    <el-card shadow="hover" class="mt14">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold">现金构成</div>
          <div class="fz14" style="color: var(--el-text-color-secondary)">单位: 万元</div>
        </div>
      </template>
      <el-table :data="tableData" class="wp-100">
        <el-table-column label="现金项目" align="center" width="140">
          <template #default="{ row }">
            <div
              :class="[
                ['线上', '线下', '其他'].includes(row.typeName)
                  ? 'font-bold tl'
                  : row.typeName.includes('其中')
                    ? 'pl26 tl'
                    : 'pl10 tl'
              ]"
            >
              {{ handleFilterTableRow(row, 'typeName') }}
              <el-tooltip class="box-item" effect="dark" placement="top">
                <template #content>
                  <div style="max-width: 360px">{{ getTipString(row.typeName) }}</div>
                </template>
                <el-icon class="pointer" size="20" color="#333">
                  <Warning />
                </el-icon>
              </el-tooltip>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="当期" align="center">
          <el-table-column prop="amount" label="当期实际" align="center">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'amount') }} </template>
          </el-table-column>
          <el-table-column prop="spAmount" label="上年同期" align="center">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'spAmount') }} </template>
          </el-table-column>
          <el-table-column prop="increaseAmount" label="同比增长额" align="center">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'increaseAmount') }} </template>
          </el-table-column>
          <el-table-column prop="increasePer" label="同比增长率" align="center">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'increasePer') }} </template>
          </el-table-column>
          <el-table-column prop="structPer" label="当期结构" align="center">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'structPer') }} </template>
          </el-table-column>
        </el-table-column>

        <el-table-column label="年度累计" align="center">
          <el-table-column prop="yearAmount" label="本年实际" align="center">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'yearAmount') }} </template>
          </el-table-column>
          <el-table-column prop="spYearAmount" label="上年累计" align="center">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'spYearAmount') }} </template>
          </el-table-column>
          <el-table-column prop="increaseYearAmount" label="同比增长额" align="center">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'increaseYearAmount') }} </template>
          </el-table-column>
          <el-table-column prop="increaseYearPer" label="同比增长率" align="center">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'increaseYearPer') }} </template>
          </el-table-column>
          <el-table-column prop="yearStructPer" label="本年结构" align="center">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'yearStructPer') }} </template>
          </el-table-column>
        </el-table-column>
      </el-table>
    </el-card>

    <el-card shadow="hover" class="mt14 pr">
      <template #header>
        <div class="font-bold h-30 lht30">月度趋势图</div>
      </template>
      <RubSelectKit v-model:type="selectKitType" :options="selectKitOptions" auth-code="MENU_CASH_COMPOSITION_READ" />
      <el-scrollbar>
        <RubBaseChart class="chart" v-bind="linesChartData" />
      </el-scrollbar>
    </el-card>
  </RubPage>
</template>

<!-- 丽妍雅集业绩管理表 -->
<script setup lang="ts" name="performanceCash">
import { CashChartItemType, CashTableItemType, getCashChartsPort, getCashTablePort } from '@/api/modules/performance';
import { SearchParamsType } from '@/components/rub-search-form/interfaces';
import { Chart } from '@/typings/global';
import { getQuestionMapItem, handleFilterTableRow } from '@/utils';

// 获取提示信息
const getTipString = (key: string) => {
  const maps: Map<string, number> = new Map([
    ['线上', 34],
    ['卡项销售', 35],
    ['其中：体验顾客入会', 36],
    ['产品销售', 37],
    ['线下', 38]
  ]);
  const id = maps.get(key) ?? 0;
  return getQuestionMapItem(id);
};

type LinesMapsEnums = keyof Omit<CashChartItemType, 'saleMonth'>;

const tableData = ref<CashTableItemType[]>([]);

const handleSearch = (data: SearchParamsType) => {
  getCashTableData(data);
  getCashChartData(data);
};

const handleReset = (data: SearchParamsType) => {
  tableData.value = [];
  handleSearch(data);
};

const getCashTableData = async (args: SearchParamsType) => {
  try {
    let { shopIdList, memberType, startMonth, endMonth } = toValue(args);
    const params = { shopIdList, memberType, startMonth, endMonth };
    let { val: data, success } = await getCashTablePort(params);
    if (success === '0') {
      tableData.value = data;
    }
  } catch (e) {
    console.log('e : ', e);
  }
};

const selectKitOptions = [
  { name: '线上', value: 1 },
  { name: '线下', value: 2 }
];

// 线上、线下 切换类型
const selectKitType = ref<number>(1);

watch(selectKitType, type => {
  handleSwitchKit(type);
});

// 线上 or 线下 线图数据
const linesChartData = ref<Chart.BaseChartType>({});

const createOriginMaps = (): Record<LinesMapsEnums, Chart.SeriesItem> => ({
  onlineAmount: { type: 'line', name: '总金额', data: [], smooth: true },
  onlineCardAmount: { type: 'line', name: '卡项销售', data: [], smooth: true },
  onlinePreCardAmount: { type: 'line', name: '体验顾客入会', data: [], smooth: true },
  onlineProductAmount: { type: 'line', name: '产品销售', data: [], smooth: true },
  offlineAmount: { type: 'line', name: '总金额', data: [], smooth: true },
  offlineCardAmount: { type: 'line', name: '卡项销售', data: [], smooth: true },
  offlinePreCardAmount: { type: 'line', name: '体验顾客入会', data: [], smooth: true },
  offlineProductAmount: { type: 'line', name: '产品销售', data: [], smooth: true }
});

// 数据映射
const lineChartMaps = ref<Record<LinesMapsEnums, Chart.SeriesItem>>(createOriginMaps());

const axis = ref<string[]>([]);
const getCashChartData = async (args: SearchParamsType) => {
  try {
    let { shopIdList, memberType, startMonth, endMonth } = toValue(args);
    const params = { shopIdList, memberType, startMonth, endMonth };
    const { val: data, success } = await getCashChartsPort(params);
    if (success === '0') {
      axis.value = [];
      lineChartMaps.value = createOriginMaps();
      for (let item of data) {
        let keys = Object.keys(item);
        for (let key of keys) {
          if (key === 'saleMonth') {
            axis.value.push(item[key]);
          } else {
            lineChartMaps.value[key as LinesMapsEnums].data.push(item[key as LinesMapsEnums]);
          }
        }
      }
      handleSwitchKit(selectKitType.value);
    }
  } catch (e) {
    console.log('e : ', e);
  }
};

function handleSwitchKit(type: number) {
  let flag = type === 1 ? 'online' : 'offline';
  let entries = Object.entries(lineChartMaps.value);
  let series: Chart.SeriesItem[] = [];
  for (let [key, value] of entries) {
    key.startsWith(flag) && series.push(value);
  }
  linesChartData.value = { axis: axis.value, series };
}
</script>
