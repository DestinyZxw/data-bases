<template>
  <RubPage>
    <template #header>
      <div class="card pb0">
        <RubSearchForm
          read-auth-code="MENU_PERFORMANCE_MANAGEMENT_READ"
          @init="handleSearch"
          @search="handleSearch"
          @reset="handleReset"
        />
      </div>
    </template>

    <el-card shadow="hover" class="mt14">
      <template #header>
        <div class="flex items-center justify-between h-30">
          <div class="font-bold">财务指标</div>
          <div class="fz14" style="color: var(--el-text-color-secondary)">单位: 万元</div>
        </div>
      </template>
      <el-table :data="tableData" class="wp-100">
        <el-table-column prop="type" label="项目" align="center" width="150">
          <template #default="{ row }">
            <div :class="[['店数', '现金收入', '业绩产出'].includes(row.type) ? 'font-bold tl' : 'pl10 tl']">
              {{ (row as businessSummaryItemType).type }}
              <el-tooltip class="box-item" effect="dark" placement="top">
                <template #content>
                  <div style="max-width: 360px">{{ getTipString(row.type) }}</div>
                </template>
                <el-icon class="pointer" size="20" color="#333">
                  <Warning />
                </el-icon>
              </el-tooltip>
            </div>
          </template>
        </el-table-column>
        <!--    当期    -->
        <el-table-column label="当期" align="center">
          <el-table-column prop="amount" label="当期实际" align="center">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'amount') }} </template>
          </el-table-column>
          <el-table-column prop="target" label="当期预算" align="center">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'target') }} </template>
          </el-table-column>
          <el-table-column prop="spAmount" label="上年同期" align="center">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'spAmount') }} </template>
          </el-table-column>
          <el-table-column prop="completionRate" label="目标达成率" align="center">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'completionRate') }} </template>
          </el-table-column>
          <el-table-column prop="increasePer" label="同比增长率" align="center">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'increasePer') }} </template>
          </el-table-column>
        </el-table-column>
        <!--    年度    -->
        <el-table-column label="年度累计" align="center">
          <el-table-column prop="yearAmount" label="本年实际" align="center">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'yearAmount') }} </template>
          </el-table-column>
          <el-table-column prop="yearTarget" label="本年预算" align="center">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'yearTarget') }} </template>
          </el-table-column>
          <el-table-column prop="spYearAmount" label="同期累计" align="center">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'spYearAmount') }} </template>
          </el-table-column>
          <el-table-column prop="yearCompletionRate" label="目标达成率" align="center">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'yearCompletionRate') }} </template>
          </el-table-column>
          <el-table-column prop="yearIncreasePer" label="同比增长率" align="center">
            <template #default="{ row }"> {{ handleFilterTableRow(row, 'yearIncreasePer') }} </template>
          </el-table-column>
        </el-table-column>
      </el-table>
    </el-card>

    <el-card shadow="hover" class="mt14">
      <template #header>
        <div class="font-bold h-30 lht30">开单与产品占比</div>
      </template>
      <el-row :gutter="15" class="wp-100" style="min-height: 400px">
        <el-col :xs="24" :sm="12" :md="12" :lg="6" v-for="(it, index) in pieChartsData" :key="index">
          <RubPieChart v-bind="it" />
        </el-col>
      </el-row>
    </el-card>

    <el-card shadow="hover" class="mt14">
      <template #header>
        <div class="font-bold h-30 lht30">业绩进度达成趋势</div>
      </template>
      <el-scrollbar>
        <RubBaseChart class="chart" v-bind="linesChartData" />
      </el-scrollbar>
    </el-card>
  </RubPage>
</template>

<!-- 丽妍雅集业绩管理表 -->
<script setup lang="ts" name="performanceSheet">
import { getSheetTableAndPiePort, getSheetLinePort, SheetLineEnums, businessSummaryItemType } from '@/api/modules/performance';
import { SearchParamsType } from '@/components/rub-search-form/interfaces';
import { Chart } from '@/typings/global';
import { handleFilterTableRow, getQuestionMapItem } from '@/utils';

const handleSearch = (data: SearchParamsType) => {
  getSheetTableAndPieData(data);
  getSheetLineData(data);
};

const handleReset = (data: SearchParamsType) => {
  tableData.value = [];
  pieChartsData.value = [];
  handleSearch(data);
};

const tableData = ref<businessSummaryItemType[]>([]);
// pie 饼图数据
const pieChartsData = ref<Chart.PieChartType[]>([]);
const getSheetTableAndPieData = async (args: SearchParamsType) => {
  try {
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = { shopIdList, startMonth, endMonth };
    let { val: data, success } = await getSheetTableAndPiePort(params);
    if (success === '0') {
      tableData.value = data.businessSummaryVOList;
      pieChartsData.value = [
        {
          name: '当期占比',
          data: [
            { name: '产品', value: data.monthProductRate },
            { name: '开单', value: data.monthTreatmentRate }
          ],
          colors: ['#eda587', '#cf6c28']
        },
        {
          name: '本年累计',
          data: [
            { name: '产品', value: data.yearProductRate },
            { name: '开单', value: data.yearTreatmentRate }
          ],
          colors: ['#95b7dd', '#4e87b9']
        },
        {
          name: '去年同期占比',
          data: [
            { name: '产品', value: data.spMonthProductRate },
            { name: '开单', value: data.spMonthTreatmentRate }
          ],
          colors: ['#fbcf81', '#dfa700']
        },
        {
          name: '去年同期累计',
          data: [
            { name: '产品', value: data.spYearProductRate },
            { name: '开单', value: data.spYearTreatmentRate }
          ],
          colors: ['#95b7dd', '#4e87b9']
        }
      ];
    }
  } catch (e) {
    console.log('e : ', e);
  }
};

// lines 线图数据
const linesChartData = ref<Chart.BaseChartType>({});
const getSheetLineData = async (args: SearchParamsType) => {
  try {
    let { shopIdList, startMonth, endMonth } = toValue(args);
    let params = { shopIdList, startMonth, endMonth };
    let { val: data, success } = await getSheetLinePort(params);
    if (success === '0') {
      let axis: string[] = [];
      let maps: Record<SheetLineEnums, string> = {
        cashPerformanceList: '现金(%)',
        treatmentPerformanceList: '开单(%)',
        productPerformanceList: '产品(%)',
        timeList: '时间(%)'
      };
      let series = Object.keys(data).map((key, index) => {
        let item = {
          type: 'line',
          name: maps[key as SheetLineEnums],
          data: data[key as SheetLineEnums].map(it => it.value)
        };
        index === 0 && (axis = data[key as SheetLineEnums].map(it => it.dimension));
        return item;
      });
      linesChartData.value = { axis, series };
    }
  } catch (e) {
    console.log('e : ', e);
  }
};

// 获取提示信息
const getTipString = (key: string) => {
  const maps: Map<string, number> = new Map([
    ['店数', 29],
    ['现金收入', 30],
    ['业绩产出', 31],
    ['护理项目开单金额', 32],
    ['产品业绩', 33]
  ]);
  const id = maps.get(key) ?? 0;
  return getQuestionMapItem(id);
};
</script>
