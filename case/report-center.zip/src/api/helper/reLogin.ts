import { useUserStore } from '@/stores/modules/user';
import router from '@/routers';
import { CURRENT_OPTION } from '@/config';

export const reLogin = () => {
  const userStore = useUserStore();
  userStore.setToken('');
  const flag = window.sessionStorage.getItem('wxFlag') ?? 'No';
  flag === 'Yes' ? router.replace('/wxLogin') : window.location.replace(CURRENT_OPTION.authUrl);
};
