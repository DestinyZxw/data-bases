import { ReqParams } from '@/api/interface';
import { PORT1 } from '@/api/config/servicePort';
import http from '@/api';

/**
 *  产品分析 模块
 */

/**
 *  产品SKU体系
 */
export type ProductSkuSystemItemType = {
  effectName: string; // 效果名称
  skuCount: number; // 计数
};
export type ProductSkuSystemType = {
  beautySalonPackage: ProductSkuSystemItemType[]; // 院装统计
  customerPackage: ProductSkuSystemItemType[]; // 客装统计
  dualUsePackage: ProductSkuSystemItemType[]; // 客院统计
};
export const getProductSkuSystemPort = () => http.post<ProductSkuSystemType>(`${PORT1}/productReport/productSkuSystem`, {});

/**
 *  产品价格带
 */
export type ProductRangeItemType = {
  [key: string]: string | number;
};
export type ProductPriceRangeType = {
  anotherOneRange: ProductRangeItemType[];
  productPriceRange: ProductRangeItemType[];
};
export const getProductPriceRangePort = (params: ReqParams) =>
  http.post<ProductPriceRangeType>(`${PORT1}/productReport/productPriceRangeForProductType`, params, { noLoading: true });

/**
 *  产品销售排行榜
 */
export type ProductSalesRankingTableItemType = {
  actualSalesRanking: number; // 实际销售额排名
  actualSalesRevenue: number; // 实际销售额
  brandEnName: string; // 品牌
  discount: number; // 折扣
  grossMargin: number; // 毛利率
  perPersonPrice: number; // 实际客单价
  preSaleRevenue: number; // 折前销售额
  price: number; // 吊牌价
  productCode: string; // 产品编号
  productName: string; // 产品名称
  salesCount: number; // 销售数量
};
export const getProductSalesRankingTablePort = (params: ReqParams) =>
  http.post<ProductSalesRankingTableItemType[]>(`${PORT1}/productReport/productSalesRanking`, params, { noLoading: true });

/**
 *  export 产品销售排行榜
 */
export const exportProductSalesRankingTablePort = (params: ReqParams) =>
  http.download(`${PORT1}/productReport/exportProductSalesRanking`, params);
