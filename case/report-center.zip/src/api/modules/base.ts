import { PORT1, PORT2 } from '@/api/config/servicePort';
import { ReqParams } from '@/api/interface';

import http from '@/api';

/**
 *  基础接口
 */
export interface basicShopItem {
  shopId: number;
  shopName: string;
  [key: string]: any;
}

/**
 * @description: 门店接口
 */
export const basicInfoShopsPort = () => http.get<Array<basicShopItem>>(`${PORT1}/basicInfo/shops`, {}, { noLoading: true });

export const fetchMemberShopListPort = () => http.get<Array<basicShopItem>>('/shop/v1/shop/all', {}, { noLoading: true });

/**
 * @description: 门店 区域接口
 */
export type ShopRegionItemType = {
  region: string;
  shopRegionList: basicShopItem[];
};
export const shopRegionPort = () => http.get<ShopRegionItemType[]>(`${PORT1}/basicInfo/shopRegion`, {}, { noLoading: true });

/**
 * @description: 科美门店列表接口
 */
export type KeMeiShopItemType = {
  abbreviationName: string;
  address: string;
  aptitude: {
    code: string;
    family: string;
    name: string;
    system: string;
    version: string;
  };
  billingHeader: string;
  contact: string;
  contactPhone: string;
  formalName: string;
  id: string;
  isActive: boolean;
  manager: {
    id: string;
    name: string;
  };
  name: string;
  number: string;
  phone: string;
};
export const keMeiShopsPort = () => http.get<KeMeiShopItemType[]>(`${PORT2}/ym/system/clinic/list`, {}, { noLoading: true });

/**
 * @description: 获取字段提示弹窗 表格数据
 */
export type FieldsTipsDialogType = {
  id: number;
  targetName: string;
  targetDescription: string;
  createdAt: string;
  updatedAt: string;
  targetClass: {
    ClassName?: string;
  };
};

export const fetchFieldsTipsDialogDataPort = (params: ReqParams) =>
  http.post<FieldsTipsDialogType[]>('/bi/target.get', params, { noLoading: true });
