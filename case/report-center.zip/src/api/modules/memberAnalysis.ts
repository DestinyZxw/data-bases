import { ReqParams } from '@/api/interface';
import { PORT1 } from '@/api/config/servicePort';
import http from '@/api';

/**------- 会员分析 模块 ------ */

/**
 * 会员现状分析-会员变动趋势
 */
export type MemberTrendItemType = {
  churnMemberCount: number;
  newMemberCount: number;
  retentionMemberCount: number;
  timePeriod: string;
};
export type MemberTrendType = {
  churnMemberRingRatio: number | null; // 流失会员环比
  newMemberRingRatio: number | null; // 新会员环比
  memberTrend: MemberTrendItemType[] | null;
};
export const getMemberTrendPort = (params: ReqParams) => http.post<MemberTrendType>(`${PORT1}/memberAnalyse/memberTrend`, params);

/**
 * 会员现状分析-会员属性
 */
export type MemberAttributesType = {
  // 会员类型人数
  memberType: {
    fullMemberAmount: number; // 正式会员
    fullMemberAmountRatio: number; // 正式会员占比
    probationaryMemberAmount: number; // 预备会员
    probationaryMemberAmountRatio: number; // 预备会员占比
  };

  // 会员类型业绩贡献
  performanceContribution: {
    fullMemberAmount: number; // 正式会员
    fullMemberAmountRatio: number; // 正式会员占比
    probationaryMemberAmount: number; // 预备会员
    probationaryMemberAmountRatio: number; // 预备会员占比
  };

  // 会员类型毛利贡献
  memberTypeGrossProfit: {
    fullMemberGrossProfit: number; // 正式会员
    fullMemberGrossProfitRatio: number; // 正式会员占比
    probationaryMemberGrossProfit: number; // 预备会员
    probationaryMemberGrossProfitRatio: number; // 预备会员占比
  };

  //会员等级人数
  memberLevelCount: {
    [key: string]: { count: number; ratio: number };
  };

  // 会员等级业绩贡献
  memberLevelAmount: {
    [key: string]: { amount: number; ratio: number };
  };

  // 会员等级毛利贡献
  memberLevelGrossProfit: {
    [key: string]: { amount: number; ratio: number };
  };
};
export const getMemberAttributesPort = (params: ReqParams) =>
  http.post<MemberAttributesType>(`${PORT1}/memberAnalyse/memberAttributes`, params);

/**
 * RFM分析 - 会员分层
 */
export type MemberStratificationMatrixType = {
  amount: number;
  frequency: number;
};
export type MemberStratificationType = {
  totalCount: number; // 会员总数
  stratification: { [key: string]: number }; // 会员分层
  stratificationContribute: { [key: string]: { amount: number; ratio: number } }; // 会员分层贡献
  stratificationCountRatio: { [key: string]: number }; // 会员分层人数占比
  mfrMatrix: MemberStratificationMatrixType[]; // MFR矩阵数据
  memberMfrFourQuadrant: MemberStratificationMatrixType; // MFR矩阵四象限分割线数据
};
export const getMemberStratificationPort = (params: ReqParams) =>
  http.post<MemberStratificationType>(`${PORT1}/memberAnalyse/memberStratification`, params);

/**
 * 体验顾客分析-关键指标
 */
export type MemberKeyIndicatorType = {
  buyCardAmount: number | null; // 买卡金额
  buyCardAmountIncreasePer: number | null; // 买卡金额复合同比
  buyCardConversionRate: number | null; // 买卡转化率
  buyCardConversionRateIncreasePer: number | null; // 买卡转化率（同比）
  buyCardCount: number | null; // 买卡人数
  buyCardCountIncreasePer: number | null; // 买卡人数（同比）
  experienceMemberCount: number | null; // 体验顾客人数
  experienceMemberCountIncreasePer: number | null; // 体验顾客人数（同比）
  memberChannelStructure: { [key: string]: { count: number; ratio: number } };
  personCountAmount: number | null; // 买卡客单
  personCountAmountIncreasePer: number | null; // 买卡客单复合同比
};
export const getMemberKeyIndicatorPort = (params: ReqParams) =>
  http.post<MemberKeyIndicatorType>(`${PORT1}/memberAnalyse/memberKeyIndicator`, params);

/**
 * 体验顾客分析-入会渠道有效性
 */
export type MemberChannelEffectivenessItemType = {
  buyCardConversionRate: number; // 买卡转化率
  buyCardConversionRateIncreasePer: number; // 买卡转化率（同比）
  buyCardCount: number; // 买卡人数
  buyCardCountIncreasePer: number; // 买卡人数（同比）
  eventTypeName: string; // 渠道
  experienceMemberCount: number; // 体验顾客人数
  experienceMemberCountIncreasePer: number; // 体验顾客人数（同比）
};
export const getMemberChannelEffectivenessPort = (params: ReqParams) =>
  http.post<MemberChannelEffectivenessItemType[]>(`${PORT1}/memberAnalyse/memberChannelEffectiveness`, params);

/**
 * 体验顾客分析-买卡转化分析
 */
export type MemberBuyCardConversionAnalyseItemType = {
  buyCardConversionRate: number; // 买卡转换率
  buyCardCount: number; // 买卡人数
  shopName: string; // 店名
  shopId: string; // 店id
};
export type MemberBuyCardConversionAnalyseType = {
  memberBuyCardConversion: MemberBuyCardConversionAnalyseItemType[];
  memberBuyCardConversionFourQuadrant: { x: number; y: number };
};
export const getMemberBuyCardConversionAnalysePort = (params: ReqParams) =>
  http.post<MemberBuyCardConversionAnalyseType>(`${PORT1}/memberAnalyse/memberBuyCardConversionAnalyse`, params);

/**
 * 体验顾客分析-买卡转化门店数据
 */
export type MemberBuyCardConversionForShopItemType = {
  buyCardConversionRate: number; // 买卡转换率
  buyCardConversionRateIncreasePer: number; // 买卡转换率（同比）
  saleMonth: string; // 统计月
};
export type MemberBuyCardConversionForEmployeeItemType = {
  buyCardConversionRate: number; // 买卡转换率
  buyCardConversionRateGrandTotal: number; // 买卡转换率（累计）
  buyCardCount: number; // 买卡人数
  buyCardCountGrandTotal: number; // 买卡人数（累计）
  employeeName: string; // 顾问
};
export type MemberBuyCardConversionForShopType = {
  memberBuyCardConversionForEmployee: MemberBuyCardConversionForEmployeeItemType[];
  memberBuyCardConversionForShop: MemberBuyCardConversionForShopItemType[];
};
export const getMemberBuyCardConversionForShopPort = (params: ReqParams) =>
  http.post<MemberBuyCardConversionForShopType>(`${PORT1}/memberAnalyse/memberBuyCardConversionForShop`, params);

/**
 * 体验顾客分析-export 买卡转化门店数据
 */
export const exportMemberBuyCardConversionForShopPort = (params: ReqParams) =>
  http.download(`${PORT1}/memberAnalyse/exportMemberBuyCardConversionForShop`, params);

/**
 * 新会员分析-关键指标数据
 */
export type NewMemberAnalysisKeyIndicatorType = {
  newMemberAmount: number | null; // 新客消费金额和
  newMemberAmountIncreasePer: number | null; // 新会员消费占比（同比）
  newMemberCounts: number | null; // 新会员消费次数
  newMemberCountsIncreasePer: number | null; // 新会员消费次数（同比）
  perCapitaRevenue: number | null; //人次客单
  perCapitaRevenueIncreasePer: number | null; //人次客单（同比）
  newConsumeRate: number | null; //新会员消费金额和
  newConsumeRateIncreasePer: number | null; //新会员消费金额和（同比）
  consumeFreq: number | null; //消费频次
  consumeFreqIncreasePer: number | null; //消费频次（同比）
  repCounts: number | null; //复购充值人数
  repCountsIncreasePer: number | null; //复购充值人数（同比）
  repAmount: number | null; //复购充值金额
  repAmountIncreasePer: number | null; //复购充值金额（同比）
  prp: number | null; //复购充值客单
  prpIncreasePer: number | null; //复购充值客单（同比）
  repeatBuyCardRate: number | null; //复购率
  repeatBuyCardRateIncreasePer: number | null; //复购率（同比）
  consumeInterval: [{ typeName: string; consumeInterval: number }]; //消费间隔
};

export const getNewMemberAnalysisKeyIndicatorDataPort = (params: ReqParams) =>
  http.post<NewMemberAnalysisKeyIndicatorType>(`${PORT1}/memberAnalyse/newMemberKeyIndicator`, params);

/**
 * 新会员分析-新会员复购买卡分析
 */
export type memberRepetitionBuyCardOfShopItemType = {
  repetitionBuyCardCount: number; // 复购人数
  repetitionBuyCardRate: number; // 复购率
  shopName: string; // 店名
  shopId: string; // 店id
};
export type MemberRepetitionBuyCardOfShopType = {
  memberRepetitionBuyCardOfShop: memberRepetitionBuyCardOfShopItemType[];
  memberRepetitionBuyCardOfShopFourQuadrant: { x: number; y: number };
};
export const getMemberRepetitionBuyCardOfShopPort = (params: ReqParams) =>
  http.post<MemberRepetitionBuyCardOfShopType>(`${PORT1}/memberAnalyse/memberRepetitionBuyCardOfShop`, params);

/**
 * 新会员分析-月度趋势和顾问排名
 */
export type NewMemberAnalysisMonthlyTrendAndEmployeeRanking = {
  memberRepetitionBuyCardOfConsForShop: NewMemberAnalysisMonthlyTrendType[]; //
  memberRepetitionBuyCardOfConsForEmployee: NewMemberAnalysisEmployeeRankingType[]; //
  [key: string]: any;
};
export type NewMemberAnalysisMonthlyTrendType = {
  repetitionBuyCardRate: number; //复购率
  repetitionBuyCardRateIncreasePer: number; //复购率同比
  statMonth: string; //统计月
};
export type NewMemberAnalysisEmployeeRankingType = {
  employeeName: string; //顾问
  repetitionBuyCardCount: number; //复购人数（当期）
  repetitionBuyCardRate: number; //复购率（当期）
  repetitionBuyCardCountGrandTotal: number; //复购人数（累计）
  repetitionBuyCardRateGrandTotal: number; //复购率（累计）
};
export const getNewMemberAnalysisMonthlyTrendAndEmployeeRankingPort = (params: ReqParams) =>
  http.post<NewMemberAnalysisMonthlyTrendAndEmployeeRanking>(`${PORT1}/memberAnalyse/memberRepetitionBuyCardOfCons`, params);

export const exportNewMemberAnalysisMonthlyTrendAndEmployeeRankingPort = (params: ReqParams) =>
  http.download(`${PORT1}/memberAnalyse/exportMemberRepetitionBuyCardOfCons`, params);

/**
 * 新会员分析-首次产品消费间隔矩阵分析
 */
export type MemberFirstConsumeOfProductItemType = {
  amount: number; // 首次产品消费客单
  days: number; // 首次产品产品消费间隔
};
export type memberFirstConsumeOfProductIntervalDaysType = {
  memberFirstConsumeOfProduct: MemberFirstConsumeOfProductItemType[];
  memberFirstConsumeOfProductFourQuadrant: MemberFirstConsumeOfProductItemType;
};
export const getMemberFirstConsumeOfProductIntervalDaysPort = (params: ReqParams) =>
  http.post<memberFirstConsumeOfProductIntervalDaysType>(
    `${PORT1}/memberAnalyse/memberFirstConsumeOfProductIntervalDays`,
    params
  );

/**
 * 新会员分析-首次产品消费间隔矩阵分析
 */
export type MemberFirstConsumeOfCardItemType = {
  amount: number; // 首次产品消费客单
  days: number; // 首次产品产品消费间隔
};
export type MemberFirstConsumeOfCardIntervalDaysType = {
  memberFirstConsumeOfCard: MemberFirstConsumeOfCardItemType[];
  memberFirstConsumeOfCardFourQuadrant: MemberFirstConsumeOfCardItemType;
};
export const getMemberFirstConsumeOfCardIntervalDaysPort = (params: ReqParams) =>
  http.post<MemberFirstConsumeOfCardIntervalDaysType>(`${PORT1}/memberAnalyse/memberFirstConsumeOfCardIntervalDays`, params);

/**
 * 老会员分析-关键指标 活跃度
 */
export type OldMemberKeyIndicatorActivityItemType = {
  [key: string]: { keyIndicator: number; keyIndicatorIncreasePer: number };
};
export type OldMemberKeyIndicatorOtherItemType = {
  [key: string]: number;
};
export type OldMemberKeyIndicatorType = {
  oldMemberActivity: OldMemberKeyIndicatorActivityItemType;
  oldMemberOtherKeyIndicator: OldMemberKeyIndicatorOtherItemType;
};
export const getOldMemberKeyIndicatorPort = (params: ReqParams) =>
  http.post<OldMemberKeyIndicatorType>(`${PORT1}/memberAnalyse/oldMemberKeyIndicator`, params);

/**
 * 会员消费习惯-会员消费时段分析
 */
export type MemberConsumeTimePeriodAnalyseItemType = {
  holidayMemberCount: number; // 人数（节假日）
  restDayMemberCount: number; // 人数（双休日）
  timePeriod: string; // 时间段
  workdayMemberCount: number; // 人数（工作日）
};
export const getMemberConsumeTimePeriodAnalysePort = (params: ReqParams) =>
  http.post<MemberConsumeTimePeriodAnalyseItemType[]>(`${PORT1}/memberAnalyse/memberConsumeTimePeriodAnalyse`, params, {
    noLoading: true
  });

/**
 * 大客户分析-消费对比分析
 */
export type bigMemberComparisonConsumeFreqType = {
  [key: string]: number;
};

export type bigMemberComparisonPerPersonAmountType = {
  [key: string]: number;
};

export type bigMemberConsumeComparisonAnalysisType = {
  consumeFreq: bigMemberComparisonConsumeFreqType;
  perPersonAmount: bigMemberComparisonPerPersonAmountType;
};

export const getBigMemberConsumeComparisonAnalysisPort = (params: ReqParams) =>
  http.post<bigMemberConsumeComparisonAnalysisType>(`${PORT1}/memberAnalyse/bigMemberConsumeAnalyse`, params);

/**
 * 大客户分析-消费偏好
 */
export type independentNursingPreferencesType = {
  nursingServiceName: string; //护理服务名称
  orderCount: number; //数值
};
export type overlayNursingPreferencesType = {
  nursingServiceName: string; //护理服务名称
  orderCount: number; //数值
};
export type productTypePreferencesType = {
  productTypeName: string; //产品品类名称
  countRatio: number; //占比
};
export type productPreferencesType = {
  productName: string; //产品名称
  subtotalCount: number; //数值
};
export type bigMemberConsumePreferencesType = {
  independentNursingPreferences: independentNursingPreferencesType[];
  overlayNursingPreferences: overlayNursingPreferencesType[];
  productTypePreferences: productTypePreferencesType[];
  productPreferences: productPreferencesType[];
};

export const getBigMemberConsumptionHabitPort = (params: ReqParams) =>
  http.post<bigMemberConsumePreferencesType>(`${PORT1}/memberAnalyse/bigMemberConsumePreferences`, params);

/**
 * 大客户分析-贡献排名
 */
export type bigMemberRankingOfContributionsItemType = {
  memberCode: string; // 会员编码
  memberName: string; // 会员姓名
  shopName: string; // 会籍门店
  consultantName: string; // 专属顾问
  beauticianName: string; // 专属美容师
  joinDate: string; // 入会日期
  yearDiff: string; // 入会年限
  // addUpAmount: number; // 充值金额
  avgUpCounts: number; // 月均消费次数
  bigMemberPpt: number; // 人次客单
  addUpAmount: number; // 消费金额
  btreAmount: number; // 护理消费金额
  bprdAmount: string; // 产品消费金额
  productRate: number; // 产品占比
  contributionRatio: number; //贡献占比
};
export const getBigMemberRankingOfContributionsPort = (params: ReqParams) =>
  http.post<bigMemberRankingOfContributionsItemType[]>(`${PORT1}/memberAnalyse/bigMemberRankingOfContributions`, params);

/**
 * 大客户分析- export 导出大客户贡献排名table数据
 */
export const exportBigMemberRankingTableDataPort = (params: ReqParams) =>
  http.download(`${PORT1}/memberAnalyse/exportBigMemberRankingOfContributions`, params);

/**
 * 会员消费习惯-会员消费时段分析
 */
export type MemberConsumeOrderAnalyseItemType = {
  orderCountRatio: number; // 订单数权重
  pricePeriod: string; // 金额段
};
export const getMemberConsumeOrderAnalysePort = (params: ReqParams) =>
  http.post<MemberConsumeOrderAnalyseItemType[]>(`${PORT1}/memberAnalyse/memberConsumeOrderAnalyse`, params, {
    noLoading: true
  });

/**
 * 会员消费偏好监控-护理偏好
 */
export type AttributePenetrationItemType = {
  [key: string]: any;
};
export type NursingServicePreferencesItemType = {
  nursingServiceName: string; // 护理服务名称
  orderCount: number; // 数值
};
export type NursingServiceSalesVolumeItemType = {
  nursingServiceName: string;
  salesVolume: number;
  salesVolumeRatio: number;
};
export type MemberConsumeNursingServicePreferencesType = {
  attributePenetration: AttributePenetrationItemType[]; // 独立护理会员属性渗透
  nursingServicePreferences: NursingServicePreferencesItemType[]; // 护理服务偏好
  nursingServiceSalesVolume: NursingServiceSalesVolumeItemType[]; // 叠加搭配销量
};
export const getMemberConsumeNursingServicePreferencesPort = (params: ReqParams) =>
  http.post<MemberConsumeNursingServicePreferencesType>(`${PORT1}/memberAnalyse/memberConsumeNursingServicePreferences`, params, {
    noLoading: true
  });

/**
 * 导出 独立护理会员属性渗透 export table data
 */
export const exportIndependentMemberAttributePort = (params: ReqParams) =>
  http.download(`${PORT1}/memberAnalyse/exportMemberConsumeNursingServicePreferences`, params, {
    noLoading: true
  });

/**
 * 会员消费偏好监控-产品偏好
 */
export type ProductPreferencesItemType = {
  productName: string; // 产品名称
  subtotalCount: number; // 数值
};
export type ProductTypePreferencesItemType = {
  countRatio: number; // 占比
  productTypeName: string; // 产品品类名称
};
export type MemberConsumeProductPreferencesType = {
  productPreferences: ProductPreferencesItemType[]; // 产品偏好
  productTypePreferences: ProductTypePreferencesItemType[]; // 产品品类偏好
  productTypeAttributePenetration: AttributePenetrationItemType[]; // 产品品类会员属性渗透
  productByAgeRegion: { ageRegion: string; ageRegionRatio: number }[]; // 产品年龄分析
};
export const getMemberConsumeProductPreferencesPort = (params: ReqParams) =>
  http.post<MemberConsumeProductPreferencesType>(`${PORT1}/memberAnalyse/memberConsumeProductPreferences`, params, {
    noLoading: true
  });

/**
 * 会员消费偏好监控- export 产品品类会员属性渗透 table data
 */
export const exportProductCategoryAttributeTablePort = (params: ReqParams) =>
  http.download(`${PORT1}/memberAnalyse/exportMemberConsumeProductPreferences`, params, {
    noLoading: true
  });

/**
 * 流失会员分析-数据集
 */
export type MemberChurnAnalyseItemType = {
  avgMemberChurnCount: number; // 人均流失人数
  memberChurnRatio: number; // 流失率
  shopName: string; // 门店
};
export type MemberChurnRankingForBeauticianItemType = {
  empId: string; // 工号
  employeeLevel: string; // 员工等级
  employeeName: string; // 员工名称
  memberChurnCount: number; // 流失人数
  memberChurnRatio: number; // 流失率
  newMemberCount: number; // 新增会员人数
  oldMemberCount: number; // 老会员人数
  totalMemberCount: number; // 会员总人数
};
export type MemberChurnRankingForConsultantItemType = {
  empId: string; // 工号
  employeeLevel: string; // 员工等级
  employeeName: string; // 员工名称
  memberChurnCount: number; // 流失人数
  memberChurnRatio: number; // 流失率
  newMemberCount: number; // 新增会员人数
  oldMemberCount: number; // 老会员人数
  totalMemberCount: number; // 会员总人数
};
export type MemberChurnTrendItemType = {
  memberChurnCount: number; // 流失人数
  memberChurnRatio: number; // 流失率
  statMonth: string; // 统计月
};
export type LostMemberMfrMatrixItemType = {
  amount: number; // 金额
  frequency: number; // 频次
};
export type LostMemberChurnAnalyseType = {
  memberChurnAnalyse: MemberChurnAnalyseItemType[]; // 已流失会员分析
  memberChurnAnalyseFourQuadrant: { x: number; y: number };
  memberChurnRankingForBeautician: MemberChurnRankingForBeauticianItemType[]; // 美容师排名
  memberChurnRankingForConsultant: MemberChurnRankingForConsultantItemType[]; // 顾问排名
  memberChurnTrend: MemberChurnTrendItemType[]; // 月度趋势
  mfrMatrix: LostMemberMfrMatrixItemType[]; // MF_R矩阵
  mfrMatrixFourQuadrant: LostMemberMfrMatrixItemType;
};
export const getLostMemberChurnAnalysePort = (params: ReqParams) =>
  http.post<LostMemberChurnAnalyseType>(`${PORT1}/memberAnalyse/memberChurnAnalyse`, params);

/**
 * 流失会员分析-导出流失会员for 顾问table数据
 */
export const exportLostMemberForConsultantPort = (params: ReqParams) =>
  http.download(`${PORT1}/memberAnalyse/exportMemberChurnRankingForConsultant`, params);

/**
 * 流失会员分析-导出流失会员for 美容师table数据
 */
export const exportLostMemberForBeauticianPort = (params: ReqParams) =>
  http.download(`${PORT1}/memberAnalyse/exportMemberChurnRankingForBeautician`, params);

/**
 * 会员预警-预警分析
 */
export type MemberWarningAnalyseItemType = {
  shopName: string; // 门店
  shopId: string;
  x: number; // 入会未消费：人均管理未消费人数；免费权益：人均剩余次数
  y: number; // 入会未消费：人均充值金额；免费权益：人均使用率
};
export type MemberWarningAnalyseType = {
  memberWarningAnalyse: MemberWarningAnalyseItemType[];
};
export const getMemberWarningAnalysePort = (params: ReqParams) =>
  http.post<MemberWarningAnalyseType>(`${PORT1}/memberAnalyse/memberWarningAnalyse`, params, { noLoading: true });

/**
 * 会员预警-免费权益分析
 */
export type MemberFreeRightsAnalyseItemType = {
  cardName: string; // 卡名称
  cardType: string; // 卡类型
  freeCount: number; // 赠送次数
  remainingCount: number; // 剩余次数
  rightsName: string; // 权益名称
  rightsType: string; // 权益分类
  usageRate: number; // 使用率
  useCount: number; // 使用次数
};
export const getMemberFreeRightsAnalysePort = (params: ReqParams) =>
  http.post<MemberFreeRightsAnalyseItemType[]>(`${PORT1}/memberAnalyse/memberFreeRightsAnalyse`, params, { noLoading: true });

/**
 * 会员预警-免费权益分析
 */
export type MemberBalanceWarningItemType = {
  avgCount: number; // 月均消费频次
  avgDateDiff: string; // 消费间隔
  balanceAmount: number; // 卡内余额
  beauticianName: string; // 专属美容师
  consultantName: string; // 专属顾问
  joinYear: string; // 入会年限
  lastBuyCardAmount: number; // 上次充值金额
  memberAge: string; // 年龄
  memberClassify: string; // 会员类型
  memberCode: string; // 卡号
  memberLevel: string; // VIP等级
  memberName: string; // 姓名
  memberPhone: string; // 手机号
  mmPpt: number; // 客单
  shopName: string; // 会籍门店
};
export const getMemberBalanceWarningPort = (params: ReqParams) =>
  http.post<MemberBalanceWarningItemType[]>(`${PORT1}/memberAnalyse/memberBalanceWarning`, params, { noLoading: true });

/**
 * 会员预警- 导出预警会员分析table数据
 */
export const exportMemberBalanceWarningPort = (params: ReqParams) =>
  http.download(`${PORT1}/memberAnalyse/exportMemberBalanceWarning`, params);

/**
 *  买卡转化分析 export 数据
 */
export const exportMemberBuyCardConversionAnalyseChartDataPort = (params: ReqParams) =>
  http.download(`${PORT1}/memberAnalyse/exportMemberBuyCardConversionAnalyse`, params);

/**
 *  新会员复购买卡分析 export 数据
 */
export const exportMemberRepetitionBuyCardOfShopChartDataPort = (params: ReqParams) =>
  http.download(`${PORT1}/memberAnalyse/exportMemberRepetitionBuyCardOfShop`, params);

/**
 *  新会员首次产品消费间隔 export 数据
 */
export const exportMemberFirstConsumeOfProductIntervalDaysChartDataPort = (params: ReqParams) =>
  http.download(`${PORT1}/memberAnalyse/exportMemberFirstConsumeOfProductIntervalDays`, params);

/**
 *  新会员复购护理买卡间隔 export 数据
 */
export const exportMemberFirstConsumeOfCardIntervalDaysChartDataPort = (params: ReqParams) =>
  http.download(`${PORT1}/memberAnalyse/exportMemberFirstConsumeOfCardIntervalDays`, params);

/**
 *  已流失会员分析 export 数据
 */
export const exportMemberChurnAnalyseChartDataPort = (params: ReqParams) =>
  http.download(`${PORT1}/memberAnalyse/exportMemberChurnAnalyse`, params);

/**
 *  会员消费订单分析 export 数据
 */
export const exportMemberWarningAnalyseChartDataPort = (params: ReqParams) =>
  http.download(`${PORT1}/memberAnalyse/exportMemberWarningAnalyse`, params);
