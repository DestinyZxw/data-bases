import { ReqParams } from '@/api/interface';
import { PORT1 } from '@/api/config/servicePort';
import http from '@/api';

/**
 *  财务部报表 模块
 */

/**
 * 生美收款分类汇总表  table表格数据
 * */
export type IncomeTableItemType = {
  kmAmount1: number; // 浦东嘉里收款
  kmAmount2: number; // 苏州中心收款
  lbAmount: number; // 生美收款
  otherAmount: number; // 其他收款金额
  shopId: string; // 门店id
  shopName: string; // 门店
  totalAmount: number; // 合计
};
export const getShengMeiIncomeTableIPort = (params: ReqParams) =>
  http.post<IncomeTableItemType[]>(`${PORT1}/zykm/getZykmOrderSummaryZy`, params, { noLoading: true });

/**
 *  生美收款分类汇总表 export 数据
 */
export const exportShengMeiIncomeTableIPort = (params: ReqParams) =>
  http.download(`${PORT1}/zykm/exportZykmOrderSummaryZy`, params);

/**
 * 科美收款分类汇总表  table表格数据
 * */
export const getKeMeiIncomeTableIPort = (params: ReqParams) =>
  http.post<IncomeTableItemType[]>(`${PORT1}/zykm/getZykmOrderSummaryKm`, params, { noLoading: true });

/**
 *  科美收款分类汇总表 export 数据
 */
export const exportKeMeiIncomeTableIPort = (params: ReqParams) => http.download(`${PORT1}/zykm/exportZykmOrderSummaryKm`, params);

/**
 * 生美代收科美收款方式表  table表格数据
 * */
export interface ProxyItemType {
  cash: number;
  creditCard: number;
  receiver: string;
  shopId: number;
  shopName: string;
  totalAmount: number;
  wxpos: number;
  zfbpos: number;
}
export const getShengMeiProxyKeMeiTableIPort = (params: ReqParams) =>
  http.post<ProxyItemType[]>(`${PORT1}/zykm/getZykmPaySummaryZy`, params, { noLoading: true });

/**
 *  生美代收科美收款方式表 export 数据
 */
export const exportShengMeiProxyKeMeiTableIPort = (params: ReqParams) =>
  http.download(`${PORT1}/zykm/exportZykmPaySummaryZy`, params);

/**
 * 科美代收生美收款方式表  table表格数据
 * */
export const getKeMeiProxyShengMeiTableIPort = (params: ReqParams) =>
  http.post<ProxyItemType[]>(`${PORT1}/zykm/getZykmPaySummaryKm`, params, { noLoading: true });

/**
 *  科美代收生美收款方式表 export 数据
 */
export const exportKeMeiProxyShengMeiTableIPort = (params: ReqParams) =>
  http.download(`${PORT1}/zykm/exportZykmPaySummaryKm`, params);
