import { ReqParams } from '@/api/interface';
import { PORT1 } from '@/api/config/servicePort';
import http from '@/api';

/**
 *  护理项目 模块
 */

/**
 *  生命周期分析表 table 数据
 */
export interface NurseTableItemType {
  avgPrice: number;
  barChartData: {
    axisData: string[];
    seriesData: number[];
  };
  cost: number; // 成本
  device: string; // 仪器
  freeCount: number; //免单数量
  freeRate: number; // 免单率
  memberCount: number; // 会员销量
  memberRate: number; // 会员占比
  moduleName: string; // 模块
  netCount: number; // 销量不含免单
  nonmemberCount: number; //非会员销量
  nursingServiceCode: string; //项目编号
  nursingServiceName: string; // 项目名称
  nursingServiceType: number; // 护理类型
  onSaleDate: string; // 上市时间
  price: number; // 吊牌价
  profit: number; // 毛利
  profitRate: string; // 利润率
  spendTime: number; // 护理时间
  totalAmount: number; // 实际销售额
  totalAmountRate: number; // 护理金占比
}
export const getNurseTablePort = (params: ReqParams) =>
  http.post<NurseTableItemType[]>(`${PORT1}/nursingService/nursingLifeCycle`, params, { noLoading: true });

/**
 * @description: 获取利润报表的数据的接口
 */
export type NurseTypes =
  | 'bodyAmountProfitModel'
  | 'bodySaleCountProfitModel'
  | 'faceAmountProfitModel'
  | 'faceSaleCountProfitModel'
  | 'machineAmountProfitModel'
  | 'machineSaleCountProfitModel';

export type NurseItem = {
  data: [number, number][];
  nursingServiceName: string;
  nursingServiceCode: string;
};

export type NurseTableType = Record<NurseTypes, NurseItem[]> & { nursingServiceNameList: string[] };

export const getProfitAnalysisInfoPort = (params: ReqParams) =>
  http.get<NurseTableType>(`${PORT1}/nursingService/nursingChartData`, params);

/**
 * @description: 获取护理详情接口的接口
 */
export type CoordinateEnums =
  | 'netAmountData'
  | 'saleAmountData'
  | 'saleCountData'
  | 'shopSaleAmountRankData'
  | 'shopSaleCountRankData';

export type PieChartEnums = 'memberLevelPieData' | 'prefixMemberLevelPieData' | 'suffixMemberLevelXPieData';

export type CardItemEnums = 'totalSaleCount' | 'totalSaleAmount' | 'repurchaseMemberCount' | 'repurchaseRate';

export type CoordinateType = { axisData: string[]; seriesData: number[] };

export type PieChartItemType = { name: string; value: number };

export type BomTableItemType = {
  accessory: string;
  dosage: string;
  productCode: string;
  productName: string;
  remark: string;
  seqName: string;
  stepSeq: number;
};

export type BomSheetItemType = {
  sheetCode: string;
  sheetName: string;
  nursingServiceSheetDtlModelList: BomTableItemType[];
};

export type BomOptionsItemType = Omit<BomSheetItemType, 'nursingServiceSheetDtlModelList'>;

export type NurseDetailType = Record<CoordinateEnums, CoordinateType> &
  Record<PieChartEnums, PieChartItemType[]> &
  Record<CardItemEnums, number> & {
    avgSaleAmount: number;
    avgSaleCount: number;
    description: string | null;
    tagList: string[];
    memberLevelSaleCountData: {
      axis: string[];
      series: { name: string; data: number[] }[];
    };
    memberTypeData: Array<(string | number)[]>;
    nursingServiceSheetModelList: BomSheetItemType[];
  };

export const getNurseDetailPort = (params: ReqParams) =>
  http.get<NurseDetailType>(`${PORT1}/nursingService/nursingDetailInfo`, params);

/**
 * @description:  护理详情页面 护理表格的信息
 */
export type NurseDetailTableItemType = {
  avgPrice: number;
  cost: number;
  discountRate: number;
  freeCount: number;
  freeRate: number;
  netCount: number;
  price: number;
  profit: number;
  totalAmount: number;
  totalCount: number;
  year: number;
  device: string;
  memberLevelRate: { [key: string]: number };
};
export const getNurseDetailTablePort = (params: ReqParams) =>
  http.get<NurseDetailTableItemType[]>(`${PORT1}/nursingService/nursingYearData`, params);
