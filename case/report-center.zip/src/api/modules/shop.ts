import { ReqParams } from '@/api/interface';
import { PORT1 } from '@/api/config/servicePort';
import http from '@/api';

/**
 *  门店管理 模块
 */

/**  门店顾客分析  table表格数据*/
export type CustomerReportTableItemType = {
  amount: number; // 本月实际
  completionRate: number; // 本月目标完成率
  increasePer: number; // 同比增长
  planTypeCode: string; // 分类code
  spAmount: number; // 上年同期
  spYearAmount: number; // 去年实际
  target: number; // 本月目标
  type: string; // 分类/项目
  yearAmount: number; // 本年实际
  yearCompletionRate: number; // 本年目标达成率
  yearIncreasePer: number; // 同店同比
  yearTarget: number; // 本年预算
};
export const getShopCustomerReportTablePort = (params: ReqParams) =>
  http.post<CustomerReportTableItemType[]>(`${PORT1}/shopReport/member/summary`, params, { noLoading: true });

/*** 门店效能分析  table表格数据*/
export type EfficiencyAnalyseTableItemType = {
  currentPeriodValue: number; // 当期实际
  currentYearValue: number; // 本年累计
  increasePer: number; // 同比增长
  planTypeCode: string; // 分类code
  prePeriodValue: number; // 上期实际
  preYearValue: number; // 上年累计
  type: string; // 分类/项目
  userCount: number; // 员工人数
  yearIncreasePer: number; // 同比增长（年度累计）
};
export const getShopEfficiencyAnalyseTablePort = (params: ReqParams) =>
  http.post<EfficiencyAnalyseTableItemType[]>(`${PORT1}/shopReport/efficiencyAnalyse`, params);

/*** 门店效能分析  顾客时段消费数据*/
export type MemberStatisticsTimePeriodItemType = {
  count: number;
  timePeriod: string;
};
export const getShopMemberStatisticsTimePeriodPort = (params: ReqParams) =>
  http.post<MemberStatisticsTimePeriodItemType[]>(`${PORT1}/shopReport/memberStatisticsTimePeriod`, params, { noLoading: true });

/*** 产品销售 - 有效产品销售大类分布  table数据*/
export type ProductCategoriesSalesTableItemType = {
  [key: string]: any;
};
export const getProductCategoriesSalesTablePort = (params: ReqParams) =>
  http.post<ProductCategoriesSalesTableItemType[]>(`${PORT1}/productReport/productCategoriesSalesDistribution`, params);

/*** 产品销售 - 产品SKU数分布  table数据*/
export const getProductSkuTablePort = (params: ReqParams) =>
  http.post<ProductCategoriesSalesTableItemType[]>(`${PORT1}/productReport/productSkuDistribution`, params);

/*** 产品销售 - 产品客院装销售占比数据*/
export type ProductSalesRatioPortType = {
  productPackTypeCode: string; // 包装code
  productPackTypeName: string; // 包装名称
  subTotalAmount: number; // 销售金额
  totalAmount: number; //总销售金额
};
export const getProductSalesRatioPort = (params: ReqParams) =>
  http.post<ProductSalesRatioPortType[]>(`${PORT1}/productReport/productSpecificationSalesRatio`, params);

/*** 产品销售 - 产品波士顿矩阵及帕累托图数据*/
export type ProductPackTypeAnalyseType = {
  productCode: string; // 产品编码
  productName: string; // 产品名称
  subGrossTotalAmount: number; // 毛利额
  cumulative: number; // 销售权重
  subSalesCount: number; // 销售数量
  subTotalAmount: number; // 销售金额
  totalAmount: number; // 总销售金额
};
export const getProductPackTypeAnalysePort = (params: ReqParams) =>
  http.post<ProductPackTypeAnalyseType[]>(`${PORT1}/productReport/productPackTypeAnalyse`, params);

/*** 护理销售 - 销售类别结构table item 数据*/
export type NursingSaleAnalyseTableItemType = {
  grossMargin: number; // 毛利率
  grossMarginSigma: number; // 毛利率Σ
  nursingServicePositionName: string; // 分类（护理部位名）
  salesAmountRatio: number; // 销售结构
  salesCountRatio: number; // 数量结构
  subtotalSalesAmount: number; // 销售金额
  subtotalSalesCount: number; // 销售数量
  cumulative: number; // 销售权重
};
export const getNursingSaleAnalyseTablePort = (params: ReqParams) =>
  http.post<NursingSaleAnalyseTableItemType[]>(`${PORT1}/shopReport/nursingSaleAnalyse`, params);

/*** 护理销售 - 导出销售类别结构table item 数据*/
export const exportNursingSaleAnalysePort = (params: ReqParams) =>
  http.download(`${PORT1}/shopReport/exportNursingSaleAnalyse`, params);

/*** 护理销售 - 护理分析数据数据*/
export type NursingServiceAnalyseType = {
  grossMargin: number; // 毛利率
  hourlyGrossProfit: number; // 小时毛利
  nursingServiceName: string; // 护理服务名称
  cumulative: number; // 销售权重
  subtotalGrossAmount: number; // 毛利额
  subtotalSalesAmount: number; // 销售额
  subtotalSalesCount: number; // 销售数量
};
export const getNursingServiceAnalysePort = (params: ReqParams) =>
  http.post<NursingServiceAnalyseType[]>(`${PORT1}/shopReport/nursingServiceAnalyse`, params);

/*** 护理销售 - 小时毛利*/
export const getNursingServiceHourlyGrossProfitPort = (params: ReqParams) =>
  http.post<NursingServiceAnalyseType[]>(`${PORT1}/shopReport/nursingServiceHourlyGrossProfit`, params);

/*** 员工体验顾客管理 - table 及 买卡转化率的 相关数据*/
export type MemberExperienceTableItemType = {
  amount: number; // 买卡客单
  amountPer: number; // 买卡客单（同比）
  buyCount: number; // 体验顾客买卡人次
  buyCountPer: number; // 体验顾客买卡人次（同比）
  employeeName: string; // 员工名称
  experienceBuyRatio: number; // 买卡转换率
  experienceBuyRatioPer: number; // 买卡转换率（同比）
  experienceCount: number; // 体验顾客人次
  experienceCountPer: number; // 体验顾客人次（同比）
  shopName: string; // 门店
};
export const getMemberExperienceTablePort = (params: ReqParams) =>
  http.post<MemberExperienceTableItemType[]>(`${PORT1}/shopReport/shopMemberExperienceAndBuyCard`, params);

/*** 员工体验顾客管理 - export 体验顾客表*/
export const exportMemberExperienceTablePort = (params: ReqParams) =>
  http.download(`${PORT1}/shopReport/exportShopMemberExperienceAndBuyCard`, params);

/*** 新会员管理 - table 及 买卡转化率的 相关数据*/
export type NewMemberManagerTableItemType = {
  employeeName: string; // 员工名称
  nursingAmount: number; // 护理业绩180天
  productAmount: number; // 产品业绩180天
  repetitionBuyCount: number; // 复购人数
  repetitionBuyRatio: number; // 复购率
  shopName: string; // 门店
  yearNursingAmount: number; // 护理业绩360天
  yearProductAmount: number; // 产品业绩360天
};
export const getNewMemberManagerTablePort = (params: ReqParams) =>
  http.post<NewMemberManagerTableItemType[]>(`${PORT1}/shopReport/shopNewMemberManager`, params);

/*** 新会员管理 - export员工新会员管理表格*/
export const exportNewMemberManagerTablePort = (params: ReqParams) =>
  http.download(`${PORT1}/shopReport/exportShopNewMemberManager`, params);

/*** 老会员管理 - table 及 买卡转化率的 相关数据*/
export type OldMemberManagerTableItemType = {
  achieveRatio: string; // 达成率
  employeeName: string; // 员工名称
  perPerson: number; // 人次
  perPersonAmount: number; // 人次客单
  perPersonAmountIncreasePer: number; // 人次客单同比
  perPersonIncreasePer: number; // 人次同比
  personCount: number; // 人数
  personCountAmount: number; // 人数客单
  personCountAmountIncreasePer: number; // 人数客单同比
  prePersonCountIncreasePer: number; // 人数同比
  preVisitFreq: number; // 到店频次同期
  shopName: string; // 门店
  visitFreq: number; // 到店频次本期
};
export const getOldMemberManagerTablePort = (params: ReqParams) =>
  http.post<OldMemberManagerTableItemType[]>(`${PORT1}/shopReport/shopOldMemberManager`, params);

/*** 老会员管理 - export导出表格数据 */
export const exportOldMemberManagerTablePort = (params: ReqParams) =>
  http.download(`${PORT1}/shopReport/exportShopOldMemberManager`, params);

/*** 顾问专属会员管理 - table 及 买卡转化率的 相关数据*/
export type ConsultantExclusiveMemberTableItemType = {
  employeeName: string; //  员工名称
  perPersonAmount: number; // 专属人次客单
  personChurnRatio: number; // 老会员流失率
  personChurnRatioIncreasePer: number; // 老会员流失率同比
  personCount: number; // 专属管理人数
  personCountAmount: number; // 专属人数客单
  shopName: string; // 门店
  visitFreq: number; // 专属频次
  visitPerPerson: number; // 专属人次
  visitPersonCount: number; // 专属进店人数
  visitRatio: number; // 专属进店率
};
export const getConsultantExclusiveMemberTablePort = (params: ReqParams) =>
  http.post<ConsultantExclusiveMemberTableItemType[]>(`${PORT1}/shopReport/consultantExclusiveMemberManage`, params);

/*** 顾问专属会员管理 - export导出表格数据*/
export const exportConsultantExclusiveMemberTablePort = (params: ReqParams) =>
  http.download(`${PORT1}/shopReport/exportConsultantExclusiveMemberManage`, params);

/*** 顾问专属会员管理-人数及客单 四个小chart图表 相关数据*/
export type ConsultantExclusiveMemberChartDataType = {
  employeeName: string; // 员工名称
  nursingPersonCount: number; // 护理购买人数
  nursingPersonCountAmount: number; // 护理人数客单
  productBuyPersonCount: number; // 产品购买人数
  productBuyPersonCountAmount: number; // 产品人数客单
  nursingPersonCountRatio: number; // 护理购买人数占比
  productBuyPersonCountRatio: number; // 产品购买人数占比
};
export const getConsultantExclusiveMemberChartDataPort = (params: ReqParams) =>
  http.post<ConsultantExclusiveMemberChartDataType[]>(
    `${PORT1}/shopReport/consultantExclusiveMemberPersonCountAndAmount`,
    params
  );

/*** 明细排行榜 -- 目标达成排名 相关数据*/
export type ReachTheGoalRankItemType = {
  employeeName: string; // 员工名称
  itemValue: number; // 护理购买人数
};
export type StarEmployeeForReachTheGoalRankType = {
  topTen: ReachTheGoalRankItemType[];
  endTen: ReachTheGoalRankItemType[];
};
export const getStarEmployeeForReachTheGoalRankPort = (params: ReqParams) =>
  http.post<StarEmployeeForReachTheGoalRankType>(`${PORT1}/shopReport/starEmployeeForReachTheGoalRank`, params, {
    noLoading: true
  });

/*** 明细排行榜 -- 门店创新高 相关数据*/
export type StarEmployeeForNewHighItemType = {
  currentCashMaxValue: number; // 本年月度新高-现金
  currentNursingMaxValue: number; // 本年月度新高-开单
  currentProductMaxValue: number; // 本年月度新高-产品
  employeeName: string; // 名称
  prevCashMaxValue: number; // 上年月度新高-现金
  prevNursingMaxValue: number; // 上年月度新高-开单
  prevProductMaxValue: number; // 上年月度新高-产品
  shopName: string; // 类别：1 - 门店，2 - 员工
};
export const getStarEmployeeForNewHighTablePort = (params: ReqParams) =>
  http.post<StarEmployeeForNewHighItemType[]>(`${PORT1}/shopReport/starEmployeeForNewHigh`, params, {
    noLoading: true
  });

/*** 明细排行榜 -- 门店创新高 相关数据*/
export type StarEmployeeForSalesChampionItemType = {
  amount: number; // 金额
  name: string; // 姓名
  topic: string; // 主题
  type: string; // 类别：1 - 门店，2 - 员工
};
export const getStarEmployeeForSalesChampionPort = (params: ReqParams) =>
  http.post<StarEmployeeForSalesChampionItemType[]>(`${PORT1}/shopReport/starEmployeeForSalesChampion`, params, {
    noLoading: true
  });

/*** 明细排行榜 -- 最佳进步 相关数据*/
export type StarEmployeeForBestProgressItemType = {
  increasePer: number; // 同比
  name: string; // 名称
  rank: number; // 排名
  type: string; // 类别：1 - 门店，2 - 员工
};
export const getStarEmployeeForBestProgressPort = (params: ReqParams) =>
  http.post<StarEmployeeForBestProgressItemType[]>(`${PORT1}/shopReport/starEmployeeForBestProgress`, params, {
    noLoading: true
  });

/*** 顾问个人效能  table数据*/
export type ConsultantEfficiencyTableItemType = {
  consultantPerformanceIncreasePer: number; // 员工劳效-同比
  consultantServicePerPersonIncreasePer: number; // 服务人次-同比
  consultantServicePersonCountIncreasePer: number; // 服务人数-同比
  currentPeriodConsultantPerformance: number; // 员工劳效-实际
  currentPeriodConsultantServicePerPerson: number; // 服务人次-实际
  currentPeriodConsultantServicePersonCount: number; // 服务人数-实际
  employeeName: string; // 员工名称
  shopName: string; // 门店名称
};
export const getConsultantEfficiencyTablePort = (params: ReqParams) =>
  http.post<ConsultantEfficiencyTableItemType[]>(`${PORT1}/shopReport/consultantEfficiency`, params, { noLoading: true });

/*** 顾问个人效能 -- export导出表格数据*/
export const exportConsultantEfficiencyTablePort = (params: ReqParams) =>
  http.download(`${PORT1}/shopReport/exportConsultantEfficiency`, params, { noLoading: true });

/*** 美容师个人效能  table数据*/
export type BeauticianEfficiencyTableItemType = {
  beauticianPerBedRateIncreasePer: number; // 翻床率-同比
  beauticianPerformanceIncreasePer: number; // 员工劳效-同比
  beauticianWorkHourIncreasePer: number; // 工时-同比
  beauticianWorkHourPerPersonIncreasePer: number; // 工时客单-同比
  currentPeriodBeauticianPerBedRate: number; // 翻床率-实际
  currentPeriodBeauticianPerformance: number; // 员工劳效-实际
  currentPeriodBeauticianWorkHour: number; // 工时-实际
  currentPeriodBeauticianWorkHourPerPerson: number; // 工时客单-实际
  employeeName: string; // 员工名称
  shopName: string; // 门店名称
};
export const getBeauticianEfficiencyTablePort = (params: ReqParams) =>
  http.post<BeauticianEfficiencyTableItemType[]>(`${PORT1}/shopReport/beauticianEfficiency`, params, { noLoading: true });

/*** 美容师个人效能  export table数据*/
export const exportBeauticianEfficiencyTablePort = (params: ReqParams) =>
  http.download(`${PORT1}/shopReport/exportBeauticianEfficiency`, params, { noLoading: true });

/*** 销售明细  table数据*/
export type SalesAnalyseTableItemType = {
  amountRank: number; // 销售金额排名
  bigType: string; // 大类
  freeSaleCount: number; // 免单数量
  freeSaleCountRate: number; // 免单占销量数比
  grossMargin: number; // 毛利率
  hourGrossAmount: number; // 小时毛利
  itemName: string; // 护理名称
  personCountAmount: number; // 客单价
  price: number; // 单价
  pricePersonCountAmountRate: number; // 销售价与客单价比
  saleAmount: number; // 实付金额
  saleAmountRate: number; // 实付金额%
  saleCount: number; // 销售数量
  saleCountRate: number; // 销售数量%
  twoOrder: string; // 二联单
  realCount: number; // 护理销售数量
};
export const getSalesAnalyseTablePort = (params: ReqParams) =>
  http.post<SalesAnalyseTableItemType[]>(`${PORT1}/shopReport/salesDetailAnalyse`, params, { noLoading: true });

/*** 销售明细  export table数据*/
export const exportSalesAnalyseTablePort = (params: ReqParams) =>
  http.download(`${PORT1}/shopReport/exportSalesDetailAnalyse`, params, { noLoading: true });

/**
 *  产品销售页面 -- 有效产品销售大类分布 export 数据
 */
export const exportProductCategoriesSalesDistributionPort = (params: ReqParams) =>
  http.download(`${PORT1}/productReport/exportProductCategoriesSalesDistribution`, params);

/**
 *  客装帕累托图 export 数据
 */
export const exportProductPackTypeAnalysePassengerParetoChartDataPort = (params: ReqParams) =>
  http.download(`${PORT1}/productReport/exportProductPackTypeAnalysePassengerParetoChart`, params);

/**
 *  客装产品矩阵 export 数据
 */
export const exportProductPackTypeAnalyseCustomerProductMatrixChartDataPort = (params: ReqParams) =>
  http.download(`${PORT1}/productReport/exportProductPackTypeAnalyseCustomerProductMatrix`, params);

/**
 *  面部独立-高频帕累托 export 数据
 */
export const exportNursingServiceAnalyseHighFrequencyParetoChartDataPort = (params: ReqParams) =>
  http.download(`${PORT1}/shopReport/exportNursingServiceAnalyseHighFrequencyPareto`, params);

/**
 *  面部独立-高频项矩阵(毛利额销量) export 数据
 */
export const exportNursingServiceAnalyseHighFrequencyItemMatrix1ChartDataPort = (params: ReqParams) =>
  http.download(`${PORT1}/shopReport/exportNursingServiceAnalyseHighFrequencyItemMatrix1`, params);

/**
 *  面部独立-高频项矩阵(毛利率销量) export 数据
 */
export const exportNursingServiceAnalyseHighFrequencyItemMatrix2ChartDataPort = (params: ReqParams) =>
  http.download(`${PORT1}/shopReport/exportNursingServiceAnalyseHighFrequencyItemMatrix2`, params);

/**
 *  买卡转换率 export 数据
 */
export const exportShopMemberExperienceAndBuyCardExperienceBuyRatioChartDataPort = (params: ReqParams) =>
  http.download(`${PORT1}/shopReport/exportShopMemberExperienceAndBuyCardExperienceBuyRatio`, params);

/**
 *  复购率 export 数据
 */
export const exportShopNewMemberManagerRepetitionBuyRatioChartDataPort = (params: ReqParams) =>
  http.download(`${PORT1}/shopReport/exportShopNewMemberManagerRepetitionBuyRatio`, params);

/**
 *  护理人数及客单 export 数据
 */
export const exportConsultantExclusiveNursingMemberPersonCountAndAmountChartDataPort = (params: ReqParams) =>
  http.download(`${PORT1}/shopReport/exportConsultantExclusiveNursingMemberPersonCountAndAmount`, params);

/**
 *  产品人数及客单 export 数据
 */
export const exportConsultantExclusiveProductMemberPersonCountAndAmountChartDataPort = (params: ReqParams) =>
  http.download(`${PORT1}/shopReport/exportConsultantExclusiveProductMemberPersonCountAndAmount`, params);

/**
 *  老会员流失率 export 数据
 */
export const exportConsultantExclusiveMemberManagePersonChurnRatioChartDataPort = (params: ReqParams) =>
  http.download(`${PORT1}/shopReport/exportConsultantExclusiveMemberManagePersonChurnRatio`, params);

/**
 *  双美卡生美销售明细表 table数据
 */
export interface DoubleBeautifulCardItemType {
  amount: string; // 金额
  belongTo: string; // 归属单位
  cardType: string; // 卡分类
  itemName: string; // 卡名称
  memberCode: string; // 顾客号
  memberName: string; // 客户名称
  saleDate: string; // 购卡日期
  saleOrderCode: string; // 销售单号
  shopName: string; // 门店
}
export const getShengMeiTableDataPort = (params: ReqParams) =>
  http.post<DoubleBeautifulCardItemType[]>(`${PORT1}/zykm/getZykmOrderDetailListZy`, params, { noLoading: true });

/**
 *  双美卡生美销售明细表 总额
 */
export const getShengMeiTotalAmountPort = (params: ReqParams) =>
  http.post<number>(`${PORT1}/zykm/getZykmOrderTotalAmountZy`, params, { noLoading: true });

/**
 *  双美卡生美销售明细表 export 数据
 */
export const exportShengMeiTablePort = (params: ReqParams) => http.download(`${PORT1}/zykm/exportZykmOrderDetailListZy`, params);

/**
 *  双美卡科美销售明细表 table数据
 */
export const getKeMeiTableDataPort = (params: ReqParams) =>
  http.post<DoubleBeautifulCardItemType[]>(`${PORT1}/zykm/getZykmOrderDetailListKm`, params, { noLoading: true });

/**
 *  双美卡科美销售明细表 总额
 */
export const getKeMeiTotalAmountPort = (params: ReqParams) =>
  http.post<number>(`${PORT1}/zykm/getZykmOrderTotalAmountKm`, params, { noLoading: true });

/**
 *  双美卡科美销售明细表 export 数据
 */
export const exportKeMeiTablePort = (params: ReqParams) => http.download(`${PORT1}/zykm/exportZykmOrderDetailListKm`, params);
