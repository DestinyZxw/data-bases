import { ReqParams } from '@/api/interface';
import { PORT1 } from '@/api/config/servicePort';
import http from '@/api';

/**
 *  业绩管理 模块
 */
export interface SheetTableAndPieType {
  monthProductRate: number; // 本月产品占比
  monthTreatmentRate: number; // 本月开单占比
  yearProductRate: number; // 本年产品占比
  yearTreatmentRate: number; // 本年开单占比
  spMonthProductRate: number; // 同期产品占比
  spMonthTreatmentRate: number; // 同期开单占比
  spYearProductRate: number; // 去年年度产品占比
  spYearTreatmentRate: number; // 去年年度开单占比
  businessSummaryVOList: businessSummaryItemType[]; // 表格数据
}

export interface businessSummaryItemType {
  amount: number;
  completionRate: number;
  increasePer: number;
  planTypeCode: string;
  spAmount: number;
  spYearAmount: number;
  target: number;
  type: string;
  yearAmount: number;
  yearCompletionRate: number;
  yearIncreasePer: number;
  yearTarget: number;
}
/**
 *  获取业绩管理表页面的 table & pie饼图数据
 */
export const getSheetTableAndPiePort = (params: ReqParams) =>
  http.post<SheetTableAndPieType>(`${PORT1}/business/overall/performance`, params, { noLoading: true });

/**
 *  获取业绩管理表的 line折线图数据
 */
interface SheetLineItem {
  dimension: string; // x轴 基点
  value: number; // x 轴相对应的 y轴的值
}

export type SheetLineEnums = 'cashPerformanceList' | 'productPerformanceList' | 'timeList' | 'treatmentPerformanceList';
export type SheetLineType = Record<SheetLineEnums, Array<SheetLineItem>>;
export const getSheetLinePort = (params: ReqParams) =>
  http.post<SheetLineType>(`${PORT1}/business/overall/performanceChart`, params);

/**
 *  获取现金构成表页面的 table数据
 */
export interface CashTableItemType extends ProductTableItemType {
  structPer: number; // 本月结构
  increaseAmount: number; // 本月同比增长额
  increaseYearAmount: number; // 本年同比增长额
  onlineYn: boolean | null; // 是否线上
  increaseYearPer: number; // 本年同比增长率
  typeCode: string; // 分类编号
  typeName: string; // 分类名称
  yearStructPer: number; // 本年结构
}
export const getCashTablePort = (params: ReqParams) =>
  http.post<Array<CashTableItemType>>(`${PORT1}/business/cash/performance`, params);

/**
 *  获取现金构成表页面的 table数据
 */
export type CashChartItemType = {
  saleMonth: string; // 月份
  offlineAmount: number; // 线下总金额
  offlineCardAmount: number; // 线下卡项销售
  offlinePreCardAmount: number; // 线下体验顾客入会
  offlineProductAmount: number; // 线下产品销售
  onlineAmount: number; // 线上总金额
  onlineCardAmount: number; // 线上卡项销售
  onlinePreCardAmount: number; // 线上体验顾客入会
  onlineProductAmount: number; // 线上产品销售
};
export const getCashChartsPort = (params: ReqParams) =>
  http.post<Array<CashChartItemType>>(`${PORT1}/business/cash/performanceChart`, params);

/**
 *  获取开单业绩表页面的 table数据
 */
export const getBillingTablePort = (params: ReqParams) =>
  http.post<Array<ProductTableItemType>>(`${PORT1}/business/treatment/performance`, params);

/**
 *  获取开单业绩表页面的 charts的数据
 */
export interface BillChartsType {
  aovContribution: number; // 客单价贡献额
  aovIncrease: number; // 客单价增长
  aovYearIncrease: number; // 客单价累计增长
  aovIncreaseRate: number; // 客单价同比增长率
  aovYearIncreaseRate: number; // 客单价累计同比增长率
  averageOrderValue: number; // 客单价
  yearAverageOrderValue: number; // 累计客单价
  bedTurnoverRate: number; // 翻床率
  btrIncreaseRate: number; // 翻床率增长率
  passengerTraffic: number; // 客流量
  popAverageOrderValue: number; // 同期客单价
  yearPopAverageOrderValue: number; // 累计同期客单价
  popBedTurnoverRate: number; // 翻床率同期
  popPassengerTraffic: number; // 同期客流量
  ptContribution: number; // 客流量贡献额
  ptIncrease: number; // 客流量增长
  ptIncreaseRate: number; // 客流量增长率
  shopCode: string; // 门店Code
  shopName: string; // 门店
}
export const getBillingChartsPort = (params: ReqParams) =>
  http.post<BillChartsType[]>(`${PORT1}/business/treatment/performanceChart`, params);

/**
 *  获取产品业绩表页面的 table数据
 */
export interface ProductTableItemType {
  amount: number; // 本月实际
  completionRate: number; // 本月目标完成率
  increasePer: number; // 本月同比增长率
  planTypeCode: string; // 分类code
  spAmount: number; // 上年同期
  spYearAmount: number; // 去年实际累计
  target: number; // 本月目标
  type: string; // 分类/项目
  yearAmount: number; // 本年实际
  yearCompletionRate: number; //本年目标达成率
  yearIncreasePer: number; // 同店同比
  yearTarget: number; // 本年预算
}
export const getProductTablePort = (params: ReqParams) =>
  http.post<Array<ProductTableItemType>>(`${PORT1}/business/product/summary`, params);

/**
 *  获取产品业绩表页面的 table数据
 */
export interface ProductChartItemType {
  activityAmount: number; //活动销售
  averageOrderValue: number; // 人数客单
  buyProductMemberCount: number; // 产品购买人数
  normalAmount: number; //非活动销售
  offlineAmount: number; // 线下
  onlineAmount: number; // 线上
  saleMonth: string; // 月份
  totalAmount: number; // 产品销售总额
}
export const getProductChartPort = (params: ReqParams) =>
  http.post<Array<ProductChartItemType>>(`${PORT1}/business/product/performanceChart`, params);

/**
 *  各店客单价 export 数据
 */
export const exportAverageOrderValueChartDataPort = (params: ReqParams) =>
  http.download(`${PORT1}/business/treatment/exportAverageOrderValue`, params);

/**
 *  客单价同比增长率 export 数据
 */
export const exportAovIncreaseChartDataPort = (params: ReqParams) =>
  http.download(`${PORT1}/business/treatment/exportAovIncrease`, params);

/**
 *  床位周转率 export 数据
 */
export const exportConversionChartDataPort = (params: ReqParams) =>
  http.download(`${PORT1}/business/treatment/exportBedTurnoverRate`, params);

/**
 *  顾问医美现金业绩  table数据
 */
export type CounselorYMCashTableTableItemType = {
  empCode: string; // 员工号
  empName: string; // 员工姓名
  shopName: string; // 门店
  positionName: string; // 职位
  memberCode: string; // r6顾客号
  memberName: string; // r6顾客姓名
  exclusiveType: string; // 专属类型
  medicalBeautyClinic: string; // 医美诊所
  medicalBeautyMemberCode: string; // 医美顾客号
  medicalBeautyMemberName: string; // 医美顾客姓名
  medicalBeautyOrderNo: string; // 医美订单号
  orderTime: string; // 开单日期
  paymentOrderNo: number; // 收款/退款单号
  paymentTime: number; // 收款/退款日期
  amount: number; // 收款/退款金额
};
export const fetchCounselorYMCashTableTablePort = (params: ReqParams) =>
  http.post<CounselorYMCashTableTableItemType[]>(`${PORT1}/medicalBeautyCommission/medicalBeautyConsultantCash`, params, {
    noLoading: true
  });

/**
 *  美容师医美现金业绩 export 数据
 */
export const exportCounselorYMCashTableTablePort = (params: ReqParams) =>
  http.download(`${PORT1}/medicalBeautyCommission/medicalBeautyConsultantCash/export`, params);

/**
 *  顾问医美执行业绩  table数据
 */
export type CounselorYMExecuteTableTableItemType = {
  empCode: string; // 员工号
  empName: string; // 员工姓名
  shopName: string; // 门店
  positionName: string; // 职位
  memberCode: string; // r6顾客号
  memberName: string; // r6顾客姓名
  exclusiveType: string; // 专属类型
  medicalBeautyClinic: string; // 医美诊所
  medicalBeautyMemberCode: string; // 医美顾客号
  medicalBeautyMemberName: string; // 医美顾客姓名
  medicalBeautyOrderNo: string; // 医美订单号
  orderTime: string; // 开单日期
  paymentOrderNo: number; // 收款/退款单号
  paymentTime: number; // 收款/退款日期
  amount: number; // 收款/退款金额
};
export const fetchCounselorYMExecuteTableTablePort = (params: ReqParams) =>
  http.post<CounselorYMExecuteTableTableItemType[]>(`${PORT1}/medicalBeautyCommission/medicalBeautyExecution`, params, {
    noLoading: true
  });

/**
 *  美容师医美执行业绩 export 数据
 */
export const exportCounselorYMExecuteTableTablePort = (params: ReqParams) =>
  http.download(`${PORT1}/medicalBeautyCommission/medicalBeautyExecution/export`, params);
