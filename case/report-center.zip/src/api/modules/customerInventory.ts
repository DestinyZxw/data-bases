import { ReqParams } from '@/api/interface';
import { PORT1 } from '@/api/config/servicePort';
import http from '@/api';

/**
 *  门店盘点工具 模块
 */

/**  顾问季度盘点表  table表格数据*/
export type ExclusiveMemberTableItemType = {
  memberCode: string; // 卡号
  memberName: string; // 会员姓名
  age: number; // 年龄
  vipLevel: string; // 客户等级
  membershipYear: number; // 入会年限
  manageStr: string; // 专属/专管

  spCashAmount: number; // 去年现金收款总额
  cashAmount: number; // 今年现金收款总额
  spTreatmentAmount: number; // 去年开单总额
  treatmentAmount: number; // 今年开单总额
  spProductAmount: number; // 去年产品总额
  productAmount: number; // 今年产品总额

  quarterTreatmentRest: number; // 上季度护理总余额
  quarterProductRest: number; // 上季度产品总余额

  quarterCashAmount: number; // 上季度现金收款总额

  quarterTreatmentAmount: number; // 上季度开单额
  quarterProductAmount: number; // 上季度产品额
  quarterConsumeCount: number; // 上季度到店次数

  consultantName: string; // 专属顾问
};
export const getExclusiveMemberTablePort = (params: ReqParams) =>
  http.post<ExclusiveMemberTableItemType[]>(`${PORT1}/ecMember/exclusiveMemberList`, params, { noLoading: true });

/**
 *  顾问季度盘点表 export 数据
 */
export const exportExclusiveMemberPort = (params: ReqParams) => http.download(`${PORT1}/ecMember/exportExclusiveMember`, params);

/**
 *  门店无人管理有效客户盘点表 table表格数据
 */
export const getShopExclusiveMemberTablePort = (params: ReqParams) =>
  http.post<ExclusiveMemberTableItemType[]>(`${PORT1}/ecMember/shopExclusiveMemberList`, params, { noLoading: true });

/**
 *  门店无人管理有效客户盘点表 export 数据
 */
export const exportShopExclusiveMemberPort = (params: ReqParams) =>
  http.download(`${PORT1}/ecMember/exportShopExclusiveMember`, params);
