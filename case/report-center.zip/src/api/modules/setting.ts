import { ReqParams, BaseTableType, RoleItem } from '@/api/interface';
import { PORT1 } from '@/api/config/servicePort';
import http from '@/api';

/**
 *  设置 模块
 */

/**
 *  用户管理 table 数据
 */
export interface UserItem {
  avatar: string | null;
  userNo: string;
  name: string;
  postName: string;
  roleList: RoleItem[];
  lastLoginTime: string;
  haveAppPermission: number;
  [key: string]: any;
}

export interface UserTableType extends BaseTableType {
  data: UserItem[];
}

export const getUserTablePort = (params: ReqParams) =>
  http.post<UserTableType>(`${PORT1}/system/role/pageUserList`, params, { noLoading: true });

export const updateUserStatusPort = (params: ReqParams) =>
  http.post(`${PORT1}/system/role/modifyUserStates`, params, { noLoading: true });
export const updateUserRolesPort = (params: ReqParams) =>
  http.post(`${PORT1}/system/role/modifyUserRoleList`, params, { noLoading: true });

/**
 *  @description: 角色管理 table 数据
 */
export interface RoleTableType extends BaseTableType {
  data: RoleItem[];
}
export const getRolesTablePort = (params: ReqParams) =>
  http.post<RoleTableType>(`${PORT1}/system/role/listAppRoles`, params, { noLoading: true });

/**
 * @description: 获取角色下的用户列表
 */
export type RoleUserItemType = {
  userNo: string;
  [key: string]: any;
};
export const getRoleUserListPort = (params: ReqParams) =>
  http.get<RoleUserItemType[]>(`${PORT1}/system/role/getUserListByRole?roleId=${params.roleId}`, {});

/**
 * @description: 新增角色接口
 */
export const addRoleInfoPort = (params: ReqParams) => http.post(`${PORT1}/system/role/addAppRole`, params);

/**
 * @description: 更新角色下的用户
 */
export const updateRoleUserListPort = (params: ReqParams) => http.post(`${PORT1}/system/role/modifyRoleUserList`, params);

/**
 * @description: 编辑角色接口
 */
export const updateRoleInfoPort = (params: ReqParams) => http.post(`${PORT1}/system/role/updateAppRole`, params);

/**
 * @description: 删除角色接口
 */
export const deleteRoleInfoPort = (params: ReqParams) => http.post(`${PORT1}/system/role/deleteAppRole`, params);

/**
 * @description: 角色下的已选择的 权限接口
 */
export interface PermissionsItemType {
  permissionId: number;
  permissionCode: string;
  permissionName: string;
  permissionDesc: string;
  permissionParent: number;
  permissionType: number;
  childPermission: PermissionsItemType[];
}
export const getRoleAuthListPort = (params: ReqParams) =>
  http.get<PermissionsItemType>(`${PORT1}/system/role/getPermissionByRole?roleId=${params.roleId}`, {});

/**
 * @description: 获取所有权限列表
 */
export const getTotalAuthListPort = () => http.get<PermissionsItemType>(`${PORT1}/system/role/getAllPermission`, {});

/**
 * @description: 获取当前用户的权限列表
 */
export const getUserAuthListPort = () => http.get<PermissionsItemType>(`${PORT1}/system/role/getCurrentUserPermission`, {});

/**
 * @description: 访问记录页面 table列表
 */
export interface AccessRecordItemType {
  deptName: string; // 部门
  empId: string; // 员工编号
  empName: string; // 姓名
  modelName: string; // 访问板块名称
  positionName: string; // 岗位
  reportName: string; // 访问报表名称
  viewTime: string; // 访问时间
}
export const getAccessRecordListPort = (params: ReqParams) =>
  http.post<AccessRecordItemType[]>(`${PORT1}/requestRecord/list`, params, { noLoading: true });

/**
 *  @description: 访问记录页面 export数据
 */
export const exportAccessRecordPort = (params: ReqParams) => http.download(`${PORT1}/requestRecord/export`, params);

/**
 *  @description: BI报表管理 -- 分页查询bi报表配置
 */
export interface ReportConfigItemType {
  deleteYn: boolean; // 删除标识
  department: string; // 部门
  id: number; // 主键
  reportName: string; // 报表名称
  reportUrl: string; // 报表地址
  type: string; // 报表类型
}
export const getReportConfigListPort = (params: ReqParams) =>
  http.get<ReportConfigItemType[]>(`${PORT1}/reportConfig/getList`, params, { noLoading: true });

/**
 *  @description: BI报表管理 -- 添加bi报表配置
 */
export const addReportConfigPort = (params: ReqParams) => http.post(`${PORT1}/reportConfig/add`, params, { noLoading: true });

/**
 *  @description: BI报表管理 -- 编辑bi报表配置
 */
export const editReportConfigPort = (params: ReqParams) => http.post(`${PORT1}/reportConfig/edit`, params, { noLoading: true });

/**
 *  @description: BI报表管理 -- 删除bi报表配置
 */
export const deleteReportConfigPort = (params: ReqParams) =>
  http.post(`${PORT1}/reportConfig/delete/${params.id}`, {}, { noLoading: true });

/**
 *  @description: BI报表管理 -- 根据部门获取报表下拉选项
 */
export interface ReportConfigModelItemType {
  reportName: string;
  reportUrl: string;
}
export interface ReportConfigByDepartmentItemType {
  typeName: string;
  reportConfigModelList: Array<ReportConfigModelItemType>;
}
export const getReportConfigByDepartmentPort = (params: ReqParams) =>
  http.get<ReportConfigByDepartmentItemType[]>(`${PORT1}/reportConfig/getByDepartment`, params, { noLoading: true });
