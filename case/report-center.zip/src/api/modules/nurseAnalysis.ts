import { ReqParams } from '@/api/interface';
import { PORT1 } from '@/api/config/servicePort';
import http from '@/api';

/**
 *  护理分析 模块
 */

/**
 *  疗程上市时间 数据
 */
export interface TreatmentPublishTimeItemType {
  count: number; // 数量
  statYear: string; // 统计年
}
export const getTreatmentPublishTimePort = () =>
  http.post<TreatmentPublishTimeItemType[]>(`${PORT1}/nursingAnalyse/treatmentPublishTime`, {});

/**
 *  护理SKU分布 数据
 */
export type NursingCategorySkuItemType = {
  independent: number; // 独立
  itemName: string; // 名目
  overlay: number; // 叠加
};
export interface DistributionOfNursingCategorySkuType {
  crossing: { [key: string]: number | string }[]; // 分类交叉
  nursingPosition: NursingCategorySkuItemType[]; // 部位分类
  nursingEffect: NursingCategorySkuItemType[]; // 功效分类
}
export const getDistributionOfNursingCategorySkuPort = () =>
  http.post<DistributionOfNursingCategorySkuType>(`${PORT1}/nursingAnalyse/distributionOfNursingCategorySku`, {});

/**
 *  护理SKU分布 --导出功效分类table数据
 */
export const exportEffectSkuTableDataPort = () =>
  http.download(`${PORT1}/nursingAnalyse/exportDistributionOfNursingCategorySkuForNursingEffect`, {});

/**
 *  护理SKU分布 --导出部位分类table数据
 */
export const exportPartSkuTableDataPort = () =>
  http.download(`${PORT1}/nursingAnalyse/exportDistributionOfNursingCategorySkuForNursingPosition`, {});

/**
 *  护理SKU分布 -- sku交叉护理类别table数据
 */
export const exportCrossSkuTableDataPort = () =>
  http.download(`${PORT1}/nursingAnalyse/exportDistributionOfNursingCategorySkuForCrossing`, {});

/**
 * 护理价格带 功效
 */
export type NursingRangeItemType = {
  [key: string]: string | number;
};
export type NursingPriceRangeType = {
  anotherOneRange: NursingRangeItemType[];
  nursingPriceRange: NursingRangeItemType[];
};
export const getNursingPriceRangeForEffectPort = (params: ReqParams) =>
  http.post<NursingPriceRangeType>(`${PORT1}/nursingAnalyse/nursingPriceRangeForEffect`, params, { noLoading: true });
/**
 * 护理价格带 部位
 */
export const getNursingPriceRangeForPositionPort = (params: ReqParams) =>
  http.post<NursingPriceRangeType>(`${PORT1}/nursingAnalyse/nursingPriceRangeForPosition`, params, { noLoading: true });

/**
 * 护理销售类别结构  分类table数据
 */
export type NursingSalesStructureItemType = {
  classification: string; // 分类
  grossProfit: number; // 毛利额
  grossProfitRatio: number; // 综合毛利率
  grossProfitStructure: number; // 毛利贡献
  salesAmount: number; // 销售收入
  salesStructure: number; // 销售结构
};
export type NursingSalesStructureType = {
  nursingSalesStructureItemVOS: NursingSalesStructureItemType[];
};
export const getNursingSalesStructurePort = (params: ReqParams) =>
  http.post<NursingSalesStructureType>(`${PORT1}/nursingAnalyse/nursingSalesStructure`, params);

/**
 * 护理上下市决策 帕累托及矩阵相关数据
 */
export type NursingSalesAnalyseItemType = {
  grossMargin: number; // 毛利率
  hourlyGrossProfit: number; // 小时毛利
  serviceName: string; // 护理服务名称
  cumulative: number; // 销售权重
  grossAmount: number; // 毛利额
  salesAmount: number; // 销售额
  salesCount: number; // 销售数量
};
export const getNursingSalesAnalysePort = (params: ReqParams) =>
  http.post<NursingSalesAnalyseItemType[]>(`${PORT1}/nursingAnalyse/nursingSalesAnalyse`, params, { noLoading: true });

/*** 护理上下市决策 - 小时毛利*/
export const getNursingSalesHourlyGrossProfitPort = (params: ReqParams) =>
  http.post<NursingSalesAnalyseItemType[]>(`${PORT1}/nursingAnalyse/nursingSalesHourlyGrossProfit`, params);
