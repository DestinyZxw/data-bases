import { ReqParams, RoleItem } from '@/api/interface';
import { PORT1 } from '@/api/config/servicePort';
import http from '@/api';

/**
 *  美容师专属 模块
 */

/**
 *  熟客明细表页面 table 数据
 */
export type RegularGuestTableItemType = {
  beauticianName: string;
  beauticianShopName: string;
  empCode: string;
  id: number;
  joinMemberDate: string;
  memberCode: string;
  memberName: number;
  productPerformance: string;
  shopName: string;
};
export const getRegularGuestTablePort = (params: ReqParams) =>
  http.post<RegularGuestTableItemType[]>(
    `${PORT1}/beauticianOldCustomerExclusiveInfo/getBeauticianExclusivePatronsHereInfoVOPage`,
    params,
    { noLoading: true }
  );

/**
 *  熟客明细表页面 export 数据
 */
export const exportRegularGuestTablePort = (params: ReqParams) =>
  http.download(`${PORT1}/beauticianOldCustomerExclusiveInfo/exportOldCustomerExclusiveInfoVO`, params);

/**
 *  熟客明细表页面 table 数据
 */
export type RegularGuestPerformanceItemType = {
  beauticianName: string;
  empId: string;
  memberCode: string;
  memberName: string;
  productCommission: number;
  saleDate: string;
  saleOrderCode: string;
  saleShop: string;
};
export const getRegularGuestPerformanceTablePort = (params: ReqParams) =>
  http.post<RegularGuestPerformanceItemType[]>(`${PORT1}/beauticianOnly/findPageBeauticianRegularCustomer`, params, {
    noLoading: true
  });

/**
 *  熟客明细表页面 export 数据
 */
export const exportRegularGuestPerformanceTablePort = (params: ReqParams) =>
  http.download(`${PORT1}/beauticianOnly/exportBeauticianRegularCustomerExcel`, params);

/**
 *  专属管理人数统计表页面 table 数据
 */

/*export interface ExclusiveManageTableType extends BaseTableType {
  data: RoleItem[];
}*/
export const getExclusiveManageTablePort = (params: ReqParams) =>
  http.post<RoleItem[]>(`${PORT1}/beauticianExclusiveManagementCount/findPageBeauticianExclusiveManagementCount`, params, {
    noLoading: true
  });

/**
 *  专属管理人数统计表页面 export 数据
 */
export const exportExclusiveManageTablePort = (params: ReqParams) =>
  http.download(`${PORT1}/beauticianExclusiveManagementCount/exportBeauticianExclusiveManagementCountExcel`, params);

/**
 *  专属业绩明细表页面 table 数据
 */
export type ExclusivePerformanceTableItemType = Omit<RegularGuestPerformanceItemType, 'saleShop'> & {
  cardCommission: number;
  shopName: string;
};
export const getExclusivePerformanceTablePort = (params: ReqParams) =>
  http.post<ExclusivePerformanceTableItemType[]>(
    `${PORT1}/beauticianExclusiveCommission/findPageBeauticianExclusiveCommission`,
    params,
    { noLoading: true }
  );

/**
 *  专属业绩明细表页面 export 数据
 */
export const exportExclusivePerformanceTablePort = (params: ReqParams) =>
  http.download(`${PORT1}/beauticianExclusiveCommission/exportBeauticianExclusiveCommission`, params);

/**
 *  初级美容师学员 买卡信息  table数据
 */
export type JuniorBeauticianTableItemType = {
  beauticianName: string; // 美容师姓名
  count: number; // 数量
  itemCode: string; // 项目编号
  itemName: string; // 项目名称
  memberCode: string; // 顾客号
  memberName: string; // 顾客姓名
  netAmount: number; // 实付额
  payMethod: string; // 支付方式
  purchaseType: string; // 购买类型
  saleDate: string; // 销售日期
  saleOrderCode: string; // 销售单号
  shopName: string; // 门店
  unitPrice: number; // 单价
};
export const getJuniorBeauticianBuyCardTablePort = (params: ReqParams) =>
  http.post<JuniorBeauticianTableItemType[]>(`${PORT1}/traineeBeauticianCommission/buyCardInfo`, params, { noLoading: true });

/**
 *  初级美容师学员 全套面部护理明细  table数据
 */
export const getJuniorBeauticianFaceTreatmentTablePort = (params: ReqParams) =>
  http.post<JuniorBeauticianTableItemType[]>(`${PORT1}/traineeBeauticianCommission/buyFaceTreatmentInfo`, params, {
    noLoading: true
  });

/**
 *  初级美容师学员 叠加护理明细  table数据
 */
export const getJuniorBeauticianOverlayTreatmentTablePort = (params: ReqParams) =>
  http.post<JuniorBeauticianTableItemType[]>(`${PORT1}/traineeBeauticianCommission/buyOverlayTreatmentInfo`, params, {
    noLoading: true
  });

/**
 *  初级美容师学员 买卡信息 export 数据
 */
export const exportJuniorBeauticianBuyCardTablePort = (params: ReqParams) =>
  http.download(`${PORT1}/traineeBeauticianCommission/exportBuyCardInfo`, params);

/**
 *  初级美容师学员 全套面部护理明细 export 数据
 */
export const exportJuniorBeauticianFaceTreatmentTablePort = (params: ReqParams) =>
  http.download(`${PORT1}/traineeBeauticianCommission/exportBuyFaceTreatmentInfo`, params);

/**
 *  初级美容师学员 买卡信息 export 数据
 */
export const exportJuniorBeauticianOverlayTreatmentTablePort = (params: ReqParams) =>
  http.download(`${PORT1}/traineeBeauticianCommission/exportBuyOverlayTreatmentInfo`, params);

/**
 *  美容师医美现金业绩  table数据
 */
export type BeauticianYmCashTableItemType = {
  empCode: string; // 员工号
  empName: string; // 员工姓名
  shopName: string; // 门店
  positionName: string; // 职位
  memberCode: string; // r6顾客号
  memberName: string; // r6顾客姓名
  exclusiveType: string; // 专属类型
  medicalBeautyClinic: string; // 医美诊所
  medicalBeautyMemberCode: string; // 医美顾客号
  medicalBeautyMemberName: string; // 医美顾客姓名
  medicalBeautyOrderNo: string; // 医美订单号
  orderTime: string; // 开单日期
  paymentOrderNo: number; // 收款/退款单号
  paymentTime: number; // 收款/退款日期
  amount: number; // 收款/退款金额
};
export const fetchBeauticianYmCashTablePort = (params: ReqParams) =>
  http.post<BeauticianYmCashTableItemType[]>(`${PORT1}/medicalBeautyCommission/medicalBeautyBeauticianCash`, params, {
    noLoading: true
  });

/**
 *  美容师医美现金业绩 export 数据
 */
export const exportBeauticianYmCashTablePort = (params: ReqParams) =>
  http.download(`${PORT1}/medicalBeautyCommission/medicalBeautyBeauticianCash/export`, params);
