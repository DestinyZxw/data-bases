import { Login, ReqParams } from '@/api/interface';
import { PORT1 } from '@/api/config/servicePort';
// import authMenuList from '@/assets/json/authMenuList.json';
// import authButtonList from '@/assets/json/authButtonList.json';
import http from '@/api';

/**
 *  登录模块
 */
// 用户登录

export const loginApi = (params: Login.ReqLoginForm) => {
  return http.post<Login.ResLogin>(PORT1 + '/login', params, { noLoading: true }); // 正常 post json 请求  ==>  application/json
  // return http.post<Login.ResLogin>(PORT1 + `/login`, params, { noLoading: true }); // 控制当前请求不显示 loading
  // return http.post<Login.ResLogin>(PORT1 + `/login`, {}, { params }); // post 请求携带 query 参数  ==>  ?username=admin&password=123456
  // return http.post<Login.ResLogin>(PORT1 + `/login`, qs.stringify(params)); // post 请求携带表单参数  ==>  application/x-www-form-urlencoded
  // return http.get<Login.ResLogin>(PORT1 + `/login?${qs.stringify(params, { arrayFormat: "repeat" })}`); // get 请求可以携带数组等复杂参数
};

// 用户户退出登录
export const logoutApi = () => {
  return http.post(PORT1 + '/logout');
};

export const loginPort = (params: ReqParams) => http.post<string>(`${PORT1}/login?code=${params.code}`, {}, { noLoading: true });

// 获取用户信息
export interface UserInfoType {
  appCode: string;
  appName: string;
  userNo: string;
  userName: string;
  userNameEn: string | null;
  nickName: string | null;
  email: string | null;
  avatar: string | null;
}
export const getUserInfoPort = () => http.post<UserInfoType>(`${PORT1}/login/getUserInfo`, {}, { noLoading: true });

export const wxLoginPort = (params: ReqParams) =>
  http.post<string>(`${PORT1}/login/workwxLogin?code=${params.code}`, {}, { noLoading: true });
