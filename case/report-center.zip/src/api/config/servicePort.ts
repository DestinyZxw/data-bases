// 后端微服务端口名
export const PORT1: string = '/datahouse/v1';
export const PORT2: string = '/data-transfer/v1/';
