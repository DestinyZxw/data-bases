<!-- 分栏布局 -->
<template>
  <el-container class="layout">
    <!--  侧边栏  -->
    <div class="el-aside-container" v-show="!maximize">
      <div class="el-aside__left">
        <div class="logo flx-center">
          <img class="logo-img" src="@/assets/images/logo.png" alt="logo" />
        </div>
        <el-scrollbar>
          <div class="split-list">
            <div
              class="split-item"
              :class="{ 'split-active': splitActive === item.path || `/${splitActive.split('/')[1]}` === item.path }"
              v-for="item in menuList"
              :key="item.path"
              @click="changeSubMenu(item)"
            >
              <el-icon>
                <component :is="item.meta.icon"></component>
              </el-icon>
              <span class="title">{{ item.meta.title }}</span>
            </div>
          </div>
        </el-scrollbar>
      </div>

      <div class="el-aside__right" :class="{ 'is-collapse': !subMenuList.length || isCollapse }">
        <div class="logo flx-center">
          <span class="logo-text">报表中心</span>
        </div>
        <el-scrollbar>
          <el-menu
            :default-active="activeMenu"
            :router="false"
            :collapse="isCollapse"
            :collapse-transition="false"
            :unique-opened="accordion"
          >
            <SubMenu :menuList="subMenuList" />
          </el-menu>
        </el-scrollbar>
      </div>
    </div>

    <!--  主区域  -->
    <el-container>
      <el-header>
        <ToolBarLeft />
        <ToolBarRight />
      </el-header>
      <Main />
    </el-container>
  </el-container>
</template>

<script setup lang="ts" name="layoutColumns">
import { useAuthStore } from '@/stores/modules/auth';
import { useGlobalStore } from '@/stores/modules/global';
import Main from '@/layouts/components/Main/index.vue';
import ToolBarLeft from '@/layouts/components/Header/ToolBarLeft.vue';
import ToolBarRight from '@/layouts/components/Header/ToolBarRight.vue';
import SubMenu from '@/layouts/components/Menu/SubMenu.vue';
import { filterPermissionsKey } from '@/utils';
import { Menu } from '@/typings/global';

const route = useRoute();
const router = useRouter();
const authStore = useAuthStore();
const globalStore = useGlobalStore();
const { isCollapse, maximize, accordion } = storeToRefs(globalStore);
const menuList = computed(() => authStore.showMenuListGet);
const activeMenu = computed(() => (route.meta.activeMenu ? route.meta.activeMenu : route.path) as string);

const subMenuList = ref<Menu.MenuOptions[]>([]);
const splitActive = ref('');

watch(
  () => [menuList, route],
  () => {
    // 当前菜单没有数据直接 return
    if (!menuList.value.length) return;
    splitActive.value = route.path;
    const menuItem = menuList.value.filter((item: Menu.MenuOptions) => {
      return route.path === item.path || `/${route.path.split('/')[1]}` === item.path;
    });
    if (menuItem[0].children?.length) return (subMenuList.value = menuItem[0].children);
    subMenuList.value = [];
  },
  {
    deep: true,
    immediate: true
  }
);

// change SubMenu
const changeSubMenu = (item: Menu.MenuOptions) => {
  splitActive.value = item.path;
  if (item.children?.length) {
    subMenuList.value = item.children;
    isCollapse.value && globalStore.setGlobalState('isCollapse', false);
    const [firstPath] = filterPermissionsKey<Menu.MenuOptions, 'children', 'path'>({
      target: item,
      children: 'children',
      key: 'path'
    });
    // 默认跳转到当前菜单的第一项
    router.push(firstPath);
    return;
  }
  subMenuList.value = [];
  router.push(item.path);
};
</script>

<style scoped lang="scss">
@import './index.scss';
</style>
