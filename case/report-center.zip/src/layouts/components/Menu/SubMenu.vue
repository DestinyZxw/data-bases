<template>
  <template v-for="subItem in menuList" :key="subItem.path">
    <el-sub-menu v-if="subItem.children?.length" :index="subItem.path">
      <template #title>
        <el-icon>
          <component :is="subItem.meta.icon"></component>
        </el-icon>
        <span class="sle">{{ subItem.meta.title }}</span>
      </template>
      <SubMenu :menuList="subItem.children" />
    </el-sub-menu>
    <el-menu-item v-else :index="subItem.path" @click="handleClickMenu(subItem)">
      <el-icon>
        <component :is="subItem.meta.icon"></component>
      </el-icon>
      <template #title>
        <span class="sle" :title="subItem.meta.title">{{ subItem.meta.title }}</span>
      </template>
    </el-menu-item>
  </template>
</template>

<script setup lang="ts">
import { useRouter } from 'vue-router';
import { useGlobalStore } from '@/stores/modules/global';
import { Menu } from '@/typings/global';

defineProps<{ menuList: Menu.MenuOptions[] }>();

const router = useRouter();
const globalStore = useGlobalStore();
const { asidePopup, device } = storeToRefs(globalStore);

const handleClickMenu = (subItem: Menu.MenuOptions) => {
  if (subItem.meta.isLink) return window.open(subItem.meta.isLink, '_blank');
  router.push(subItem.path);

  if (device.value === 'mobile') {
    // globalStore.setGlobalState('asidePopup', false);
    asidePopup.value = false;
  }
};
</script>

<style lang="scss">
@mixin el-icon {
  .el-icon {
    margin-right: 0;
    font-size: var(--el-font-size-medium);
  }
}
.el-sub-menu {
  .el-sub-menu__title {
    @include el-icon;
    &:hover {
      color: var(--el-menu-hover-text-color) !important;
      background-color: transparent !important;
    }
  }
}
.el-menu--collapse {
  .is-active {
    .el-sub-menu__title {
      color: #ffffff !important;
      background-color: var(--el-color-primary) !important;
    }
  }
}
.el-menu-item {
  @include el-icon;
  &:hover {
    color: var(--el-menu-active-color);
    background-color: var(--el-menu-active-bg-color);
  }
  &.is-active {
    color: var(--el-menu-active-color) !important;
    background-color: var(--el-menu-active-bg-color) !important;
  }
}
.columns {
  .el-menu-item {
    --el-menu-base-level-padding: 10px;
    --el-menu-item-height: 48px;

    margin-top: 10px;
    margin-bottom: 5px;
    border-radius: 5px;
  }
}
.classic,
.transverse {
  #driver-highlighted-element-stage {
    background-color: #606266 !important;
  }
}
</style>
