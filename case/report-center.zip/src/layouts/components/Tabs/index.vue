<template>
  <div class="tabs">
    <el-tabs
      :class="['tabs-content', `tabs-content-${tabsBarStyle}`]"
      v-model="tabsMenuValue"
      type="card"
      @tab-click="tabClick"
      @tab-remove="tabRemove"
    >
      <el-tab-pane v-for="item in tabsMenuList" :key="item.path" :label="item.title" :name="item.path" :closable="item.close">
        <template #label>
          <span class="inline-flex items-center" @contextmenu.prevent="openMenu">
            <el-icon class="tabs-icon" v-show="item.icon && tabsIcon">
              <component :is="item.icon"></component>
            </el-icon>
            {{ item.title }}
          </span>
        </template>
      </el-tab-pane>
    </el-tabs>

    <el-dropdown
      popper-class="tabs-more-dropdown"
      placement="bottom-end"
      :trigger="isMobile ? 'click' : 'hover'"
      @command="handleCommand"
      @visible-change="handleVisibleChange"
    >
      <span class="tabs-more" :class="{ 'tabs-more-active': dropdownActive }">
        <span class="tabs-more-icon">
          <i class="box box-t"></i>
          <i class="box box-b"></i>
        </span>
      </span>
      <template #dropdown>
        <el-dropdown-menu class="tabs-more">
          <el-dropdown-item command="refreshThisTab">
            <el-icon><Refresh /></el-icon>{{ $t('tabs.refresh') }}
          </el-dropdown-item>
          <el-dropdown-item command="maximize">
            <el-icon>
              <ZoomIn v-if="!maximizeStatus" />
              <ZoomOut v-else />
            </el-icon>
            {{ maximizeStatus ? $t('tabs.recover') : $t('tabs.maximize') }}
          </el-dropdown-item>
          <el-dropdown-item divided command="closeOtherTabs">
            <el-icon><CloseBold /></el-icon>{{ $t('tabs.closeOther') }}
          </el-dropdown-item>
          <el-dropdown-item command="closeLeftTabs">
            <el-icon><Back /></el-icon><span>关闭左侧</span>
          </el-dropdown-item>
          <el-dropdown-item command="closeRightTabs">
            <el-icon><Right /></el-icon><span>关闭右侧</span>
          </el-dropdown-item>
          <el-dropdown-item command="closeAllTabs">
            <el-icon><FolderDelete /></el-icon>{{ $t('tabs.closeAll') }}
          </el-dropdown-item>
        </el-dropdown-menu>
      </template>
    </el-dropdown>

    <ul v-if="visible" class="contextmenu el-dropdown-menu" :style="{ left: `${left}px`, top: `${top}px` }">
      <li class="el-dropdown-menu__item" @click="refreshThisTab">
        <el-icon><Refresh /></el-icon>{{ $t('tabs.refresh') }}
      </li>
      <li class="el-dropdown-menu__item" @click="maximize">
        <el-icon>
          <ZoomIn v-if="!maximizeStatus" />
          <ZoomOut v-else />
        </el-icon>
        {{ maximizeStatus ? $t('tabs.recover') : $t('tabs.maximize') }}
      </li>
      <li role="separator" class="el-dropdown-menu__item--divided"></li>
      <li class="el-dropdown-menu__item" @click="closeOtherTabs">
        <el-icon><CloseBold /></el-icon>{{ $t('tabs.closeOther') }}
      </li>
      <li class="el-dropdown-menu__item" @click="closeLeftTabs">
        <el-icon><Back /></el-icon><span>关闭左侧</span>
      </li>
      <li class="el-dropdown-menu__item" @click="closeRightTabs">
        <el-icon><Right /></el-icon><span>关闭右侧</span>
      </li>
      <li class="el-dropdown-menu__item" @click="closeAllTabs">
        <el-icon><FolderDelete /></el-icon>{{ $t('tabs.closeAll') }}
      </li>
    </ul>
  </div>
</template>

<script setup lang="ts">
import Sortable from 'sortablejs';
import { useRoute, useRouter } from 'vue-router';
import { useGlobalStore } from '@/stores/modules/global';
import { useTabsStore } from '@/stores/modules/tabs';
import { useAuthStore } from '@/stores/modules/auth';
import { useKeepAliveStore } from '@/stores/modules/keepAlive';
import { TabsPaneContext, TabPaneName } from 'element-plus';
import { HOME_URL } from '@/config';
import { useMouse } from '@vueuse/core';
import { TabsMenuProps } from '@/stores/interface';
import * as config from '@/config';

const route = useRoute();
const router = useRouter();
const tabStore = useTabsStore();
const authStore = useAuthStore();
const globalStore = useGlobalStore();
const keepAliveStore = useKeepAliveStore();

const tabsMenuValue = ref(route.fullPath);
const tabsMenuList = computed(() => tabStore.tabsMenuList);
const { tabsIcon, device, tabsBarStyle, maximize: maximizeStatus, version } = storeToRefs(globalStore);
const isMobile = computed(() => device.value === 'mobile');

const dropdownActive = ref(false); // dropdown 展开状态

const visible = ref(false);
const top = ref(0);
const left = ref(0);

onMounted(() => {
  !isMobile && tabsDrop();
  initTabs();
});

// 监听路由的变化（防止浏览器后退/前进不变化 tabsMenuValue）
watch(
  () => route.fullPath,
  () => {
    if (route.meta.isFull) return;
    tabsMenuValue.value = route.fullPath.includes(HOME_URL) ? HOME_URL : route.fullPath;
    const title = (route.meta.title as string) || (route.params.name as string);
    const tabsParams = {
      icon: route.meta.icon as string,
      title,
      path: route.fullPath,
      name: route.name as string,
      close: !route.meta.isAffix,
      isKeepAlive: route.meta.isKeepAlive as boolean
    };
    tabStore.addTabs(tabsParams);
    route.meta.isKeepAlive && keepAliveStore.addKeepAliveName(route.name as string);
  },
  { immediate: true }
);

// 监听版本号的改动
nextTick(() => {
  console.log('version : ', version.value);
  console.log('config.VERSION : ', config.VERSION);
  if (version.value === config.VERSION) return;
  console.log('版本号不一致，重新加载');
  version.value = config.VERSION;
  closeAllTabs();
});

// tabs 拖拽排序
const tabsDrop = () => {
  Sortable.create(document.querySelector('.el-tabs__nav') as HTMLElement, {
    draggable: '.el-tabs__item',
    animation: 300,
    onEnd({ newIndex, oldIndex }) {
      const tabsList = [...tabStore.tabsMenuList];
      const currRow = tabsList.splice(oldIndex as number, 1)[0];
      tabsList.splice(newIndex as number, 0, currRow);
      tabStore.setTabs(tabsList);
    }
  });
};

// 初始化需要固定的 tabs
const initTabs = () => {
  authStore.flatMenuListGet.forEach(item => {
    if (item.meta.isAffix && !item.meta.isHide && !item.meta.isFull) {
      const tabsParams = {
        icon: item.meta.icon,
        title: item.meta.title,
        path: item.path,
        name: item.name,
        close: !item.meta.isAffix,
        isKeepAlive: item.meta.isKeepAlive
      };
      tabStore.addTabs(tabsParams);
    }
  });
};

// Tab Click
const tabClick = (tabItem: TabsPaneContext) => {
  const fullPath = tabItem.props.name as string;
  router.push(fullPath);
};

// Remove Tab
const tabRemove = (fullPath: TabPaneName) => {
  const name = tabStore.tabsMenuList.filter(item => item.path == fullPath)[0].name || '';
  keepAliveStore.removeKeepAliveName(name);
  tabStore.removeTabs(fullPath as string, fullPath == route.fullPath);
};

const handleCommand = (command: string) => {
  const maps: { [key: string]: () => void } = {
    refreshThisTab,
    maximize,
    closeOtherTabs,
    closeLeftTabs,
    closeRightTabs,
    closeAllTabs
  };
  maps[command]();
};

// refresh current page
const refreshCurrentPage: Function = inject('refresh') as Function;
const refreshThisTab = () => {
  setTimeout(() => {
    keepAliveStore.removeKeepAliveName(route.name as string);
    refreshCurrentPage(false);
    nextTick(() => {
      keepAliveStore.addKeepAliveName(route.name as string);
      refreshCurrentPage(true);
    });
  }, 0);
};

// maximize current page
const maximize = () => {
  globalStore.setGlobalState('maximize', !globalStore.maximize);
};

// Close Other
const closeOtherTabs = () => {
  tabStore.closeMultipleTab(route.fullPath);
  keepAliveStore.setKeepAliveName([route.name] as string[]);
};

// Close left
const closeLeftTabs = () => {
  const tabsList = [...tabStore.tabsMenuList];
  const index = tabsList.findIndex(item => item.path === route.fullPath);
  const homeIndex = tabsList.findIndex(item => item.title === '首页');
  let newTabs: TabsMenuProps[] = [];
  if (homeIndex < index) {
    newTabs = tabsList.reduce((p, c, i) => {
      if (i === homeIndex || i >= index) {
        p.push(c);
      }
      return p;
    }, [] as TabsMenuProps[]);
  } else {
    newTabs = tabsList.slice(index);
  }
  tabStore.setTabs(newTabs);

  // keep alive保持同步
  const KeepAliveList = newTabs.filter(item => item.isKeepAlive);
  keepAliveStore.setKeepAliveName(KeepAliveList.map(item => item.name));
};

// Close right
const closeRightTabs = () => {
  const tabsList = [...tabStore.tabsMenuList];
  const index = tabsList.findIndex(item => item.path === route.fullPath);
  const homeIndex = tabsList.findIndex(item => item.title === '首页');
  let newTabs: TabsMenuProps[] = [];
  if (homeIndex < index) {
    newTabs = tabsList.slice(0, index + 1);
  } else {
    newTabs = tabsList.reduce((p, c, i) => {
      if (i <= index || i === homeIndex) {
        p.push(c);
      }
      return p;
    }, [] as TabsMenuProps[]);
  }
  tabStore.setTabs(newTabs);

  // keep alive保持同步
  const KeepAliveList = newTabs.filter(item => item.isKeepAlive);
  keepAliveStore.setKeepAliveName(KeepAliveList.map(item => item.name));
};

// Close All
const closeAllTabs = () => {
  tabStore.closeMultipleTab();
  keepAliveStore.setKeepAliveName();
  router.push(HOME_URL);
};

const handleVisibleChange = (val: boolean) => {
  dropdownActive.value = val;
};

const { x, y } = useMouse();
const openMenu = () => {
  left.value = x.value;
  top.value = y.value;
  visible.value = true;
};

const closeMenu = () => {
  visible.value = false;
  // hoverRoute.value = null
};

watchEffect(() => {
  if (visible.value) {
    document.body.addEventListener('click', closeMenu);
  } else {
    document.body.removeEventListener('click', closeMenu);
  }
});
</script>

<style scoped lang="scss">
@import './index.scss';
</style>
