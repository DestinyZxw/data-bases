<!-- 纵向布局 -->
<template>
  <el-container class="layout" :class="{ mobile: device === 'mobile' }">
    <div class="aside" :style="{ width: `${asideWidth}px` }">
      <div class="logo flx-center">
        <img class="logo-img" src="@/assets/images/logo.png" alt="logo" />
        <span class="logo-text" v-show="device === 'mobile' || !isCollapse">报表中心</span>
      </div>
      <el-scrollbar>
        <el-menu
          :default-active="activeMenu"
          :collapse="isCollapse"
          :router="false"
          :unique-opened="accordion"
          :collapse-transition="false"
        >
          <SubMenu :menuList="menuList" />
        </el-menu>
      </el-scrollbar>
    </div>
    <div v-if="device === 'mobile' && asidePopup" class="v-model" @click="setGlobalState('asidePopup', false)" />
    <el-container :style="{ marginLeft: `${mainContainerMarginLeft}px` }">
      <el-header>
        <ToolBarLeft />
        <ToolBarRight />
      </el-header>
      <Main />
    </el-container>
  </el-container>
</template>

<script setup lang="ts" name="layoutVertical">
import { useAuthStore } from '@/stores/modules/auth';
import { useGlobalStore } from '@/stores/modules/global';
import Main from '@/layouts/components/Main/index.vue';
import ToolBarLeft from '@/layouts/components/Header/ToolBarLeft.vue';
import ToolBarRight from '@/layouts/components/Header/ToolBarRight.vue';
import SubMenu from '@/layouts/components/Menu/SubMenu.vue';

const route = useRoute();
const authStore = useAuthStore();
const menuList = computed(() => authStore.showMenuListGet);
const activeMenu = computed(() => (route.meta.activeMenu ? route.meta.activeMenu : route.path) as string);

const globalStore = useGlobalStore();
const { isCollapse, device, asidePopup, accordion } = storeToRefs(globalStore);
const { setGlobalState } = globalStore;

const asideWidth = computed(() => {
  let width: number;
  if (device.value === 'mobile') {
    width = asidePopup.value ? 228 : 0;
  } else {
    width = isCollapse.value ? 65 : 228;
  }
  return width;
});
const mainContainerMarginLeft = computed(() => {
  return device.value === 'mobile' ? 0 : isCollapse.value ? 65 : 228;
});
</script>

<style scoped lang="scss">
@import './index.scss';
</style>
